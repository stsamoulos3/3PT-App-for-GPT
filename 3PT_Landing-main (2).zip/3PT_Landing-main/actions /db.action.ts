'use server';

import pool from '@/utils/db';

export async function getData() {
  try {
    const result = await pool.query('SELECT * FROM "user"');
    return JSON.parse(JSON.stringify(result.rows));
  } catch (err) {
    console.error('DB error:', err);
    return [];
  }
}
