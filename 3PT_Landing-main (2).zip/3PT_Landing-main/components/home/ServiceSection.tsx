/* eslint-disable @next/next/no-img-element */
"use client";
import React from "react";
import ArrowCircle from "../shared/ArrowCircle";
import { BsArrowUpRight } from "react-icons/bs";
import GridLayout from "../shared/GridLayout";
import { useRouter } from "next/navigation";

const allServiceData = [
  {
    title: "Physical Therapy",
    link: "/services?category=1",
    href: "/graphic/home/hero1.webp",
    className: "animate-fadeInRight",
  },
  {
    title: "Nutrition Counseling",
    href: "/graphic/home/hero4.webp",
    link: "/services?category=3",
    className: "animate-fadeInRight",
  },
  {
    title: "Behavioral Health",
    href: "/graphic/home/hero2.webp",
    link: "/services?category=4",
    className: "animate-fadeInLeft",
  },
  {
    title: "Multidisciplinary Weight Loss",
    href: "/graphic/home/hero3.webp",
    link: "/services?category=2",
    className: "animate-fadeInLeft",
  }
];

type allServiceItem = {
  title: string;
  href: string;
  link: string;
  className : string;
};

const ServiceSection = ({ type }: { type?: string }) => {
  const router = useRouter();
  return (
    <GridLayout
      className={` box ${
        type === "hero" ? "mt-0 grid-cols-4" : "mt-16 grid-cols-5 hidden"
      } py-4 max-md:hidden`}
    >
      <div
        className={`relative ${
          type === "hero" && "hidden"
        } h-full w-full rounded-lg group`}
      >
        {/* SVG Background */}
        <div className="relative">
          <svg
            viewBox="0 0 324 368"
            fill="currentColor"
            className="w-full  text-black group-hover:text-primary-300 transition-colors duration-300"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M322.143 30C322.143 13.4315 308.712 0 292.143 0H30C13.4315 0 0 13.4315 0 30V335.198C0 351.767 13.4315 365.198 30 365.198H170.626C187.195 365.198 200.626 351.767 200.626 335.198V275.868C200.626 259.3 214.057 245.868 230.626 245.868H292.143C308.712 245.868 322.143 232.437 322.143 215.868V30Z"
            />
          </svg>

          {/* Arrow Circle - Changes color on hover */}
          <div className="absolute bottom-0 right-0">
            <ArrowCircle
              className="bg-primary-300 max-2xl:w-[6vw] 2xl:w-24 2xl:h-24 max-2xl:h-[6vw] group-hover:bg-black transition-colors duration-300"
              icon={
                <BsArrowUpRight className="w-[2vw] h-[2vw] text-black group-hover:text-white transition-colors duration-300" />
              }
            />
          </div>

          {/* Text Content */}
          <div className="absolute top-0 flex flex-col gap-2 p-4">
            <p className="body1-semibold text-white">
              <span className="block">All our</span>
              <span>Services</span>
            </p>
            <p className="small2-regular hidden xl:block text-white">
              Experience a transformative approach to health—built just for you.
            </p>
          </div>
        </div>
      </div>

      {allServiceData.map((item: allServiceItem, index: number) => (
        <div
          onClick={() => {
            router.push(item.link);
          }}
          key={index}
          className={` group flex ${item.className }  cursor-pointer flex-col gap-2 rounded-lg `}
        >
          <div className="w-full relative ">
            <img
              className="w-full h-full object-cover rounded-[44px]"
              alt="Graphic"
              src={item?.href}
            />
            <div
              className="absolute top-0 w-full h-full rounded-[44px] transition-opacity duration-300 opacity-0 group-hover:opacity-100"
              style={{
                background:
                  "linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.75) 100%)",
              }}
            />
          </div>
          <p className="small2-bold group-hover:text-secondary-200">
            {item.title}
          </p>
        </div>
      ))}
    </GridLayout>
  );
};

export default ServiceSection;
