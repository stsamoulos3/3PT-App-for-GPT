/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable @next/next/no-img-element */
"use client";
import React from "react";
import Button from "../shared/Button";
import Logo from "../shared/Logo";
import { useRouter } from "next/navigation";
import Carousel from "../shared/Carousel";
import Link from "next/link";
import ServiceSection from "./ServiceSection";

// const heroServiceData = [
//   {
//     imgLink: "/graphic/home/hero1.webp",
//     title: "Physical Therapy",
//     className: "top-0 translate-x-0 left-2 -rotate-10",
//     offsetX: "600px",
//     offsetY: "400px",
//     href: "/services?category=1",
//   },
//   {
//     imgLink: "/graphic/home/hero2.webp",
//     title: "Behavioral Health",
//     className: "bottom-0 left-2 -rotate-10",
//     offsetX: "600px",
//     offsetY: "-100px",
//     href: "/services?category=4",
//   },
//   {
//     imgLink: "/graphic/home/hero3.webp",
//     title: "Weight Loss & Wellbeing ",
//     className: "right-2 top-0  rotate-10",
//     offsetX: "-600px",
//     offsetY: "400px",
//     href: "/services?category=2",
//   },
//   {
//     imgLink: "/graphic/home/hero4.webp",
//     title: "Nutritional Counseling",
//     className: "bottom-0 right-2 rotate-10",
//     offsetX: "-600px",
//     offsetY: "-100px",
//     href: "/services?category=3",
//   },
// ];

const HeroSection = () => {
  const router = useRouter();
  return (
    <>
      <section className="w-full  max-md:hidden md:mt-4  box flex items-center gap-3 justify-center text-center relative">
        {/* <div className="">
          {heroServiceData.map((item) => (
            <div
              onClick={() => router.push(item.href)}
              style={{
                // @ts-expect-error get unwanted error
                "--x-offset": item.offsetX,
                "--y-offset": item.offsetY,
              }}
              key={item.title}
              className={`absolute   group animate-fadeOut box    box ${item.className}`}
            >
              <Button
                className="flex flex-col  items-center"
                onClick={() => router.push("/services?category=1")}
              >
                <img
                  className="  group-hover:shadow-xl w-20 lg:w-[7rem]"
                  alt="graphic1"
                  src={item.imgLink}
                />
                <p className="text-xs whitespace-pre-line max-lg:w-28 group-hover:bg-primary-200 text-center font-bold py-1 px-4 shadow-2xl  rounded-full mt-1">
                  {item.title}
                </p>
              </Button>
            </div>
          ))}
        </div> */}
        {/* Main Content */}
        <div className="flex flex-col items-center max-w-7xl justify-center space-y-4">
          <div className="flex flex-col gap-0 items-center justify-center">
            <img
              alt="logo"
              src="/3PT Logo - 3PT Only.png"
              className="h-10 animate-fadeInDown lg:h-[3rem]"
            />
            <h1 className="text-black animate-fadeInDown small2-regular-marcellus">
              Physical Therapy - Behavioral Health - Nutritional Counseling
            </h1>
          </div>
          <div className="   animate-fadeInDown">
            <p className="text-black h4-semibold">Transforming Recovery</p>
            <p className="text-black h4-semibold">Elevating Healthcare</p>
          </div>

          <div className="w-[70%] h-[2px]  bg-black" />
          <ServiceSection type="hero" />
          <div className="w-[70%] h-[2px]  bg-black" />

          <p className="body2-regular max-xl:w-[80%] animate-fadeInUp text-black">
            Experience the <Logo /> difference and start your journey toward a
            healthier, more active life! Schedule an evaluation or free injury
            screening today - either in-office or telehealth!
          </p>
          <Button
            onClick={() => {
              router.push("/schedule-appointment");
            }}
            className="px-16 py-3 transition-transform hover:shadow-[0_4px_12px_rgba(0,0,0,0.3)] animate-fadeInUp animate-fadeInDown duration-300 ease-in-out hover:scale-110 hover:bg-gradient-to-r hover:from-primary-300 hover:via-primary-400 hover:to-primary-300 text-white bg-gradient-to-r from-primary-400 via-primary-300 to-primary-400 rounded-full small2-bold"
          >
            BOOK NOW
          </Button>
        </div>
      </section>
      <section className="md:hidden">
        <div className="flex flex-col items-center justify-center space-y-2">
          <Link
            href="/"
            className="h4-bold animate-fadeInDown font-bold text-blue-600"
          >
            {/* <Logo type="logo" /> */}
            <img src="/logo.png" alt="Logo" className=" h-10" />
          </Link>
          <h1 className="text-black animate-fadeInDown small4-regular-marcellus">
            Physical Therapy - Behavioral Health - Nutritional Counseling
          </h1>
        </div>
        <Carousel />
        <p className="small3-regular mt-8 animate-fadeInUp text-black">
          Experience the <Logo /> difference and start your journey toward a
          healthier, more active life! Schedule an evaluation or free injury
          screening today - either in-office or telehealth!
        </p>
      </section>
    </>
  );
};

export default HeroSection;
