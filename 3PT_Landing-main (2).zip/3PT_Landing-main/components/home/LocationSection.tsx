"use client";
import React, { useState } from "react";
import GridLayout from "../shared/GridLayout";
import Button from "../shared/Button";
import { LuMapPin } from "react-icons/lu";


const defaultMapHref ="https://www.google.com/maps/d/embed?mid=1NOeqFSmm-cTNGmVrJTUgJbqzO0eSNfw&ehbc=2E312F&noprof=1";



const locationData = [
  {
    title: "GLEN ELLYN",
    address1: "918 Roosevelt Rd.",
    address2: "Glen Ellyn, IL 60137",
    href: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2971.493312823573!2d-88.0508759240727!3d41.86073166650165!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880e52545469c883%3A0x94de4e07546bc096!2s918%20Roosevelt%20Rd%2C%20Glen%20Ellyn%2C%20IL%2060137%2C%20USA!5e0!3m2!1sen!2sin!4v1742994763275!5m2!1sen!2sin",
    phone: "P: 630.576.0378",
  },
  {
    title: "MOKENA",
    address1: "19805 S. LaGrange Rd",
    address2 : "Mokena, IL 60448",
    href: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2986.7509869784535!2d-87.85214952408842!3d41.531334287054364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880e14d1fd0f9fa7%3A0x4d5b3ed9e55aa2a8!2s19805%20LaGrange%20Rd%2C%20Mokena%2C%20IL%2060448%2C%20USA!5e0!3m2!1sen!2sin!4v1742994859618!5m2!1sen!2sin",
    phone: "P: 708.938.3378",
  },
  {
    title: "ELMHURST",
    address1 : "624 N. York St. Unit C",
    address2 : "Elmhurst, IL 60126",
    href: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2968.798869859732!2d-87.94287182406994!3d41.91868226287244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fb35dad400001%3A0xc57b39722b3987db!2s624%20N%20York%20St%20Unit%20C%2C%20Elmhurst%2C%20IL%2060126%2C%20USA!5e0!3m2!1sen!2sin!4v1742994917870!5m2!1sen!2sin",
    phone: "P: 630.410.1378",
  },
  {
    title: "OAK LAWN",
    address1 : "4817 W. 95th St.",
    address2 : "Oak Lawn, IL 60453",
    href: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2978.0306538343266!2d-87.74417162407944!3d41.71985737530716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880e3a60c894c26f%3A0x6cad54ae9c1db4de!2s4817%20W%2095th%20St%2C%20Oak%20Lawn%2C%20IL%2060453%2C%20USA!5e0!3m2!1sen!2sin!4v1742994962257!5m2!1sen!2sin",
    phone: "P: 708.598.7880",
  },
  {
    title: "LAGRANGE",
    address1 : "1415 W. 47 St.",
    address2 : "La Grange, IL 60525",
    href: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2974.0841796787245!2d-87.89066372407538!3d41.80494696999144!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880e49996a0b4f3f%3A0x5a60c0b672c6254c!2s1415%20W%2047th%20St%2C%20La%20Grange%2C%20IL%2060525%2C%20USA!5e0!3m2!1sen!2sin!4v1742995007745!5m2!1sen!2sin",
    phone: "P: 708.294.2229",
  },
  {
    title: "JOLIET",
    address1 : "1695 Plainfield Rd.",
    address2 : "Crest Hill, IL 60403",
    href: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2985.703613671039!2d-88.12770982408736!3d41.554014185643425!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880e60f99a24c295%3A0x1b0ecee665308113!2s1695%20Plainfield%20Rd%2C%20Crest%20Hill%2C%20IL%2060403%2C%20USA!5e0!3m2!1sen!2sin!4v1742995101216!5m2!1sen!2sin",
    phone: "P: 815.255.3784",
  },
  {
    title: "MELROSE PARK",
    address1 : "2225 W. North Ave",
    address2 : "Melrose Park, IL 60160",
    href: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2969.279046846101!2d-87.86352472407047!3d41.90835966351927!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fb55094248425%3A0x49b40a6e8e4ddddd!2sNorthPark%20Medical%20Group!5e0!3m2!1sen!2sin!4v1742995165124!5m2!1sen!2sin",
    phone: "P: 708.719.9309",
  },
  {
    title: "BOURBONNAIS",
    address1 : "1511 N. Convent St.Suite 1000",
    address2 : "Bourbonnais, IL 60914",
    href: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3002.928617588526!2d-87.8787023241051!3d41.1797241088507!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880ddddfee40cfdf%3A0xae81a6adc516fce4!2sThe%20UPS%20Store!5e0!3m2!1sen!2sin!4v1742995211893!5m2!1sen!2sin",
    phone: "P: 708.274.2402",
  },
];


const LocationSection: React.FC = () => {
  const [selectedLocation, setSelectedLocation] = useState<null | typeof locationData[0]>(null);

  const mapSrc = selectedLocation ? selectedLocation.href : defaultMapHref;

  return (
    <GridLayout  className="md:grid-cols-2 md:gap-8  box">
      <div className="flex flex-1 flex-col gap-4">
        <h2 className="h2-semibold font-bold">
          <span>Our</span>
          <span className="text-primary-300 ml-2">Clinics</span>
        </h2>
        <iframe
        
        title="Embedded Google Map"
          key={mapSrc}
          src={mapSrc}
          className="w-full md:h-full h-[24rem] border-primary-300 border-2 rounded-xl shadow-xl"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>

      <div className="flex-1 grid  grid-cols-2 gap-4">
        {locationData.map((item, index) => (
          <Button
            key={index}
            onClick={() => setSelectedLocation(item)}
            className={`p-3 bg-gray-100 flex flex-col  md:items-center  overflow-hidden gap-2 rounded-lg  shadow  cursor-pointer transition-all duration-200 ease-in-out hover:bg-blue-100 ${
              selectedLocation?.title === item.title
                ? "bg-primary-200 border-2 border-primary-300"
                : ""
            }`}
          >
            <p className="body3-semibold font-medium flex items-center gap-2 text-gray-900">
             <span><LuMapPin /></span>
              <span className="text-start small2-bold">{item.title}</span>
            </p>
            <p className="small3-regular  max-md:text-start">{item.address1}</p>
            <p className="small3-regular max-md:text-start">{item.address2}</p>
            <p className="small3-regular max-md:text-start">{item.phone}</p>
          </Button>
        ))}
      </div>
    </GridLayout>
  );
};

export default LocationSection;
