"use client";
import React from "react";
import GridLayout from "../shared/GridLayout";
import { CgArrowLongRight } from "react-icons/cg";
import Link from "next/link";

const whyUsData: WhyUsItem[] = [
  {
    title: "Physical Therapy",
    description: [
      "We provide expert care tailored to your needs—whether recovering from injury, managing pain, or enhancing performance.",
      "Our therapists help restore mobility, strength, and confidence with personalized treatment. With in-clinic and virtual options, quality care is always within reach.",
    ],
    href: "/services?category=1",
  },
  {
    title: "Behavioral Health ",
    description: [
      "Pain, stress, depression, and anxiety can lead to loss of function and obesity—creating a cycle that feeds back into more pain and mental health challenges.",
      "Our team of licensed therapists utilize sophisticated methods to drive positive change in your lifestyle to break this cycle and support your overall well-being.",
    ],
    href: "/services?category=4",
  },
  {
    title: "Nutritional Counseling",
    description: [
      "Our Medical Nutritional Therapy & Counseling program helps you make sustainable changes to support recovery, manage weight, and improve overall health.",
      "Whether you're learning about the power of nutrition for your health, fueling rehabilitation, addressing inflammation, building healthier habits, our dietitians provide personalized, science-backed guidance.",
      "Over 90% of in-network nutrition patients pay $0 out-of-pocket.",
    ],
    href: "/services?category=3",
  },
];

type WhyUsItem = {
  title: string;
  description: string[];
  href: string;
};

const WhyUsSection: React.FC = () => {
  return (
    <GridLayout className="sm:grid-cols-2 grid-cols-1   box lg:grid-cols-4">
      <h2 className="h2-semibold animate-fadeInRight font-bold  w-full flex flex-col justify-start items-start  text-gray-900 ">
        <span>Our Unique</span>
        <span className="text-primary-300">Offerings</span>
      </h2>
      {whyUsData.map((item: WhyUsItem, index: number) => (
        <div
          key={item.title}
          className={`group flex flex-col justify-start gap-2  ${
            index === whyUsData.length - 1 && "animate-fadeInLeft"
          }`}
        >
          <div className="flex justify-between gap-2 items-center">
          <p className="body2-bold mb-2 group-hover:text-secondary-200 transition-colors duration-300 font-medium ">
            {item.title}
          </p>
          <Link href={item.href} className="small3-regular flex md:hidden hover:text-secondary-500 active:text-secondary-200 whitespace-nowrap  gap-2 items-center  text-secondary-200" onClick={()=>{}}>More Info <CgArrowLongRight/></Link>

          </div>
          {item.description.map((des: string) =>
            des.startsWith("Over 90%") ? (
              <p
                key={des}
                className="text-secondary-500 font-bold  small3-bold"
              >
                {des}
              </p>
            ) : (
              <p key={des} className="text-secondary-500 mb-1 small3-regular">
                {des}
              </p>
            )
          )}
          <Link
            href={item.href}
            className="small3-regular hidden md:flex hover:text-secondary-500 active:text-secondary-200  gap-2 items-center mt-4 text-secondary-200"
            onClick={() => {}}
          >
            More Info <CgArrowLongRight />
          </Link>
        </div>
      ))}
    </GridLayout>
  );
};

export default WhyUsSection;
