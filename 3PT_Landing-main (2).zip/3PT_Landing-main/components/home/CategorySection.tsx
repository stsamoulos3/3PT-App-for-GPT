/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable @next/next/no-img-element */
"use client";
import React from "react";
import GridLayout from "../shared/GridLayout";
import ArrowCircle from "../shared/ArrowCircle";
import { BsArrowUpRight } from "react-icons/bs";
import Logo from "../shared/Logo";
import { useRouter } from "next/navigation";
import Link from "next/link";

const allServiceData = [
  {
    title: "Physical Therapy",
    link: "/services?category=1",
    href: "/graphic/home/service1.webp",
  },
  {
    title: "Multidisciplinary Wellbeing & Weight-loss",
    href: "/graphic/home/service2.webp",
    link: "/services?category=2",
  },
  {
    title: "Nutrition Counseling",
    href: "/graphic/home/service3.webp",
    link: "/services?category=3",
  },
  {
    title: "Behavioral Health",
    href: "/graphic/home/service4.webp",
    link: "/services?category=4",
  },
];

const CategorySection: React.FC = () => {
  const router = useRouter();
  return (
    <GridLayout className="lg:grid-cols-3 grid-cols-1 xl:gap-8 h-auto  md:grid-cols-2 ">
      <div className="flex flex-col h-auto gap-5">
        <h2 className="h2-semibold    flex flex-col justify-start items-start ">
          <span>Personalized</span>
          <span className="text-primary-300">Care Programs</span>
        </h2>
        <p className="small1-regular flex flex-col gap-3 xl:gap-6">
          <span>
            We’re a{" "}
            <span className="font-bold">5-star rated provider on Google</span>{" "}
            for a reason—our patients don’t just feel better, they feel cared
            for. At <Logo /> , you get real results, real attention, and a team
            fully invested in your recovery.
          </span>
          <span>
            What makes us different? We’ve left the outdated healthcare model
            behind. No rushed visits. No one-size-fits-all plans. Just expert
            care, tailored to your goals—delivered by clinicians who actually
            listen.
          </span>
          <span>
            Whether you&apos;re logging in for a virtual session or stepping
            into one of our bright, open clinics, you’ll feel the difference
            right away. It’s energizing. It’s welcoming. And it’s built to
            deliver long-lasting outcomes.
          </span>
        </p>
      </div>

  

      <div className="relative hidden h-full  xl:h-[570px] md:block">
        <div
          className="box bg-cover  group flex  justify-center rounded-3xl bg-center   w-full h-full"
          style={{
            backgroundImage: "url('/graphic/home/category1.webp')",
          }}
        >
          <div
            className="absolute top-0 w-full h-full rounded-3xl transition-opacity duration-300 opacity-0 group-hover:opacity-100"
            style={{
              background:
                "linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 1) 100%)",
            }}
          />
          <div
            onClick={() => {
              router.push("/services?category=1");
            }}
            className="  w-[92%] cursor-pointer absolute bottom-6  group-hover:block  overflow-hidden h-24  rounded-full  bg-none group-hover:bg-gray-600"
          >
            {/* Arrow Circle - Changes color on hover */}

            <div className=" flex items-center transform group-hover:translate-x-0 duration-300 translate-x-[calc(100%-96px)]  gap-4">
              <div className="">
                <ArrowCircle
                  className="bg-primary-300  w-24 h-24 group-hover:text-primary-300 group-hover:bg-white transition-colors duration-300"
                  icon={
                    <BsArrowUpRight className="w-8 h-8 text-black group-hover:text-primary-300 transition-colors duration-300" />
                  }
                />
              </div>

              <p className="hidden group-hover:block text-center small2-bold pr-3 text-white ">
                Read More Physical Therapy Services
              </p>
            </div>
          </div>
        </div>
        <p className="body1-semibold mt-2 w-full text-center">Physical Therapy</p>
      </div>

      <div className="relative hidden h-full  xl:h-[570px] lg:block">
        <div
          className="box bg-cover  group flex  justify-center rounded-3xl bg-center   w-full h-full"
          style={{
            backgroundImage: "url('/graphic/home/category2.webp')",
          }}
        >
          <div
            className="absolute top-0 w-full h-full rounded-3xl transition-opacity duration-300 opacity-0 group-hover:opacity-100"
            style={{
              background:
                "linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 1) 100%)",
            }}
          />
          <div
            onClick={() => {
              router.push("/services?category=2");
            }}
            className="  w-[92%] cursor-pointer absolute bottom-6  group-hover:block  overflow-hidden h-24  rounded-full  bg-none group-hover:bg-gray-600"
          >
            {/* Arrow Circle - Changes color on hover */}

            <div className=" flex items-center transform group-hover:translate-x-0 duration-300 translate-x-[calc(100%-96px)]  gap-4">
              <div className="">
                <ArrowCircle
                  className="bg-primary-300  w-24 h-24 group-hover:text-primary-300 group-hover:bg-white transition-colors duration-300"
                  icon={
                    <BsArrowUpRight className="w-8 h-8 text-black group-hover:text-primary-300 transition-colors duration-300" />
                  }
                />
              </div>

              <p className="hidden group-hover:block text-center small2-bold pr-3 text-white ">
                Read More Physical Therapy Services
              </p>
            </div>
          </div>
        </div>
        <p className="body1-semibold mt-2 w-full text-center">Weight Loss & Wellbeing</p>
      </div>
      {/* //mobile screen  */}
      <div className=" h-auto  md:hidden w-full  overflow-x-auto  gap-2   scrollbar-hide flex">
        {allServiceData.map((data) => (
          <Link
            href={data.link}
            key={data.title}
            className="min-w-[90%] h-full"
          >
            <img
              alt="graphic1"
              className=" object-cover aspect-video max-sm:h-[75%] sm:h-[85%] w-full rounded-2xl"
              src={data.href}
            />
            <p className="small2-bold">{data.title}</p>
          </Link>
        ))}
      </div>
    </GridLayout>
  );
};

export default CategorySection;
