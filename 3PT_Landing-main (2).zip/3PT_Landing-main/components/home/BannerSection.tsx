/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */
import React from "react";

const BannerSection = () => {
  return (
    <div className="box  relative ">
      <div className="absolute right-16 w-72">
        <img alt="graphic1" className="" src="/graphic/home/model.webp" />
      </div>
      <div className="w-full my-16 flex justify-between p-12 gap-4 bg-black rounded-2xl ">
        <div className="flex flex-col gap-2 ">
          <p className="    h1-regular">
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-secondary-400 via-white to-secondary-400">
              Our Professional
            </span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary-400 via-white to-secondary-400">
              Services.
            </span>
          </p>

          <p className="text-white body1-regular ">
            Comprehensive Care for Your Recovery & Wellbeing
          </p>
        </div>
      </div>
    </div>
  );
};

export default BannerSection;
