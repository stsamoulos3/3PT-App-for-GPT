/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */
import React from "react";
import GridLayout from "../shared/GridLayout";
import Logo from "../shared/Logo";

const PhysicalTherapy = () => {
  return (
    <div className="flex  mt-2 flex-col gap-4 ">
      <h2 className="h1-semibold animate-fadeInDown box">Physical Therapy</h2>
      <div className="box w-full animate-fadeIn">
        <img
          alt="graphic1"
          className="max-sm:hidden"
          src="/graphic/services/service1/S1-banner1.webp"
        />
        <img
          alt="graphic1"
          className="w-full sm:hidden"
          src="/graphic/services/service1/S1-banner1-mobile.webp"
        />
        <div className="flex flex-col small1-regular gap-3 pt-4">
          <p>
            Whether you&apos;re recovering from surgery, healing from an injury,
            managing chronic pain, or looking to improve your function and
            mobility, our skilled clinicians are here to help. We focus on your
            personal goals, utilizing hands-on treatments and targeted exercises
            to restore strength, endurance, balance, and independence.
          </p>
          <p>
            Your recovery will take place in an energizing environment that
            feels nothing like a typical physical therapy clinic. Our clinics
            are bright, open, and vibrant, with clean, modern finishes designed
            to motivate you through your recovery.
          </p>
        </div>
      </div>
      <GridLayout
        className="grid-cols-2 gap-4 sm:gap-8 max-xl:grid-cols-1"
        gap={8}
      >
        <div className="animate-fadeIn">
          <div className="body1-semibold mb-2">
            Physical therapy at
            <Logo className="inline-block mx-2" />
            is about getting you back to living, working, and moving with
            confidence.
          </div>
          <p className="small1-regular">
            Our skilled clinicians focus on your personal goals, combining
            hands-on treatments with targeted exercises to rebuild strength,
            mobility, and independence. Your recovery will take place in an
            energizing environment that feels nothing like a typical physical
            therapyclinic. Our clinics are bright, open, and vibrant, with
            clean, modern finishes designed to motivate you through your
            recovery.
          </p>
        </div>
        <div className="animate-fadeIn w-full max-sm:hidden">
          <img
            alt="graphic1"
            className="w-full"
            src="/graphic/services/service1/s1-banner2.webp"
          />
        </div>
      </GridLayout>

      <div className="box">
        <p className="body1-semibold text-secondary-200">
          A referral from your physician is not required to access our 5 star
          rated Physical Therapy Services.
        </p>
      </div>
      <p className="h2-semibold box">
        Injured Employees & Worker&apos;s Compensation
      </p>
      <GridLayout className="xl:grid-cols-3">
        <img
          alt="graphic1"
          className=" rounded-3xl xl:block hidden max-lg:mb-3 h-full object-cover w-full"
          src="/graphic/services/service1/s1-banner3.webp"
        />
        <img
          alt="graphic1"
          className="h-auto rounded-3xl xl:hidden max-lg:mb-3  object-cover w-full"
          src="/graphic/services/service1/s1-banner3-mobile.webp"
        />
        <div className="flex flex-col gap-4 col-span-2">
          <p className="small1-regular">
            If you’ve been injured on the job, we know how overwhelming the
            recovery process can feel. At <Logo />, we’re here to guide you
            every step of the way with specialized physical therapy that’s built
            around your needs, your job, and your long-term well-being.
          </p>
          <p className="small1-regular">
            Our licensed therapists create personalized treatment plans to help
            you heal, regain strength, and safely return to work—without rushing
            the process or cutting corners. From sprains and strains to
            post-surgical rehab, we focus on restoring function, preventing
            re-injury, and getting you back to what matters most.
          </p>
          <p className="small2-bold">Our Services Include:</p>
          <ul className="list-disc small2-regular pl-5 space-y-3">
            <li>
              <strong>Functional Capacity Evaluations (FCEs):</strong> Objective
              assessments to determine an employee&apos;s readiness to return to
              work and identify any necessary accommodations.
            </li>
            <li>
              <strong>Work Conditioning Programs:</strong> Structured
              interventions designed to improve strength, endurance, and
              flexibility, preparing employees for the physical demands of their
              job roles.
            </li>
            <li>
              <strong>Job-Specific Rehabilitation:</strong> Targeted therapy
              focusing on the movements and tasks pertinent to an
              employee&apos;s duties, ensuring a safe and effective transition
              back to work.
            </li>
            <li>
              <strong>Case Management Services:</strong> Coordinated oversight
              of the rehabilitation process, ensuring timely treatment,
              consistent communication, and alignment with all parties involved.
            </li>
          </ul>
        </div>
      </GridLayout>
    </div>
  );
};

export default PhysicalTherapy;
