/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable @next/next/no-img-element */
import React from "react";
import GridLayout from "../shared/GridLayout";
import Logo from "../shared/Logo";

const BehavioralTherapy = () => {
  return (
    <div className="flex sm:mt-6 mt-2 flex-col gap-4">
      <h2 className="h1-semibold animate-fadeInDown">
        Behavioral Health Therapy
      </h2>
      <div>
        <img
          alt="graphic1"
          className="w-full max-sm:hidden box animate-fadeIn h-auto"
          src="/graphic/services/service3/s3-banner1.webp"
        />
        <img
          alt="graphic1"
          className="w-full box sm:hidden animate-fadeIn h-auto"
          src="/graphic/services/service3/s3-banner1-mobile.webp"
        />
      </div>
      <GridLayout className="animate-fadeIn box md:grid-cols-2" gap={8}>
        <div className="body2-regular">
          Life comes with challenges, whether you’re feeling overwhelmed, stuck,
          or simply not like yourself, it’s okay to ask for help. At{" "}
          <Logo className="px-1" /> , our Behavioral Health Therapy services are
          designed to provide you with a safe, supportive space to navigate
          life’s obstacles and take care of your mental and emotional
          well-being.
        </div>
        <p className="small1-regular">
          You can expect thoughtful, one-on-one sessions tailored to your unique
          needs and goals. Our therapists take the time to understand your
          experiences and collaborate with you on a path forward—whether that
          means developing healthier thought patterns, improving relationships,
          or finding new ways to manage everyday stress.
          <span className="block mt-3">
            Our licensed therapists work with adults from all walks of life,
            offering personalized support to help you build coping skills,
            increase self-awareness, and feel more in control of your life.
            Whether you’re facing stress, anxiety, or life transitions, we’re
            here to listen and guide you through it.
          </span>
        </p>
      </GridLayout>

      <div>
        <p className="body1-semibold text-secondary-200"></p>
      </div>
    </div>
  );
};

export default BehavioralTherapy;
