/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable @next/next/no-img-element */
import React from "react";
import GridLayout from "../shared/GridLayout";

const NutritionalCounseling = () => {
  return (
    <section className="sm:mt-6 mt-2 flex over flex-col gap-4 ">
      <h2 className="h1-semibold animate-fadeInDown box">
        Nutritional Counseling{" "}
      </h2>

      <GridLayout className="animate-fadeIn sm:gap-8 gap-4   lg:grid-cols-2">
        <div className=" flex box flex-col sm:gap-8 gap-4  ">
          <div className="    relative w-full  ">
            <img
              alt="graphic1"
              className="w-full"
              src="/graphic/services/service4/s4-group1.webp"
            />
          </div>
          <div className="flex-1 box flex flex-col gap-2">
            <p className="small1-regular">
              At 3PT, our Nutrition Counseling isn’t about quick fixes or
              one-size- fits-all diets. It’s about creating sustainable changes
              that support your health, energy, and long-term success. Our
              Registered Dietitian Nutritionists (RDNs) take a personalized
              approach, helping you make smart, practical choices that fit your
              life—and get lasting results.
            </p>
            <p className="small1-regular">
              Every member of our nutrition team is a credentialed Registered
              Dietitian Nutritionist. That means they&apos;ve completed rigorous
              education, such as a bachelors or masters program, passed a
              national board exam, and maintain ongoing certifications through
              advanced continuing education. You can trust that your care is
              guided by experts with the training and experience to help you
              succeed.
            </p>
            <p className="body2-bold text-secondary-200">
              Over 90% of in-network patients pay $0 out-of-pocket for
              Nutritional Counseling as it is a covered preventative benefit
              under the ACA.
            </p>
          </div>
        </div>
        <div className="  box h-full relative   ">
          <img
            alt="graphic1"
            className="w-full h-[250px] md:h-[400px] lg:h-full rounded-3xl object-cover"
            src="/graphic/services/service4/s4-group2.webp"
          />
          {/* <img
              className="absolute top-[-10%]  right-[-16%]  animate-[spin_12s_linear_infinite] w-52"
              src="/graphic/about-us/circle_.webp"
            /> */}
        </div>
      </GridLayout>
    </section>
  );
};

export default NutritionalCounseling;
