/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable @next/next/no-img-element */
import React from "react";
import GridLayout from "../shared/GridLayout";

interface multidisiplinaryType {
  imgLink: string;
  count: string;
  description: string[];
  title: string;
}

const multidisciplinaryData: multidisiplinaryType[] = [
  {
    imgLink: "/graphic/services/service2/s2-banner1.webp",
    count: "01.",
    title: "Cardiopulmonary Exercise Test",
    description: [
      "By measuring key metrics like VO₂ Sub Max and CO₂ output, we identify the ideal exercise intensity tailored specifically for you.",
      "This personalized approach ensures each workout is both highly efficient and comfortably sustainable, leaving you energized, not exhausted, by guiding you to the optimal heart rate for your body's unique needs.",
      "If you’ve struggled to maintain exercise routines in the past, this testing removes the guesswork found in consumer wearables and standard gym equipment. Instead, you get data-backed guidance that works with your body, not against it.",
      "You will learn to love to exercise when doing it pain free at an intensity that patients of all ages enjoy.",
    ],
  },
  {
    imgLink: "/graphic/services/service2/s2-banner5.webp",
    count: "02.",
    title: "Resting Metabolic Rate",
    description: [
      "Measuring your actual Resting Metabolic Rate (RMR) with Indirect Calorimetry gives our dietitians precise insight into how many calories your body burns at rest.",
      "If you’ve struggled to maintain diets in the past, this analysis removes the guesswork—allowing us to build a personalized nutrition plan tailored to your metabolism, preferences, and any underlying health conditions. The result is sustainable energy, effective weight management, and long-term health improvements that any patient can sustain.",
    ],
  },
  {
    imgLink: "/graphic/services/service2/s2-banner3.webp",
    count: "03.",
    title: "Behavioral Health Assessments",
    description: [
      "Our Behavioral Health Assessments evaluate your mindset, motivation, and readiness for change. Understanding these insights allows us to tailor our techniques specifically to you.",
      "Regular assessments help our clinicians communicate, collaborate, & adapt your treatment, ensuring meaningful, lasting improvements in function, Wellbeing, confidence, and overall quality of life well beyond pounds falling off the scale.",
    ],
  },
  {
    imgLink: "/graphic/services/service2/s2-banner2.webp",
    count: "04.",
    title: "Biometric Data Tracking",
    description: [
      "We track & report to you on changes in key biometric data— weight, body composition, blood glucose levels, strength & endurance gain, and overall improvement in function.",
      "These objective measures allows our clinicians to closely monitor your physiological responses, fine-tune your personalized treatment plan, and clearly demonstrate your progress— keeping you informed, motivated, and confident on your Wellbeing transformation.",
    ],
  },
];

const MultidisciplinaryWellness = () => {
  return (
    <section className="flex flex-col w-full sm:mt-6 mt-2 gap-4">
      <h2 className="h1-semibold animate-fadeInDown box ">
        Clinical Multidisciplinary Weight Loss Program
      </h2>
      <p className="small1-regular animate-fadeIn box">
        Our clinical integrated multidisciplinary program utilizes Physical
        Therapy, Nutrition Counseling, and Behavioral Health to support your
        overall health & well-being. We begin with thorough evaluations of each
        patient’s metabolism, physiology and your past/current mental state to
        formulate a plan specific to each patient that produces predictable and
        long-lasting health outcomes.
      </p>

      {multidisciplinaryData.map(
        (data: multidisiplinaryType, index: number) => (
          <GridLayout
            className="animate-fadeIn box lg:grid-cols-3 max-lg:flex flex-col lg:gap-8 items-center"
            key={data.title}
          >
            {index % 2 === 0 && (
              <div className="max-lg:order-2 w-full  lg:col-span-1">
                <img
                  alt="graphic1"
                  className="w-full h-full"
                  src={data.imgLink}
                />
              </div>
            )}

            <div className="max-lg:order-1 col-span-2">
              <h3 className="h4-medium text-secondary-400">{data.count}</h3>
              <h2 className="h4-medium">{data.title}</h2>
              <div className="flex flex-col gap-3">
                {data.description.map((item: string) => (
                  <p className="small1-regular" key={item}>
                    {item}
                  </p>
                ))}
              </div>
            </div>
            {index % 2 === 1 && (
              <div className="max-lg:order-2 w-full">
                <img
                  alt="graphic1"
                  className="w-full h-full"
                  src={data.imgLink}
                />
              </div>
            )}
          </GridLayout>
        )
      )}

      <div>
        <p className="body1-semibold box text-secondary-200">
          A referral from your physician is not required to access our 5 star
          rated Physical Therapy Services.
        </p>
      </div>
    </section>
  );
};

export default MultidisciplinaryWellness;
