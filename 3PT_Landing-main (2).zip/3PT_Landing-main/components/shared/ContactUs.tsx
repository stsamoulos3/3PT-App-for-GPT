/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable @next/next/no-img-element */
"use client";

import React from "react";
import GridLayout from "./GridLayout";
import ContactForm from "./ContactForm";
import { usePathname } from "next/navigation";
import { IoCall } from "react-icons/io5";
import { MdEmail } from "react-icons/md";
import { FaLocationDot } from "react-icons/fa6";
import { FaFacebook, FaInstagram, FaLinkedin } from "react-icons/fa";

const socialLinks = [
  { icon: <FaFacebook />, url: "https://www.facebook.com/3pthealthcare" },
  { icon: <FaInstagram />, url: "https://www.instagram.com/3pthealthcare/" },
  {
    icon: <FaLinkedin />,
    url: "https://www.linkedin.com/company/11547232/admin/dashboard/",
  },
];

const ContactUsSection: React.FC = () => {
  const pathname = usePathname();
  return (
    <GridLayout className="sm:grid-cols-2 grid-cols-1 box" gap={8}>
      {pathname === "/schedule-appointment" && (
        <div className="flex flex-col gap-2 items-start justify-between">
          <div>
            <p className="h2-semibold">
              Schedule an evaluation or{" "}
              <span className="text-secondary-200">free consultation</span>
              today
            </p>
          </div>
          <div className=" hidden sm:flex justify-center h-auto ">
            <img
              alt="graphic1"
              className="w-full h-auto"
              src="/graphic/schedule-appointment-banner.webp"
            />
          </div>
        </div>
      )}
      {pathname === "/" && (
        <div
          className="flex max-sm:h-96 bg-blue-600 max-sm:hidden rounded-2xl relative flex-col gap-4 p-8 text-white bg-cover bg-center"
          style={{ backgroundImage: "url('/graphic/contact_banner.webp')" }}
        >
          <h2 className="h2-regular font-bold   flex flex-col justify-start items-start ">
            Contact Us
          </h2>
          <p className="small2-regular font-bold">Schedule an Appointment</p>
          <div className="mt-8 absolute bottom-24 lg:bottom-32 small2-regular flex flex-col gap-6  lg:gap-10">
            <p className="flex items-center gap-2 ">
              <IoCall />
              708-938-3378
            </p>
            <p className="flex items-center gap-2">
              {" "}
              <MdEmail />
              info@3pthealthcare.com{" "}
            </p>
            <p className="flex items-center gap-2">
              <FaLocationDot />
              19805 LaGrange Rd, Mokena, IL 60448
            </p>
          </div>

          {/* Social Links */}
          <div className="flex absolute bottom-8 gap-4 mt-4">
            {socialLinks.map((social, index) => (
              <a
                key={index}
                href={social.url}
                className=" hover:text-white text-xl"
              >
                {social.icon}
              </a>
            ))}
          </div>
        </div>
      )}
      <ContactForm />
      {pathname === "/schedule-appointment" && (
        <div className="flex justify-center sm:hidden h-auto ">
          <img
            alt="graphic1"
            className="w-[70%] h-auto"
            src="/graphic/schedule-appointment-banner.webp"
          />
        </div>
      )}
      {pathname === "/services" && (
        <div className="flex sm:flex-col row-start-1  gap-2 items-center justify-center">
          <div className="flex-1">
            <p className="md:text-2xl">
              Schedule an evaluation or free consultation today
              <span className="block text-secondary-300">
                either in office or telehealth
              </span>
            </p>
          </div>
          <div className="flex justify-center max-sm:w-[30%] h-auto ">
            <img
              alt="graphic1"
              className="sm:w-[70%] w-full h-auto"
              src="/graphic/services/contactGraphic.webp"
            />
          </div>
        </div>
      )}
    </GridLayout>
  );
};

export default ContactUsSection;
