/* eslint-disable @next/next/no-img-element */
"use client";

import React, { useState } from "react";
import Button from "./Button";
import { usePathname } from "next/navigation";
import { formSubmission } from "@/actions /formSubmission.action";
const ContactForm = () => {
  const pathname = usePathname();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    number: "",
    date: "",
    message: "",
  });

  const [loading, setLoading] = useState(false);
  const [responseMessage, setResponseMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showSuccessImage, setShowSuccessImage] = useState(false);
  const [showFailureImage, setShowFailureImage] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.id]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault(); // prevent page reload
    setLoading(true);
    setResponseMessage(null);
    setErrorMessage(null);

    try {
      const result = await formSubmission({
        name: formData.name,
        email: formData.email,
        number: formData.number,
        date: formData.date,
        message: formData.message,
      });

      if (result.success) {
        setShowSuccessImage(true);
        setResponseMessage(result.message || "Form submitted successfully!");
        setFormData({
          name: "",
          email: "",
          number: "",
          date: "",
          message: "",
        });
      } else {
        setShowFailureImage(true);
        setErrorMessage(
          result.error || "Failed to submit form. Please try again."
        );
      }
    } catch (error: any) {
      setShowFailureImage(true);
      console.error("Unexpected error:", error);
      setErrorMessage("Something went wrong. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className={`grid max-sm:flex flex-col items-center text-black border border-primary-200 md:p-8 p-4 rounded-2xl shadow-lg grid-cols-2 md:gap-8 gap-4 relative h-auto 
        ${
          pathname === "/schedule-appointment"
        } bg-[url('/graphic/contact_banner.webp')] sm:bg-none bg-cover bg-center`}
    >
      <h2 className="h4-bold text-white max-sm:col-span-2 sm:hidden w-full text-center">
        Contact Us
      </h2>

      {/* Name Field */}
      <div className="w-full max-sm:col-span-2">
        <label htmlFor="name" className="small3-bold text-white sm:text-black">
          Name
        </label>
        <input
          id="name"
          type="text"
          value={formData.name}
          onChange={handleChange}
          className="p-3 mt-1 bg-white shadow outline-none rounded-lg w-full"
          required
        />
      </div>

      {/* Email Field */}
      <div className="w-full max-sm:col-span-2">
        <label htmlFor="email" className="small3-bold text-white sm:text-black">
          Email
        </label>
        <input
          id="email"
          type="email"
          value={formData.email}
          onChange={handleChange}
          className="p-3 mt-1 bg-white shadow outline-none rounded-lg w-full"
          required
        />
      </div>

      {/* Phone Number Field */}
      <div className="w-full max-sm:col-span-2">
        <label
          htmlFor="number"
          className="small3-bold text-white sm:text-black"
        >
          Phone Number
        </label>
        <input
          id="number"
          type="tel"
          value={formData.number}
          onChange={handleChange}
          className="p-3 mt-1 bg-white shadow outline-none rounded-lg w-full"
          required
        />
      </div>

      {/* DOB Field */}
      <div className="w-full max-sm:col-span-2">
        <label htmlFor="date" className="small3-bold text-white sm:text-black">
          DOB
        </label>
        <input
          id="date"
          type="date"
          value={formData.date}
          onChange={handleChange}
          className="p-3 mt-1 bg-white shadow outline-none rounded-lg w-full"
          required
        />
      </div>

      {/* Message Field */}
      <div className="w-full col-span-2">
        <label
          htmlFor="message"
          className="small3-bold text-white sm:text-black"
        >
          Message
        </label>
        <textarea
          id="message"
          value={formData.message}
          onChange={handleChange}
          className="p-3 mt-1 bg-white shadow outline-none rounded-lg w-full"
          rows={3}
          required
        ></textarea>
      </div>

      {/* Submit Button */}
      <div className="col-span-2 w-full">
        <Button
          type="submit"
          // @ts-expect-error error
          disabled={loading}
          className="w-full bg-black text-white py-3 rounded-lg font-semibold transition disabled:opacity-50"
        >
          {loading ? "Submitting..." : "Book a Free Consultation Now"}
        </Button>
      </div>

      {/* Success / Error Messages */}
      {responseMessage && (
        <div className="col-span-2 text-green-600 text-center font-semibold mt-4">
          {responseMessage}
        </div>
      )}
      {errorMessage && (
        <div className="col-span-2 text-red-600 text-center font-semibold mt-4">
          {errorMessage}
        </div>
      )}

      {/* Success Image Overlay */}
      {showSuccessImage && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            setShowSuccessImage(false);
          }}
          className="fixed top-0 inset-0  z-50 flex justify-center items-center"
        >
          <div className="bg-black opacity-15 backdrop-blur-2xl  fixed w-[100vw] h-[100vh] top-0 left-0" />
          <div onClick={(e) => e.stopPropagation()} className="relative ">
            <img
              src="/Group3139.svg"
              alt="Success"
              className="w-[300px] lg:w-[500px] h-[400px] object-contain"
            />
            <button
              className="absolute top-40 lg:top-[90px] opacity-0 right-2 lg:right-10 bg-white rounded-full p-2 shadow-md"
              onClick={() => {
                setShowSuccessImage(false);
              }}
            >
              ✖
            </button>
          </div>
        </div>
      )}
      {showFailureImage && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            setShowFailureImage(false);
          }}
          className="fixed inset-0  flex justify-center items-center z-50"
        >
          <div className="bg-black opacity-15 backdrop-blur-2xl  fixed w-[100vw] h-[100vh] top-0 left-0" />
          <div onClick={(e) => e.stopPropagation()} className="relative ">
            <img
              src="/Group 3140.svg"
              alt="failure"
              className="w-[300px] lg:w-[500px] h-[400px] object-contain"
            />
            <button
              className="absolute top-40 lg:top-[90px] opacity-0 right-2 lg:right-10 bg-white rounded-full p-2 shadow-md"
              onClick={() => {
                setShowFailureImage(false);
              }}
            >
              ✖
            </button>
          </div>
        </div>
      )}
    </form>
  );
};

export default ContactForm;
