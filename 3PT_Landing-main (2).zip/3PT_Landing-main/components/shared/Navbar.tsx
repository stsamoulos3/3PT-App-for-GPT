/* eslint-disable @next/next/no-img-element */
/* eslint-disable react-hooks/rules-of-hooks */
"use client";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import React, { useEffect, useState } from "react";
import { FaFacebook, FaInstagram, FaLinkedin } from "react-icons/fa";
import { IoIosArrowDown, IoIosArrowUp } from "react-icons/io";
import Button from "./Button";
import { useRouter } from "next/navigation";
import { GiHamburgerMenu } from "react-icons/gi";
import { GoHome, GoPeople } from "react-icons/go";
import { TfiBag } from "react-icons/tfi";
import { BiPhoneCall } from "react-icons/bi";
import { MdPayment } from "react-icons/md";
import { HiOutlineVideoCamera } from "react-icons/hi";
import { GrScorecard } from "react-icons/gr";

const navLinks = [
  { href: "/", label: "Home", icon: <GoHome /> },
  {
    href: "/services",
    label: "Services",
    icon: <TfiBag />,
    subContent: [
      {
        href: "/services?category=1",
        searchParam: "1",
        label: "Physical Therapy",
        icon: <TfiBag />,
      },
      {
        href: "/services?category=3",
        searchParam: "3",
        label: "Nutritional Counseling",
        icon: <TfiBag />,
      },
      {
        href: "/services?category=4",
        searchParam: "4",
        label: "Behavioral Health Therapy",
        icon: <TfiBag />,
      },
      {
        href: "/services?category=2",
        searchParam: "2",
        label: "Multidisciplinary Weight Loss",
        icon: <TfiBag />,
      }
    ],
  },
  { href: "/resources", icon: <HiOutlineVideoCamera />, label: "Resources" },
  { href: "/about-us", label: "About Us", icon: <GoPeople /> },
  { href: "/locations", icon: <BiPhoneCall />, label: "Locations" },
  {
    href: "https://go.promptemr.com/payment?w=341",
    icon: <MdPayment />,
    label: "Pay My Bill",
  },
];

const Navbar = () => {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const searchParams =
    typeof window !== "undefined" && useSearchParams().get("category");
  const [isScrolled, setIsScrolled] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 5);
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <nav
      className={`w-full sticky top-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-white shadow-md" : "bg-transparent"
      }`}
    >
      <div className="px-4 ">
        <div className="  fixed top-0 left-0  w-full bg-primary-400 opacity-50  blur-3xl" />

        <div className="flex justify-between  animate-fadeIn items-center sm:py-6 py-4">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link href="/" className="h4-bold font-bold text-blue-600">
              {/* <Logo type="logo" /> */}
              <img src="/logo.png" alt="Logo" className=" h-8 lg:h-11" />
            </Link>
          </div>

          {/* Navigation Links for web screen */}
          <div className="flex items-center max-lg:hidden space-x-2 xl:space-x-6">
            {navLinks.map((link) =>
              link.subContent ? (
                <div
                  key={link.label}
                  className="relative group animate-fadeIn"
                  onMouseEnter={() => setDropdownOpen(link.label)}
                  onMouseLeave={() => setDropdownOpen(null)}
                >
                  <div
                    className={`small3-regular cursor-pointer flex gap-2 items-center px-4 py-2 rounded-full transition ${
                      pathname.startsWith("/services")
                        ? "bg-primary-400 text-white"
                        : "bg-neutral-200"
                    }`}
                  >
                    {link.label}{" "}
                    {dropdownOpen === link.label ? (
                      <IoIosArrowUp />
                    ) : (
                      <IoIosArrowDown />
                    )}
                  </div>
                  {dropdownOpen === link.label && (
                    <div className="absolute left-0 rounded-lg">
                      <div className="rounded-2xl bg-neutral-100 w-52 mt-2">
                        {link.subContent.map((subLink) => (
                          <Link
                            key={subLink.label}
                            href={subLink.href}
                            className={`flex hover:bg-primary-200 cursor-pointer hover:text-secondary-white rounded-lg py-2 px-4 ${
                              searchParams === subLink.searchParam
                                ? "bg-primary-400 hover:bg-primary-400 text-secondary-100"
                                : ""
                            }`}
                          >
                            {subLink.label}
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <Button
                  key={link.label}
                  onClick={() => {
                    if (link.label !== "Pay My Bill") {
                      router.push(link.href);
                    } else {
                      window.open(link.href, "_blank");
                    }
                  }}
                  className={`small3-regular cursor-pointer hover:bg-primary-200 animate-fadeIn px-4 py-2 rounded-full transition ${
                    pathname === link.href
                      ? "bg-primary-400 hover:bg-primary-400 text-white"
                      : "bg-neutral-200 hover:text-blue-600"
                  }`}
                >
                  {link.label}
                </Button>
              )
            )}
            <Link
              href="https://www.facebook.com/3pthealthcare/"
              target="_blank"
            >
              <FaFacebook className="animate-fadeIn hidden xl:block w-6 h-6 cursor-pointer" />
            </Link>

            <Link
              target="_blank"
              href="https://www.linkedin.com/company/11547232/admin/dashboard/"
            >
              <FaLinkedin className="animate-fadeIn hidden xl:block w-6 h-6 cursor-pointer" />
            </Link>

            <Link
              target="_blank"
              href="https://www.instagram.com/3pthealthcare/"
            >
              <FaInstagram className="animate-fadeIn hidden xl:block w-6 h-6 cursor-pointer" />
            </Link>
            <Button
              onClick={() => {
                router.push("/schedule-appointment");
              }}
              className="px-4 py-2  animate-fadeIn  text-white bg-primary-400 hover:bg-neutral-200 hover:text-black  rounded-full small3-semibold"
            >
              Schedule Appointment
            </Button>
          </div>
          {/* Navigation Links for mobile screen */}
          <div className="lg:hidden ">
            <GiHamburgerMenu
              onClick={() => {
                setMenuOpen(!menuOpen);
              }}
              className="sm:w-10 w-9 h-9 sm:h-10"
            />
            <div>
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  setMenuOpen(false);
                }}
                className={`fixed flex justify-end  transition-transform duration-300 ${
                  menuOpen ? "translate-x-0" : "translate-x-full"
                }   top-0 right-0 h-full w-full   `}
              >
                <div
                  onClick={(e) => {
                    e.stopPropagation();
                  }}
                  className={`h-full fixed top-0 right-0 sm:w-80 w-2xs  bg-white`}
                >
                  <div className="py-4 px-4 ">
                    <Link
                      href="/"
                      className="w-full relative flex items-center justify-center mt-1"
                    >
                      {/* <Logo type="logo" /> */}
                      <img
                        src="/logo.png"
                        alt="Logo"
                        className=" h-8 lg:h-11"
                      />
                    </Link>

                    <div className="w-full flex flex-col py-8 gap-3 ">
                      {navLinks.map((link) =>
                        link.subContent ? (
                          <div
                            key={link.label}
                            className="relative group animate-fadeIn"
                            onClick={() => {
                              if (dropdownOpen) {
                                setDropdownOpen(null);
                              } else {
                                setDropdownOpen(link.label);
                              }
                            }}
                            // onMouseLeave={() => setDropdownOpen(null)}
                          >
                            <div
                              className={`small3-regular flex gap-2 w-full justify-between items-center px-6 py-3 rounded-lg transition ${
                                pathname.startsWith("/services")
                                  ? "bg-primary-400 text-white"
                                  : "bg-neutral-200"
                              }`}
                            >
                              <div className="flex items-center gap-4">
                                {link.icon}
                                {link.label}{" "}
                              </div>
                              {dropdownOpen === link.label ? (
                                <IoIosArrowUp />
                              ) : (
                                <IoIosArrowDown />
                              )}
                            </div>
                            {dropdownOpen === link.label && (
                              <div className=" ">
                                <div className="rounded-lg bg-neutral-100 w-full mt-2">
                                  {link.subContent.map((subLink) => (
                                    <Link
                                      onClick={() => {
                                        setMenuOpen(!menuOpen);
                                      }}
                                      key={subLink.label}
                                      href={subLink.href}
                                      className={`flex small3-regular items-center gap-4 rounded-lg py-2 px-8 ${
                                        searchParams === subLink.searchParam
                                          ? "bg-primary-400 hover:bg-primary-400 text-secondary-100"
                                          : ""
                                      }`}
                                    >
                                      <div>{subLink.icon}</div>
                                      {subLink.label}
                                    </Link>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ) : (
                          <Button
                            key={link.label}
                            onClick={() => {
                              if (link.label !== "Pay My Bill") {
                                setMenuOpen(!menuOpen);
                                router.push(link.href);
                              } else {
                                setMenuOpen(!menuOpen);
                                window.open(link.href, "_blank");
                              }
                            }}
                            className={`small3-regular  text-start flex items-center gap-4 animate-fadeIn px-6 py-3 rounded-lg transition ${
                              pathname === link.href
                                ? "bg-primary-400 text-white"
                                : "bg-neutral-200 hover:text-blue-600"
                            }`}
                          >
                            {link.icon}
                            {link.label}
                          </Button>
                        )
                      )}
                      <Button
                        onClick={() => {
                          setMenuOpen(!menuOpen);
                          router.push("/schedule-appointment");
                        }}
                        className="px-6 py-3 flex items-center whitespace-nowrap gap-4 text-white bg-primary-400 rounded-lg small3-semibold"
                      >
                        <GrScorecard />
                        Schedule Appointment
                      </Button>
                      <div className="w-full flex items-center absolute -left-[8px]  bottom-8 justify-center gap-8 mt-20">
                        <Link
                          href="https://www.facebook.com/3pthealthcare/"
                          target="_blank"
                        >
                          <FaFacebook className="animate-fadeIn  w-6 h-6 cursor-pointer" />
                        </Link>

                        <Link
                          target="_blank"
                          href="https://www.linkedin.com/company/11547232/admin/dashboard/"
                        >
                          <FaLinkedin className="animate-fadeIn  w-6 h-6 cursor-pointer" />
                        </Link>

                        <Link
                          target="_blank"
                          href="https://www.instagram.com/3pthealthcare/"
                        >
                          <FaInstagram className="animate-fadeIn  w-6 h-6 cursor-pointer" />
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
