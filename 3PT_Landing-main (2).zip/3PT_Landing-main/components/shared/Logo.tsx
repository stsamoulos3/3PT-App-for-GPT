import React from "react";

const Logo = ({ className, type }: { className?: string; type?: string }) => {
  return (
    <>
      <span className={` ${type === "logo" && "flex flex-col leading-8  items-center"} ${className}`}>
        <span className="italic font-bold">
          <span className={`${type === "footer" ? "text-white" : "text-gray-700"}`}>3</span>
          <span className={`${type === "footer" ? "text-white"  : "text-secondary-200"} `}>PT</span>
        </span>
        {(type === "logo" || type === "footer") && (
          <p className={`text-black  ${type === "footer" ? "text-white" : "text-gray-900"} font-bold text-[10px] max-sm:leading-2 sm:text-xs`}>THREE POINT HEALTHCARE</p>
        )}
      </span>
    </>
  );
};

export default Logo;
