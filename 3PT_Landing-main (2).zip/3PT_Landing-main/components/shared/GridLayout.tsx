import React from "react";

interface GridLayoutProps {
  children: React.ReactNode;
  columns?: number; // Default columns for large screens
  gap?: number; // Gap size (Ensure Tailwind valid values)
  className?: string;
  breakpoints?: { [key: string]: number }; // Custom breakpoints (e.g., { sm: 2, lg: 4 })
}

const GridLayout: React.FC<GridLayoutProps> = ({ 
  children, 
  gap = 4, 
  columns = 1, 
  className = "", 
  breakpoints = {} 
}) => {
  // Mapping columns to Tailwind classes
  const columnClasses: { [key: number]: string } = {
    1: "grid-cols-1",
    2: "grid-cols-2",
    3: "grid-cols-3",
    4: "grid-cols-4",
    5: "grid-cols-5",
    6: "grid-cols-6",
    7: "grid-cols-7",
    8: "grid-cols-8",
    9: "grid-cols-9",
    10: "grid-cols-10",
    11: "grid-cols-11",
    12: "grid-cols-12",
  };

  let columnClass = columnClasses[columns] || "grid-cols-2";

  // Convert breakpoints into Tailwind classes (Fixing incorrect interpolation)
  const responsiveClasses = Object.entries(breakpoints)
    .map(([size, cols]) => columnClasses[cols] ? `${size}:${columnClasses[cols]}` : "")
    .join(" ");
    
    console.log("responsiveClasses",responsiveClasses)
    if(responsiveClasses) {
       columnClass = ""
    }

  return (
    <section className="w-full">
      <div className="w-full">
        <div className={`grid ${className} ${columnClass} ${responsiveClasses} gap-${gap}`}>
          {children}
        </div>
      </div>
    </section>
  );
};

export default GridLayout;
