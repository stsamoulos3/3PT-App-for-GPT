import React from "react";

interface ButtonProps {
  onClick: () => void;
  className?: string;
  children: React.ReactNode;
  type?: "button" | "submit" | "reset";
}

const Button: React.FC<ButtonProps> = ({ onClick,type, className = "", children }) => {
  return (
    <button 
      type ={type}
      onClick={onClick} 
      className={`  transition duration-300 cursor-pointer  hover:scale-105 active:scale-95 ${className}`}
    >
      {children}
    </button>
  );
};

export default Button;
