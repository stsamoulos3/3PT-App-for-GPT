/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import React from "react";
import { FaFacebook,FaInstagram, FaLinkedin } from "react-icons/fa";
import Logo from "./Logo";

const links = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about-us" },
  { label: "Services", href: "/services?category=1" },
  { label: "Locations", href: "/locations" },
  // { label: "Privacy Policy", href: "#" },
  { label: "Resource", href: "/resources" },
  { label: "Contact Us", href: "/locations" },
  { label: "Privacy Practices", href: "/privacy" },
];



const socialLinks = [
  { icon: <FaFacebook />, url: "https://www.facebook.com/3pthealthcare" },
  { icon: <FaInstagram />, url: "https://www.instagram.com/3pthealthcare/" },
  { icon: <FaLinkedin />, url: "https://www.linkedin.com/company/11547232/admin/dashboard/" },
];




const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 sm:mt-12 mt-6  text-white py-10 text-center">
      <div className="max-w-7xl mx-auto flex flex-col items-center gap-6 px-6">
        {/* Logo */}
        <div className="flex-shrink-0 flex flex-col gap-4">
          <Link href="/" className="h4-bold font-bold text-blue-600">
            <Logo type = "footer" className="text-white"  />
          </Link>
          <p className="text-xs font-bold">Physical Therapy - Behavioral Health - Nutritional Counseling</p>
        </div>
        {/* Paragraph */}
        <p className="text-secondary-300  body2-regular ">
          Three lifechanging Pathways
        </p>

        {/* Links */}
        <div className="grid grid-cols-1 md:grid-col-4  lg:grid-cols-7 gap-6 w-full max-w-4xl text-gray-400 text-sm">
          {links.map((link, index) => (
            <a key={index} href={link.href} className="hover:text-white whitespace-nowrap">
              {link.label}
            </a>
          ))}
        </div>

        {/* Social Links */}
        <div className="flex gap-4 mt-4">
          {socialLinks.map((social, index) => (
            <a
              key={index}
              href={social.url}
              className="text-gray-400  hover:text-white text-xl"
            >
              {social.icon}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
