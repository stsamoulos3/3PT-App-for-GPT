import React from 'react'

const ArrowCircle = ({icon, className} : {icon : React.ReactNode, className : string}) => {
  return (
    <div className={`${className} flex justify-center items-center rounded-full`}>{icon}</div>
  )
}

export default ArrowCircle