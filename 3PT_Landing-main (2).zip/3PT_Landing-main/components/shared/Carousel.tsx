"use client";

import React, { useEffect, useState } from "react";
import Button from "./Button";
import { useRouter } from "next/navigation";

export const GenAIJourney = [
  {
    title: "PHYSICAL THERAPY",
    imgLink: "/graphic/home/mobile-hero1.webp",
  },
  {
    title: "WELLBEING& WEIGHT LOSS",
    imgLink: "/graphic/home/mobile-hero2.webp",
  },
  {
    title: "BEHAVIORAL HEALTH",
    imgLink: "/graphic/home/mobile-hero3.webp",
  },
  {
    title: "NUTRITIONAL COUNSELING",
    imgLink: "/graphic/home/mobile-hero4.webp",
  },
];
const Carousel = () => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const router= useRouter();

  useEffect(() => {
    const interval = setInterval(() => {
      setSelectedIndex((prevIndex) => (prevIndex + 1) % GenAIJourney.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="mt-2 animate-fadeIn">
      <div className="flex-1">
        <div
          style={{
            backgroundImage: `url(${GenAIJourney[selectedIndex].imgLink})`,
          }}
          className=" bg-cover relative   w-full h-full rounded-xl sm:rounded-3xl p-6 sm:p-6 sm:pl-10 flex flex-col gap-20  transition-shadow duration-300"
        >
          <div className="flex  justify-between items-center">
          <p className="small3-bold text-secondary-100">{GenAIJourney[selectedIndex].title}</p>
            {/* Mobile pagination indicators */}
            <div className="flex justify-center space-x-2">
            {GenAIJourney.map((_, index) => (
              <span
                key={index}
                className={`h-[6px] w-[6px] rounded-full cursor-pointer transition-all duration-300 ${
                  selectedIndex === index
                    ? "bg-white scale-125"
                    : "bg-slate-300"
                }`}
                onClick={() => setSelectedIndex(index)}
              />
            ))}
          </div>
          </div>
        <div className="mb-4 mt-28">
        <p className=" text-secondary-100 h4-bold  font-medium">
            Transforming Recovery Elevating Wellbeing
          </p>
          {/* <p className=" text-secondary-100 small2-regular font-medium">
            Experience the 3PT difference and start your journey toward a
            healthier, more active life! Schedule an evaluation or free injury
            screening today - either in office or telehealth!{" "}
          </p> */}
        </div>

        <Button onClick={()=>{router.push("/schedule-appointment")}} className="absolute text-secondary-100 bg-primary-400 border-8  border-white px-8 small1-bold py-2 rounded-full -bottom-8 left-[calc(100%-50%-24px-64px)]">Book Now</Button>
        

        
        </div>
      </div>
    </div>
  );
};

export default Carousel;
