/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'https://3pthealthcare.com', // replace with your actual domain
  generateRobotsTxt: true,           // (optional)
  changefreq: 'monthly',
  priority: 0.7,
  sitemapSize: 5000,
};
