import GridLayout from "@/components/shared/GridLayout";
import React from "react";

const videoLink = [
  {
    title: "Dynamic Warm up Lower Extremity",
    link: "https://www.youtube.com/embed/JMv7ASK4Jks?si=nE322sBj6H1fnKmD",
  },
  {
    title: "Dynamic Warm Up Upper Extremity",
    link: "https://www.youtube.com/embed/Q0IIa-qkMTQ?si=6XyjfJm5gnlArqGe",
  },
  {
    title: "Thoracic Mobility",
    link: "https://www.youtube.com/embed/QfQYmZWEYKQ?si=oXz4wP8eUQn7gSky",
  },
  {
    title: "Reverse Flyes",
    link: "https://www.youtube.com/embed/rMP2FFLHBKU?si=Bh2KOxi_JWD4axEH",
  },
  {
    title: "Trunk Rotation",
    link: "https://www.youtube.com/embed/R8vbhcw_R-A?si=2pCrevuufq7eJkQ3",
  },
  {
    title: "Sit to Stand",
    link: "https://www.youtube.com/embed/fwfR-JAch7A?si=9JozPmGtNAnBynnJ",
  },
];

const page = () => {
  return (
    <>
      <h2 className="h1-semibold animate-fadeInDown mt-2 sm:mt-8 box">Resources</h2>
      <div className="bg-primary-200 overflow-hidden animate-fadeIn relative lg:p-12 px-5 py-3  box flex flex-col gap-4 rounded-2xl lg:rounded-4xl">
        <div>
          {/* Background SVG 1 (Right Side) */}
          <div className="absolute top-0 -z-30 right-0">
            <svg
              width="475"
              height="440"
              viewBox="0 0 475 440"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                className="animate-draw stroke-secondary-200 stroke-[13]"
                opacity="0.2"
                d="M559.199 292.34C370.371 546.84 139.99 416.766 170.835 200.685C178.16 149.373 245.994 -146.825 287.41 6.88154C311.602 96.6684 -84.0859 219.621 25.6846 -103.941"
              />
            </svg>
          </div>
        </div>

        <div className="  w-full  flex max-lg:flex-col-reverse  gap-8 justify-between items-center ">
          <div className="flex flex-col lg:w-[60%] gap-2">
            <p className="body2-regular">OUR VIDEO RESOURCES</p>
            <h3 className="h2-semibold">
              Learn, Grow & Thrive with Expert Insights
            </h3>
            <p className="body2-regular">
              Explore our collection of expert-led videos on YouTube, covering
              topics on physical therapy, mental Wellbeing, nutrition, and weight
              loss strategies. Whether you&apos;re looking for guided exercises,
              Wellbeing tips, or educational content, our resources are designed
              to support your journey to better health.
            </p>
          </div>
          <div className="lg:flex-1 rounded-3xl    w-full">
            <iframe
              className="rounded-xl w-full aspect-video"
              src="https://www.youtube.com/embed/9fW1Ry4mj3E?si=mCF8ykk4nyOfUY9P"
              title="YouTube video player"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              referrerPolicy="strict-origin-when-cross-origin"
              allowFullScreen
            ></iframe>
          </div>
        </div>
        <GridLayout className="lg:grid-cols-3 sm:grid-cols-2 lg:gap-8 gap-4  mt-4">
          {videoLink.map((link) => (
            <div key={link.title} className="w-full h-auto">
              <iframe
                className="w-full aspect-video rounded-xl"
                src={link.link}
                title="YouTube video player"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
              ></iframe>
              <p className="small2-bold mt-2 px-1">{link.title}</p>
            </div>
          ))}
        </GridLayout>
      </div>
    </>
  );
};

export default page;
