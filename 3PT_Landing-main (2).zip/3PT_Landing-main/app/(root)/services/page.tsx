import BehavioralTherapy from "@/components/service/BehavioralTherapy";
import MultidisciplinaryWellness from "@/components/service/MultidisciplinaryWellness";
import NutritionalCounseling from "@/components/service/NutritionalCounseling";
import PhysicalTherapy from "@/components/service/PhysicalTherapy";
import ContactUsSection from "@/components/shared/ContactUs";
import GridLayout from "@/components/shared/GridLayout";
import Logo from "@/components/shared/Logo";
import React from "react";

const videoLink = [
  {
    title: "Dynamic Warm up Lower Extremity",
    link: "https://www.youtube.com/embed/JMv7ASK4Jks?si=nE322sBj6H1fnKmD",
  },
  {
    title: "Dynamic Warm Up Upper Extremity",
    link: "https://www.youtube.com/embed/Q0IIa-qkMTQ?si=6XyjfJm5gnlArqGe",
  },
  {
    title: "Thoracic Mobility",
    link: "https://www.youtube.com/embed/QfQYmZWEYKQ?si=oXz4wP8eUQn7gSky",
  },
  {
    title: "Reverse Flyes",
    link: "https://www.youtube.com/embed/rMP2FFLHBKU?si=Bh2KOxi_JWD4axEH",
  },
  {
    title: "Trunk Rotation",
    link: "https://www.youtube.com/embed/R8vbhcw_R-A?si=2pCrevuufq7eJkQ3",
  },
  {
    title: "Sit to Stand",
    link: "https://www.youtube.com/embed/fwfR-JAch7A?si=9JozPmGtNAnBynnJ",
  },
];

const Page = ({ searchParams }: any) => {
  return (
    <>
      {searchParams?.category === "1" && <PhysicalTherapy />}
      {searchParams?.category === "2" && <MultidisciplinaryWellness />}
      {searchParams?.category === "3" && <NutritionalCounseling />}
      {searchParams?.category === "4" && <BehavioralTherapy />}
      <div>
        <p className="h4-semibold box">
          Experience the <Logo className="inline-block px-3" />
          difference and start your journey toward a healthier, more active
          life!
        </p>
      </div>
      <ContactUsSection />
      {searchParams?.category === "1" && (
        <div>
          <h1 className="h3-medium font-semibold">
            Physical Therapy exercises
          </h1>

          <GridLayout className="lg:grid-cols-3 sm:grid-cols-2 lg:gap-8 gap-4  mt-4">
            {videoLink.map((link) => (
              <div key={link.title} className="w-full h-auto">
                <iframe
                  className="w-full aspect-video rounded-xl"
                  src={link.link}
                  title="YouTube video player"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  referrerPolicy="strict-origin-when-cross-origin"
                  allowFullScreen
                ></iframe>
                <p className="small2-bold mt-2 px-1">{link.title}</p>
              </div>
            ))}
          </GridLayout>
        </div>
      )}
    </>
  );
};

export default Page;
