"use client"

import CategorySection from "@/components/home/CategorySection";
import ContactUsSection from "@/components/shared/ContactUs";
import HeroSection from "@/components/home/HeroSection";
import LocationSection from "@/components/home/LocationSection";
import ServiceSection from "@/components/home/ServiceSection";
import WhyUsSection from "@/components/home/WhyUsSection";
// import { getData } from "@/actions /db.action";
// import { useEffect, useState } from "react";


export default  function Home() {
  
  console.log("logs submitted")
  // const [rows, setRows] = useState<any>({});

  // async function getDataFn(){
  //   try { 
  //    const   rows : any = await getData();
  //     setRows(rows)
  //     console.log("rows",rows)

  //   }catch(error){
  //     console.error("dberror",error)
  //   }
  // }

  // useEffect(()=>{
  //     getDataFn();
  // },[])


  return (
    <>
      {/* hello raj */}
         {/* {process.env.NEXT_PUBLIC_EMAIL} db {rows.length > 0 && rows[0].name} */}
      {/* Background SVG 1 (Right Side) */}
      {/* <div className="absolute top-0 -z-30 hidden md:block right-0">
        <svg width="475" height="440" viewBox="0 0 475 440" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            className="animate-draw stroke-secondary-200 stroke-[13]"
            opacity="0.2"
            d="M559.199 292.34C370.371 546.84 139.99 416.766 170.835 200.685C178.16 149.373 245.994 -146.825 287.41 6.88154C311.602 96.6684 -84.0859 219.621 25.6846 -103.941"
          />
        </svg>
      </div> */}

      {/* Background SVG 2 (Left Side) */}
      {/* <div className="absolute top-40 -z-30 left-0">
        <svg width="211" height="545" viewBox="0 0 211 545" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            className="animate-draw stroke-secondary-200 stroke-[13]"
            opacity="0.2"
            d="M-58 7C-58 7 84.5964 27.3561 126 95.5C165.441 160.414 91.2451 222.461 126 290C145.671 328.226 184.141 331.542 200 371.5C244.237 482.957 -58 538 -58 538"
          />
        </svg>
      </div> */}

      {/* Sections with Scroll Effect */}
        <HeroSection />
        <WhyUsSection />
        <CategorySection />
        <div className="max-md:hidden">
        <ServiceSection />
        <h2 className="h3-bold text-center mt-8 mb-4  lg:mt-20 lg:mb-10  ">
          <span>Experience a transformative approach to health - </span>
          <span className="text-primary-300">built just for you</span>
        </h2>
        </div>
        <LocationSection />
        <ContactUsSection />
    </>
  );
}
