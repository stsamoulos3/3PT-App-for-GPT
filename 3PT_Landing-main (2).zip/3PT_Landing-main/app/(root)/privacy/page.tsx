"use client";

import GridLayout from "@/components/shared/GridLayout";
import Logo from "@/components/shared/Logo";
import React from "react";

const Page = () => {
  return (
    <>
      <GridLayout className="grid-cols-1 lg:gap-6 gap-4  ">
        <h2 className="h1-semibold animate-fadeInDown mt-2 sm:mt-8 box">
          Notice of Privacy Practices
          <span className="block small1-regular">
            Three Point Healthcare (<Logo />)
          </span>
        </h2>
        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            Welcome to <Logo className="ml-2" />
          </h2>
          <p className="small1-regular">
            At Three Point Healthcare (3PT), we believe better outcomes start
            with better understanding — of your body, your goals, and your
            privacy. Our interdisciplinary approach integrates Physical Therapy,
            Nutrition Counseling, and Behavioral Health to help you feel better,
            move better, and live better. But just as we treat the whole person,
            we also protect the whole patient.
          </p>
        </div>
        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            Our Privacy Pledge to You
          </h2>
          <div className="flex flex-col gap-2">
            <p className="small1-regular">
              At 3PT, your trust means everything to us. We understand that
              health information is deeply personal, and we are committed to
              protecting your privacy at every step. Whether you’re working with
              a therapist, dietitian, or physical therapist, your data will only
              be used to improve your care — never to exploit it.
            </p>
            <p className="small1-regular">
              We do not sell, rent, or share your personal information with
              anyone for marketing purposes without your explicit consent. Our
              goal is simple: To give you exceptional care — and to handle your
              information with the same respect and confidentiality we would
              want for our own families.{" "}
            </p>
          </div>
        </div>

        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            How We Collect Your Personal Information{" "}
          </h2>
          <p className="small1-regular mb-2">
            We collect most of your personal and health information directly
            from you — when you fill out forms, meet with our team, or use our
            website and services. In addition, we may collect information in the
            following ways:
          </p>
          <ul className="list-disc small1-regular pl-5 lg:pl-10 space-y-3">
            <li>
              <strong>From Your Devices or Apps:</strong> If you choose to
              connect third-party applications or devices such as Apple Health,
              Google Fit, Polar, MyFitnessPal, or smartwatches, we may receive
              data such as step counts, heart rate, sleep patterns, nutrition
              logs, and other biometric data.
            </li>
            <li>
              <strong>Via Our Website or Platform:</strong> When you visit our
              website or use our online tools, we may collect information
              through forms you complete, appointment scheduling tools, cookies,
              and usage analytics.
            </li>
            <li>
              <strong>From Payment Activity:</strong> When you make a payment
              through our online platform, we may receive transaction-related
              details, such as a confirmation number and payment amount.{" "}
              <strong>
                However, we do not collect or store your full financial account
                details such as credit card or bank account numbers.
              </strong>
            </li>
            <li>
              <strong>When You Contact Us:</strong> If you reach out to 3PT —
              whether via email, web form, or phone we collect the contents of
              your message, any attachments, and any additional details you
              choose to share.
            </li>
          </ul>
        </div>

        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            Our Legal Responsibilities{" "}
          </h2>
          <p className="small1-regular mb-2">We are required by law to:</p>
          <ul className="list-disc small1-regular pl-5 lg:pl-10 space-y-3">
            <li>
              Protect the privacy of your protected health information (PHI)
            </li>
            <li>
              Provide you with this notice outlining our privacy practices
            </li>
            <li>Comply with the terms of this notice</li>
            <li>
              Notify you promptly if a breach occurs that may compromise your
              information
            </li>
          </ul>
        </div>

        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            How We May Use and Disclose Your Health Information{" "}
          </h2>
          <p className="small1-regular mb-2">
            We may use or share your health information for:
          </p>
          <ul className="list-disc small1-regular pl-5 lg:pl-10 space-y-3">
            <li>
              <strong>Treatment - </strong> To coordinate care among providers
            </li>
            <li>
              <strong>Payment - </strong>To bill your insurance or other payer
            </li>
            <li>
              <strong>Operations - </strong>For quality improvement, analytics,
              and administration
            </li>
            <li>
              <strong>Appointment Reminders and Care Recommendations </strong>
            </li>
            <li>
              <strong>Marketing or Fundraising - </strong>Only with your
              permission
            </li>
            <li>
              <strong>When Required by Law </strong>
            </li>
            <li>
              <strong>Other Purposes - </strong>Only with your written
              authorization
            </li>
          </ul>
        </div>
        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            Your Privacy Rights{" "}
          </h2>
          <p className="small1-regular mb-2">You have to right to:</p>
          <ul className="list-disc small1-regular pl-5 lg:pl-10 space-y-3">
            <li>Access and request a copy of your health information</li>
            <li>
              Request corrections to incomplete or inaccurate information{" "}
            </li>
            <li>Receive a list of certain disclosures made </li>
            <li>Request restrictions on sharing your data </li>
            <li>Choose alternative ways for us to contact you </li>
            <li>Revoke authorizations you’ve previously granted </li>
            <li>Receive a paper copy of this notice at any time </li>
          </ul>
        </div>
        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            Digital Use, Third-Party Tools & Online Data{" "}
          </h2>
          <p className="small1-regular mb-2">
            When using our digital services or wearable integrations, your data
            is encrypted and handled with strict HIPAA-compliant security
            protocols. Any information shared with or received from third-party
            services is used solely to support your care. We thoroughly vet our
            partners to ensure they meet privacy and security standards.
          </p>
          <p className="small1-bold mt-2">
            We do not sell your data. We never have, and never will.
          </p>
        </div>
        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            Cookies & Analytics{" "}
          </h2>
          <p className="small1-regular mb-2">
            Our website may use cookies and tracking tools to improve your
            experience. These may collect non-personal data such as browser
            type, device, and pages visited. You may control cookie settings in
            your browser at any time.{" "}
          </p>
        </div>
        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            Data Storage & Transfers{" "}
          </h2>
          <p className="small1-regular mb-2">
            Your data is securely stored in the United States. If you access our
            services from outside the U.S., you consent to your information
            being transferred and processed in accordance with U.S. laws and
            privacy standards.
          </p>
        </div>
        <div>
          <h2 className="h4-medium animate-fadeIn  box">Data Retention </h2>
          <p className="small1-regular mb-2">
            We retain your personal and health information only as long as
            needed to provide care and meet legal requirements. When no longer
            needed, data is securely deleted or archived according to HIPAA
            guidelines.
          </p>
        </div>
        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            Questions or Complaints?{" "}
          </h2>
          <p className="small1-regular mb-2">
            If you have questions about this Notice or believe your rights have
            been violated, contact :
          </p>
          <ul className="list-disc small1-regular pl-5 lg:pl-10 space-y-3">
            <li>HIPAA Privacy Officer – Three Point Healthcare</li>
            <li>Phone: (708) 938-3378</li>
            <li>Email: info@3pthealthcare.com</li>
            <li>Address: 19805 LaGrange Rd, Mokena, IL 60448</li>
          </ul>
          <p className="small1-regular mt-2">
            You can also file a complaint with the U.S. Department of Health and
            Human Services at{" "}
            <a
              href="https://www.hhs.gov/ocr/privacy"
              className="text-secondary-200 hover:text-blue-700"
              target="_blank"
              rel="noopener noreferrer"
            >
              www.hhs.gov/ocr/privacy
            </a>
            . You will not be penalized for filing a complaint.
          </p>
        </div>
        <div>
          <h2 className="h4-medium animate-fadeIn  box">
            We May Update This Notice{" "}
          </h2>
          <p className="small1-regular mb-2">
            This Notice may be updated periodically. The latest version will
            always be posted here and available at our clinic locations.
          </p>

          <p className="small1-regular mt-2">
            Thank you for trusting 3PT. We treat your health and your privacy
            with the care it deserves.{" "}
          </p>
        </div>
      </GridLayout>
      <p className="text-center body1-regular">
        Thank you for trusting.
        <Logo className="mx-2" /> We treat your health and your privacy with the
        care it deserves.
      </p>
    </>
  );
};

export default Page;
