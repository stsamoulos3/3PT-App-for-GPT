"use client";
import LocationSection from "@/components/home/LocationSection";
import Button from "@/components/shared/Button";
import { useRouter } from "next/navigation";
import React from "react";

const Page = () => {
  const router = useRouter();
  return (
    <section className="flex flex-col mt-4 sm:mt-8 gap-8 ">
      <LocationSection />

      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          <h4 className=" body2-regular animate-fadeInDown">CONTACT INFO</h4>
          <h2 className="h2-semibold animate-fadeInDown">
            We are always happy to assist you
          </h2>
        </div>
        <div className="bg-primary-200 animate-fadeIn gap-4 max-md:flex-col  flex justify-between md:items-center rounded-2xl p-6 sm:p-8 w-full ">
          <div className="flex flex-col gap-4">
            <h3 className="body2-regular">Get Started</h3>
            <h3 className="h2-regular">
              {"We're here to"}
              <span className="text-secondary-200 block">assist you.</span>
            </h3>
            <Button
              className="bg-black px-4 py-2 small3-regular text-white w-full rounded-full"
              onClick={() => {
                router.push("/schedule-appointment");
              }}
            >
              Schedule Appointment
            </Button>
          </div>
          <div className="flex flex-col gap-3 mt-2 sm:gap-5">
            <h3 className="body3-semibold">Email Address</h3>
            <div className="h-1 w-10 bg-black rounded" />

            <p className="body3-semibold">info@3pthealthcare.com</p>
          </div>
          <div className="flex flex-col gap-5">
            <h3 className="body3-semibold">Number</h3>
            <div className="h-1 w-10 bg-black rounded" />

            <p className="body3-semibold">(708) 938-3378</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Page;
