/* eslint-disable @next/next/no-img-element */
/* eslint-disable react-hooks/rules-of-hooks */

"use client";
import Footer from "@/components/shared/Footer";
import Navbar from "@/components/shared/Navbar";
import { usePathname, useSearchParams } from "next/navigation";
import React from "react";

const Layout = ({ children }: { children: React.ReactNode }) => {
  // useEffect(() => {
  //   const scaleOnScroll = () => {
  //     document.querySelectorAll(".box").forEach((box) => {
  //       const element = box as HTMLElement; // Type assertion

  //       const rect = element.getBoundingClientRect();
  //       const windowHeight = window.innerHeight;
  //       const center = windowHeight / 2; // Center of viewport
  //       const distanceFromCenter = Math.abs(
  //         rect.top + rect.height / 2 - center
  //       );

  //       // Normalize distance (0 when at center, 1 at top/bottom)
  //       const progress = Math.min(1, distanceFromCenter / center);
  //       const scaleValue = 1 - progress * 0.05; // Scale from 0.5 to 1

  //       element.style.transform = `scale(${scaleValue})`;
  //     });
  //   };

  //   window.addEventListener("scroll", scaleOnScroll);
  //   window.addEventListener("resize", scaleOnScroll);
  //   scaleOnScroll(); // Run on mount

  //   return () => {
  //     window.removeEventListener("scroll", scaleOnScroll);
  //     window.removeEventListener("resize", scaleOnScroll);
  //   };
  // }, []);

  const pathname = usePathname();
  const searchParam =
    typeof window !== "undefined" && useSearchParams().get("category");
  return (
    <main className="relative">
      <Navbar />
      <section className="">
        <div
          className={`flex flex-col ${
            pathname === "/services" && searchParam !== "2"
              ? "lg:px-28 md:px-16 sm:px-8"
              : "sm:px-8"
          } gap-8 px-4   overflow-hidden   scroll-smooth  max-w-[1536px] mx-auto`}
        >
          {children}
        </div>
      </section>
      <Footer />
    </main>
  );
};

export default Layout;
