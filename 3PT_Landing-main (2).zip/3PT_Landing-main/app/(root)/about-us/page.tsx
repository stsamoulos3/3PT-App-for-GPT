/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */
"use client";
import Button from "@/components/shared/Button";
import GridLayout from "@/components/shared/GridLayout";
import { useRouter } from "next/navigation";
import React from "react";

const Page = () => {
  const router = useRouter();
  return (
    <>
      <section className="md:flex  md:mt-8 mt-2 gap-8 h-full items-center justify-between ">
        <div className="md:w-[35%] animate-fadeIn  flex flex-col  md:gap-2 ">
          <h1 className="h1-semibold ">
            The{" "}
            <span className="italic h1-bold ">
              <span className="text-gray-900">3</span>
              <span className="text-blue-500">PT</span>
            </span>{" "}
          </h1>
          <h1 className="h1-semibold ">Difference</h1>
          <h1 className=" body2-regular">
            Revolutionizing Recovery, Redefining Wellbeing
          </h1>
        </div>
        <div className=" mt-4  h-full flex justify-end   flex-1 w-full ">
          <div className="relative">
            <img
              alt="graphic1"
              className="animate-fadeIn max-sm:hidden"
              src="/graphic/about-us/graphic1.webp"
            />
            <img
              alt="graphic2"
              className="animate-fadeIn sm:hidden"
              src="/graphic/about-us/graphic1-mobile.webp"
            />
            {/* <div className="animate-fadeInOut">
              <img
                className="absolute lg:top-[-30%] top-[-40%] left-[-13%] max-md:hidden  lg:left-[-12%]  animate-[spin_12s_linear_infinite] w-40 lg:w-52"
                src="/graphic/about-us/circle_.webp"
              />
            </div> */}
          </div>
        </div>
      </section>

      <GridLayout className="animate-fadeIn grid-cols-1 lg:grid-cols-2" gap={8}>
        <div className="    relative max-lg:row-start-2  w-full ">
          <img
            alt="graphic3"
            className=" 2xl:h-[56rem] object-cover rounded-3xl max-lg:hidden h-full w-full"
            src="/graphic/about-us/banner2.webp"
          />
          <img
            alt="graphic4"
            className=" h-full bg-cover lg:hidden w-full"
            src="/graphic/about-us/banner2-mobile.webp"
          />
          {/* <img
            className="absolute max-lg:hidden bottom-[-8.5%] max-md:hidden  right-[-16%]  xl:bottom-[-12%] xl:right-[-13%] animate-[spin_12s_linear_infinite] w-52"
            src="/graphic/about-us/circle_.webp"
          /> */}
        </div>

        <div className="flex-1 flex flex-col gap-4 ">
          <h1 className="hidden md:block h4-bold ">
            Welcome to{" "}
            <span className="italic font-bold">
              <span className="text-gray-900">3</span>
              <span className="text-blue-500">PT</span>
            </span>{" "}
          </h1>
          <div className="flex flex-col gap-3">
            <h1 className="h4-medium ">
              Empowering <span className="text-secondary-400">Your Health</span>
              , Elevating <span className="text-secondary-400">Your Life</span>
            </h1>
            <p className="small1-regular">
              At Three Point Healthcare (3PT), our name says it all. The &quot;3
              Points&quot; at the heart of our approach are Physical Therapy,
              Behavioral Health, and Nutritional Counseling. These three pillars
              work independently or in harmony to support your journey to
              long-term Wellbeing.
            </p>
            <p className="small1-regular">
              Whether you&apos;re recovering from injury, managing chronic pain,
              or looking to drive behavior change to build a healthier
              lifestyle, each of our services is designed to meet you exactly
              where you are. You can access any of our disciplines individually
              based on your goals, or combine them for a powerful,
              multidisciplinary approach to Wellbeing and weight loss that
              addresses your body, mind, and habits together.
            </p>
          </div>
          <div className="flex flex-col gap-3">
            <h1 className="h4-medium">A Unique Approach</h1>
            <p className="small1-regular">
              Our 5-star rated clinics aren’t just places to receive
              care—they’re where real transformation begins. Bright, modern, and
              welcoming, every 3PT location is built to empower you with expert
              guidance and evidence-based care. We don’t believe in rushed
              visits or one-size-fits-all treatment plans. We believe in people.
            </p>
            <p className="small1-regular">
              In Physical Therapy, you’ll find hands-on treatment and
              personalized exercise programs that restore movement and reduce
              pain with no referral needed. In Behavioral Health, our licensed
              therapists provide practical strategies to overcome stress,
              anxiety, and emotional barriers to healing. In Nutritional
              Counseling, our registered dietitians help you fuel your progress
              with plans rooted in science and tailored to your lifestyle.
            </p>
            <p className="small1-regular">
              When combined, these services create the foundation for our
              holistic Wellbeing and weight loss program—a fully integrated care
              plan that supports your physical, emotional, and metabolic health
              for sustainable results.
            </p>
          </div>
        </div>
      </GridLayout>

      <section className="">
        <div className="lg:flex items-center mb-6  gap-12  justify-between">
          <div className=" flex-1   ">
            <h1 className="h3-medium xl:flex items-start flex-col gap-2">
              Benefits of
              <span className="max-xl:ml-3">Choosing us.</span>
            </h1>
          </div>
          <div className="flex-1 body1-regular flex flex-col items-end lg:text-end ">
            <p>
              When you choose 3PT Healthcare, you’re not just getting
              treatment—you’re investing in a comprehensive, results-driven
              approach to your health.
            </p>
          </div>
        </div>

        <GridLayout className="lg:grid-cols-2 gap-4 md:gap-8 grid-cols-1">
          <div className="   h-full relative hidden lg:block w-full ">
            <img
              alt="graphic"
              className="object-cover rounded-3xl h-auto md:h-[42rem] w-full"
              src="/graphic/about-us/banner3.webp"
            />
          </div>
          <div className=" flex flex-col gap-8">
            <div className="    relative  w-full ">
              <img alt="graphic" src="/graphic/about-us/banner4.webp" />
            </div>
            <div className="flex-1">
              <h1 className="h3-medium font-semibold">
                Why{" "}
                <span>
                  {" "}
                  The{" "}
                  <span className="italic font-bold">
                    <span className="text-gray-900">3</span>
                    <span className="text-blue-500">PT</span>
                  </span>{" "}
                </span>{" "}
                Healthcare?
                <span className="block text-gray-500">
                  {" "}
                  The Smart Choice for Your Wellbeing{" "}
                </span>
              </h1>
              <p className="small1-regular">
                With multiple Chicagoland locations and telehealth options, it’s
                easier than ever to get the care you deserve. Experience the 3PT
                difference today: compassionate providers, proven outcomes, and
                a community built around your success.
              </p>
            </div>
            <Button
              onClick={() => {
                router.push("/schedule-appointment");
              }}
              type="submit"
              className="col-span-2 w-full bg-black text-white py-3 rounded-lg font-semibold transition"
            >
              Schedule Consultation Today
            </Button>
          </div>
        </GridLayout>
      </section>
    </>
  );
};

export default Page;
