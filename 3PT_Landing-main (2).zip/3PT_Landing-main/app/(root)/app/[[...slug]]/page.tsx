import React from "react";

const UniversalLinkPage = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 bg-gray-50 text-center">
      <h1 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
        Open in 3PT Healthcare App
      </h1>
      <p className="text-gray-600 mb-6 max-w-xl">
        If you have the app installed, the link below will open the app directly.
        Otherwise, you&apos;ll be redirected to the App Store.
      </p>

      <a
        href="3pthealthcare://home"
        className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-lg font-medium transition-all"
      >
        Open in App
      </a>

      <p className="text-sm text-gray-500 mt-6">
        Don’t have the app?{" "}
        <a
          href="https://apps.apple.com/us/app/3pt-healthcare/id6740134955"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:underline"
        >
          Download from the App Store
        </a>
      </p>
    </div>
  );
};

export default UniversalLinkPage;
