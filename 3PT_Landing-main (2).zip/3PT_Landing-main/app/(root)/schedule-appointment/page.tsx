import ContactUsSection from '@/components/shared/ContactUs'
import React from 'react'

const page = () => {
  return (
    <div className='sm:mt-12 mt-2 animate-fadeIn'>
        <ContactUsSection/>
    </div>
  )
}

export default page