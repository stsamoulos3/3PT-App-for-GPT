import { Metadata } from "next";
import { Manrope, Marcellus } from "next/font/google";
import "./globals.css";
import Script from "next/script";

const manrope = Manrope({
  subsets: ["latin"],
  weight: ["200", "300", "400", "500", "600", "700", "800"],
  variable: "--font-manrope",
});

const marcellus = Marcellus({
  subsets: ["latin"],
  weight: ["400"], // Marcellus has only one weight
  variable: "--font-marcellus",
});

export const metadata: Metadata = {
  title: "Three Point Healthcare",
  description:
    "Expert healthcare services including Physical Therapy, Behavioral Health, and Nutritional Counseling.",
  icons: [
    {
      rel: "icon",
      type: "image/png",
      sizes: "32x32",
      url: "/favicon.ico",
    },
    {
      rel: "icon",
      type: "image/png",
      sizes: "16x16",
      url: "/favicon.ico",
    },
    {
      rel: "apple-touch-icon",
      sizes: "180x180",
      url: "/favicon.ico",
    },
  ],
  manifest: "/site.webmanifest",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://3pthealthcare.com",
    siteName: "Three Point Healthcare",
    title: "Three Point Healthcare - Personalized Care for Your Well-Being",
    description:
      "Providing expert Physical Therapy, Behavioral Health support, and Nutritional Counseling to help you recover, manage pain, and improve overall Wellbeing.",
    images: [
      {
        url: "https://3pthealthcare.com/graphic/home/category1.webp",
        width: 1200,
        height: 630,
        alt: "Three Point Healthcare",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Three Point Healthcare - Personalized Care for Your Well-Being",
    description:
      "Expert care for Physical Therapy, Behavioral Health, and Nutritional Counseling—helping you achieve better health and a balanced lifestyle.",
    images: ["https://3pthealthcare.com/graphic/home/category1.webp"],
    creator: "@threepointhealth",
  },
  keywords: [
    "physical therapy",
    "behavioral health",
    "nutritional counseling",
    "healthcare services",
    "injury recovery",
    "mental Wellbeing",
    "pain management",
    "healthy living",
  ],
  authors: [{ name: "Three Point Healthcare Team" }],
  category: "Healthcare & Wellbeing",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="canonical" href="https://3pthealthcare.com" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "MedicalOrganization",
              name: "Three Point Healthcare",
              url: "https://3pthealthcare.com",
              logo: "https://3pthealthcare.com/logo.png",
              image: "https://3pthealthcare.com/graphic/home/category1.webp",
              telephone: "708-938-3378", // Replace with your real number
              address: {
                "@type": "PostalAddress",
                streetAddress: "19805 LaGrange Rd",
                addressLocality: "Mokena",
                addressRegion: "IL",
                postalCode: "60448",
                addressCountry: "US",
              },
              description:
                "Expert healthcare services including Physical Therapy, Behavioral Health, and Nutritional Counseling to support your complete well-being.",
              sameAs: [
                "https://www.facebook.com/3pthealthcare",
                "https://www.linkedin.com/company/11547232/admin/dashboard",
                "https://www.instagram.com/3pthealthcare",
                "https://www.youtube.com/@threepointhealthcare3454"
              ],
            }),
          }}
        />
        {/* Google Analytics */}
        <Script
          src="https://www.googletagmanager.com/gtag/js?id=G-CMW09SNSGY"
          strategy="afterInteractive"
        />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-CMW09SNSGY');
          `}
        </Script>
      </head>
      <body className={`${manrope.variable} ${marcellus.variable} antialiased`}>
        {children}
      </body>
    </html>
  );
}
