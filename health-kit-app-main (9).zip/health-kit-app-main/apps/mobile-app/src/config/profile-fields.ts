import { FormField } from "@/components/common/FormBuilder";

export interface ProfileForm {
  dob: string;
  gender: string;
  is3PTPatient: string;
  patientId?: string;
  isMultidisciplinaryPatient: string;
  rmr?: number;
  prescribedExerciseHR?: number;
  hourlyCaloriesAtHR?: number;
  prescribedDailyCalories?: number;
  vo2Max?: number;
}

export const profileFormFields: FormField<ProfileForm>[] = [
  {
    name: "dob",
    placeholder: "Date of Birth",
    type: "date",
    rules: { required: "Date of Birth is required" },
  },
  {
    name: "gender",
    placeholder: "Gender (Male/Female)",
    type: "select",
    options: [
      { label: "Male", value: "male" },
      { label: "Female", value: "female" },
    ],
    rules: { required: "Gender is required" },
    maximumDate: new Date(),
  },
  {
    name: "is3PTPatient",
    placeholder: "Are you a 3PT Patient?",
    type: "select",
    options: [
      { label: "Yes", value: "true" },
      { label: "No", value: "false" },
    ],
    rules: { required: "This field is required" },
  },
];

export const patientFormFieldsBuilder: (
  is3PTPatient: boolean
) => FormField<ProfileForm>[] = (is3PTPatient: boolean) => [
  {
    name: "patientId",
    placeholder: "Patient ID",
    rules: {
      required: is3PTPatient ? "Patient ID is required" : undefined,
    },
  },
  {
    name: "isMultidisciplinaryPatient",
    placeholder: "Are you a Multidisciplinary Patient?",
    type: "select",
    options: [
      { label: "Yes", value: "true" },
      { label: "No", value: "false" },
    ],
    rules: { required: "This field is required" },
  },
];

export const multidisciplinaryPatientFormFieldsBuilder: (
  isMultidisciplinaryPatient: boolean
) => FormField<ProfileForm>[] = (isMultidisciplinaryPatient: boolean) => [
  {
    name: "rmr",
    placeholder: "RMR",
    type: "number",
    keyboardType: "numeric",
    rules: {
      required: isMultidisciplinaryPatient ? "RMR is required" : undefined,
    },
  },
  {
    name: "prescribedExerciseHR",
    placeholder: "Prescribed Exercise HR",
    type: "number",
    keyboardType: "numeric",
    rules: {
      required: isMultidisciplinaryPatient
        ? "Prescribed Exercise HR is required"
        : undefined,
    },
  },
  {
    name: "hourlyCaloriesAtHR",
    placeholder: "Hourly Calories at HR",
    type: "number",
    keyboardType: "numeric",
    rules: {
      required: isMultidisciplinaryPatient
        ? "Hourly Calories at HR is required"
        : undefined,
    },
  },
  {
    name: "prescribedDailyCalories",
    placeholder: "Prescribed Daily Calories",
    type: "number",
    keyboardType: "numeric",
    rules: {
      required: isMultidisciplinaryPatient
        ? "Prescribed Daily Calories is required"
        : undefined,
    },
  },
  {
    name: "vo2Max",
    placeholder: "VO2 Max",
    type: "number",
    keyboardType: "numeric",
    rules: {
      required: isMultidisciplinaryPatient ? "VO2 Max is required" : undefined,
    },
  },
];
