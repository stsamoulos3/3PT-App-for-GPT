function formatNumberWithPostfix(number: number | string, digits = 1) {
	// For numbers less than 1000, return as is
	let num = number;

	if (typeof num === "string") {
		num = Number(num);
	}

	if (Math.abs(num) < 1000) {
		return num.toFixed(digits);
	}

	const units = ["k", "M", "B", "T", "P", "E", "Z", "Y"];
	const floor = Math.floor(Math.abs(num).toString().split(".")[0].length / 3);

	const value = num / 1000 ** floor;

	// Always show one decimal place unless it's a whole number
	const digitsToShow = Number.isInteger(value) ? 0 : 2;

	return (
		value.toLocaleString(undefined, {
			minimumFractionDigits: digitsToShow,
			maximumFractionDigits: digitsToShow,
		}) + units[floor - 1]
	);
}

export default formatNumberWithPostfix;
