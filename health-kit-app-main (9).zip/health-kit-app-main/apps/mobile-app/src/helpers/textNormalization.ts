/**
 * Text normalization utilities for handling special characters and Unicode variations
 */

// Character replacement map for common Unicode variations to ASCII
const UNICODE_TO_ASCII_MAP: Record<string, string> = {
  // Smart quotes
  "\u2018": "'", // Left single quotation mark
  "\u2019": "'", // Right single quotation mark
  "\u201C": '"', // Left double quotation mark
  "\u201D": '"', // Right double quotation mark
  "`": "'", // Grave accent
  "\u00B4": "'", // Acute accent

  // Dashes
  "–": "-", // En dash
  "—": "-", // Em dash
  "―": "-", // Horizontal bar

  // Spaces
  "\u00A0": " ", // Non-breaking space
  "\u2002": " ", // En space
  "\u2003": " ", // Em space
  "\u2009": " ", // Thin space

  // Other common characters
  "…": "...", // Horizontal ellipsis
  "•": "*", // Bullet
  "·": "*", // Middle dot
  "°": "deg", // Degree symbol
  "©": "(c)", // Copyright
  "®": "(r)", // Registered trademark
  "™": "(tm)", // Trademark

  // Accented characters (basic Latin)
  à: "a",
  á: "a",
  â: "a",
  ã: "a",
  ä: "a",
  å: "a",
  è: "e",
  é: "e",
  ê: "e",
  ë: "e",
  ì: "i",
  í: "i",
  î: "i",
  ï: "i",
  ò: "o",
  ó: "o",
  ô: "o",
  õ: "o",
  ö: "o",
  ù: "u",
  ú: "u",
  û: "u",
  ü: "u",
  ý: "y",
  ÿ: "y",
  ñ: "n",
  ç: "c",

  // Uppercase variants
  À: "A",
  Á: "A",
  Â: "A",
  Ã: "A",
  Ä: "A",
  Å: "A",
  È: "E",
  É: "E",
  Ê: "E",
  Ë: "E",
  Ì: "I",
  Í: "I",
  Î: "I",
  Ï: "I",
  Ò: "O",
  Ó: "O",
  Ô: "O",
  Õ: "O",
  Ö: "O",
  Ù: "U",
  Ú: "U",
  Û: "U",
  Ü: "U",
  Ý: "Y",
  Ÿ: "Y",
  Ñ: "N",
  Ç: "C",
};

/**
 * Normalizes Unicode characters to their ASCII equivalents
 * @param text The text to normalize
 * @returns Normalized text with ASCII characters
 */
export function normalizeToAscii(text: string): string {
  if (!text) return text;

  let normalized = text;

  // Replace characters using the mapping
  for (const [unicode, ascii] of Object.entries(UNICODE_TO_ASCII_MAP)) {
    normalized = normalized.replace(new RegExp(unicode, "g"), ascii);
  }

  return normalized;
}

/**
 * Normalizes text for search purposes
 * Combines Unicode normalization with additional cleaning
 * @param text The text to normalize for search
 * @returns Cleaned and normalized text for search
 */
export function normalizeForSearch(text: string): string {
  if (!text) return text;

  return normalizeToAscii(text)
    .toLowerCase() // Convert to lowercase
    .trim() // Remove leading/trailing whitespace
    .replace(/\s+/g, " "); // Collapse multiple spaces to single space
}

/**
 * Alternative approach using built-in Unicode normalization
 * followed by ASCII conversion
 * @param text The text to normalize
 * @returns Normalized text
 */
export function normalizeUnicode(text: string): string {
  if (!text) return text;

  return text
    .normalize("NFD") // Decompose Unicode characters
    .replace(/[\u0300-\u036f]/g, "") // Remove diacritical marks
    .replace(/[''`´]/g, "'") // Normalize quotes
    .replace(/[""]/g, '"') // Normalize double quotes
    .replace(/[–—―]/g, "-") // Normalize dashes
    .replace(/…/g, "...") // Normalize ellipsis
    .replace(/\u00A0/g, " "); // Replace non-breaking space
}

/**
 * Comprehensive normalization combining both approaches
 * @param text The text to normalize
 * @returns Fully normalized text
 */
export function normalizeText(text: string): string {
  if (!text) return text;

  // First apply Unicode normalization
  let normalized = normalizeUnicode(text);

  // Then apply character mapping for anything missed
  normalized = normalizeToAscii(normalized);

  return normalized;
}
