export const getBgColorFromName = (name: string) => {
  // Create a more consistent hash from the name
  const hash = name.split("").reduce((acc, char, index) => {
    return acc + char.charCodeAt(0) * (index + 1);
  }, 0);

  // Define a set of pleasing pastel colors
  const colorPalette = [
    "#FFD6E0", // Light Pink
    "#FFEFB5", // Light Yellow
    "#C1E1C1", // Light Green
    "#C4D7ED", // Light Blue
    "#D8C3E9", // Light Purple
    "#F0D1B5", // Light Orange
    "#B5EAD7", // Mint
    "#E2F0CB", // Light Lime
    "#C7CEEA", // Periwinkle
    "#FFC8DD", // Pink
  ];

  // Use the hash to select a color from the palette
  const colorIndex = hash % colorPalette.length;
  return colorPalette[colorIndex];
};
