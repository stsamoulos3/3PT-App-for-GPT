import React, { useEffect } from "react";
import useAuth from "@/hooks/useAuth";
import { router, useRootNavigationState } from "expo-router";
import { Text } from "@/components/ui/text";
import { View } from "react-native";

function index() {
  const { onboardingCompleted, isAuthenticated, user } = useAuth();

  const rootNavigationState = useRootNavigationState();

  useEffect(() => {
    if (!rootNavigationState?.key) {
      return;
    }

    if (!isAuthenticated) {
      return router.replace("/auth");
    }

    // Check if email is verified after authentication
    if (isAuthenticated && user && !user.emailVerified) {
      return router.replace("/(private)/email-verification-pending");
    }

    if (isAuthenticated && user && user.emailVerified) {
      return router.replace("/(private)/tabs");
    }
  }, [rootNavigationState?.key, isAuthenticated, user?.emailVerified]);

  return (
    <View className="flex-1 justify-center items-center bg-background-0">
      <Text>Loading...</Text>
    </View>
  );
}

export default index;
