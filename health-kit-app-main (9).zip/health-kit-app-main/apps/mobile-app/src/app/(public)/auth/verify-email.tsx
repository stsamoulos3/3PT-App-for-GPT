import React, { useState, useEffect } from "react";
import { Alert } from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { Box } from "@/components/ui/box";
import { VStack } from "@/components/ui/vstack";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { AuthService } from "@repo/core/services/AuthService";
import useAuth from "@/hooks/useAuth";

export default function VerifyEmailScreen() {
  const { token } = useLocalSearchParams<{ token: string }>();
  const [isLoading, setIsLoading] = useState(true);
  const [verificationStatus, setVerificationStatus] = useState<
    "initial" | "loading" | "success" | "error"
  >("initial");
  const [errorMessage, setErrorMessage] = useState("");
  const { isAuthenticated, getUser } = useAuth();

  useEffect(() => {
    if (!token) {
      setVerificationStatus("error");
      setErrorMessage("Invalid verification link");
      setIsLoading(false);
      return;
    }

    setVerificationStatus("loading");
    verifyEmail();
  }, [token]);

  const verifyEmail = async () => {
    try {
      console.log("[VerifyEmailScreen] verifying email");
      const result = await AuthService.verifyEmail({ token });

      if (result.message === "Email verified successfully") {
        setVerificationStatus("success");

        // If user is authenticated, refresh their data to update email verification status
        if (isAuthenticated) {
          try {
            await getUser();

            // Auto-redirect authenticated users after a short delay
            setTimeout(() => {
              router.replace("/(private)/tabs");
            }, 2000);
          } catch (error) {
            console.error("Failed to refresh user data:", error);
          }
        }
      } else {
        setVerificationStatus("error");
        setErrorMessage(result.message || "Email verification failed");
      }

      console.log("[VerifyEmailScreen] result", result);
    } catch (error) {
      console.error("Email verification error:", error);
      setVerificationStatus("error");
      setErrorMessage("Link is invalid or expired");
    } finally {
      setIsLoading(false);
    }
  };

  const handleContinue = () => {
    if (verificationStatus === "success") {
      if (isAuthenticated) {
        // User is already logged in, redirect to main app
        router.replace("/(private)/tabs");
      } else {
        // User is not logged in, show success message and redirect to sign in
        Alert.alert(
          "Welcome!",
          "Your email has been verified successfully. You can now sign in to your account.",
          [
            {
              text: "Sign In",
              onPress: () => router.replace("/auth"),
            },
          ]
        );
      }
    } else {
      router.replace("/auth");
    }
  };

  const handleResendVerification = () => {
    Alert.alert(
      "Resend Verification",
      "Would you like to go back to sign in and request a new verification email?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Yes",
          onPress: () => router.replace("/auth"),
        },
      ]
    );
  };

  if (verificationStatus === "initial") {
    return (
      <Box className="flex-1 bg-background-50 justify-center items-center">
        <Text>Invalid verification link</Text>
      </Box>
    );
  }

  if (verificationStatus === "loading") {
    return (
      <Box className="flex-1 bg-background-50 justify-center items-center">
        <VStack className="items-center">
          <Spinner size="large" />
          <Text className="text-lg text-center mt-4">
            Verifying your email...
          </Text>
          <Text className="text-sm text-center text-typography-500 mt-2">
            Please wait while we verify your email address
          </Text>
        </VStack>
      </Box>
    );
  }

  if (verificationStatus === "success") {
    return (
      <Box className="flex-1 bg-background-50 justify-center px-6">
        <VStack className="items-center">
          <Box className="bg-success-100 p-6 rounded-full items-center justify-center mb-6">
            <Text className="text-4xl text-success-700">✓</Text>
          </Box>

          <VStack className="items-center mb-8">
            <Text className="text-3xl font-bold text-center text-success-700 mb-2">
              Email Verified!
            </Text>

            <Text className="text-base text-center text-typography-500">
              Your email has been successfully verified. You can now access all
              features of the app.
            </Text>
          </VStack>

          <Button onPress={handleContinue} className="w-full">
            <ButtonText>
              {isAuthenticated ? "Continue to App" : "Continue to Sign In"}
            </ButtonText>
          </Button>
        </VStack>
      </Box>
    );
  }

  // Error state
  return (
    <Box className="flex-1 bg-background-50 justify-center px-6">
      <VStack className="items-center">
        <Box className="bg-error-100 p-6 rounded-full items-center justify-center mb-6">
          <Text className="text-4xl text-error-700">✗</Text>
        </Box>

        <VStack className="items-center mb-8">
          <Text className="text-3xl font-bold text-center text-error-700 mb-2">
            Verification Failed
          </Text>

          <Text className="text-base text-center text-typography-500">
            {errorMessage ||
              "We could not verify your email address. The link may be invalid or expired."}
          </Text>
        </VStack>

        <VStack className="w-full" space="md">
          <Button onPress={handleResendVerification} className="w-full">
            <ButtonText>Request New Verification</ButtonText>
          </Button>

          <Button
            variant="outline"
            onPress={() => router.replace("/auth")}
            className="w-full"
          >
            <ButtonText>Back to Sign In</ButtonText>
          </Button>
        </VStack>
      </VStack>
    </Box>
  );
}
