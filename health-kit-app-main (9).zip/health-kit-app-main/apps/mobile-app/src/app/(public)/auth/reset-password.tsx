import React, { useState, useEffect, useMemo } from "react";
import { Alert, KeyboardAvoidingView, Platform } from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { Box } from "@/components/ui/box";
import { VStack } from "@/components/ui/vstack";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { useForm } from "react-hook-form";
import FormBuilder, { FormField } from "@/components/common/FormBuilder";
import { AuthService } from "@repo/core/services/AuthService";

interface ResetPasswordFormData {
  newPassword: string;
  confirmPassword: string;
}

export default function ResetPasswordScreen() {
  const { token } = useLocalSearchParams<{ token: string }>();
  const [isLoading, setIsLoading] = useState(false);

  const { control, handleSubmit, formState, watch } =
    useForm<ResetPasswordFormData>();

  console.log("[ResetPasswordScreen] token", token);

  const getFormFields = (): FormField<ResetPasswordFormData>[] => {
    return [
      {
        name: "newPassword",
        placeholder: "Enter new password",
        type: "password",
        rules: {
          required: "Password is required",
          validate(value) {
            if (value.length < 8) {
              return "Password must be at least 8 characters";
            }
            return true;
          },
        },
      },
      {
        name: "confirmPassword",
        placeholder: "Confirm new password",
        type: "password",
        rules: {
          required: "Please confirm your password",
          validate: (value: string) => {
            const newPassword = watch("newPassword");
            return value === newPassword || "Passwords do not match";
          },
        },
      },
    ];
  };

  const formFields = useMemo(() => getFormFields(), [watch]);

  const handleResetPassword = async (data: ResetPasswordFormData) => {
    setIsLoading(true);

    try {
      const result = await AuthService.resetPassword({
        token,
        newPassword: data.newPassword,
      });

      console.log("[ResetPasswordScreen] result", result);

      if (result.message === "Password reset successfully") {
        Alert.alert(
          "Success!",
          "Your password has been reset successfully. You can now sign in with your new password.",
          [
            {
              text: "Sign In",
              onPress: () => router.replace("/auth"),
            },
          ]
        );
      } else {
        Alert.alert("Error", "Failed to reset password. Please try again.");
      }
    } catch (error) {
      console.error("Password reset error:", error);
      Alert.alert(
        "Error",
        "Network error. Please check your connection and try again."
      );
    } finally {
      setIsLoading(false);
    }
  };

  if (!token) {
    return (
      <Box className="flex-1 bg-background-50 justify-center items-center">
        <Spinner size="large" />
        <Text className="text-lg mt-4">Validating reset link...</Text>
      </Box>
    );
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-background-50"
    >
      <Box className="flex-1 justify-center px-6">
        <VStack className="w-full gap-4">
          <Text size="4xl" className="font-semibold text-primary-500">
            Reset Password
          </Text>

          <Text className="text-base text-typography-500 -mt-4">
            Enter your new password below
          </Text>

          <FormBuilder fields={formFields} control={control} />

          <Button
            className="h-14 w-full"
            disabled={formState.isSubmitting || isLoading}
            size="lg"
            onPress={handleSubmit(handleResetPassword)}
          >
            {formState.isSubmitting || isLoading ? (
              <Spinner />
            ) : (
              <ButtonText className="text-primary-0">Reset Password</ButtonText>
            )}
          </Button>

          <Button
            variant="outline"
            onPress={() => router.replace("/auth")}
            size="lg"
            className="h-14 w-full"
            disabled={formState.isSubmitting || isLoading}
          >
            <ButtonText>Back to Sign In</ButtonText>
          </Button>
        </VStack>
      </Box>
    </KeyboardAvoidingView>
  );
}
