import { Stack } from "expo-router";
import { HeartRateCard } from "@/components/screens/home/HeartRateCard";
import useGlobalStore from "@/store/global.store";

export default function PrivateLayout() {
	const { selectedDate } = useGlobalStore();

	return (
		<Stack
			screenOptions={{ headerShown: false }}
			initialRouteName="tabs"
			screenLayout={(props) => (
				<>
					<HeartRateCard
						startDate={selectedDate.startDate}
						endDate={selectedDate.endDate}
					/>
					{props.children}
				</>
			)}
		>
			<Stack.Screen name="tabs" />
			<Stack.Screen name="onboarding" />
			<Stack.Screen
				name="update-profile"
				options={{
					headerShown: true,
					title: "Update Profile",
					headerBackTitle: "Back",
				}}
			/>
			<Stack.Screen
				name="change-password"
				options={{
					headerShown: true,
					title: "Change Password",
					headerBackTitle: "Back",
				}}
			/>
			<Stack.Screen
				name="calorie-method-selection"
				options={{
					headerShown: true,
					title: "Calorie Method Selection",
					headerBackTitle: "Back",
				}}
			/>
			<Stack.Screen
				name="my-files"
				options={{
					headerShown: true,
					title: "My Files",
					headerBackTitle: "Back",
				}}
			/>
		</Stack>
	);
}
