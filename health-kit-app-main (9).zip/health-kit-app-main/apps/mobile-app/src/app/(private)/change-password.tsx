import { KeyboardAvoidingView, SafeAreaView, View } from "react-native";
import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { VStack } from "@/components/ui/vstack";
import { useForm } from "react-hook-form";
import FormBuilder, { type FormField } from "@/components/common/FormBuilder";
import useAuth from "@/hooks/useAuth";
import { useState } from "react";
import { Spinner } from "@/components/ui/spinner";
import { useToast } from "@/components/common/Toast";
import { router } from "expo-router";

interface ChangePasswordForm {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export default function ChangePasswordScreen() {
  const toast = useToast();
  const { changePassword } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { control, handleSubmit, watch } = useForm<ChangePasswordForm>({
    shouldFocusError: true,
  });

  const newPassword = watch("newPassword");

  const formFields: FormField<ChangePasswordForm>[] = [
    {
      name: "currentPassword",
      placeholder: "Current Password",
      type: "password",
      rules: { required: "Current password is required" },
    },
    {
      name: "newPassword",
      placeholder: "New Password",
      type: "password",
      rules: {
        required: "New password is required",
        validate: (value) =>
          value.length >= 8 || "Password must be at least 8 characters",
      },
    },
    {
      name: "confirmPassword",
      placeholder: "Confirm New Password",
      type: "password",
      rules: {
        required: "Please confirm your password",
        validate: (value) =>
          value === newPassword || "The passwords do not match",
      },
    },
  ];

  const onSubmit = async (values: ChangePasswordForm) => {
    setIsSubmitting(true);
    try {
      await changePassword(values);
      toast.success({
        message: "Password changed successfully",
      });
      router.back();
    } catch (error) {
      console.error(error);
      toast.error({
        message:
          "Failed to change password. Please check your current password and try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-background-50"
      behavior="padding"
      keyboardVerticalOffset={16}
    >
      <SafeAreaView className="flex-1 bg-background-50">
        <Box className="p-6 flex-1">
          <VStack className="gap-6 flex-1">
            {/* <Text size="3xl" className="font-bold text-typography-900">
              Change Password
            </Text> */}

            <Text size="lg" className="text-typography-600">
              Enter your current password and choose a new one
            </Text>

            <FormBuilder fields={formFields} control={control} showLabel />

            <View className=" w-full">
              <Button
                size="lg"
                variant="solid"
                className="bg-primary-500 w-full"
                onPress={handleSubmit(onSubmit)}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <Spinner size="small" />
                ) : (
                  <ButtonText>Change Password</ButtonText>
                )}
              </Button>
            </View>
          </VStack>
        </Box>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}
