import React, { useState, useRef, useEffect, useCallback } from "react";
import {
	View,
	ScrollView,
	Pressable,
	SafeAreaView,
	Animated,
	Linking,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { router, useFocusEffect } from "expo-router";
import { HStack } from "@/components/ui/hstack";
import { VStack } from "@/components/ui/vstack";
import { Text } from "@/components/ui/text";
import { Button } from "@/components/ui/button";
import { SearchBar } from "@/components/screens/record-nutrition/SearchBar";
import { CameraView, useCameraPermissions } from "expo-camera";
import { FoodItem } from "@/components/screens/record-nutrition/FoodItem";
import { AddFoodModal } from "@/components/screens/record-nutrition/AddFoodModal";
import { Toast, ToastTitle, useToast } from "@/components/ui/toast";
import type { Food } from "@repo/core/types/entities/food";
import { useFood } from "@/hooks/useFood";
import { StyleSheet } from "react-native";
import { useQuery } from "@tanstack/react-query";
import { normalizeForSearch } from "@/helpers/textNormalization";
import { QuickAddFoodModal } from "@/components/screens/record-nutrition/QuickAddFoodModal";

export default function RecordFoodScreen() {
	const [searchQuery, setSearchQuery] = useState("");
	const [cameraActive, setCameraActive] = useState(false);
	const [isAddModalOpen, setIsAddModalOpen] = useState(false);
	const [isQuickAddModalOpen, setIsQuickAddModalOpen] = useState(false);
	const [selectedFood, setSelectedFood] = useState<Food | null>(null);
	const [cameraSide, setCameraSide] = useState<"front" | "back">("back");
	const [hardFetch, setHardFetch] = useState(false);
	const [isBarcodeScan, setIsBarcodeScan] = useState(false);

	const {
		searchFoods,
		createFood,
		recordFoodConsumption,
		error,
		getRecentFoods,
	} = useFood();
	const toast = useToast();

	// Animation values
	const fadeAnim = useRef(new Animated.Value(0)).current;
	const slideAnim = useRef(new Animated.Value(50)).current;
	const buttonAnim = useRef(new Animated.Value(0)).current;

	useEffect(() => {
		// Animate content in when component mounts
		Animated.parallel([
			Animated.timing(fadeAnim, {
				toValue: 1,
				duration: 600,
				useNativeDriver: true,
			}),
			Animated.timing(slideAnim, {
				toValue: 0,
				duration: 600,
				useNativeDriver: true,
			}),
			Animated.spring(buttonAnim, {
				toValue: 1,
				friction: 7,
				tension: 40,
				useNativeDriver: true,
			}),
		]).start();
	}, [fadeAnim, slideAnim, buttonAnim]);
	const [identifiedBarcode, setIdentifiedBarcode] = useState<string | null>();
	const [debouncedSearchQuery, setDebouncedSearchQuery] = useState(searchQuery);

	const searchFood = useCallback(async () => {
		if (debouncedSearchQuery.trim()) {
			const normalizedQuery = normalizeForSearch(debouncedSearchQuery);
			const results = await searchFoods(
				normalizedQuery,
				identifiedBarcode || undefined,
				hardFetch,
			);
			setHardFetch(false);

			return results;
		}

		const results = await searchFoods("", identifiedBarcode || undefined);

		if (identifiedBarcode) {
			setIdentifiedBarcode(null);
		}
		return results as Food[];
	}, [identifiedBarcode, hardFetch, debouncedSearchQuery, searchFoods]);

	const { data: recentFoods, isLoading: isLoadingRecentFoods } = useQuery({
		queryKey: ["recentFoods", debouncedSearchQuery],
		queryFn: () => {
			const normalizedQuery = normalizeForSearch(debouncedSearchQuery);
			return getRecentFoods(5, normalizedQuery);
		},
	});

	const {
		data,
		isLoading: isLoadingSearch,
		refetch,
	} = useQuery({
		queryKey: ["searchFoods", debouncedSearchQuery, identifiedBarcode],
		queryFn: () => {
			return searchFood();
		},
	});

	useEffect(() => {
		const debounceTimeout = setTimeout(() => {
			setDebouncedSearchQuery(searchQuery);
		}, 500);
		return () => clearTimeout(debounceTimeout);
	}, [searchQuery]);

	const handleQuickAdd = (food: Food) => {
		setSelectedFood(food);
		setIsQuickAddModalOpen(true);
	};

	const handleAddFood = (food: Food) => {
		router.navigate(`/nutrition/food/${food.id}?serving=${food.serving}`);
	};

	const handleQuickAddSubmit = async (data: {
		servings: number;
		servingSize: string;
		meal: "BREAKFAST" | "LUNCH" | "DINNER" | "SNACK";
		date: Date;
	}) => {
		if (!selectedFood) return;

		const success = await recordFoodConsumption({
			foodId: selectedFood.id,
			...data,
		});

		if (success) {
			setIsQuickAddModalOpen(false);
			setSelectedFood(null);

			// Show success toast
			toast.show({
				placement: "top",
				render: ({ id }) => (
					<Toast nativeID={`toast-${id}`} action="primary" variant="solid">
						<ToastTitle>
							{selectedFood.foodName} added to {data.meal.toLowerCase()}! 🎉
						</ToastTitle>
					</Toast>
				),
			});
		}
	};

	const handleCreateFood = async (foodData: Omit<Food, "id">) => {
		const newFood = await createFood(foodData);
		if (newFood) {
			handleAddFood(newFood);
		}
	};

	const [permission, requestPermission] = useCameraPermissions();

	useEffect(() => {
		if (identifiedBarcode) {
			setCameraActive(false);
			setIsBarcodeScan(true);
			refetch();
		}
	}, [identifiedBarcode, refetch]);

	const handleHardFetch = () => {
		setHardFetch(true);
		setIsBarcodeScan(false);
		refetch();
	};

	if (cameraActive) {
		if (!permission) {
			// Camera permissions are still loading.
			return <View />;
		}

		if (!permission.granted) {
			return (
				<View className="flex-1 items-center justify-center p-4">
					<Text className="text-center text-lg font-semibold text-typography-900 mb-4">
						Camera Access Required
					</Text>
					<Text className="text-center text-typography-600 mb-6">
						We need camera access to scan food barcodes. This helps you quickly
						log your nutrition information.
					</Text>
					<Button
						onPress={permission.canAskAgain ? requestPermission : () => Linking.openSettings()}
						className="mb-4"
					>
						<Text className="text-white">Continue</Text>
					</Button>
				</View>
			);
		}

		return (
			<SafeAreaView className="flex-1 bg-background-50">
				<View style={styles.container}>
					<CameraView
						style={styles.camera}
						facing={cameraSide}
						onBarcodeScanned={(barcode) => {
							setIdentifiedBarcode(barcode.data);
						}}
						barcodeScannerSettings={{
							barcodeTypes: ["ean13", "ean8", "upc_a", "upc_e", "code128"],
						}}
					>
						<View className="flex-1 justify-center items-center">
							<View className="w-1/2 h-1/2 border-2 border-primary-500 rounded-lg bg-transparent" />
							<Text className="text-white text-center mt-4 text-lg font-semibold">
								Align barcode within the frame
							</Text>
						</View>
						<View style={styles.buttonContainer}>
							<Pressable
								style={styles.button}
								onPress={() =>
									setCameraSide((prev) => (prev === "front" ? "back" : "front"))
								}
							>
								<MaterialIcons
									name={cameraSide === "front" ? "camera-front" : "camera-rear"}
									size={24}
									color="white"
								/>
							</Pressable>
							<Pressable
								style={styles.button}
								onPress={() => setCameraActive(false)}
							>
								<MaterialIcons name="close" size={24} color="white" />
							</Pressable>
						</View>
					</CameraView>
				</View>
			</SafeAreaView>
		);
	}

	return (
		<SafeAreaView className="flex-1 bg-background-50">
			{/* Header */}
			<View className="p-4">
				<HStack className="mb-4 justify-between" space="sm">
					<Text size="3xl" className="font-bold text-typography-900">
						Record Food
					</Text>
					<Pressable
						onPress={() => router.back()}
						className="w-10 h-10 items-center justify-center rounded-full"
					>
						{/* <Text>Back</Text> */}
						<MaterialIcons name="arrow-back-ios" size={24} color="#4a7aff" />
					</Pressable>
				</HStack>
			</View>
			<SearchBar
				value={searchQuery}
				onChangeText={(text) => {
					setSearchQuery(text);
					setIsBarcodeScan(false);
				}}
				onScanPress={() => setCameraActive(true)}
			/>
			<VStack space="sm" className="flex-1 pt-3">
				{/* <Tabs activeTab={activeTab} onTabChange={setActiveTab} /> */}

				{/* Recent Foods Section */}
				<VStack className="px-4 flex-1" space="sm">
					<ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
						{recentFoods && recentFoods.length > 0 && (
							<HStack className="justify-between items-center">
								<Text className="text-lg font-semibold text-typography-900">
									Most Recent
								</Text>
							</HStack>
						)}
						{recentFoods &&
							recentFoods.length > 0 &&
							recentFoods.map((food: Food, index: number) => (
								<Animated.View
									key={food.id}
									style={{
										opacity: fadeAnim,
										transform: [
											{
												translateY: slideAnim.interpolate({
													inputRange: [0, 50],
													outputRange: [0, 10 * (index + 1)],
												}),
											},
										],
									}}
								>
									<FoodItem
										food={food}
										onAdd={handleAddFood}
										onQuickAdd={handleQuickAdd}
									/>
								</Animated.View>
							))}
						{data && data.length > 0 && (
							<HStack className="justify-between items-center">
								<Text className="text-lg font-semibold text-typography-900">
									All
								</Text>
							</HStack>
						)}
						{isLoadingSearch ? (
							<View className="flex-1 items-center justify-center py-8">
								<Text>Loading...</Text>
							</View>
						) : data?.length > 0 ? (
							data.map((food: Food, index: number) => (
								<Animated.View
									key={food.id}
									style={{
										opacity: fadeAnim,
										transform: [
											{
												translateY: slideAnim.interpolate({
													inputRange: [0, 50],
													outputRange: [0, 10 * (index + 1)],
												}),
											},
										],
									}}
								>
									<FoodItem
										food={food}
										onAdd={handleAddFood}
										onQuickAdd={handleQuickAdd}
									/>
								</Animated.View>
							))
						) : (
							<View className="flex-1 items-center justify-center py-8">
								{isBarcodeScan ? (
									<VStack space="md" className="items-center">
										<MaterialIcons
											name="error-outline"
											size={48}
											color="#ff6b6b"
										/>
										<Text className="text-lg font-semibold text-typography-900 text-center">
											No food found for this barcode
										</Text>
										<Text className="text-typography-600 text-center px-8">
											We couldn't find any matching food for the scanned
											barcode. Try searching manually or add this food yourself.
										</Text>
									</VStack>
								) : debouncedSearchQuery.trim() ? (
									<Text>No foods found for "{debouncedSearchQuery}"</Text>
								) : (
									<Text>
										No recent foods found. Start by searching for a food above.
									</Text>
								)}
							</View>
						)}
						<Pressable onPress={handleHardFetch}>
							<Text className="text-center text-sm text-typography-500 pt-4">
								Could not find the food? Tap here to search again
							</Text>
						</Pressable>
					</ScrollView>
				</VStack>
			</VStack>
			{/* Create Food Button - Floating */}
			<Pressable
				className="w-14 h-14 rounded-full bg-primary-500 items-center justify-center shadow-lg absolute bottom-8 right-8"
				onPress={() => setIsAddModalOpen(true)}
			>
				<MaterialIcons name="add" size={30} color="white" />
			</Pressable>
			<AddFoodModal
				isOpen={isAddModalOpen}
				onClose={() => setIsAddModalOpen(false)}
				onSubmit={handleCreateFood}
			/>
			<QuickAddFoodModal
				isOpen={isQuickAddModalOpen}
				onClose={() => {
					setIsQuickAddModalOpen(false);
					setSelectedFood(null);
				}}
				onSubmit={handleQuickAddSubmit}
				food={selectedFood}
			/>
		</SafeAreaView>
	);
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "black",
	},
	camera: {
		flex: 1,
	},
	buttonContainer: {
		position: "absolute",
		bottom: 40,
		left: 0,
		right: 0,
		flexDirection: "row",
		justifyContent: "space-around",
		paddingHorizontal: 20,
	},
	button: {
		width: 50,
		height: 50,
		borderRadius: 25,
		backgroundColor: "rgba(0,0,0,0.5)",
		justifyContent: "center",
		alignItems: "center",
	},
});
