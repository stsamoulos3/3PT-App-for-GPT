import React, { useEffect, useMemo, useState } from "react";
import { View, SafeAreaView, ScrollView, Pressable } from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { HStack } from "@/components/ui/hstack";
import { VStack } from "@/components/ui/vstack";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { Box } from "@/components/ui/box";
import { Food, FoodLog, Meal } from "@repo/core/types/entities/food";
import { useFood } from "@/hooks/useFood";
import { MaterialIcons, Feather } from "@expo/vector-icons";
import {
  Select,
  SelectBackdrop,
  SelectContent,
  SelectDragIndicator,
  SelectDragIndicatorWrapper,
  SelectInput,
  SelectItem,
  SelectPortal,
  SelectTrigger,
} from "@/components/ui/select";
import { ProgressFilledTrack } from "@/components/ui/progress";
import { Divider } from "@/components/ui/divider";
import FactGroup from "@/components/screens/food/FactGroup";
import {
  HealthService,
  NutritionToHKQuantityType,
  NutritionToHKUnit,
} from "@/services/HealthService";
import formatNumberWithPostfix from "@/helpers/formatNumberWithPostfix";
import { Progress } from "@/components/ui/progress";
import { getBgColorFromName } from "@/helpers/getColorFromName";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { NutritionService } from "@repo/core/services/NutritionService";
import useAuth from "@/hooks/useAuth";
import { HKQuantityTypeIdentifier } from "@kingstinct/react-native-healthkit";
import moment from "moment";

const metaKeys: (keyof Food)[] = [
  "serving",
  "brandName",
  "foodName",
  "id",
  "servingSize",
  "userId",
  "createdAt",
  "updatedAt",
  "nixId",
  "synced",
];

const MEAL_TYPES = ["BREAKFAST", "LUNCH", "DINNER", "SNACK"];

export default function EditFoodLogScreen() {
  const { accessToken } = useAuth();
  const { logId } = useLocalSearchParams();
  const { getFoodLogById, isLoading, error, updateFoodLog } = useFood();
  const [foodLog, setFoodLog] = useState<FoodLog | null>(null);
  const [servings, setServings] = useState(1);
  const [servingSize, setServingSize] = useState("");
  const [meal, setMeal] = useState<Meal>(Meal.Breakfast);
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateError, setUpdateError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);

  const queryClient = useQueryClient();
  const {
    data: foodLogData,
    isLoading: queryLoading,
    error: queryError,
  } = useQuery({
    queryKey: ["foodLog", logId],
    queryFn: () => getFoodLogById(logId as string),
    enabled: !!logId && !!accessToken,
  });

  useEffect(() => {
    if (foodLogData) {
      setFoodLog(foodLogData);
      setServings(foodLogData.servings);
      setServingSize(foodLogData.servingSize);
      setMeal(foodLogData.meal);
    }
  }, [foodLogData]);

  const handleUpdate = async () => {
    if (!foodLog) return;
    setIsUpdating(true);
    setUpdateError(null);
    const success = await updateFoodLog(foodLog.id, {
      servings,
      servingSize,
      meal,
    });

    setIsUpdating(false);
    if (success) {
      queryClient.invalidateQueries({ queryKey: ["foodLogs"] });
      router.back();
    } else {
      setUpdateError("Failed to update meal. Please try again.");
    }
  };

  const nutFacts = useMemo(() => {
    if (!foodLog?.food) return {};
    let nutFacts: Record<string, number> = {};

    let omitKeys: (keyof Food)[] = [
      ...metaKeys,
      "calories",
      "totalCarbohydrates",
      "totalFat",
      "protein",
    ];

    for (const key in foodLog?.food) {
      if (omitKeys.includes(key as keyof Food)) continue;
      Object.assign(nutFacts, {
        [key]: Number(foodLog?.food[key as keyof Food]) * Number(servings),
      });
    }
    return nutFacts;
  }, [foodLog, servings]);

  const carbsGroup = useMemo(() => {
    return {
      dietaryFiber: Number(foodLog?.food?.dietaryFiber) * Number(servings),
      sugars: Number(foodLog?.food?.sugars) * Number(servings),
      addedSugar: Number(foodLog?.food?.addedSugar) * Number(servings),
    };
  }, [foodLog, servings]);

  const fatGroup = useMemo(() => {
    return {
      transFat: Number(foodLog?.food?.transFat) * Number(servings),
      saturatedFat: Number(foodLog?.food?.saturatedFat) * Number(servings),
      polyunsaturatedFat:
        Number(foodLog?.food?.polyunsaturatedFat) * Number(servings),
      monounsaturatedFat:
        Number(foodLog?.food?.monounsaturatedFat) * Number(servings),
    };
  }, [foodLog, servings]);

  const vitaminsGroup = useMemo(() => {
    return {
      vitaminA: Number(foodLog?.food?.vitaminA) * Number(servings),
      vitaminC: Number(foodLog?.food?.vitaminC) * Number(servings),
      vitaminD: Number(foodLog?.food?.vitaminD) * Number(servings),
      vitaminE: Number(foodLog?.food?.vitaminE) * Number(servings),
      vitaminK: Number(foodLog?.food?.vitaminK) * Number(servings),
      vitaminB6: Number(foodLog?.food?.vitaminB6) * Number(servings),
      vitaminB12: Number(foodLog?.food?.vitaminB12) * Number(servings),
    };
  }, [foodLog, servings]);

  const mineralsGroup = useMemo(() => {
    return {
      calcium: Number(foodLog?.food?.calcium) * Number(servings),
      iron: Number(foodLog?.food?.iron) * Number(servings),
      sodium: Number(foodLog?.food?.sodium) * Number(servings),
      potassium: Number(foodLog?.food?.potassium) * Number(servings),
      phosphorus: Number(foodLog?.food?.phosphorus) * Number(servings),
      selenium: Number(foodLog?.food?.selenium) * Number(servings),
      zinc: Number(foodLog?.food?.zinc) * Number(servings),
    };
  }, [foodLog, servings]);

  if (queryLoading || !foodLog) {
    return (
      <SafeAreaView className="flex-1 bg-background-50">
        <View className="flex-1 items-center justify-center">
          <Text>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-background-50">
      {/* Header */}
      <View className="p-4">
        <HStack className="mb-4 justify-between" space="sm">
          <Text size="3xl" className="font-bold text-typography-900">
            Edit Meal
          </Text>
          <Pressable
            onPress={() => router.back()}
            className="w-10 h-10 items-center justify-center rounded-full"
          >
            <MaterialIcons name="arrow-back-ios" size={24} color="#4a7aff" />
          </Pressable>
        </HStack>
      </View>
      <ScrollView className="flex-1 pt-4" showsVerticalScrollIndicator={false}>
        {/* Food Info Card */}
        {/* Food Card */}
        <Box className="mx-4 mb-4 bg-white rounded-2xl shadow-soft-1 p-4 border border-gray-100">
          <VStack className="space-y-2">
            <Text className="text-2xl font-bold text-typography-900">
              {foodLog?.food?.foodName}
            </Text>
            <Text className="text-typography-500">
              Basic nutritional information
            </Text>

            {/* Nutrition Circle */}
            <HStack className="items-center justify-between mt-4">
              <Box className="items-center">
                <View className="w-28 h-28 rounded-full bg-gray-50 items-center justify-center overflow-hidden">
                  {/* Custom pie chart visualization */}
                  <View className="absolute w-full h-full">
                    <View className="absolute w-full h-full bg-primary-500" />
                  </View>
                  <View className="w-24 h-24 rounded-full bg-white items-center justify-center">
                    <Text className="text-3xl font-bold text-primary-500">
                      {formatNumberWithPostfix(
                        Number(foodLog?.food?.calories) * Number(servings)
                      )}
                    </Text>
                    <Text className="text-typography-500 text-xs">
                      calories
                    </Text>
                  </View>
                </View>
              </Box>

              <VStack className="space-y-3 flex-1 ml-4">
                {/* Macros Legend */}
                <HStack className="items-center" space="sm">
                  <Box
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor: getBgColorFromName("Carbs"),
                    }}
                  />
                  <Text className="text-typography-900 flex-1">Carbs</Text>
                  <Text className="text-typography-900 font-semibold">
                    {(
                      Number(foodLog?.food?.totalCarbohydrates) *
                      Number(servings)
                    ).toFixed(1)}
                    g
                  </Text>
                </HStack>
                <HStack className="items-center" space="sm">
                  <Box
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor: getBgColorFromName("Fat"),
                    }}
                  />
                  <Text className="text-typography-900 flex-1">Fat</Text>
                  <Text className="text-typography-900 font-semibold">
                    {Number(
                      Number(foodLog?.food?.totalFat) * Number(servings)
                    ).toFixed(1)}
                    g
                  </Text>
                </HStack>
                <HStack className="items-center" space="sm">
                  <Box
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor: getBgColorFromName("Protein"),
                    }}
                  />
                  <Text className="text-typography-900 flex-1">Protein</Text>
                  <Text className="text-typography-900 font-semibold">
                    {(
                      Number(foodLog?.food?.protein) * Number(servings)
                    ).toFixed(1)}
                    g
                  </Text>
                </HStack>
              </VStack>
            </HStack>
          </VStack>
        </Box>
        {/* Serving & Meal Controls */}
        <Box className="mx-4 mb-4 bg-white rounded-xl shadow-soft-1 p-4 border border-gray-100">
          <VStack space="md">
            <Text className="text-lg font-semibold text-typography-900">
              Serving Information
            </Text>

            {/* Number of Servings */}
            <HStack className="justify-between items-center">
              <Text className="text-typography-900">Number of Servings</Text>
              <Select
                selectedValue={servings.toString()}
                onValueChange={(value) => setServings(Number(value))}
                className="flex-1 w-full max-w-52"
              >
                <SelectTrigger variant="outline" size="md" className="flex-1">
                  <SelectInput
                    placeholder="Select servings"
                    className="flex-1"
                  />
                  <Feather
                    name="chevron-down"
                    size={16}
                    className="self-center pr-2"
                  />
                </SelectTrigger>
                <SelectPortal snapPoints={[60]}>
                  <SelectBackdrop />
                  <SelectContent>
                    <SelectDragIndicatorWrapper>
                      <SelectDragIndicator />
                    </SelectDragIndicatorWrapper>
                    <ScrollView className="flex-1 w-full">
                      {Array.from({ length: 40 }, (_, i) => (i + 1) * 0.5).map(
                        (amount) => (
                          <SelectItem
                            key={amount.toString()}
                            value={amount.toString()}
                            label={amount.toString()}
                          />
                        )
                      )}
                      <Box className="h-16" />
                    </ScrollView>
                  </SelectContent>
                </SelectPortal>
              </Select>
            </HStack>

            {/* Meal */}
            <HStack className="justify-between items-center">
              <Text className="text-typography-900">Meal</Text>
              <Select
                selectedValue={meal}
                onValueChange={(value) => setMeal(value as Meal)}
                className="flex-1 w-full max-w-52"
              >
                <SelectTrigger variant="outline" size="md" className="flex-1">
                  <SelectInput placeholder="Select meal" className="flex-1" />
                  <Feather
                    name="chevron-down"
                    size={16}
                    className="self-center pr-2"
                  />
                </SelectTrigger>
                <SelectPortal>
                  <SelectBackdrop />
                  <SelectContent>
                    <SelectDragIndicatorWrapper>
                      <SelectDragIndicator />
                    </SelectDragIndicatorWrapper>
                    {["Breakfast", "Lunch", "Dinner", "Snack"].map(
                      (mealType) => (
                        <SelectItem
                          key={mealType}
                          label={mealType}
                          value={mealType.toUpperCase()}
                        />
                      )
                    )}
                    <Box className="h-8" />
                  </SelectContent>
                </SelectPortal>
              </Select>
            </HStack>
          </VStack>
        </Box>
        {/* Detailed Nutrition Facts */}
        <Box className="mx-4 mb-4 bg-white rounded-2xl shadow-soft-1 p-4 border border-gray-100">
          <VStack className="space-y-4">
            <Pressable onPress={() => setExpanded(!expanded)}>
              <HStack className="justify-between items-center">
                <Text className="text-lg font-semibold text-typography-900">
                  Nutrition Facts
                </Text>
                <View className="w-8 h-8 items-center justify-center rounded-full bg-[#e6efff]">
                  <MaterialIcons
                    name={expanded ? "expand-less" : "expand-more"}
                    size={24}
                    color="#4a7aff"
                  />
                </View>
              </HStack>
            </Pressable>

            {expanded && (
              <VStack space="md" className="mt-4">
                <Divider />

                {/* Fat */}
                <FactGroup title="Fat" data={fatGroup} />
                {/* Carbs */}
                <FactGroup title="Carbohydrates" data={carbsGroup} />
                {/* Minerals */}
                <FactGroup title="Minerals" data={mineralsGroup} />
                {/* Vitamins */}
                <FactGroup title="Vitamins" data={vitaminsGroup} />

                <Text className="text-typography-900 font-medium">
                  Additional Information
                </Text>
                {Object.entries(nutFacts)
                  .filter(
                    ([key]) =>
                      !metaKeys.includes(key as keyof Food) &&
                      ![
                        ...Object.keys(carbsGroup),
                        ...Object.keys(fatGroup),
                        ...Object.keys(vitaminsGroup),
                        ...Object.keys(mineralsGroup),
                      ].includes(key as string)
                  )
                  .map(([key, value], index) => (
                    <VStack key={index} space="xs">
                      <HStack className="justify-between">
                        <Text className="text-typography-900">
                          {key.charAt(0).toUpperCase() + key.slice(1)}
                        </Text>
                        <Text className="text-typography-900">
                          {value
                            ? `${formatNumberWithPostfix(value)} ${
                                NutritionToHKUnit[
                                  key as keyof typeof NutritionToHKUnit
                                ]
                              }`
                            : "-"}
                        </Text>
                      </HStack>
                      <Progress
                        value={value}
                        max={100}
                        className="h-1 bg-gray-200"
                      >
                        <ProgressFilledTrack className="h-1 bg-[#4a7aff]" />
                      </Progress>
                    </VStack>
                  ))}
              </VStack>
            )}
          </VStack>
        </Box>
        {/* Error Message */}
        {updateError && (
          <Text className="text-red-500 text-center mt-2">{updateError}</Text>
        )}
      </ScrollView>
      {/* Update Button */}
      <View className="px-4 pb-4">
        <Button
          className="h-12 mx-auto rounded-xl w-full"
          onPress={handleUpdate}
          disabled={isUpdating}
        >
          <ButtonText className="text-white font-semibold">
            {isUpdating ? "Updating..." : "Update Meal"}
          </ButtonText>
        </Button>
      </View>
    </SafeAreaView>
  );
}
