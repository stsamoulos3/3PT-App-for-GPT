import React, { useState, useEffect, useMemo } from "react";
import { View, ScrollView, Pressable, SafeAreaView } from "react-native";
import { Feather, MaterialIcons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { HStack } from "@/components/ui/hstack";
import { VStack } from "@/components/ui/vstack";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { Box } from "@/components/ui/box";
import { Progress, ProgressFilledTrack } from "@/components/ui/progress";
import { Divider } from "@/components/ui/divider";
import {
  Select,
  SelectBackdrop,
  SelectContent,
  SelectDragIndicator,
  SelectDragIndicatorWrapper,
  SelectInput,
  SelectItem,
  SelectPortal,
  SelectTrigger,
} from "@/components/ui/select";
import { Input, InputField } from "@/components/ui/input";
import { Food } from "@repo/core/types/entities/food";
import { getBgColorFromName } from "@/helpers/getColorFromName";
import { useFood } from "@/hooks/useFood";
import formatNumberWithPostfix from "@/helpers/formatNumberWithPostfix";
import {
  HealthService,
  NutritionToHKQuantityType,
  NutritionToHKUnit,
} from "@/services/HealthService";
import { HKQuantityTypeIdentifier } from "@kingstinct/react-native-healthkit";
import FactGroup from "@/components/screens/food/FactGroup";
import moment from "moment";
import DatePicker from "react-native-date-picker";

const metaKeys: (keyof Food)[] = [
  "serving",
  "brandName",
  "foodName",
  "id",
  "servingSize",
  "userId",
  "createdAt",
  "updatedAt",
  "nixId",
  "synced",
];

export default function FoodDetailScreen() {
  const { id, serving } = useLocalSearchParams();
  const [food, setFood] = useState<Food | null>(null);
  const [servings, setServings] = useState(serving ?? "1");
  const [servingSize, setServingSize] = useState("1.0 Cup");
  const [expanded, setExpanded] = useState(false);
  const [meal, setMeal] = useState<"BREAKFAST" | "LUNCH" | "DINNER" | "SNACK">(
    "BREAKFAST"
  );
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const { getFoodById, recordFoodConsumption, error } = useFood();

  const loadFood = async (hardFetch?: boolean) => {
    if (typeof id === "string") {
      const foodData = await getFoodById(id, hardFetch);
      if (foodData) {
        setFood(foodData);
        setServingSize(foodData.servingSize!);
      }
    }
    setIsLoading(false);
  };

  useEffect(() => {
    loadFood();
  }, [id]);

  const hardRefresh = async () => {
    setIsLoading(true);
    await loadFood(true);
    setIsLoading(false);
  };

  const handleAddToLog = async () => {
    if (!food) return;

    const success = await recordFoodConsumption({
      foodId: food.id,
      servings: Number(servings),
      servingSize,
      meal,
      date: selectedDate,
    });

    if (!success) return;

    // Object.keys(food).forEach(async (key) => {
    //   if (metaKeys.includes(key as keyof Food)) return;
    //   if (Number(food[key as keyof Food]) === 0) return;
    //   if (
    //     !NutritionToHKQuantityType[
    //       key as keyof typeof NutritionToHKQuantityType
    //     ]
    //   )
    //     return;

    //   await HealthService.saveNutritionData({
    //     quantityType: NutritionToHKQuantityType[
    //       key as keyof typeof NutritionToHKQuantityType
    //     ] as unknown as HKQuantityTypeIdentifier,
    //     unit: NutritionToHKUnit[key as keyof typeof NutritionToHKUnit],
    //     value: Number(food[key as keyof Food]) * Number(servings),
    //     timestamp: selectedDate.toISOString(),
    //   });
    // });

    if (success) {
      router.navigate("/");
    }
  };

  const nutFacts = useMemo(() => {
    if (!food) return {};
    let nutFacts: Record<string, number> = {};

    let omitKeys: (keyof Food)[] = [
      ...metaKeys,
      "calories",
      "totalCarbohydrates",
      "totalFat",
      "protein",
    ];

    for (const key in food) {
      if (omitKeys.includes(key as keyof Food)) continue;
      Object.assign(nutFacts, {
        [key]: Number(food[key as keyof Food]) * Number(servings),
      });
    }
    return nutFacts;
  }, [food, servings]);

  const carbsGroup = useMemo(() => {
    return {
      dietaryFiber: Number(food?.dietaryFiber) * Number(servings),
      sugars: Number(food?.sugars) * Number(servings),
      addedSugar: Number(food?.addedSugar) * Number(servings),
    };
  }, [food, servings]);

  const fatGroup = useMemo(() => {
    return {
      transFat: Number(food?.transFat) * Number(servings),
      saturatedFat: Number(food?.saturatedFat) * Number(servings),
      polyunsaturatedFat: Number(food?.polyunsaturatedFat) * Number(servings),
      monounsaturatedFat: Number(food?.monounsaturatedFat) * Number(servings),
    };
  }, [food, servings]);

  const vitaminsGroup = useMemo(() => {
    return {
      vitaminA: Number(food?.vitaminA) * Number(servings),
      vitaminC: Number(food?.vitaminC) * Number(servings),
      vitaminD: Number(food?.vitaminD) * Number(servings),
      vitaminE: Number(food?.vitaminE) * Number(servings),
      vitaminK: Number(food?.vitaminK) * Number(servings),
      vitaminB6: Number(food?.vitaminB6) * Number(servings),
      vitaminB12: Number(food?.vitaminB12) * Number(servings),
    };
  }, [food, servings]);

  const mineralsGroup = useMemo(() => {
    return {
      calcium: Number(food?.calcium) * Number(servings),
      iron: Number(food?.iron) * Number(servings),
      sodium: Number(food?.sodium) * Number(servings),
      potassium: Number(food?.potassium) * Number(servings),
      phosphorus: Number(food?.phosphorus) * Number(servings),
      selenium: Number(food?.selenium) * Number(servings),
      zinc: Number(food?.zinc) * Number(servings),
    };
  }, [food, servings]);

  if (isLoading) {
    return (
      <SafeAreaView className="flex-1 bg-background-50">
        <View className="flex-1 items-center justify-center">
          <Text>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!food) {
    return (
      <SafeAreaView className="flex-1 bg-background-50">
        <View className="flex-1 items-center justify-center">
          <Text>Food not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-background-50">
      {/* Header */}
      <View className="p-4">
        <HStack className="mb-4 justify-between" space="sm">
          <Text size="3xl" className="font-bold text-typography-900">
            Food Details
          </Text>
          <Pressable
            onPress={() => router.back()}
            className="w-10 h-10 items-center justify-center rounded-full"
          >
            <MaterialIcons name="arrow-back-ios" size={24} color="#4a7aff" />
          </Pressable>
        </HStack>
      </View>
      <ScrollView className="flex-1 pt-4" showsVerticalScrollIndicator={false}>
        {/* Food Card */}
        <Box className="mx-4 mb-4 bg-white rounded-2xl shadow-soft-1 p-4 border border-gray-100">
          <VStack className="space-y-2">
            <Text className="text-2xl font-bold text-typography-900">
              {food.foodName}
            </Text>
            <Text className="text-typography-500">
              Basic nutritional information
            </Text>

            {/* Nutrition Circle */}
            <HStack className="items-center justify-between mt-4">
              <Box className="items-center">
                <View className="w-28 h-28 rounded-full bg-gray-50 items-center justify-center overflow-hidden">
                  {/* Custom pie chart visualization */}
                  <View className="absolute w-full h-full">
                    <View className="absolute w-full h-full bg-primary-500" />
                  </View>
                  <View className="w-24 h-24 rounded-full bg-white items-center justify-center">
                    <Text className="text-3xl font-bold text-primary-500">
                      {formatNumberWithPostfix(
                        Number(food.calories) * Number(servings)
                      )}
                    </Text>
                    <Text className="text-typography-500 text-xs">
                      calories
                    </Text>
                  </View>
                </View>
              </Box>

              <VStack className="space-y-3 flex-1 ml-4">
                {/* Macros Legend */}
                <HStack className="items-center" space="sm">
                  <Box
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor: getBgColorFromName("Carbs"),
                    }}
                  />
                  <Text className="text-typography-900 flex-1">Carbs</Text>
                  <Text className="text-typography-900 font-semibold">
                    {(
                      Number(food.totalCarbohydrates) * Number(servings)
                    ).toFixed(1)}
                    g
                  </Text>
                </HStack>
                <HStack className="items-center" space="sm">
                  <Box
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor: getBgColorFromName("Fat"),
                    }}
                  />
                  <Text className="text-typography-900 flex-1">Fat</Text>
                  <Text className="text-typography-900 font-semibold">
                    {Number(Number(food.totalFat) * Number(servings)).toFixed(
                      1
                    )}
                    g
                  </Text>
                </HStack>
                <HStack className="items-center" space="sm">
                  <Box
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor: getBgColorFromName("Protein"),
                    }}
                  />
                  <Text className="text-typography-900 flex-1">Protein</Text>
                  <Text className="text-typography-900 font-semibold">
                    {(Number(food.protein) * Number(servings)).toFixed(1)}g
                  </Text>
                </HStack>
              </VStack>
            </HStack>
          </VStack>
        </Box>

        {/* Serving Information */}
        <Box className="mx-4 mb-4 bg-white rounded-xl shadow-soft-1 p-4 border border-gray-100">
          <VStack space="md">
            <Text className="text-lg font-semibold text-typography-900">
              Serving Information
            </Text>

            {/* Number of Servings */}
            <HStack className="justify-between items-center">
              <Text className="text-typography-900">Number of Servings</Text>
              <Select
                selectedValue={servings.toString()}
                onValueChange={(value) => setServings(value)}
                className="flex-1 w-full max-w-52"
              >
                <SelectTrigger variant="outline" size="md" className="flex-1">
                  <SelectInput
                    placeholder="Select servings"
                    className="flex-1"
                  />
                  <Feather
                    name="chevron-down"
                    size={16}
                    className="self-center pr-2"
                  />
                </SelectTrigger>
                <SelectPortal snapPoints={[60]}>
                  <SelectBackdrop />
                  <SelectContent>
                    <SelectDragIndicatorWrapper>
                      <SelectDragIndicator />
                    </SelectDragIndicatorWrapper>
                    <ScrollView className="flex-1 w-full">
                      {Array.from({ length: 40 }, (_, i) => (i + 1) * 0.5).map(
                        (amount) => (
                          <SelectItem
                            key={amount.toString()}
                            value={amount.toString()}
                            label={amount.toString()}
                          />
                        )
                      )}
                      <Box className="h-16" />
                    </ScrollView>
                  </SelectContent>
                </SelectPortal>
              </Select>
            </HStack>

            {/* Meal */}
            <HStack className="justify-between items-center">
              <Text className="text-typography-900">Meal</Text>
              <Select
                selectedValue={meal}
                onValueChange={(value) => setMeal(value as typeof meal)}
                className="flex-1 w-full max-w-52"
              >
                <SelectTrigger variant="outline" size="md" className="flex-1">
                  <SelectInput placeholder="Select meal" className="flex-1" />
                  <Feather
                    name="chevron-down"
                    size={16}
                    className="self-center pr-2"
                  />
                </SelectTrigger>
                <SelectPortal>
                  <SelectBackdrop />
                  <SelectContent>
                    <SelectDragIndicatorWrapper>
                      <SelectDragIndicator />
                    </SelectDragIndicatorWrapper>
                    {["Breakfast", "Lunch", "Dinner", "Snack"].map((meal) => (
                      <SelectItem
                        key={meal}
                        label={meal}
                        value={meal.toUpperCase()}
                      />
                    ))}
                    <Box className="h-8" />
                  </SelectContent>
                </SelectPortal>
              </Select>
            </HStack>

            {/* Date Selection */}
            <VStack space="sm">
              <Text className="text-typography-900">Date</Text>
              <Pressable
                onPress={() => setShowDatePicker(true)}
                className="flex-row items-center px-4 py-3 bg-background-100 rounded-lg border border-background-200"
                style={{ minHeight: 48 }}
              >
                <Feather
                  name="calendar"
                  size={20}
                  color="#4176CC"
                  style={{ marginRight: 10 }}
                />
                <Text size="lg" className="text-typography-900 flex-1">
                  {moment(selectedDate).format("MMMM D, YYYY")}
                </Text>
              </Pressable>
              <HStack space="sm" className="flex-wrap">
                <Button
                  variant="outline"
                  size="sm"
                  onPress={() => setSelectedDate(new Date())}
                >
                  <ButtonText>Today</ButtonText>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onPress={() =>
                    setSelectedDate(moment().add(1, "day").toDate())
                  }
                >
                  <ButtonText>Tomorrow</ButtonText>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onPress={() =>
                    setSelectedDate(moment().subtract(1, "day").toDate())
                  }
                >
                  <ButtonText>Yesterday</ButtonText>
                </Button>
              </HStack>
            </VStack>
          </VStack>
        </Box>

        {/* Detailed Nutrition Facts */}
        <Box className="mx-4 mb-4 bg-white rounded-2xl shadow-soft-1 p-4 border border-gray-100">
          <VStack className="space-y-4">
            <Pressable onPress={() => setExpanded(!expanded)}>
              <HStack className="justify-between items-center">
                <Text className="text-lg font-semibold text-typography-900">
                  Nutrition Facts
                </Text>
                <View className="w-8 h-8 items-center justify-center rounded-full bg-[#e6efff]">
                  <MaterialIcons
                    name={expanded ? "expand-less" : "expand-more"}
                    size={24}
                    color="#4a7aff"
                  />
                </View>
              </HStack>
            </Pressable>

            {expanded && (
              <VStack space="md" className="mt-4">
                <Divider />

                {/* Fat */}
                <FactGroup title="Fat" data={fatGroup} />
                {/* Carbs */}
                <FactGroup title="Carbohydrates" data={carbsGroup} />
                {/* Minerals */}
                <FactGroup title="Minerals" data={mineralsGroup} />
                {/* Vitamins */}
                <FactGroup title="Vitamins" data={vitaminsGroup} />

                <Text className="text-typography-900 font-medium">
                  Additional Information
                </Text>
                {Object.entries(nutFacts)
                  .filter(
                    ([key]) =>
                      !metaKeys.includes(key as keyof Food) &&
                      ![
                        ...Object.keys(carbsGroup),
                        ...Object.keys(fatGroup),
                        ...Object.keys(vitaminsGroup),
                        ...Object.keys(mineralsGroup),
                      ].includes(key as string)
                  )
                  .map(([key, value], index) => (
                    <VStack key={index} space="xs">
                      <HStack className="justify-between">
                        <Text className="text-typography-900">
                          {key.charAt(0).toUpperCase() + key.slice(1)}
                        </Text>
                        <Text className="text-typography-900">
                          {value
                            ? `${formatNumberWithPostfix(value)} ${
                                NutritionToHKUnit[
                                  key as keyof typeof NutritionToHKUnit
                                ]
                              }`
                            : "-"}
                        </Text>
                      </HStack>
                      <Progress
                        value={value}
                        max={100}
                        className="h-1 bg-gray-200"
                      >
                        <ProgressFilledTrack className="h-1 bg-[#4a7aff]" />
                      </Progress>
                    </VStack>
                  ))}
              </VStack>
            )}
          </VStack>
        </Box>
        <Button onPress={hardRefresh} className="mx-4 mb-8" variant="link">
          <ButtonText>Missing some nutrients? Click here to refresh</ButtonText>
        </Button>
      </ScrollView>
      {/* Add Button */}
      <View className="px-4">
        <Button
          className="h-12 mx-auto rounded-xl w-full"
          onPress={handleAddToLog}
        >
          <Text className="text-white font-semibold mr-2">+</Text>
          <ButtonText className="text-white font-semibold">
            Add to Food Log
          </ButtonText>
        </Button>
      </View>

      {/* Date Picker */}
      <DatePicker
        modal
        mode="date"
        open={showDatePicker}
        date={selectedDate}
        onConfirm={(date) => {
          setShowDatePicker(false);
          setSelectedDate(date);
        }}
        onCancel={() => setShowDatePicker(false)}
      />
    </SafeAreaView>
  );
}
