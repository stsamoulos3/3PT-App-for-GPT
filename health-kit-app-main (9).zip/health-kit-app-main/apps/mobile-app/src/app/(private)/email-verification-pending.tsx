import React, { useState, useEffect } from "react";
import { Box } from "@/components/ui/box";
import { VStack } from "@/components/ui/vstack";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import useAuth from "@/hooks/useAuth";
import { useToast } from "@/components/common/Toast";
import { FontAwesome5 } from "@expo/vector-icons";
import { Icon } from "@/components/ui/icon";
import { router } from "expo-router";

export default function EmailVerificationPendingScreen() {
  const [isResending, setIsResending] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { user, resendVerification, handleLogout, getUser } = useAuth();
  const toast = useToast();

  // Check if email is verified when user returns to the app or screen
  useEffect(() => {
    if (user?.emailVerified) {
      router.replace("/(private)/tabs");
    }
  }, [user?.emailVerified]);

  const handleRefreshStatus = async () => {
    setIsRefreshing(true);
    try {
      await getUser();
      toast.success({ message: "Status refreshed" });
    } catch (error: any) {
      toast.error({
        message: error.message || "Failed to refresh status",
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleResendVerification = async () => {
    if (!user?.email) {
      toast.error({ message: "Email not found" });
      return;
    }

    setIsResending(true);
    try {
      await resendVerification({ email: user.email });
      toast.success({
        message: "Verification email sent successfully",
      });
    } catch (error: any) {
      toast.error({
        message: error.message || "Failed to send verification email",
      });
    } finally {
      setIsResending(false);
    }
  };

  const handleLogoutAndReturn = async () => {
    await handleLogout();
  };

  return (
    <Box className="flex-1 bg-background-50 justify-center px-6">
      <VStack className="items-center">
        {/* Icon */}
        <Box className="bg-primary-100 p-6 rounded-full items-center justify-center mb-6">
          <FontAwesome5 name="envelope" size={32} color={"#4176CC"} />
        </Box>

        {/* Title and Description */}
        <VStack className="items-center mb-8">
          <Text className="text-3xl font-bold text-center text-typography-900 mb-2">
            Email Verification Required
          </Text>

          <Text className="text-base text-center text-typography-500 mb-4">
            We've sent a verification email to:
          </Text>

          <Text className="text-lg font-semibold text-center text-primary-600 mb-4">
            {user?.email}
          </Text>

          <Text className="text-sm text-center text-typography-500">
            Please check your inbox and click the verification link to access
            your account.
          </Text>
        </VStack>

        {/* Action Buttons */}
        <VStack className="w-full" space="md">
          <Button
            onPress={handleResendVerification}
            disabled={isResending}
            className="w-full h-14"
          >
            {isResending ? (
              <Spinner />
            ) : (
              <>
                <FontAwesome5
                  name="sync-alt"
                  size={16}
                  color="white"
                  style={{ marginRight: 8 }}
                />
                <ButtonText>Resend Verification Email</ButtonText>
              </>
            )}
          </Button>

          <Button
            variant="outline"
            onPress={handleLogoutAndReturn}
            className="w-full h-14"
          >
            <ButtonText>Sign Out</ButtonText>
          </Button>
        </VStack>

        {/* Help Text */}
        <VStack className="items-center mt-8">
          <Text className="text-xs text-center text-typography-400 mb-2">
            Didn't receive the email? Check your spam folder or click resend.
          </Text>
          <Text className="text-xs text-center text-typography-400">
            If you continue to have issues, please contact support.
          </Text>
        </VStack>
      </VStack>
    </Box>
  );
}
