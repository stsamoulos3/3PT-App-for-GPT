import { Feather } from "@expo/vector-icons";
import { FileService, type UserFile } from "@repo/core/services/FileService";
import { useQuery } from "@tanstack/react-query";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import moment from "moment";
import { useState } from "react";
import {
	ActivityIndicator,
	Alert,
	FlatList,
	Linking,
	Platform,
	Pressable,
	RefreshControl,
	SafeAreaView,
	SectionList,
	TouchableOpacity,
	View,
} from "react-native";
import Header from "@/components/common/Header";
import { Box } from "@/components/ui/box";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";
import { VStack } from "@/components/ui/vstack";
import useAuth from "@/hooks/useAuth";

export default function MyFilesScreen() {
	const { accessToken } = useAuth();
	const [refreshing, setRefreshing] = useState(false);

	const { data, isLoading, error, refetch } = useQuery({
		queryKey: ["userFiles"],
		queryFn: async () => {
			if (!accessToken) throw new Error("No authentication token");
			return FileService.getUserFiles(accessToken);
		},
		enabled: !!accessToken,
	});

	const [loading, setLoading] = useState<string | boolean>(false);
	const [downloadProgress, setDownloadProgress] = useState<{
		[key: string]: number;
	}>({});

	const handleDownload = async (file: UserFile) => {
		setLoading(file.id);
		try {
			if (!accessToken) throw new Error("No authentication token");

			// Download the file
			const downloadDir = FileSystem.documentDirectory + "Downloads/";

			// Get the signed URL
			const [response, _] = await Promise.all([
				FileService.getFileSignedUrl(file.id, accessToken),
				FileSystem.makeDirectoryAsync(downloadDir, {
					intermediates: true,
				}).catch(() => {
					// Directory might already exist
				}),
			]);

			const fileUri = downloadDir + file.fileName;

			const downloadResumable = FileSystem.createDownloadResumable(
				response.signedUrl,
				fileUri,
				{},
				(d) => {
					const progress = d.totalBytesWritten / d.totalBytesExpectedToWrite;

					setDownloadProgress((prev) => ({
						...prev,
						[file.id]: progress * 100,
					}));
				},
			);

			const downloadResult = await downloadResumable.downloadAsync();

			if (downloadResult && downloadResult.status === 200) {
				if (Platform.OS === "ios") {
					await Sharing.shareAsync(downloadResult.uri, {
						UTI: file.mimeType,
						mimeType: file.mimeType,
					});
				} else {
					// On Android, try to open with appropriate app
					await Linking.openURL(downloadResult.uri);
				}
			} else {
				Alert.alert("Error", "Failed to download file. Please try again.");
			}

			setLoading(false);
			setDownloadProgress((prev) => {
				const newProgress = { ...prev };
				delete newProgress[file.id];
				return newProgress;
			});
		} catch (error) {
			console.error("Error downloading file:", error);
			Alert.alert("Error", "Failed to download file. Please try again.");
			setLoading(false);
			setDownloadProgress((prev) => {
				const newProgress = { ...prev };
				delete newProgress[file.id];
				return newProgress;
			});
		}
	};

	const handleFilePress = async (file: UserFile) => {
		setLoading(file.id);
		try {
			if (!accessToken) throw new Error("No authentication token");

			// Get the signed URL
			const response = await FileService.getFileSignedUrl(file.id, accessToken);

			await Linking.openURL(response.signedUrl);
			setLoading(false);
		} catch (error) {
			console.error("Error opening file:", error);
			setLoading(false);
			setDownloadProgress((prev) => {
				const newProgress = { ...prev };
				delete newProgress[file.id];
				return newProgress;
			});
		}
	};

	const handleRefresh = async () => {
		setRefreshing(true);
		await refetch();
		setRefreshing(false);
	};

	const formatFileSize = (bytes: number): string => {
		if (bytes < 1024) return bytes + " B";
		else if (bytes < 1048576) return Math.round(bytes / 1024) + " KB";
		else return Math.round(bytes / 1048576) + " MB";
	};

	const getFileIcon = (mimeType: string): string => {
		if (mimeType.includes("pdf")) return "file-text";
		if (mimeType.includes("image")) return "image";
		if (mimeType.includes("video")) return "video";
		if (mimeType.includes("audio")) return "music";
		if (mimeType.includes("spreadsheet") || mimeType.includes("excel"))
			return "bar-chart";
		if (mimeType.includes("document") || mimeType.includes("word"))
			return "file-text";
		return "file";
	};

	const groupFilesByDate = (files: UserFile[]) => {
		const grouped = files.reduce(
			(acc, file) => {
				const date = moment(file.createdAt).format("YYYY-MM-DD");
				const dateKey = moment(file.createdAt).calendar(null, {
					sameDay: "[Today]",
					lastDay: "[Yesterday]",
					lastWeek: "dddd",
					sameElse: "MMMM DD, YYYY",
				});

				if (!acc[date]) {
					acc[date] = {
						title: dateKey,
						data: [],
						date: file.createdAt,
					};
				}
				acc[date].data.push(file);
				return acc;
			},
			{} as Record<string, { title: string; data: UserFile[]; date: string }>,
		);

		// Sort sections by date (most recent first) and files within each section by upload time (most recent first)
		return Object.values(grouped)
			.sort((a, b) => moment(b.date).valueOf() - moment(a.date).valueOf())
			.map((section) => ({
				...section,
				data: section.data.sort(
					(a, b) =>
						moment(b.createdAt).valueOf() - moment(a.createdAt).valueOf(),
				),
			}));
	};

	const renderFileItem = ({ item }: { item: UserFile }) => (
		<Pressable
			onPress={() => handleFilePress(item)}
			className="bg-white p-4 mx-4 mb-3 rounded-lg border border-primary-200 shadow-soft-4"
		>
			<HStack className="items-start gap-3">
				<Box className="p-2 bg-primary-50 rounded-lg">
					<Feather
						name={getFileIcon(item.mimeType) as any}
						size={24}
						color="#6B7280"
					/>
				</Box>
				<VStack className="flex-1 gap-1">
					<Text size="md" className="font-medium text-typography-900">
						{item.fileName}
					</Text>
					{item.description && (
						<Text size="sm" className="text-typography-600">
							{item.description}
						</Text>
					)}
					<HStack className="gap-3">
						<Text size="xs" className="text-typography-500">
							{formatFileSize(item.fileSize)}
						</Text>
						<Text size="xs" className="text-typography-500">
							Uploaded {moment(item.createdAt).fromNow()}
						</Text>
					</HStack>
				</VStack>

				{loading === item.id ? (
					<View className="items-center justify-center">
						<ActivityIndicator size="small" color="#6B7280" />
					</View>
				) : (
					<TouchableOpacity onPress={() => handleDownload(item)}>
						<Feather name="download" size={20} color="#6B7280" />
					</TouchableOpacity>
				)}
			</HStack>
			{downloadProgress[item.id] !== undefined && (
				<View className="mt-3">
					<View className="h-1 bg-gray-200 rounded-full overflow-hidden">
						<View
							className="h-full bg-primary-600 rounded-full"
							style={{ width: `${downloadProgress[item.id] * 100}%` }}
						/>
					</View>
				</View>
			)}
		</Pressable>
	);

	const renderEmptyState = () => (
		<Box className="flex-1 items-center justify-center p-6">
			<Feather name="folder" size={64} color="#D1D5DB" />
			<Text size="lg" className="text-typography-600 mt-4 text-center">
				No files available
			</Text>
			<Text size="sm" className="text-typography-500 mt-2 text-center">
				Files uploaded by your provider will appear here
			</Text>
		</Box>
	);

	const renderContent = () => {
		if (isLoading) {
			return (
				<Box className="flex-1 items-center justify-center">
					<ActivityIndicator size="large" color="#6366F1" />
				</Box>
			);
		}

		if (error) {
			return (
				<Box className="flex-1 items-center justify-center p-6">
					<Feather name="alert-circle" size={48} color="#EF4444" />
					<Text size="md" className="text-red-600 mt-4 text-center">
						Failed to load files
					</Text>
					<Pressable onPress={() => refetch()} className="mt-4">
						<Text size="sm" className="text-primary-600">
							Tap to retry
						</Text>
					</Pressable>
				</Box>
			);
		}

		if (!data?.files || data.files.length === 0) {
			return renderEmptyState();
		}

		const groupedFiles = groupFilesByDate(data.files);

		return (
			<SectionList
				sections={groupedFiles}
				renderItem={renderFileItem}
				renderSectionHeader={({ section }) => (
					<View className="bg-transparent px-4 py-2 border-b  mb-4 mx-4">
						<Text
							size="sm"
							className="font-semibold text-typography-700 uppercase tracking-wide"
						>
							{section.title}
						</Text>
					</View>
				)}
				keyExtractor={(item) => item.id}
				contentContainerStyle={{ paddingBottom: 16 }}
				stickySectionHeadersEnabled={true}
				refreshControl={
					<RefreshControl
						refreshing={refreshing}
						onRefresh={handleRefresh}
						colors={["#6366F1"]}
					/>
				}
			/>
		);
	};

	return (
		<SafeAreaView className="flex-1 bg-background-50">
			{/* <Box className="p-4">
				<Header title="My Files" />
			</Box> */}
			{renderContent()}
		</SafeAreaView>
	);
}
