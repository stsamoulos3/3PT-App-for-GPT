import { Feather } from "@expo/vector-icons";
import {
	PersonalizedCalorieCalculator,
	type PnoeDataStatus,
	type UserCalProfile,
} from "@repo/core/services/PersonalizedCalorieCalculator";
import { router } from "expo-router";
import React, { useEffect, useState } from "react";
import {
	ActivityIndicator,
	Alert,
	RefreshControl,
	SafeAreaView,
	ScrollView,
} from "react-native";
import Header from "@/components/common/Header";
import { Box } from "@/components/ui/box";
import { Button, ButtonIcon, ButtonText } from "@/components/ui/button";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";
import { VStack } from "@/components/ui/vstack";
import useAuthStore from "@/store/auth.store";

export default function PnoeDebugScreen() {
	const { accessToken } = useAuthStore();
	const [loading, setLoading] = useState(true);
	const [refreshing, setRefreshing] = useState(false);
	const [debugData, setDebugData] = useState<UserCalProfile>(null);
	const [status, setStatus] = useState<PnoeDataStatus | null>(null);
	const loadDebugData = async () => {
		if (!accessToken) return;

		try {
			// Get PNOE status
			const _status =
				await PersonalizedCalorieCalculator.getPnoeDataStatus(accessToken);

			setStatus(_status);

			const data =
				await PersonalizedCalorieCalculator.getUserCoefficients(accessToken);

			setDebugData(data);
		} catch (error) {
			console.error("Error loading debug data:", error);
			Alert.alert("Error", "Failed to load PNOE debug data");
		} finally {
			setLoading(false);
			setRefreshing(false);
		}
	};


	const handleRefresh = () => {
		setRefreshing(true);
		loadDebugData();
	};

	useEffect(() => {
		loadDebugData();
	}, [accessToken]);

	const renderStatusSection = () => (
		<Box className="bg-white p-4 rounded-xl mb-4">
			<HStack className="items-center mb-3">
				<Feather name="info" size={20} color="#4176CC" />
				<Text size="lg" className="font-semibold text-typography-900 ml-2">
					PNOE Data Status
				</Text>
			</HStack>

			{status ? (
				<VStack className="gap-2">
					<HStack className="justify-between">
						<Text className="text-typography-600">Has PNOE Data:</Text>
						<Text
							className={`font-semibold ${status.hasPnoeData ? "text-green-600" : "text-red-600"}`}
						>
							{status.hasPnoeData ? "Yes" : "No"}
						</Text>
					</HStack>

					<HStack className="justify-between">
						<Text className="text-typography-600">Last Processed:</Text>
						<Text className="text-typography-900">
							{status.lastProcessedAt
								? new Date(status.lastProcessedAt).toLocaleDateString()
								: "Never"}
						</Text>
					</HStack>

					<VStack className="gap-1">
						<Text className="text-typography-600">Available Methods:</Text>
						<HStack className="flex-wrap gap-1">
							{status.availableMethods.map((method) => (
								<Box key={method} className="bg-blue-100 px-2 py-1 rounded">
									<Text size="sm" className="text-blue-800 font-medium">
										{method}
									</Text>
								</Box>
							))}
						</HStack>
					</VStack>
				</VStack>
			) : (
				<Text className="text-typography-500">Loading status...</Text>
			)}
		</Box>
	);

	const renderModel1Section = () => {
		if (
			debugData?.hrVo2Slope &&
			debugData?.hrVo2Intercept &&
			debugData?.hrRerIntercept &&
			debugData?.hrRerIntercept
		)
			return (
				<Box className="bg-white p-4 rounded-xl mb-4">
					<HStack className="items-center mb-3">
						<Feather name="trending-up" size={20} color="#10B981" />
						<Text size="lg" className="font-semibold text-typography-900 ml-2">
							MODEL 1
						</Text>
					</HStack>

					<VStack className="gap-2">
						<HStack className="justify-between">
							<Text className="text-typography-600">Slope HR to VO2:</Text>
							<Text className="font-semibold text-typography-900">
								{debugData.hrVo2Slope}
							</Text>
						</HStack>

						<HStack className="justify-between">
							<Text className="text-typography-600">Slope HR to RER:</Text>
							<Text className="font-semibold text-typography-900">
								{debugData.hrRerSlope}
							</Text>
						</HStack>

						<HStack className="justify-between">
							<Text className="text-typography-600">Intercept HR to VO2:</Text>
							<Text className="font-semibold text-typography-900">
								{debugData.hrVo2Intercept}
							</Text>
						</HStack>

						<HStack className="justify-between">
							<Text className="text-typography-600">Intercept HR to RER:</Text>
							<Text className="font-semibold text-typography-900">
								{debugData.hrRerIntercept}
							</Text>
						</HStack>
					</VStack>
				</Box>
			);

		return null;
	};

	const renderModel2Section = () => {
		if (!debugData?.hrEeSlope && !debugData?.hrEeIntercept) return null;

		return (
			<Box className="bg-white p-4 rounded-xl mb-4">
				<HStack className="items-center mb-3">
					<Feather name="trending-up" size={20} color="#10B981" />
					<Text size="lg" className="font-semibold text-typography-900 ml-2">
						MODEL 2
					</Text>
				</HStack>

				<VStack className="gap-2">
					<HStack className="justify-between">
						<Text className="text-typography-600">Slope HR to EE:</Text>
						<Text className="font-semibold text-typography-900">
							{debugData.hrEeSlope}
						</Text>
					</HStack>

					<HStack className="justify-between">
						<Text className="text-typography-600">Intercept HR to EE:</Text>
						<Text className="font-semibold text-typography-900">
							{debugData.hrEeIntercept}
						</Text>
					</HStack>
				</VStack>
			</Box>
		);
	};

	const renderModel3Section = () => {
		if (!debugData?.o2RerSlope && !debugData?.o2RerIntercept) return null;

		return (
			<Box className="bg-white p-4 rounded-xl mb-4">
				<HStack className="items-center mb-3">
					<Feather name="trending-up" size={20} color="#10B981" />
					<Text size="lg" className="font-semibold text-typography-900 ml-2">
						MODEL 3
					</Text>
				</HStack>

				<VStack className="gap-2">
					<HStack className="justify-between">
						<Text className="text-typography-600">Slope O2 vs RER:</Text>
						<Text className="font-semibold text-typography-900">
							{debugData.o2RerSlope}
						</Text>
					</HStack>

					<HStack className="justify-between">
						<Text className="text-typography-600">Intercept O2 vs RER:</Text>
						<Text className="font-semibold text-typography-900">
							{debugData.o2RerIntercept}
						</Text>
					</HStack>
				</VStack>
			</Box>
		);
	};

	if (loading) {
		return (
			<SafeAreaView className="flex-1 bg-background-50">
				<Box className="p-4 flex-1 justify-center items-center">
					<ActivityIndicator size="large" color="#4176CC" />
					<Text className="mt-2 text-typography-600">
						Loading PNOE debug data...
					</Text>
				</Box>
			</SafeAreaView>
		);
	}

	return (
		<SafeAreaView className="flex-1 bg-background-50">
			<Box className="p-4 flex-1">
				<Header
					title="PNOE Debug Data"
					showBackButton
					onBackPress={() => router.back()}
				/>

				<ScrollView
					className="flex-1 mt-4"
					refreshControl={
						<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
					}
				>
					{renderStatusSection()}

					<HStack className="gap-2 mb-4">
						<Button
							variant="outline"
							className="flex-1"
							onPress={handleRefresh}
							disabled={refreshing}
						>
							<ButtonIcon as={Feather} name="refresh-ccw" />
							<ButtonText className="ml-1">Refresh</ButtonText>
						</Button>
					</HStack>

					{status?.hasPnoeData ? (
						<VStack className="gap-0">
							{renderModel1Section()}
							{renderModel2Section()}
							{renderModel3Section()}
						</VStack>
					) : (
						<Box className="bg-yellow-50 p-4 rounded-xl border-l-4 border-yellow-400">
							<HStack className="items-center mb-2">
								<Feather name="alert-triangle" size={20} color="#F59E0B" />
								<Text className="font-semibold text-yellow-800 ml-2">
									No PNOE Data Found
								</Text>
							</HStack>
							<Text className="text-yellow-700 mb-3">
								Upload a pnoe.csv or vo2_master.csv file through "My Files" 
								to automatically generate coefficient data.
							</Text>
							<Button
								size="sm"
								className="bg-yellow-500"
								onPress={() => router.push("/my-files")}
							>
								<ButtonText className="text-white">Go to My Files</ButtonText>
							</Button>
						</Box>
					)}
				</ScrollView>
			</Box>
		</SafeAreaView>
	);
}
