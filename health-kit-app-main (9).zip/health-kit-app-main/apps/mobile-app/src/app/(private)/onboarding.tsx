import { KeyboardAvoidingView, SafeAreaView, ScrollView } from "react-native";
import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { VStack } from "@/components/ui/vstack";
import { useForm } from "react-hook-form";
import FormBuilder, { FormField } from "@/components/common/FormBuilder";
import useAuth from "@/hooks/useAuth";
import { router } from "expo-router";
import { useEffect, useState } from "react";
import { Spinner } from "@/components/ui/spinner";
import {
  multidisciplinaryPatientFormFieldsBuilder,
  patientFormFieldsBuilder,
  ProfileForm,
  profileFormFields,
} from "@/config/profile-fields";

export default function OnboardingScreen() {
  const { handleOnboardingCompleted, saveUserPersonalInfo } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { control, handleSubmit, watch, resetField } = useForm<ProfileForm>({
    defaultValues: {
      dob: "",
      gender: "",
      is3PTPatient: "false",
      isMultidisciplinaryPatient: "false",
    },
  });

  const is3PTPatient = watch("is3PTPatient") === "true";
  const isMultidisciplinaryPatient =
    watch("isMultidisciplinaryPatient") === "true";

  const onSubmit = async (values: ProfileForm) => {
    setIsSubmitting(true);
    try {
      const personalInfo = {
        dob: values.dob,
        gender: values.gender,
        is3PTPatient: values.is3PTPatient === "true",
        patientId: values.patientId,
        isMultidisciplinaryPatient:
          values.isMultidisciplinaryPatient === "true",
        rmr: values.rmr ? values.rmr : undefined,
        prescribedExerciseHR: values.prescribedExerciseHR
          ? values.prescribedExerciseHR
          : undefined,
        hourlyCaloriesAtHR: values.hourlyCaloriesAtHR
          ? values.hourlyCaloriesAtHR
          : undefined,
        prescribedDailyCalories: values.prescribedDailyCalories
          ? values.prescribedDailyCalories
          : undefined,
        vo2Max: values.vo2Max ? values.vo2Max : undefined,
      };
      const result = await saveUserPersonalInfo(personalInfo);

      console.log("[OnboardingScreen] result", result);

      handleOnboardingCompleted();
      router.replace("/(private)/email-verification-pending");
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    if (is3PTPatient) {
      return;
    }

    resetField("patientId");
    resetField("isMultidisciplinaryPatient");
    resetField("rmr");
    resetField("prescribedExerciseHR");
    resetField("hourlyCaloriesAtHR");
    resetField("prescribedDailyCalories");
    resetField("vo2Max");
  }, [is3PTPatient]);

  useEffect(() => {
    if (isMultidisciplinaryPatient) {
      return;
    }

    resetField("rmr");
    resetField("prescribedExerciseHR");
    resetField("hourlyCaloriesAtHR");
    resetField("prescribedDailyCalories");
    resetField("vo2Max");
  }, [isMultidisciplinaryPatient]);

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-background-50"
      behavior="padding"
      keyboardVerticalOffset={16}
    >
      <SafeAreaView className="flex-1 bg-background-50">
        <Box className="p-6 flex-1  justify-center">
          <VStack className="gap-6">
            <Text size="3xl" className="font-bold text-typography-900">
              Welcome! Let's get to know you better
            </Text>

            <Text size="lg" className="text-typography-600">
              Please provide some basic information to help us personalize your
              experience
            </Text>

            <ScrollView
              className="h-3/4"
              contentContainerClassName="gap-4"
              showsVerticalScrollIndicator={false}
            >
              <FormBuilder
                fields={profileFormFields}
                control={control}
                showLabel
              />
              {is3PTPatient && (
                <FormBuilder
                  fields={patientFormFieldsBuilder(is3PTPatient)}
                  control={control}
                  showLabel
                />
              )}
              {isMultidisciplinaryPatient && (
                <FormBuilder
                  fields={multidisciplinaryPatientFormFieldsBuilder(
                    isMultidisciplinaryPatient
                  )}
                  control={control}
                  showLabel
                />
              )}
            </ScrollView>

            <Button
              size="lg"
              variant="solid"
              className="bg-primary-500 mt-4 h-14"
              onPress={handleSubmit(onSubmit)}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <Spinner size="small" />
              ) : (
                <ButtonText>Complete Setup</ButtonText>
              )}
            </Button>
          </VStack>
        </Box>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}
