import { Feather } from "@expo/vector-icons";
import {
	PersonalizedCalorieCalculator,
	type PnoeDataStatus,
} from "@repo/core/services/PersonalizedCalorieCalculator";
import { UserService } from "@repo/core/services/UserService";
import { router } from "expo-router";
import { useEffect, useState } from "react";
import { Alert, Pressable, SafeAreaView } from "react-native";
import Header from "@/components/common/Header";
import { Box } from "@/components/ui/box";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";
import { VStack } from "@/components/ui/vstack";
import useAuth from "@/hooks/useAuth";

type CalorieCountingMethod = "MODEL1" | "MODEL2" | "MODEL3" | "MODEL4";

const CALORIE_METHODS = [
	{
		value: "MODEL1" as CalorieCountingMethod,
		label: "Weir Equation - Regression VO2",
		description: "Calories burned based on VO2 and heart rate",
	},
	{
		value: "MODEL2" as CalorieCountingMethod,
		label: "HR to EE Regression of PNOE Data",
		description: "Calories burned based on EE and heart rate",
	},
	{
		value: "MODEL3" as CalorieCountingMethod,
		label: "Personalized WEIR Regression of VO2",
		description:
			"Also Regression of  kcal/L of O2 and Regression of RER from PNOE Data",
	},
	{
		value: "MODEL4" as CalorieCountingMethod,
		label: "Default",
		description: "Direct Data from HealthKit",
	},
];

export default function CalorieMethodSelectionScreen() {
	const { user, accessToken, getUser } = useAuth();
	const [selectedMethod, setSelectedMethod] =
		useState<CalorieCountingMethod | null>(
			user?.calorieCountingMethod || "MODEL1",
		);
	const [isLoading, setIsLoading] = useState(false);

	const handleMethodSelect = async (method: CalorieCountingMethod) => {
		if (!user || !accessToken) return;

		setIsLoading(true);
		try {
			await UserService.update(
				user.id,
				{ calorieCountingMethod: method },
				accessToken,
			);

			setSelectedMethod(method);
			await getUser();

			Alert.alert(
				"Success",
				"Energy expenditure algorithm updated successfully",
				[{ text: "OK" }],
			);
		} catch (error) {
			console.error("Error updating calorie method:", error);
			Alert.alert("Error", "Failed to update energy expenditure algorithm");
		} finally {
			setIsLoading(false);
		}
	};

	const [status, setStatus] = useState<PnoeDataStatus | null>(null);
	const loadDebugData = async () => {
		if (!accessToken) return;

		try {
			// Get PNOE status
			const _status =
				await PersonalizedCalorieCalculator.getPnoeDataStatus(accessToken);

			setStatus(_status);
		} catch (error) {
			console.error("Error loading debug data:", error);
			Alert.alert("Error", "Failed to load PNOE debug data");
		}
	};

	useEffect(() => {
		loadDebugData();
	}, []);

	return (
		<SafeAreaView className="flex-1 bg-background-50">
			<Box className="p-4 flex-1">
				<VStack className="gap-4">
					<Text className="text-typography-600 mb-2">
						Select your preferred method for calculating calories during
						workouts:
					</Text>
					<VStack className="gap-3">
						{CALORIE_METHODS.filter((itm) =>
							status?.availableMethods.includes(itm.value),
						).map((method) => (
							<Pressable
								key={method.value}
								onPress={() => handleMethodSelect(method.value)}
								disabled={isLoading}
								className={`p-4 bg-white rounded-lg border-2 ${
									selectedMethod === method.value
										? "border-primary-500"
										: "border-transparent"
								}`}
							>
								<HStack className="items-center justify-between">
									<VStack className="flex-1 gap-1">
										<Text
											size="lg"
											className="text-typography-900 font-semibold"
										>
											{method.label}
										</Text>
										<Text size="sm" className="text-typography-600">
											{method.description}
										</Text>
									</VStack>

									{selectedMethod === method.value && (
										<Box className="w-6 h-6 bg-primary-500 rounded-full items-center justify-center">
											<Feather name="check" size={16} color="white" />
										</Box>
									)}
								</HStack>
							</Pressable>
						))}
					</VStack>

					<Box className="mt-4 p-4 bg-blue-50 rounded-lg">
						<Text size="sm" className="text-blue-800">
							<Text className="font-semibold">Note:</Text> This setting affects
							how calories are calculated for your workouts. You can change this
							at any time from your profile settings.
						</Text>
					</Box>
				</VStack>
			</Box>
		</SafeAreaView>
	);
}
