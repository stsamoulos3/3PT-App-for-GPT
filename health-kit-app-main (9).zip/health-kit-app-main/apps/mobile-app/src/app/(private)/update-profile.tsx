import {
  KeyboardAvoidingView,
  ScrollView,
} from "react-native";
import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import FormBuilder from "@/components/common/FormBuilder";
import useAuth from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import { Spinner } from "@/components/ui/spinner";
import { useToast } from "@/components/common/Toast";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  multidisciplinaryPatientFormFieldsBuilder,
  patientFormFieldsBuilder,
  type ProfileForm,
  profileFormFields,
} from "@/config/profile-fields";

export default function UpdateProfileScreen() {
  const toast = useToast();
  const { user, saveUserPersonalInfo } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { bottom } = useSafeAreaInsets();

  const { control, handleSubmit, watch, resetField, setValue } =
    useForm<ProfileForm>({
      shouldFocusError: true,
    });

  const is3PTPatient = watch("is3PTPatient") === "true";
  const isMultidisciplinaryPatient =
    watch("isMultidisciplinaryPatient") === "true";

  useEffect(() => {
    if (!user) return;

    // Set initial values from user data
    setValue("dob", user.dob ?? "");
    setValue("gender", user.gender ?? "");
    setValue("is3PTPatient", user.is3PTPatient ? "true" : "false");
    setValue("patientId", user.patientId ?? "");
    setValue(
      "isMultidisciplinaryPatient",
      user.isMultidisciplinaryPatient ? "true" : "false",
    );
    setValue("rmr", user.rmr ?? undefined);
    setValue("prescribedExerciseHR", user.prescribedExerciseHR ?? undefined);
    setValue("hourlyCaloriesAtHR", user.hourlyCaloriesAtHR ?? undefined);
    setValue(
      "prescribedDailyCalories",
      user.prescribedDailyCalories ?? undefined,
    );
    setValue("vo2Max", user.vo2Max ?? undefined);
  }, [user, setValue]);

  useEffect(() => {
    if (is3PTPatient) {
      return;
    }

    resetField("patientId");
    resetField("isMultidisciplinaryPatient");
    resetField("rmr");
    resetField("prescribedExerciseHR");
    resetField("hourlyCaloriesAtHR");
    resetField("prescribedDailyCalories");
    resetField("vo2Max");
  }, [is3PTPatient, resetField]);

  useEffect(() => {
    if (isMultidisciplinaryPatient) {
      return;
    }
    resetField("rmr");
    resetField("prescribedExerciseHR");
    resetField("hourlyCaloriesAtHR");
    resetField("prescribedDailyCalories");
    resetField("vo2Max");
  }, [isMultidisciplinaryPatient, resetField]);

  const onSubmit = async (values: ProfileForm) => {
    setIsSubmitting(true);
    try {
      const personalInfo = {
        dob: values.dob,
        gender: values.gender,
        is3PTPatient: values.is3PTPatient === "true",
        patientId: values.patientId,
        isMultidisciplinaryPatient:
          values.isMultidisciplinaryPatient === "true",
        rmr: values.rmr ? values.rmr : undefined,
        prescribedExerciseHR: values.prescribedExerciseHR
          ? values.prescribedExerciseHR
          : undefined,
        hourlyCaloriesAtHR: values.hourlyCaloriesAtHR
          ? values.hourlyCaloriesAtHR
          : undefined,
        prescribedDailyCalories: values.prescribedDailyCalories
          ? values.prescribedDailyCalories
          : undefined,
        vo2Max: values.vo2Max ? values.vo2Max : undefined,
      };
      await saveUserPersonalInfo(personalInfo);
      toast.success({
        message: "Profile updated successfully",
      });
    } catch (error) {
      console.error(error);
      toast.error({
        message: "Failed to update profile. Please try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={"padding"}
      className="flex-1 bg-background-50"
      keyboardVerticalOffset={32}
    >
      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerClassName="px-4 gap-4 pb-64"
      >
        <Text size="lg" className="text-typography-600 p-4">
          Update your personal information
        </Text>
        <FormBuilder fields={profileFormFields} control={control} showLabel />
        {is3PTPatient && (
          <FormBuilder
            fields={patientFormFieldsBuilder(is3PTPatient)}
            control={control}
            showLabel
          />
        )}
        {isMultidisciplinaryPatient && (
          <FormBuilder
            fields={multidisciplinaryPatientFormFieldsBuilder(
              isMultidisciplinaryPatient,
            )}
            control={control}
            showLabel
          />
        )}
        <Box className="py-8 bg-background-50">
          <Button
            size="lg"
            className="bg-primary-500 w-full"
            onPress={handleSubmit(onSubmit)}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <Spinner size="small" />
            ) : (
              <ButtonText>Save Changes</ButtonText>
            )}
          </Button>
        </Box>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
