import { FontAwesome5 } from "@expo/vector-icons";
import Healthkit, {
	HKQuantityTypeIdentifier,
	HKUpdateFrequency,
} from "@kingstinct/react-native-healthkit";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Tabs } from "expo-router";
import { useEffect, useState } from "react";

import { HeartRateCard } from "@/components/screens/home/HeartRateCard";
import { useDateRange } from "@/hooks/useDateRange";

export default function TabsLayout() {
	const [isBackgroundDeliveryEnabled, setIsBackgroundDeliveryEnabled] =
		useState(false);

	const setupBackgroundDelivery = async () => {
		try {
			// await Healthkit.disableAllBackgroundDelivery();
			// await AsyncStorage.setItem("isBackgroundDeliveryEnabled", "false");
			// setIsBackgroundDeliveryEnabled(false);
			// return;

			const isBackgroundDeliveryEnabled =
				(await AsyncStorage.getItem("isBackgroundDeliveryEnabled")) === "true";

			if (isBackgroundDeliveryEnabled) {
				setIsBackgroundDeliveryEnabled(isBackgroundDeliveryEnabled);
				return;
			}

			const result = await Healthkit.enableBackgroundDelivery(
				HKQuantityTypeIdentifier.heartRate,
				HKUpdateFrequency.immediate,
			);

			await AsyncStorage.setItem(
				"isBackgroundDeliveryEnabled",
				result.toString(),
			);
			setIsBackgroundDeliveryEnabled(result);
		} catch (error) {}
	};

	useEffect(() => {
		setupBackgroundDelivery();
	}, []);

	// useEffect(() => {
	//   if (isBackgroundDeliveryEnabled) {
	//     Healthkit.subscribeToChanges(HKQuantityTypeIdentifier.heartRate, () => {
	//
	//       scheduleNotificationAsync({
	//         content: {
	//           title: "Heart Rate Alert",
	//           body: "Your heart rate is too high",
	//         },
	//         trigger: null,
	//       });
	//     });
	//   }
	// }, [isBackgroundDeliveryEnabled]);

	return (
		<Tabs
			screenOptions={{
				headerShown: false,
				tabBarStyle: {
					backgroundColor: "#ffffff",
					borderTopWidth: 1,
					borderTopColor: "#e5e7eb",
				},
				tabBarActiveTintColor: "#4176CC",
				tabBarInactiveTintColor: "#6b7280",
			}}
		>
			<Tabs.Screen
				name="index"
				options={{
					title: "Home",
					tabBarIcon: ({ color, size }) => (
						<FontAwesome5 name="home" size={size} color={color} />
					),
				}}
			/>
			<Tabs.Screen
				name="nutritions"
				options={{
					title: "Nutrition",
					tabBarIcon: ({ color, size }) => (
						<FontAwesome5 name="utensils" size={size} color={color} />
					),
				}}
			/>
			<Tabs.Screen
				name="workouts"
				options={{
					title: "Workouts",
					tabBarIcon: ({ color, size }) => (
						<FontAwesome5 name="dumbbell" size={size} color={color} />
					),
				}}
			/>
			<Tabs.Screen
				name="profile"
				options={{
					title: "Profile",
					tabBarIcon: ({ color, size }) => (
						<FontAwesome5 name="user" size={size} color={color} />
					),
				}}
			/>
		</Tabs>
	);
}
