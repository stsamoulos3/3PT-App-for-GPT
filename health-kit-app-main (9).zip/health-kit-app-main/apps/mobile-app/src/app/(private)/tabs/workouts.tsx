import { ScrollView, SafeAreaView, View } from "react-native";
import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { HStack } from "@/components/ui/hstack";
import { DateRangeSelector } from "@/components/screens/home/DateRangeSelector";
import { useDateRange } from "@/hooks/useDateRange";
import { WorkoutCard } from "@/components/screens/home/Workouts/WorkoutCard";
import ActiveWorkoutCard from "@/components/screens/home/ActiveWorkoutCard";
import { ActionFab } from "@/components/screens/home/ActionFab";
import { Logo } from "@/components/common/Logo";
import Header from "@/components/common/Header";

export default function WorkoutsScreen() {
  const {
    selectedDate,
    changeDate,
    formatDate,
    setToday,
    setLast7Days,
    setCurrentWeek,
    setLast3Days,
  } = useDateRange();

  return (
    <SafeAreaView className="flex-1 bg-background-50">
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <ActiveWorkoutCard />
        <Box className="p-4">
          <Header title="Workouts" />

          <DateRangeSelector
            selectedDate={selectedDate}
            formatDate={formatDate}
            changeDate={changeDate}
            setToday={setToday}
            setLast7Days={setLast7Days}
            setCurrentWeek={setCurrentWeek}
            setLast3Days={setLast3Days}
          />

          <WorkoutCard
            startDate={selectedDate.startDate}
            endDate={selectedDate.endDate}
          />

          {/* Today Button */}
          <HStack className="justify-center mt-4 mb-8 gap-4">
            <Button
              size="lg"
              variant="solid"
              className="flex-1 rounded-xl"
              onPress={setToday}
            >
              <ButtonText className="text-white font-semibold">
                Today
              </ButtonText>
            </Button>
          </HStack>
        </Box>
      </ScrollView>
      <ActionFab />
    </SafeAreaView>
  );
}
