import React, { useCallback, useState } from "react";
import { View, SafeAreaView, ScrollView } from "react-native";
import { Text } from "@/components/ui/text";
import { Box } from "@/components/ui/box";
import { HStack } from "@/components/ui/hstack";
import { VStack } from "@/components/ui/vstack";
import { Feather } from "@expo/vector-icons";
import { useFocusEffect } from "expo-router";
import { DateRangeSelector } from "@/components/screens/home/DateRangeSelector";
import { useDateRange } from "@/hooks/useDateRange";
import { ButtonIcon, ButtonText } from "@/components/ui/button";
import { Button } from "@/components/ui/button";
import { useFood } from "@/hooks/useFood";
import { ActionFab } from "@/components/screens/home/ActionFab";
import formatNumberWithPostfix from "@/helpers/formatNumberWithPostfix";
import { NutritionToHKUnit } from "@/services/HealthService";
import MealsCard from "@/components/screens/nutrition/MealsCard";
import StatsCard from "@/components/screens/nutrition/StatsCard";
import { useQuery } from "@tanstack/react-query";
import { Logo } from "@/components/common/Logo";
import Header from "@/components/common/Header";
import moment from "moment";
import useAuth from "@/hooks/useAuth";

export default function NutritionIndex() {
	const {
		selectedDate,
		changeDate,
		formatDate,
		setToday,
		setLast7Days,
		setCurrentWeek,
		setLast3Days,
	} = useDateRange();
	const { getFoodLog } = useFood();

	const { user } = useAuth();

	const [nutritionData, setNutritionData] = useState({
		calories: {
			goal: user?.prescribedDailyCalories ?? 0 * 7,
		},
		macros: {
			carbs: { goal: 250, unit: "g" },
			protein: { goal: 120, unit: "g" },
			fat: { goal: 65, unit: "g" },
		},
	});

	const {
		data: foodLogs,
		isLoading,
		refetch,
	} = useQuery({
		queryKey: ["foodLogs", selectedDate],
		queryFn: () =>
			getFoodLog({
				startDate: moment(selectedDate.startDate).startOf("day").toISOString(),
				endDate: moment(selectedDate.endDate).endOf("day").toISOString(),
			}),
		select: (data) => {
			return data || [];
		},
	});

	const totalCalories =
		foodLogs?.reduce(
			(acc, log) => acc + (log.food?.calories ?? 0) * log.servings,
			0,
		) ?? 0;

	const totalCarbs =
		foodLogs?.reduce(
			(acc, log) => acc + (log.food?.totalCarbohydrates ?? 0) * log.servings,
			0,
		) ?? 0;

	const totalProtein =
		foodLogs?.reduce(
			(acc, log) => acc + (log.food?.protein ?? 0) * log.servings,
			0,
		) ?? 0;

	const totalFat =
		foodLogs?.reduce(
			(acc, log) => acc + (log.food?.totalFat ?? 0) * log.servings,
			0,
		) ?? 0;

	useFocusEffect(
		useCallback(() => {
			refetch();
		}, [refetch]),
	);

	return (
		<SafeAreaView className="flex-1 bg-background-50 relative">
			{/* Date Range Selector */}
			<Box className="p-4 flex-1">
				<Header title="Nutrition" />
				<DateRangeSelector
					selectedDate={selectedDate}
					formatDate={formatDate}
					changeDate={changeDate}
					setToday={setToday}
					setLast7Days={setLast7Days}
					setCurrentWeek={setCurrentWeek}
					setLast3Days={setLast3Days}
				/>

				<ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
					{/* Calories Card */}
					<Box className="bg-background-0 rounded-2xl mb-4 shadow-soft-1 flex-col gap-4 py-4">
						<HStack className="justify-between items-center px-4 pb-4 border-b border-background-200">
							<Text size="lg" className="font-semibold text-typography-900">
								Nutrition
							</Text>
							<Button
								variant="outline"
								size="sm"
								className="w-8 h-8 rounded-full"
							>
								<ButtonIcon className="items-center justify-center">
									<Feather name="refresh-cw" color={"#4176CC"} />
								</ButtonIcon>
							</Button>
						</HStack>

						<HStack className="items-center justify-center my-4 p-4">
							<VStack className="items-center">
								<Text className="text-5xl font-bold text-[#ff3b30]">
									{formatNumberWithPostfix(totalCalories, 2)}
								</Text>
								{user?.prescribedDailyCalories && (
									<Text className="text-typography-500">
										of {formatNumberWithPostfix(nutritionData.calories.goal, 2)}{" "}
										kcal
									</Text>
								)}
							</VStack>
						</HStack>

						{/* Progress Bar */}
						<Box className="h-2 bg-gray-200 rounded-full  mb-4 mx-4">
							<Box
								className="h-2 bg-[#ff3b30] rounded-full"
								style={{
									maxWidth: "100%",
									width: `${(totalCalories / nutritionData.calories.goal) * 100}%`,
								}}
							/>
						</Box>

						{/* Macros */}
						<VStack className="space-y-3 px-4">
							<HStack className="justify-between">
								<Text className="text-typography-900">Carbs</Text>
								<Text className="text-typography-900">
									{formatNumberWithPostfix(totalCarbs, 2)}{" "}
									{NutritionToHKUnit.totalCarbohydrates}
								</Text>
							</HStack>
							<HStack className="justify-between">
								<Text className="text-typography-900">Protein</Text>
								<Text className="text-typography-900">
									{formatNumberWithPostfix(totalProtein, 2)}{" "}
									{NutritionToHKUnit.protein}
								</Text>
							</HStack>
							<HStack className="justify-between">
								<Text className="text-typography-900">Fat</Text>
								<Text className="text-typography-900">
									{formatNumberWithPostfix(totalFat, 2)}{" "}
									{NutritionToHKUnit.totalFat}
								</Text>
							</HStack>
						</VStack>
					</Box>

					{/* Meals Card */}
					<MealsCard
						isLoading={isLoading}
						foodLogs={foodLogs ?? []}
						fetchFoodLogs={refetch}
					/>

					<StatsCard isLoading={isLoading} foodLogs={foodLogs ?? []} />

					{/* Today Button */}
					<HStack className="justify-center mt-4 mb-8 gap-4">
						<Button
							size="lg"
							variant="solid"
							className="flex-1 rounded-xl"
							onPress={setToday}
						>
							<ButtonText className="text-white font-semibold">
								Today
							</ButtonText>
						</Button>
					</HStack>

					<Box className="h-16" />
				</ScrollView>
			</Box>

			<ActionFab />
		</SafeAreaView>
	);
}
