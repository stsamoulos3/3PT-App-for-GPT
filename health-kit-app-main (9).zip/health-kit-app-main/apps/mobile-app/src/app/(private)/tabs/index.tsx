import { useEffect, useState } from "react";
import { SafeAreaView, ScrollView } from "react-native";
import Header from "@/components/common/Header";
import { AnimatedPentagonBadge } from "@/components/common/Pentagon";
import { ActionFab } from "@/components/screens/home/ActionFab";
import ActiveWorkoutCard from "@/components/screens/home/ActiveWorkoutCard";
import { CaloriesChartCard } from "@/components/screens/home/CaloriesChartCard";
import { DateRangeSelector } from "@/components/screens/home/DateRangeSelector";
import { HeartRateCard } from "@/components/screens/home/HeartRateCard";
import { StreakPentagonCard } from "@/components/screens/home/StreakPentagonCard";
import { Box } from "@/components/ui/box";
import { Button, ButtonText } from "@/components/ui/button";
import { Drawer, DrawerBackdrop, DrawerContent } from "@/components/ui/drawer";
import { HStack } from "@/components/ui/hstack";
import { Spinner } from "@/components/ui/spinner";
import { Text } from "@/components/ui/text";
import useAuth from "@/hooks/useAuth";
import { useDateRange } from "@/hooks/useDateRange";
import { useHealthKitSetup } from "@/hooks/useHealthKitSetup";
import { useStreaks } from "@/hooks/useStreaks";
import useTrackHealth from "@/hooks/useTrackHealth";

export default function HomeScreen() {
	const {
		selectedDate,
		setToday,
		changeDate,
		formatDate,
		setLast7Days,
		setCurrentWeek,
		setLast3Days,
	} = useDateRange();

	const { trackerStates } = useTrackHealth();
	const { streaks, isLoading: streaksLoading } = useStreaks();
	useHealthKitSetup();

	const { getUser } = useAuth();

	// biome-ignore lint/correctness/useExhaustiveDependencies: <explanation>
	useEffect(() => {
		getUser();
	}, []);

	return (
		<SafeAreaView className="flex-1 bg-background-50">
			<ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
				{trackerStates.isSaving && (
					<Drawer isOpen={true} onClose={() => {}} anchor="bottom" size="lg">
						<DrawerBackdrop />
						<DrawerContent className="items-center justify-center gap-4">
							<Spinner size={"large"} />
							<Text size="3xl">Saving data...</Text>
						</DrawerContent>
					</Drawer>
				)}
				<ActiveWorkoutCard />

				<Box className="p-4">
					<Header title="Summary View" />

					{/* <DateRangeSelector
						selectedDate={selectedDate}
						formatDate={formatDate}
						changeDate={changeDate}
						setToday={setToday}
						setLast7Days={setLast7Days}
						setCurrentWeek={setCurrentWeek}
						setLast3Days={setLast3Days}
					/> */}

					{/* Streak Card with Pentagon Badge */}
					{streaks && (
						<StreakPentagonCard streaks={streaks} isLoading={streaksLoading} />
					)}

					{/* Legacy Pentagon Badge (commented out) */}
					{/* <AnimatedPentagonBadge
						completedCount={2}
						label="of 5 workouts completed"
						size={80}
					/> */}

					<CaloriesChartCard
						startDate={selectedDate.startDate}
						endDate={selectedDate.endDate}
					/>

					{/* <HStack className="justify-between mt-4 mb-8 gap-4">
						<Button
							size="lg"
							variant="solid"
							className="flex-1 rounded-xl"
							onPress={setToday}
						>
							<ButtonText className="text-white font-semibold">
								Today
							</ButtonText>
						</Button>
					</HStack> */}
				</Box>
			</ScrollView>
			<ActionFab />
		</SafeAreaView>
	);
}
