import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import { Alert, Linking, Pressable, SafeAreaView } from "react-native";
import Header from "@/components/common/Header";
import { ActionFab } from "@/components/screens/home/ActionFab";
import { Box } from "@/components/ui/box";
import { Button, ButtonText } from "@/components/ui/button";
import { Text } from "@/components/ui/text";
import { VStack } from "@/components/ui/vstack";
import useAuth from "@/hooks/useAuth";

export default function ProfileScreen() {
	const { user, handleLogout } = useAuth();
	const [showDeleteDialog, setShowDeleteDialog] = useState(false);

	const menuItems = [
		{
			title: "Update Profile",
			onPress: () => router.push("/update-profile"),
		},
		{
			title: "My Files",
			onPress: () => router.push("/my-files"),
		},
		{
			title: "Change Password",
			onPress: () => router.push("/change-password"),
		},
		{
			title: "Request Account Deletion",
			onPress: () => setShowDeleteDialog(true),
		},
	];

	// Admin-only menu items
	if (user?.role === "ADMIN") {
		menuItems.splice(1, 0, {
			title: "Energy Expenditure Algorithm",
			onPress: () => router.push("/calorie-method-selection"),
		});
		menuItems.push({
			title: "PNOE Debug Data",
			onPress: () => router.push("/pnoe-debug"),
		});
	}

	const handleOpenDeleteForm = () => {
		Linking.openURL(
			"https://docs.google.com/forms/d/e/1FAIpQLSccsByK82oeVxypYcYXzXiFraSF94MSFauKlndghh7QkJcWCQ/viewform?usp=header",
		);
		setShowDeleteDialog(false);
	};

	return (
		<SafeAreaView className="flex-1 bg-background-50">
			<Box className="p-4 flex-1">
				<VStack className="gap-2">
					<Header title="Profile Settings" />

					<VStack className="gap-2">
						{menuItems.map((item, index) => (
							<Pressable
								key={item.title}
								onPress={item.onPress}
								className="flex-row items-center justify-between p-4 bg-white rounded-lg"
							>
								<Text size="lg" className="text-typography-900">
									{item.title}
								</Text>
								<Feather name="chevron-right" size={20} color="#6B7280" />
							</Pressable>
						))}
					</VStack>
					<Button
						size="lg"
						variant="solid"
						className="bg-primary-500 rounded-xl "
						onPress={handleLogout}
					>
						<ButtonText className="text-white font-semibold">Logout</ButtonText>
					</Button>
				</VStack>
			</Box>
			<ActionFab />
			{showDeleteDialog && (
				<Box className="absolute left-0 right-0 bottom-0 top-0 items-center justify-center bg-black/40">
					<Box className="bg-white p-6 rounded-xl w-5/6 max-w-md items-center">
						<Text size="xl" className="font-bold mb-2">
							Request Account Deletion
						</Text>
						<Text className="mb-4 text-center">
							To request deletion of your account and data, please fill out our
							secure online form. Our team will process your request as soon as
							possible.
						</Text>
						<Button className="mb-2 w-full" onPress={handleOpenDeleteForm}>
							<ButtonText>Open Deletion Request Form</ButtonText>
						</Button>
						<Button
							variant="outline"
							className="w-full"
							onPress={() => setShowDeleteDialog(false)}
						>
							<ButtonText>Cancel</ButtonText>
						</Button>
					</Box>
				</Box>
			)}
		</SafeAreaView>
	);
}
