import { router, Stack, usePathname } from "expo-router";
import { Lato_400Regular, useFonts } from "@expo-google-fonts/lato";

import "@/global.css";
import { GluestackUIProvider } from "@/components/ui/gluestack-ui-provider";
import { useEffect, useRef, useState } from "react";
import * as Updates from "expo-updates";
import { VStack } from "@/components/ui/vstack";
import { ActivityIndicator, Image, Platform } from "react-native";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import * as SplashScreen from "expo-splash-screen";
import { Box } from "@/components/ui/box";
import * as Notifications from "expo-notifications";
import * as Device from "expo-device";
import Constants from "expo-constants";
import * as Linking from "expo-linking";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

SplashScreen.preventAutoHideAsync();
SplashScreen.setOptions({
  fade: true,
  duration: 1000,
});

export default function RootLayout() {
  const pathname = usePathname();
  const url = Linking.useLinkingURL();

  const [loaded, error] = useFonts({
    Lato_400Regular,
  });

  const { isUpdateAvailable, isDownloading } = Updates.useUpdates();

  useEffect(() => {
    if (loaded || error) {
      SplashScreen.hideAsync();
    }
  }, [loaded, error]);

  useEffect(() => {
    if (isUpdateAvailable) {
      Updates.reloadAsync();
    }
  }, [isUpdateAvailable]);

  useEffect(() => {
    if (!loaded || error) {
      return;
    }

    if (url) {
      const { path } = Linking.parse(url);

      if (!path) {
        return;
      }

      console.log("[RootLayout] path", path);
      // crash app if url is not valid
      if (!["auth/reset-password", "auth/verify-email"].includes(path ?? "")) {
        throw new Error("Invalid URL");
      }
    }
  }, [url, loaded, error]);

  // const [expoPushToken, setExpoPushToken] = useState("");
  // const [channels, setChannels] = useState<Notifications.NotificationChannel[]>(
  //   []
  // );
  // const [notification, setNotification] = useState<
  //   Notifications.Notification | undefined
  // >(undefined);
  // const notificationListener = useRef<Notifications.EventSubscription>();
  // const responseListener = useRef<Notifications.EventSubscription>();

  // useEffect(() => {
  //   registerForPushNotificationsAsync().then(
  //     (token) => token && setExpoPushToken(token)
  //   );

  //   if (Platform.OS === "android") {
  //     Notifications.getNotificationChannelsAsync().then((value) =>
  //       setChannels(value ?? [])
  //     );
  //   }
  //   notificationListener.current =
  //     Notifications.addNotificationReceivedListener((notification) => {
  //       setNotification(notification);
  //     });

  //   responseListener.current =
  //     Notifications.addNotificationResponseReceivedListener((response) => {});

  //   return () => {
  //     notificationListener.current &&
  //       Notifications.removeNotificationSubscription(
  //         notificationListener.current
  //       );
  //     responseListener.current &&
  //       Notifications.removeNotificationSubscription(responseListener.current);
  //   };
  // }, []);

  if (!loaded && !error) {
    return null;
  }

  if (isUpdateAvailable || isDownloading) {
    return (
      <GluestackUIProvider>
        <Box className="flex-1 bg-background-50">
          <VStack className="flex-1 items-center justify-center gap-8">
            <VStack className="items-center justify-around gap-4 h-2/3">
              <Image
                source={require("@/assets/images/logo.png")}
                style={{
                  width: 200,
                  height: 200,
                  objectFit: "contain",
                }}
              />
              <VStack className="items-center gap-4">
                <Text size="2xl" className="font-bold text-typography-50">
                  New update is available
                </Text>
                {isDownloading ? (
                  <ActivityIndicator size="large" color="#16A34A" />
                ) : (
                  <Button
                    size="lg"
                    variant="solid"
                    className="bg-primary-500"
                    onPress={() => Updates.reloadAsync()}
                    disabled={isDownloading}
                  >
                    <ButtonText>Download update</ButtonText>
                  </Button>
                )}
              </VStack>
            </VStack>
          </VStack>
        </Box>
      </GluestackUIProvider>
    );
  }

  return (
    <GluestackUIProvider>
      <Stack
        screenOptions={{
          headerShown: false,
        }}
        initialRouteName="(public)"
      >
        <Stack.Screen name="(public)" />
        <Stack.Screen name="(private)" />
      </Stack>
    </GluestackUIProvider>
  );
}
