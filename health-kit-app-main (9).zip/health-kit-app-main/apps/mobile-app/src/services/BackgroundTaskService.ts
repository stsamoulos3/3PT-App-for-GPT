import * as TaskManager from "expo-task-manager";
import * as BackgroundFetch from "expo-background-fetch";
import { HealthService } from "./HealthService";
import { StepsService } from "@repo/core/services/StepsService";
import { HeartRateService } from "@repo/core/services/HeartRateService";
import { WorkoutService } from "@repo/core/services/WorkoutService";

import useAuthStore from "@/store/auth.store";
import Healthkit, {
	HKQuantityTypeIdentifier,
} from "@kingstinct/react-native-healthkit";
import moment from "moment";

export const BACKGROUND_FETCH_TASK = "background-fetch";

// biome-ignore lint/complexity/noStaticOnlyClass: <explanation>
class BackgroundTaskService {
	static async registerBackgroundFetchAsync() {
		try {
			await BackgroundFetch.registerTaskAsync(BACKGROUND_FETCH_TASK, {
				minimumInterval: 15 * 60, // 15 minutes
				stopOnTerminate: false, // android only,
				startOnBoot: true, // android only
			});
			console.log("Task registered successfully");
		} catch (err) {
			console.log("Task Register failed:", err);
		}
	}

	static async unregisterBackgroundFetchAsync() {
		try {
			if (
				(await BackgroundFetch.getStatusAsync()) ===
				BackgroundFetch.BackgroundFetchStatus.Available
			) {
				await BackgroundFetch.unregisterTaskAsync(BACKGROUND_FETCH_TASK);
				console.log("Task unregistered successfully");
			}
		} catch (err) {
			console.log("Task Unregister failed:", err);
		}
	}

	static async saveHealthData(
		date: Date,
		data: any,
		userId: string,
		accessToken: string,
	) {
		try {
			const promises = [];

			// Save steps
			if (data.steps && data.steps.length > 0) {
				promises.push(
					StepsService.createBulkSteps(
						data.steps.map((step: any) => ({
							timestamp: new Date(step.startDate),
							stepsCount: step.value,
						})),
						accessToken,
					),
				);
			}

			// Save heart rates
			if (data.heartRates) {
				promises.push(
					HeartRateService.createBulkHeartRate(
						data.heartRates.map((hr: any) => ({
							timestamp: new Date(hr.startDate),
							heartRateBPM: hr.value,
							hkId: hr.id,
						})),
						accessToken,
					),
				);
			}

			// Save workouts
			if (data.workouts) {
				promises.push(
					...data.workouts.map(async (workout: any) => {
						const averageHeartRateBPM =
							await HealthService.getAverageHeartRateDuringWorkout(workout);

						return WorkoutService.create(
							{
								userId,
								activityType: workout.activityName,
								startDate: new Date(workout.start),
								endDate: new Date(workout.end),
								totalDistanceMeters: workout.distance,
								totalEnergyBurnedKcal: workout.calories,
								workoutDurationSeconds: workout.duration,
								averageHeartRateBPM: averageHeartRateBPM.averageHeartRate,
								firstHeartRateTime: averageHeartRateBPM.firstHeartRateSample
									?.startDate
									? new Date(
											averageHeartRateBPM.firstHeartRateSample?.startDate,
										)
									: undefined,
								lastHeartRateTime: averageHeartRateBPM.lastHeartRateSample
									?.startDate
									? new Date(averageHeartRateBPM.lastHeartRateSample?.startDate)
									: undefined,
								highestHeartRate: averageHeartRateBPM.highestHeartRate,
								lowestHeartRate: averageHeartRateBPM.lowestHeartRate,
								hkId: workout.id,
							},
							accessToken,
						);
					}),
				);
			}

			await Promise.all(promises);
		} catch (error) {
			console.error("Error saving health data:", error);
			throw error;
		}
	}

	static async fetchHealthData(date: Date) {
		try {
			// Get user info from store
			const { user, accessToken } = useAuthStore.getState();
			if (!user?.id || !accessToken) {
				throw new Error("User not authenticated");
			}

			const isAuthorized = await Healthkit.authorizationStatusFor(
				HKQuantityTypeIdentifier.heartRate,
			);
			if (!isAuthorized) {
				return;
			}

			const healthData = await Promise.all([
				HealthService.getStepCount(date),
				HealthService.getHeartRateSamples(
					moment(date).startOf("day").toDate(),
					moment(date).endOf("day").toDate(),
				),
				HealthService.getWorkouts(date),
			]);

			const [steps, heartRates, workouts] = healthData;

			const data = {
				steps,
				heartRates,
				workouts,
			};

			// Save all the data
			// biome-ignore lint/complexity/noThisInStatic: <explanation>
			await this.saveHealthData(date, data, user.id, accessToken);

			console.log("Background fetch and save completed successfully");
			return data;
		} catch (error) {
			console.error("Error in background fetch:", error);
		}
	}
}

// Define the background task
// TaskManager.defineTask(BACKGROUND_FETCH_TASK, async (t) => {
//   const now = new Date();

//   console.log(
//     `Background fetch started at: ${now.toISOString()} t.executionInfo.appState? ${t.executionInfo.appState}`
//   );

//   try {
//     await BackgroundTaskService.fetchHealthData(now);
//     return BackgroundFetch.BackgroundFetchResult.NewData;
//   } catch (error) {
//     console.error("Background fetch failed:", error);
//     return BackgroundFetch.BackgroundFetchResult.NoData;
//   }
// });

export default BackgroundTaskService;
