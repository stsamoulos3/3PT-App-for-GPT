import {
  queryQuantitySamples,
  HKQuantityTypeIdentifier,
  HKQuantitySample,
} from "@kingstinct/react-native-healthkit";
import { HeartRateDevice } from "@/store/tracker.store";
import moment from "moment";

export interface HeartRateSample {
  quantity: number;
  startDate: Date;
  endDate: Date;
  source: {
    name: string;
    bundleIdentifier: string;
  };
}

export class HeartRateDeviceService {
  private static instance: HeartRateDeviceService;
  private heartRateTimeoutCallbacks: Set<() => void> = new Set();
  private deviceStatusCallbacks: Set<
    (deviceId: string, isConnected: boolean) => void
  > = new Set();

  public static getInstance(): HeartRateDeviceService {
    if (!HeartRateDeviceService.instance) {
      HeartRateDeviceService.instance = new HeartRateDeviceService();
    }
    return HeartRateDeviceService.instance;
  }

  /**
   * Get all available heart rate devices from recent heart rate samples
   */
  async getAvailableDevices(
    lookbackHours: number = 24
  ): Promise<HeartRateDevice[]> {
    try {
      const heartRateResults = (await queryQuantitySamples(
        HKQuantityTypeIdentifier.heartRate,
        {
          from: moment().subtract(lookbackHours, "hours").toDate(),
          to: new Date(),
        }
      )) as HKQuantitySample<HKQuantityTypeIdentifier.heartRate>[];

      if (!heartRateResults || heartRateResults.length === 0) {
        return [];
      }

      // Group by source and track latest activity
      const sourceMap = new Map<string, HeartRateDevice>();

      heartRateResults.forEach((sample) => {
        if (
          sample.sourceRevision &&
          sample.sourceRevision.source.name &&
          sample.sourceRevision.source.bundleIdentifier
        ) {
          const sourceId = `${sample.sourceRevision.source.bundleIdentifier}_${sample.sourceRevision.source.name}`;
          const existingDevice = sourceMap.get(sourceId);
          const sampleDate = new Date(sample.startDate);

          if (
            !existingDevice ||
            (existingDevice.lastDataTime &&
              sampleDate > existingDevice.lastDataTime)
          ) {
            // Consider device connected if it provided data in the last 30 minutes
            const isConnected =
              moment().diff(moment(sampleDate), "minutes") <= 5;

            sourceMap.set(sourceId, {
              id: sourceId,
              name: sample.sourceRevision.source.name,
              bundleIdentifier: sample.sourceRevision.source.bundleIdentifier,
              isConnected,
              lastDataTime: sampleDate,
            });
          }
        }
      });

      return Array.from(sourceMap.values()).sort((a, b) => {
        // Sort by connection status first, then by last data time
        if (a.isConnected && !b.isConnected) return -1;
        if (!a.isConnected && b.isConnected) return 1;

        if (a.lastDataTime && b.lastDataTime) {
          return b.lastDataTime.getTime() - a.lastDataTime.getTime();
        }

        return a.name.localeCompare(b.name);
      });
    } catch (error) {
      console.error(
        "[HeartRateDeviceService] Error fetching available devices:",
        error
      );
      return [];
    }
  }

  /**
   * Get heart rate samples filtered by specific device
   */
  async getHeartRateSamplesForDevice(
    device: HeartRateDevice | null,
    startDate: Date,
    endDate?: Date
  ): Promise<HeartRateSample[]> {
    try {
      const queryOptions = {
        from: startDate,
        to: endDate || new Date(),
      };

      const heartRateResults = (await queryQuantitySamples(
        HKQuantityTypeIdentifier.heartRate,
        queryOptions
      )) as HKQuantitySample<HKQuantityTypeIdentifier.heartRate>[];

      if (!heartRateResults || heartRateResults.length === 0) {
        return [];
      }

      // Filter by device if specified
      let filteredResults = heartRateResults;
      if (device) {
        filteredResults = heartRateResults.filter((sample) => {
          return (
            sample.sourceRevision &&
            sample.sourceRevision.source.bundleIdentifier ===
              device.bundleIdentifier &&
            sample.sourceRevision.source.name === device.name
          );
        });
      }

      return filteredResults.map((sample) => ({
        quantity: sample.quantity,
        startDate: new Date(sample.startDate),
        endDate: new Date(sample.endDate),
        source: {
          name: sample.sourceRevision?.source?.name || "Unknown",
          bundleIdentifier:
            sample.sourceRevision?.source?.bundleIdentifier || "unknown",
        },
      }));
    } catch (error) {
      console.error(
        "[HeartRateDeviceService] Error fetching heart rate samples:",
        error
      );
      return [];
    }
  }

  /**
   * Check if a device is still providing data
   */
  async checkDeviceConnectionStatus(
    device: HeartRateDevice,
    timeoutMinutes: number = 2
  ): Promise<boolean> {
    try {
      const samples = await this.getHeartRateSamplesForDevice(
        device,
        moment().subtract(timeoutMinutes, "minutes").toDate()
      );

      const isConnected = samples.length > 0;

      // Notify listeners about status change
      this.deviceStatusCallbacks.forEach((callback) => {
        callback(device.id, isConnected);
      });

      return isConnected;
    } catch (error) {
      console.error(
        "[HeartRateDeviceService] Error checking device status:",
        error
      );
      return false;
    }
  }

  /**
   * Get the most recent heart rate reading for a specific device
   */
  async getMostRecentHeartRate(device: HeartRateDevice | null): Promise<{
    heartRate: number;
    timestamp: Date;
    isFromSelectedDevice: boolean;
  } | null> {
    try {
      // Look back 5 minutes to get recent data
      const samples = await this.getHeartRateSamplesForDevice(
        device,
        moment().subtract(5, "minutes").toDate()
      );

      if (samples.length === 0) {
        return null;
      }

      // Get the most recent sample
      const mostRecent = samples[samples.length - 1];

      return {
        heartRate: mostRecent.quantity,
        timestamp: mostRecent.startDate,
        isFromSelectedDevice: device !== null,
      };
    } catch (error) {
      console.error(
        "[HeartRateDeviceService] Error getting most recent heart rate:",
        error
      );
      return null;
    }
  }

  /**
   * Start monitoring for heart rate timeout (15 seconds)
   */
  startHeartRateTimeoutMonitoring(
    device: HeartRateDevice | null,
    onTimeout: () => void,
    timeoutSeconds: number = 15
  ): () => void {
    const timeoutId = setInterval(async () => {
      const recentReading = await this.getMostRecentHeartRate(device);

      if (!recentReading) {
        onTimeout();
        return;
      }

      const timeSinceLastReading = moment().diff(
        moment(recentReading.timestamp),
        "seconds"
      );

      if (timeSinceLastReading >= timeoutSeconds) {
        onTimeout();
      }
    }, 5000); // Check every 5 seconds

    // Return cleanup function
    return () => {
      clearInterval(timeoutId);
    };
  }

  /**
   * Start monitoring device connection status
   */
  startDeviceConnectionMonitoring(
    device: HeartRateDevice,
    onDisconnected: (device: HeartRateDevice) => void,
    checkIntervalSeconds: number = 30
  ): () => void {
    const intervalId = setInterval(async () => {
      const isConnected = await this.checkDeviceConnectionStatus(device);

      if (!isConnected) {
        onDisconnected(device);
      }
    }, checkIntervalSeconds * 1000);

    // Return cleanup function
    return () => {
      clearInterval(intervalId);
    };
  }

  /**
   * Register callback for heart rate timeout events
   */
  onHeartRateTimeout(callback: () => void): () => void {
    this.heartRateTimeoutCallbacks.add(callback);

    return () => {
      this.heartRateTimeoutCallbacks.delete(callback);
    };
  }

  /**
   * Register callback for device status changes
   */
  onDeviceStatusChange(
    callback: (deviceId: string, isConnected: boolean) => void
  ): () => void {
    this.deviceStatusCallbacks.add(callback);

    return () => {
      this.deviceStatusCallbacks.delete(callback);
    };
  }

  /**
   * Get heart rate statistics for a workout period
   */
  async getWorkoutHeartRateStats(
    device: HeartRateDevice | null,
    startDate: Date,
    endDate: Date
  ): Promise<{
    average: number;
    max: number;
    min: number;
    count: number;
    validReadings: number[];
  }> {
    try {
      const samples = await this.getHeartRateSamplesForDevice(
        device,
        startDate,
        endDate
      );

      if (samples.length === 0) {
        return {
          average: 0,
          max: 0,
          min: 0,
          count: 0,
          validReadings: [],
        };
      }

      const validReadings = samples
        .map((sample) => sample.quantity)
        .filter((rate) => rate > 0 && rate < 300); // Reasonable heart rate bounds

      if (validReadings.length === 0) {
        return {
          average: 0,
          max: 0,
          min: 0,
          count: samples.length,
          validReadings: [],
        };
      }

      const average =
        validReadings.reduce((sum, rate) => sum + rate, 0) /
        validReadings.length;
      const max = Math.max(...validReadings);
      const min = Math.min(...validReadings);

      return {
        average,
        max,
        min,
        count: samples.length,
        validReadings,
      };
    } catch (error) {
      console.error(
        "[HeartRateDeviceService] Error calculating workout stats:",
        error
      );
      return {
        average: 0,
        max: 0,
        min: 0,
        count: 0,
        validReadings: [],
      };
    }
  }
}
