import KHealthKit, {
	HKQuantityTypeIdentifier,
	type HKUnit,
	HKUnitMetric,
	HKWorkoutActivityType,
	UnitOfEnergy,
	UnitOfLength,
} from "@kingstinct/react-native-healthkit";
import { fromUTCToLocal, getUTCDateRange } from "@repo/core/helpers/dateUtils";
import { WorkoutService } from "@repo/core/services/WorkoutService";
import { DateTime } from "luxon";
import moment from "moment";
import type {
	HealthInputOptions,
	HealthValue,
	HKWorkoutEventType,
	HKWorkoutQueriedSampleType,
} from "react-native-health";
import { HealthKit } from "../helpers/healthkit";

export interface BodyMeasurements {
	bodyFatPercentage: { value: number; timestamp: string };
	bodyMassIndex: { value: number; timestamp: string };
	bodyTemperature: { value: number; timestamp: string };
	leanBodyMass: { value: number; timestamp: string };
	waistCircumference: { value: number; timestamp: string };
}

export interface MobilityMetrics {
	walkingSpeed: number;
	stepLength: number;
	asymmetry: number;
	doubleSupport: number;
}

export interface VitalSigns {
	bloodPressureSystolic: number;
	bloodPressureDiastolic: number;
	oxygenSaturation: number;
	respiratoryRate: number;
	bodyTemperature: number;
}

export interface VitalSignsSamples {
	bloodPressureSystolics: Array<{ value: number; timestamp: string }>;
	bloodPressureDiastolics: Array<{ value: number; timestamp: string }>;
	oxygenSaturations: Array<{ value: number; timestamp: string }>;
	respiratoryRates: Array<{ value: number; timestamp: string }>;
	bodyTemperatures: Array<{ value: number; timestamp: string }>;
}

export interface NutritionData {
	value: number;
	timestamp: string;
	quantityType: HKQuantityTypeIdentifier;
	unit: HKUnit;
	hkId: string;
}

export interface Nutritions {
	calories: Array<NutritionData>;
	protein: Array<NutritionData>;
	carbs: Array<NutritionData>;
	fat: Array<NutritionData>;
}

// biome-ignore lint/complexity/noStaticOnlyClass: <explanation>
export class HealthService {
	private static getDateRange(startDate: Date, endDate?: Date) {
		return getUTCDateRange(startDate, endDate);
	}

	static async getStepCount(date: Date): Promise<
		{
			value: number;
			startDate: string;
			endDate: string;
		}[]
	> {
		try {
			const dateTime = DateTime.fromJSDate(date);
			const results: {
				value: number;
				startDate: string;
				endDate: string;
			}[] = await new Promise((resolve, reject) => {
				HealthKit.getDailyStepCountSamples(
					{
						startDate: dateTime.startOf("day").toISO(),
						endDate: dateTime.endOf("day").toISO(),
					} as HealthInputOptions,
					(
						err: Record<string, unknown>,
						results: {
							value: number;
							startDate: string;
							endDate: string;
						}[],
					) => {
						if (err) {
							reject(err);
							return;
						}
						resolve(results);
					},
				);
			});

			return results || [];
		} catch (error) {
			console.error("Error fetching steps:", error);
			return [];
		}
	}

	static async getHeartRateSamples(
		startDate: Date,
		endDate?: Date,
	): Promise<HealthValue[]> {
		try {
			const dateRange = HealthService.getDateRange(startDate, endDate);

			return await new Promise((resolve, reject) => {
				HealthKit.getHeartRateSamples(
					{
						...dateRange,
						ascending: true,
					} as HealthInputOptions,
					(err: Record<string, unknown>, results: HealthValue[]) => {
						if (err) {
							reject(err);
							return;
						}
						resolve(results || []);
					},
				);
			});
		} catch (error) {
			return [];
		}
	}

	static async getWorkouts(
		startDate: Date,
		endDate?: Date,
		accessToken?: string,
	): Promise<HKWorkoutQueriedSampleType[]> {
		const dateRange = HealthService.getDateRange(startDate, endDate);

		try {
			const start = DateTime.fromJSDate(startDate).startOf("day");
			const end = endDate
				? DateTime.fromJSDate(endDate).endOf("day")
				: start.endOf("day");

			const results = await WorkoutService.list(
				{
					filter: {
						startDate: moment(startDate).startOf("day").toISOString(),
						endDate: moment(endDate).endOf("day").toISOString(),
					},
				},
				accessToken!,
			);

			return results.data
				.map(
					(workout) =>
						({
							activityId: workout.activityType,
							activityName: workout.activityType,
							calories: workout.totalEnergyBurnedKcal,
							device: workout.device,
							id: workout.hkId,
							tracked: true,
							sourceId: workout.source,
							sourceName: workout.source,
							distance: workout.totalDistanceMeters,
							start: workout.startDate,
							end: workout.endDate,
							duration: workout.workoutDurationSeconds,
							metadata: workout.metadata,
							workoutEvents: [],
						}) satisfies HKWorkoutQueriedSampleType,
				)
				.sort(
					(a, b) => new Date(b.start).getTime() - new Date(a.start).getTime(),
				);
		} catch (error) {
			console.error("Error fetching workouts:", error);
			return [];
		}
	}

	static async getWorkoutsFromHealthKit(
		startDate: Date,
		endDate?: Date,
	): Promise<HKWorkoutQueriedSampleType[]> {
		try {
			const start = DateTime.fromJSDate(startDate).startOf("day");
			const end = endDate
				? DateTime.fromJSDate(endDate).endOf("day")
				: start.endOf("day");

			const results = await KHealthKit.queryWorkoutSamples({
				from: start.toJSDate(),
				to: end.toJSDate(),
				limit: 100,
				distanceUnit: UnitOfLength.Miles,
			});

			return results
				.map(
					(result) =>
						({
							activityId: result.workoutActivityType,
							activityName:
								HKWorkoutActivityType[
									result.workoutActivityType
								].toLocaleUpperCase(),
							calories: result.totalEnergyBurned?.quantity ?? 0,
							device: result.device?.name ?? "",
							distance: result.totalDistance?.quantity ?? 0,
							id: result.uuid,
							tracked: true,
							sourceId: result.sourceRevision?.source.bundleIdentifier ?? "",
							sourceName: result.sourceRevision?.source.name ?? "",
							workoutEvents: (result.events as any) ?? [],
							start: result.startDate.toISOString(),
							end: result.endDate.toISOString(),
							duration: result.duration,
							metadata: result.metadata,
						}) satisfies HKWorkoutQueriedSampleType,
				)
				.sort(
					(a, b) => new Date(b.start).getTime() - new Date(a.start).getTime(),
				);
		} catch (error) {
			console.error("Error fetching workouts:", error);
			return [];
		}
	}

	static async getAverageHeartRateDuringWorkout(
		workout: Pick<HKWorkoutQueriedSampleType, "start" | "end">,
	): Promise<{
		averageHeartRate: number;
		firstHeartRateSample: HealthValue | null;
		lastHeartRateSample: HealthValue | null;
		highestHeartRate: number;
		lowestHeartRate: number;
		lastHeartRateTime: string | null;
		firstHeartRateTime: string | null;
	}> {
		const heartRateSamples = await new Promise<HealthValue[]>(
			(resolve, reject) => {
				HealthKit.getHeartRateSamples(
					{
						startDate: moment(workout.start).toISOString(),
						endDate:
							moment(workout.end).minute() === moment(workout.start).minute()
								? moment(workout.end).toDate()
								: workout.end,
					} as HealthInputOptions,
					(err: Record<string, unknown>, results: HealthValue[]) => {
						if (err) {
							reject(err);
							return;
						}
						resolve(results || []);
					},
				);
			},
		).catch((err) => {
			console.error("[getAverageHeartRateDuringWorkout] error", err);
			return [];
		});

		// Return default values if no heart rate samples
		if (!heartRateSamples || (heartRateSamples as HealthValue[]).length === 0) {
			return {
				averageHeartRate: 0,
				firstHeartRateSample: null,
				lastHeartRateSample: null,
				highestHeartRate: 0,
				lowestHeartRate: 0,
				lastHeartRateTime: null,
				firstHeartRateTime: null,
			};
		}

		// we only need to get heart rates in 15 second intervals from previous heart rate samples
		const highestHeartRate = 0;
		let lowestHeartRate = Number.MAX_VALUE;

		// const heartRateSamplesIn15SecondIntervals = (
		//   heartRateSamples as HealthValue[]
		// ).filter((sample) => {
		//   // Update highest heart rate
		//   if (sample.value > highestHeartRate) {
		//     highestHeartRate = sample.value;
		//   }

		//   // Fix: Proper lowest heart rate comparison
		//   if (sample.value < lowestHeartRate) {
		//     lowestHeartRate = sample.value;
		//   }

		//   if (!previousHeartRateSamples) {
		//     previousHeartRateSamples = sample;
		//     return true;
		//   }

		//   if (
		//     new Date(sample.startDate).getTime() -
		//       new Date(previousHeartRateSamples.startDate).getTime() >=
		//     15000
		//   ) {
		//     previousHeartRateSamples = sample;
		//     return true;
		//   }

		//   return false;
		// });

		// Fix: Array index bug - use length - 1
		const firstHeartRateSample: HealthValue | null =
			heartRateSamples[0] || null;
		const lastHeartRateSample: HealthValue | null =
			heartRateSamples[heartRateSamples.length - 1] || null;

		// Fix: Protect against division by zero and handle empty arrays
		const averageHeartRate =
			heartRateSamples.length > 0
				? Math.round(
						heartRateSamples.reduce((sum, sample) => sum + sample.value, 0) /
							heartRateSamples.length,
					)
				: 0;

		// Fix: Handle case when no valid heart rate samples found
		if (lowestHeartRate === Number.MAX_VALUE) {
			lowestHeartRate = 0;
		}

		return {
			averageHeartRate,
			firstHeartRateSample,
			lastHeartRateSample,
			highestHeartRate,
			lowestHeartRate,
			lastHeartRateTime: lastHeartRateSample?.startDate || null,
			firstHeartRateTime: firstHeartRateSample?.startDate || null,
		};
	}

	static formatWorkoutDuration(startDate: string, endDate: string): string {
		const start = DateTime.fromISO(startDate);
		const end = DateTime.fromISO(endDate);
		const durationMinutes = end.diff(start, "minutes").minutes;
		return `${Math.floor(durationMinutes)} min`;
	}

	static formatWorkoutTime(dateString: string, withAmPm?: boolean): string {
		return fromUTCToLocal(dateString, withAmPm ? "hh:mm a" : "hh:mm");
	}

	static async getNutritionData(
		startDate: Date,
		endDate?: Date,
	): Promise<Nutritions> {
		try {
			const start = DateTime.fromJSDate(startDate).startOf("day");
			const end = endDate
				? DateTime.fromJSDate(endDate).endOf("day")
				: start.endOf("day");

			const [calories, protein, carbs, fat] = await Promise.all([
				new Promise<NutritionData[]>((resolve) => {
					KHealthKit.queryQuantitySamples(
						HKQuantityTypeIdentifier.dietaryEnergyConsumed,
						{
							from: start.toJSDate(),
							to: end.toJSDate(),
						},
					).then((results) => {
						resolve(
							results.map((result) => ({
								value: result.quantity,
								timestamp: result.startDate.toISOString(),
								quantityType: result.quantityType,
								unit: result.unit,
								hkId: result.uuid,
							})),
						);
					});
				}),
				new Promise<NutritionData[]>((resolve) => {
					KHealthKit.queryQuantitySamples(
						HKQuantityTypeIdentifier.dietaryProtein,
						{
							from: start.toJSDate(),
							to: end.toJSDate(),
						},
					).then((results) => {
						resolve(
							results.map((result) => ({
								value: result.quantity,
								timestamp: result.startDate.toISOString(),
								quantityType: result.quantityType,
								unit: result.unit,
								hkId: result.uuid,
							})),
						);
					});
				}),
				new Promise<NutritionData[]>((resolve) => {
					KHealthKit.queryQuantitySamples(
						HKQuantityTypeIdentifier.dietaryCarbohydrates,
						{
							from: start.toJSDate(),
							to: end.toJSDate(),
						},
					).then((results) => {
						resolve(
							results.map((result) => ({
								value: result.quantity,
								timestamp: result.startDate.toISOString(),
								quantityType: result.quantityType,
								unit: result.unit,
								hkId: result.uuid,
							})),
						);
					});
				}),

				new Promise<NutritionData[]>((resolve) => {
					KHealthKit.queryQuantitySamples(
						HKQuantityTypeIdentifier.dietaryFatTotal,
						{
							from: start.toJSDate(),
							to: end.toJSDate(),
						},
					).then((results) => {
						resolve(
							results.map((result) => ({
								value: result.quantity,
								timestamp: result.startDate.toISOString(),
								quantityType: result.quantityType,
								unit: result.unit,
								hkId: result.uuid,
							})),
						);
					});
				}),
			]);

			return {
				calories,
				protein,
				carbs,
				fat,
			};
		} catch (error) {
			console.error("Error fetching nutrition data:", error);
			return {
				calories: [],
				protein: [],
				carbs: [],
				fat: [],
			};
		}
	}

	static async saveWorkoutSample(workout: {
		activityName: string;
		start: string;
		end: string;
		calories: number;
		distance: number;
		workoutEvents: HKWorkoutEventType[];
	}) {
		// save workout sample
		await HealthKit.saveWorkout(
			{
				type: workout.activityName,
				startDate: workout.start,
				endDate: workout.end,
				energyBurned: workout.calories,
				energyBurnedUnit: UnitOfEnergy.LargeCalories,
				distance: workout.distance,
				distanceUnit: UnitOfLength.Miles,
			},
			(err: Record<string, unknown>) => {
				if (err) {
					console.error("Error saving workout:", err);
				}
			},
		);
	}

	static async saveHeartRateSample(heartRateSample: HealthValue) {
		await HealthKit.saveHeartRateSample(
			heartRateSample,
			(err: Record<string, unknown>) => {
				if (err) {
					console.error("Error saving heart rate sample:", err);
				}
			},
		);
	}

	static async saveCaloriesSample(caloriesSample: NutritionData) {
		await KHealthKit.saveQuantitySample(
			HKQuantityTypeIdentifier.dietaryEnergyConsumed,
			"J",
			caloriesSample.value,
			{
				start: new Date(caloriesSample.timestamp),
				end: new Date(caloriesSample.timestamp),
			},
		);
	}

	static async getBurntCalories(
		startDate: Date,
		endDate: Date,
		vo2Max: number,
		age: number,
		isMale: boolean,
		accessToken: string,
	) {
		try {
			const start = DateTime.fromJSDate(startDate).startOf("day");
			const end = DateTime.fromJSDate(endDate).endOf("day");

			// Get all workouts in the date range
			const workouts = await HealthService.getWorkouts(
				startDate,
				endDate,
				accessToken,
			);
			const workoutCalories = [];

			for (const workout of workouts) {
				// Get average heart rate during workout
				const { averageHeartRate } =
					await HealthService.getAverageHeartRateDuringWorkout(workout);

				// Get user's weight in kg
				const weightResults = await KHealthKit.queryQuantitySamples(
					HKQuantityTypeIdentifier.bodyMass,
					{
						from: start.toJSDate(),
						to: DateTime.fromISO(workout.start).toJSDate(),
						limit: 1,
					},
				);
				const weightKg = weightResults[0]?.quantity || 0;

				// Get workout duration in minutes
				const durationMinutes = workout.duration / 60;

				// Calculate calories burned using the appropriate formula
				let caloriesBurned = workout.calories;

				if (Number.isNaN(caloriesBurned)) {
					caloriesBurned = 0;
				}

				workoutCalories.push({
					workoutId: workout.id,
					start: workout.start,
					end: workout.end,
					activityName: workout.activityName,
					calculatedCalories: -Math.min(0, Math.round(caloriesBurned)),
					measuredCalories: workout.calories,
					averageHeartRate,
					duration: durationMinutes,
				});
			}

			return workoutCalories;
		} catch (error) {
			console.error("Error calculating burnt calories:", error);
			return [];
		}
	}

	static async addDummyHeartRates() {
		// for (let i = 0; i < 1; i++) {
		await HealthService.saveHeartRateSample({
			value: Math.floor(Math.random() * (200 - 70 + 1)) + 70,
			startDate: new Date().toISOString(),
			endDate: new Date().toISOString(),
		});
		// }
	}

	static async addDummyCalories() {
		await HealthService.saveCaloriesSample({
			value: Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000,
			timestamp: new Date().toISOString(),
			quantityType: HKQuantityTypeIdentifier.dietaryEnergyConsumed,
			unit: HKUnitMetric.Joule,
			hkId: "dummy-calories",
		});
	}

	static async saveNutritionData(nutritionData: {
		quantityType: HKQuantityTypeIdentifier;
		unit: HKUnit;
		value: number;
		timestamp: string;
	}) {
		try {
			await KHealthKit.saveQuantitySample(
				nutritionData.quantityType,
				nutritionData.unit,
				nutritionData.value,
				{
					start: new Date(nutritionData.timestamp),
					end: new Date(nutritionData.timestamp),
				},
			);
		} catch (error) {
			console.error(
				"Error saving nutrition data for",
				nutritionData.quantityType,
				nutritionData.value,
			);
		}
	}

	static async saveWorkoutWithHeartRateData(workout: {
		activityType: HKWorkoutActivityType;
		start: Date;
		end: Date;
		calories: number;
		distance: number;
		averageHeartRate?: number;
		maxHeartRate?: number;
		minHeartRate?: number;
	}) {
		try {
			console.log(
				"[HealthService] Saving workout with heart rate data:",
				workout,
			);

			// Prepare workout data with heart rate metadata
			const metadata: Record<string, unknown> = {};

			if (workout.averageHeartRate && workout.averageHeartRate > 0) {
				metadata.averageHeartRate = workout.averageHeartRate;
			}

			if (workout.maxHeartRate && workout.maxHeartRate > 0) {
				metadata.maxHeartRate = workout.maxHeartRate;
			}

			if (workout.minHeartRate && workout.minHeartRate > 0) {
				metadata.minHeartRate = workout.minHeartRate;
			}

			const averageHeartRateSample =
				await HealthService.getAverageHeartRateDuringWorkout({
					start: workout.start.toISOString(),
					end: workout.end.toISOString(),
				});

			if (averageHeartRateSample.averageHeartRate > 0) {
				metadata.averageHeartRate = averageHeartRateSample.averageHeartRate;
			}

			const workoutsWithHeartRates = {
				...workout,
				activityType: workout.activityType.toString().toUpperCase(),
				averageHeartRateBPM: averageHeartRateSample.averageHeartRate,
				firstHeartRateTime:
					averageHeartRateSample.firstHeartRateSample?.startDate,
				lastHeartRateTime:
					averageHeartRateSample.lastHeartRateSample?.startDate,
				highestHeartRate: averageHeartRateSample.highestHeartRate,
				lowestHeartRate: averageHeartRateSample.lowestHeartRate,
			};

			await KHealthKit.saveWorkoutSample(
				workout.activityType,
				[], // No additional samples for now
				workout.start,
				{
					end: workout.end,
					totals: {
						distance: workout.distance,
						energyBurned: workout.calories,
					},
					metadata: Object.keys(metadata).length > 0 ? metadata : undefined,
				},
			);

			console.log(
				"[HealthService] Workout saved successfully with metadata:",
				metadata,
			);
			return true;
		} catch (error) {
			console.error("[HealthService] Error saving workout:", error);
			return false;
		}
	}
}

export enum NutritionToHKQuantityType {
	calories = HKQuantityTypeIdentifier.dietaryEnergyConsumed,
	totalFat = HKQuantityTypeIdentifier.dietaryFatTotal,
	saturatedFat = HKQuantityTypeIdentifier.dietaryFatSaturated,
	polyunsaturatedFat = HKQuantityTypeIdentifier.dietaryFatPolyunsaturated,
	monounsaturatedFat = HKQuantityTypeIdentifier.dietaryFatMonounsaturated,
	cholesterol = HKQuantityTypeIdentifier.dietaryCholesterol,
	sodium = HKQuantityTypeIdentifier.dietarySodium,
	totalCarbohydrates = HKQuantityTypeIdentifier.dietaryCarbohydrates,
	dietaryFiber = HKQuantityTypeIdentifier.dietaryFiber,
	sugars = HKQuantityTypeIdentifier.dietarySugar,
	protein = HKQuantityTypeIdentifier.dietaryProtein,
	calcium = HKQuantityTypeIdentifier.dietaryCalcium,
	iron = HKQuantityTypeIdentifier.dietaryIron,
	potassium = HKQuantityTypeIdentifier.dietaryPotassium,
	vitaminA = HKQuantityTypeIdentifier.dietaryVitaminA,
	vitaminC = HKQuantityTypeIdentifier.dietaryVitaminC,
	vitaminD = HKQuantityTypeIdentifier.dietaryVitaminD,

	caffeine = HKQuantityTypeIdentifier.dietaryCaffeine,
	copper = HKQuantityTypeIdentifier.dietaryCopper,
	manganese = HKQuantityTypeIdentifier.dietaryManganese,
	niacin = HKQuantityTypeIdentifier.dietaryNiacin,
	pantothenicAcid = HKQuantityTypeIdentifier.dietaryPantothenicAcid,
	phosphorus = HKQuantityTypeIdentifier.dietaryPhosphorus,
	selenium = HKQuantityTypeIdentifier.dietarySelenium,
	thiamin = HKQuantityTypeIdentifier.dietaryThiamin,
	vitaminB6 = HKQuantityTypeIdentifier.dietaryVitaminB6,
	vitaminB12 = HKQuantityTypeIdentifier.dietaryVitaminB12,
	vitaminE = HKQuantityTypeIdentifier.dietaryVitaminE,
	vitaminK = HKQuantityTypeIdentifier.dietaryVitaminK,
	water = HKQuantityTypeIdentifier.dietaryWater,
	zinc = HKQuantityTypeIdentifier.dietaryZinc,
}

export enum NutritionToHKUnit {
	calories = "kcal",
	totalFat = "g",
	saturatedFat = "g",
	polyunsaturatedFat = "g",
	monounsaturatedFat = "g",
	transFat = "g",
	cholesterol = "mg",
	sodium = "mg",
	totalCarbohydrates = "g",
	dietaryFiber = "g",
	sugars = "g",
	addedSugar = "g",
	protein = "g",
	calcium = "mg",
	iron = "mg",
	potassium = "mg",
	vitaminA = "mcg",
	vitaminC = "mg",
	vitaminD = "mcg",

	caffeine = "mg",
	copper = "mg",
	manganese = "mg",
	niacin = "mg",
	pantothenicAcid = "mg",
	phosphorus = "mg",
	selenium = "mcg",
	thiamin = "mg",
	vitaminB6 = "mg",
	vitaminB12 = "mcg",
	vitaminE = "mg",
	vitaminK = "mcg",
	water = "g",
	zinc = "mg",
}

enum Multiplier {
	calories = 4.184,
	totalFat = 1,
	saturatedFat = 1,
	polyunsaturatedFat = 1,
	monounsaturatedFat = 1,
	transFat = 1,
	cholesterol = 1,
	sodium = 1,
	totalCarbohydrates = 1,
	dietaryFiber = 1,
	sugars = 1,
	addedSugar = 1,
	protein = 1,
	calcium = 1,
	iron = 1,
	potassium = 1,
	vitaminA = 1,
	vitaminC = 1,
	vitaminD = 1,
}
