import { useCallback, useState } from "react";
import { NutritionService } from "@repo/core/services/NutritionService";
import type { Food, FoodLog } from "@repo/core/types/entities/food";
import useAuth from "./useAuth";
import { useStreaks } from "./useStreaks";

export const useFood = () => {
	const { accessToken } = useAuth();
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const { refetch: refetchStreaks } = useStreaks();

	const searchFoods = async (
		query: string,
		barcode?: string,
		hardFetch?: boolean,
	) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				return [];
			}
			const foods = await NutritionService.searchFoods(
				query,
				accessToken,
				barcode,
				hardFetch,
			);
			return foods;
		} catch (err) {
			setError(err instanceof Error ? err.message : "Failed to search foods");
			return [];
		} finally {
			setIsLoading(false);
		}
	};

	const getFoodById = async (id: string, hardFetch?: boolean) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				return null;
			}
			const food = await NutritionService.getFoodById(
				id,
				accessToken,
				hardFetch,
			);
			return food;
		} catch (err) {
			setError(
				err instanceof Error ? err.message : "Failed to get food details",
			);
			return null;
		} finally {
			setIsLoading(false);
		}
	};

	const createFood = async (food: Omit<Food, "id">) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				return null;
			}
			const newFood = await NutritionService.createFood(food, accessToken);
			return newFood;
		} catch (err) {
			setError(err instanceof Error ? err.message : "Failed to create food");
			return null;
		} finally {
			setIsLoading(false);
		}
	};

	const recordFoodConsumption = async (data: {
		foodId: string;
		servings: number;
		servingSize: string;
		meal: "BREAKFAST" | "LUNCH" | "DINNER" | "SNACK";
		date: Date;
	}) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				return false;
			}
			await NutritionService.recordFoodConsumption(data, accessToken);

			// Refresh streak data after recording food consumption
			await refetchStreaks();

			return true;
		} catch (err) {
			setError(
				err instanceof Error
					? err.message
					: "Failed to record food consumption",
			);
			return false;
		} finally {
			setIsLoading(false);
		}
	};

	const getFoodLog = useCallback(
		async (params: {
			startDate?: string;
			endDate?: string;
			meal?: "BREAKFAST" | "LUNCH" | "DINNER" | "SNACK";
		}) => {
			try {
				setIsLoading(true);
				setError(null);

				if (!accessToken) {
					return [];
				}

				const log = await NutritionService.getFoodLogs(params, accessToken);
				return log;
			} catch (err) {
				setError(err instanceof Error ? err.message : "Failed to get food log");
				return [];
			} finally {
				setIsLoading(false);
			}
		},
		[accessToken],
	);

	const updateFoodLog = async (
		id: string,
		data: Partial<Pick<FoodLog, "servings" | "servingSize" | "meal">>,
	) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				return false;
			}
			await NutritionService.updateFoodLog(id, data, accessToken);

			// Refresh streak data after updating food log
			await refetchStreaks();

			return true;
		} catch (err) {
			setError(
				err instanceof Error ? err.message : "Failed to update food log",
			);
			return false;
		} finally {
			setIsLoading(false);
		}
	};

	const getFoodLogById = async (id: string) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				return null;
			}
			const log = await NutritionService.getFoodLog(id, accessToken);
			return log;
		} catch (err) {
			setError(err instanceof Error ? err.message : "Failed to get food log");
			return null;
		} finally {
			setIsLoading(false);
		}
	};

	const deleteFoodLog = async (id: string) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				return false;
			}
			await NutritionService.deleteFoodLog(id, accessToken);

			// Refresh streak data after deleting food log
			await refetchStreaks();

			return true;
		} catch (err) {
			setError(
				err instanceof Error ? err.message : "Failed to delete food log",
			);
			return false;
		} finally {
			setIsLoading(false);
		}
	};

	const getRecentFoods = async (limit?: number, search?: string) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				return [];
			}
			const foods = await NutritionService.getRecentFoods(
				limit,
				accessToken,
				search,
			);
			console.log("foods", foods);
			return foods;
		} catch (err) {
			console.log("foods", err);

			setError(
				err instanceof Error ? err.message : "Failed to get recent foods",
			);
			return [];
		} finally {
			setIsLoading(false);
		}
	};

	return {
		isLoading,
		error,
		searchFoods,
		getFoodById,
		createFood,
		recordFoodConsumption,
		getFoodLog,
		updateFoodLog,
		getFoodLogById,
		deleteFoodLog,
		getRecentFoods,
	};
};
