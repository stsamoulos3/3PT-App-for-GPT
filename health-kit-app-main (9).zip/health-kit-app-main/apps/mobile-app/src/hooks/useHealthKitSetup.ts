import { useEffect } from "react";
import { HealthKit } from "@/helpers/healthkit";
import { healthKitPermissions } from "@/config/healthkit-permissions";
import { Platform } from "react-native";

export const useHealthKitSetup = () => {
  useEffect(() => {
    // Initialize HealthKit when component mounts

    if (Platform.OS !== "ios") {
      return;
    }

    HealthKit.initHealthKit(healthKitPermissions, (error: string) => {
      if (error) {
        console.error("Failed to initialize HealthKit:", error);
      }
    });
  }, []);

  // useEffect(() => {
  //   const setupBackgroundFetch = async () => {
  //     try {
  //       // await BackgroundTaskService.registerBackgroundFetchAsync();
  //       // await BackgroundTaskService.unregisterBackgroundFetchAsync();
  //     } catch (error) {
  //       console.error("Failed to set up background fetch:", error);
  //     }
  //   };

  //   setupBackgroundFetch();
  // }, []);
};
