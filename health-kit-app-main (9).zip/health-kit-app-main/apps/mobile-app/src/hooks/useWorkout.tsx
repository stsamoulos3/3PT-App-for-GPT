import { useState } from "react";

import type { Workout } from "@repo/core/types/entities/workout";
import useAuth from "./useAuth";
import { WorkoutService } from "@repo/core/services/WorkoutService";
import { useStreaks } from "./useStreaks";

export const useWorkout = () => {
	const { accessToken } = useAuth();
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const { refetch: refetchStreaks } = useStreaks();

	const getWorkoutById = async (id: string, hardFetch?: boolean) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				throw new Error("Access token is required");
			}
			const workout = await WorkoutService.get(id, accessToken);
			return workout;
		} catch (err) {
			setError(
				err instanceof Error ? err.message : "Failed to get workout details",
			);
			return null;
		} finally {
			setIsLoading(false);
		}
	};

	const createWorkout = async (workout: Omit<Workout, "id">) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				throw new Error("Access token is required");
			}
			const newWorkout = await WorkoutService.create(workout, accessToken);

			// Refresh streak data after creating workout
			await refetchStreaks();

			return newWorkout;
		} catch (err) {
			setError(err instanceof Error ? err.message : "Failed to create food");
			return null;
		} finally {
			setIsLoading(false);
		}
	};

	const getWorkoutLog = async (params: {
		startDate?: Date;
		endDate?: Date;
		meal?: "BREAKFAST" | "LUNCH" | "DINNER" | "SNACK";
	}) => {
		const startDate = params.startDate
			? params.startDate.toDateString()
			: undefined;
		const endDate = params.endDate ? params.endDate.toDateString() : undefined;

		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				throw new Error("Access token is required");
			}
			const log = await WorkoutService.list(
				{
					filter: {
						startDate,
						endDate,
					},
				},
				accessToken,
			);
			return log;
		} catch (err) {
			setError(
				err instanceof Error ? err.message : "Failed to get workout log",
			);
			return [];
		} finally {
			setIsLoading(false);
		}
	};

	const updateWorkout = async (
		id: string,
		data: Omit<
			Workout,
			"id" | "startDate" | "endDate" | "activityType" | "userId"
		> & {
			startDate?: string;
			endDate?: string;
		},
	) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				throw new Error("Access token is required");
			}
			await WorkoutService.update(id, data, accessToken);

			// Refresh streak data after updating workout
			await refetchStreaks();

			return true;
		} catch (err) {
			setError(err instanceof Error ? err.message : "Failed to update workout");
			return false;
		} finally {
			setIsLoading(false);
		}
	};

	const deleteWorkout = async (hkId: string) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				throw new Error("Access token is required");
			}
			await WorkoutService.delete(hkId, accessToken);

			// Refresh streak data after deleting workout
			await refetchStreaks();

			return true;
		} catch (err) {
			setError(err instanceof Error ? err.message : "Failed to delete workout");
			return false;
		} finally {
			setIsLoading(false);
		}
	};

	const getRecentWorkoutTypes = async (limit?: number) => {
		try {
			setIsLoading(true);
			setError(null);
			if (!accessToken) {
				throw new Error("Access token is required");
			}
			const workoutTypes = await WorkoutService.getRecentWorkoutTypes(
				limit,
				accessToken,
			);
			return workoutTypes;
		} catch (err) {
			setError(
				err instanceof Error
					? err.message
					: "Failed to get recent workout types",
			);
			return [];
		} finally {
			setIsLoading(false);
		}
	};

	return {
		isLoading,
		error,
		getWorkoutById,
		createWorkout,
		getWorkoutLog,
		updateWorkout,
		deleteWorkout,
		getRecentWorkoutTypes,
	};
};
