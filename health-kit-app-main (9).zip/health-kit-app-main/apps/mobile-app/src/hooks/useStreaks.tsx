import { useEffect } from "react";
import useAuth from "./useAuth";
import { useStreakStore } from "../store/streak.store";

export const useStreaks = () => {
    const { user, accessToken } = useAuth();
    const {
        streaks,
        isLoading,
        error,
        fetchStreaks,
        updateStreaks,
        clearError
    } = useStreakStore();

    useEffect(() => {
        if (user?.id && accessToken) {
            console.log("fetching streaks");
            fetchStreaks(user.id, accessToken);
        }
    }, [user?.id, accessToken, fetchStreaks]);

    const refetch = () => {
        if (user?.id && accessToken) {
            fetchStreaks(user.id, accessToken);
        }
    };

    const updateStreaksData = () => {
        if (user?.id && accessToken) {
            updateStreaks(user.id, accessToken);
        }
    };

    return {
        streaks,
        isLoading,
        error,
        refetch,
        updateStreaks: updateStreaksData,
        clearError,
    };
}; 