import { fromUTCToLocal } from "@repo/core/helpers/dateUtils";
import moment from "moment";
import { useEffect, useState } from "react";
import useGlobalStore from "@/store/global.store";

interface DateRange {
	startDate: Date;
	endDate: Date;
}

export const useDateRange = () => {
	const { selectedDate, setSelectedDate } = useGlobalStore();

	const formatDate = (date: Date) => {
		// Convert to ISO string first to ensure consistent formatting
		const isoString = date.toISOString();
		return fromUTCToLocal(isoString, "LLL d, yyyy");
	};

	const changeDate = (direction: "left" | "right") => {
		const daysToChange = direction === "left" ? -7 : 7;

		const newStartDate = moment(selectedDate.startDate)
			.add(daysToChange, "days")
			.startOf("day")
			.toDate();
		const newEndDate = moment(newStartDate)
			.add(6, "days")
			.endOf("day")
			.toDate();

		setSelectedDate({
			startDate: newStartDate,
			endDate: newEndDate,
		});
	};

	const setToday = () => {
		setSelectedDate({
			startDate: new Date(),
			endDate: new Date(),
		});
	};

	const setLast7Days = () => {
		const endDate = moment().endOf("day").toDate();
		const startDate = moment().subtract(6, "days").startOf("day").toDate();

		setSelectedDate({
			startDate,
			endDate,
		});
	};

	const setCurrentWeek = () => {
		const startDate = moment().startOf("week").toDate();
		const endDate = moment().endOf("week").toDate();

		setSelectedDate({
			startDate,
			endDate,
		});
	};

	const setLast3Days = () => {
		const endDate = moment().endOf("day").toDate();
		const startDate = moment().subtract(2, "days").startOf("day").toDate();

		setSelectedDate({
			startDate,
			endDate,
		});
	};

	return {
		selectedDate,
		setSelectedDate,
		formatDate,
		changeDate,
		setToday,
		setLast7Days,
		setCurrentWeek,
		setLast3Days,
	};
};
