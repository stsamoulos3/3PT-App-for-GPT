import { ProfileForm } from "@/config/profile-fields";
import BackgroundTaskService from "@/services/BackgroundTaskService";
import useAuthStore from "@/store/auth.store";
import { AuthService } from "@repo/core/services/AuthService";
import { UserService } from "@repo/core/services/UserService";
import { registerLogout } from "@repo/core/helpers/apiInterceptor";
import { router } from "expo-router";
import { useEffect } from "react";

export interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  dob: string | null | undefined;
  gender: string | null | undefined;
  is3PTPatient: boolean | null | undefined;
  patientId: string | null | undefined;
  isMultidisciplinaryPatient: boolean | null | undefined;
  rmr: number | null | undefined;
  prescribedExerciseHR: number | null | undefined;
  hourlyCaloriesAtHR: number | null | undefined;
  prescribedDailyCalories: number | null | undefined;
  vo2Max: number | null | undefined;
  calorieCountingMethod: "HR" | "VO2" | "RER" | "EE" | null | undefined;
  user_agreement: string | null | undefined;
  createdAt: string;
  updatedAt: string;
}

function useAuth() {
  const {
    isAuthenticated,
    authenticate,
    onboardingCompleted,
    setOnboardingCompleted,
    logout,
    user,
    accessToken,
    updateUser,
    ...rest
  } = useAuthStore();

  // Register the logout function with the API interceptor
  useEffect(() => {
    const handleLogout = async () => {
      // BackgroundTaskService.unregisterBackgroundFetchAsync().catch(
      //   console.error
      // );
      logout();
      router.replace("/auth");
    };

    registerLogout(handleLogout);
  }, [logout]);

  const handleSignIn = async (values: {
    email: string;
    password: string;
  }): Promise<void> => {
    const data = await AuthService.login(values);

    authenticate(data.user, data.access_token, data.refresh_token);
  };

  const handleSignUp = async (values: {
    email: string;
    password: string;
    first_name: string;
    last_name: string;
    user_agreement?: boolean;
  }): Promise<void> => {
    const data = await AuthService.signup(values);

    authenticate(data.user, data.access_token, data.refresh_token);
  };

  const handleOnboardingCompleted = () => {
    setOnboardingCompleted(true);
  };

  const handleLogout = async () => {
    // BackgroundTaskService.unregisterBackgroundFetchAsync().catch(console.error);
    logout();
    router.replace("/auth");
  };

  const saveUserPersonalInfo = async (values: Partial<User>) => {
    try {
      if (!user?.id) {
        throw new Error("User ID is required");
      }

      if (!accessToken) {
        throw new Error("Access token is required");
      }

      const updateData = {
        ...values,
        dob: values.dob ? values.dob : undefined,
      };

      // Filter out null values for calorieCountingMethod
      if (updateData.calorieCountingMethod === null) {
        delete updateData.calorieCountingMethod;
      }

      const response = await UserService.update(
        user?.id,
        updateData,
        accessToken,
      );
      updateUser(Object.assign(user, values));
      return response;
    } catch (error) {
      console.error(error);
      throw error;
    }
  };

  const getUser = async () => {
    if (!user?.id) {
      throw new Error("User ID is required");
    }

    try {
      if (!user?.id) {
        throw new Error("User ID is required");
      }

      if (!accessToken) {
        throw new Error("Access token is required");
      }

      const data = await UserService.get(user?.id, accessToken);
      updateUser(data);
      return data;
    } catch (error) {
      console.error(error);
      throw error;
    }
  };

  const changePassword = async (values: {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
  }) => {
    try {
      if (!accessToken) {
        throw new Error("Access token is required");
      }

      const data = await AuthService.changePassword(values, accessToken);
      return data;
    } catch (error) {
      console.error(error);
      throw error;
    }
  };

  const forgotPassword = async (values: { email: string }) => {
    try {
      const data = await AuthService.forgotPassword(values);
      return data;
    } catch (error) {
      console.error(error);
      throw error;
    }
  };

  const resetPassword = async (values: {
    token: string;
    newPassword: string;
  }) => {
    try {
      const data = await AuthService.resetPassword(values);
      return data;
    } catch (error) {
      console.error(error);
      throw error;
    }
  };

  const verifyEmail = async (values: { token: string }) => {
    try {
      const data = await AuthService.verifyEmail(values);
      return data;
    } catch (error) {
      console.error(error);
      throw error;
    }
  };

  const resendVerification = async (values: { email: string }) => {
    try {
      const data = await AuthService.resendVerification(values);
      return data;
    } catch (error) {
      console.error(error);
      throw error;
    }
  };

  return {
    handleSignIn,
    handleSignUp,
    isAuthenticated,
    onboardingCompleted,
    handleOnboardingCompleted,
    handleLogout,
    saveUserPersonalInfo,
    user,
    accessToken,
    getUser,
    changePassword,
    forgotPassword,
    resetPassword,
    verifyEmail,
    resendVerification,
    ...rest,
  };
}

export default useAuth;
