import { BodyMeasurementService } from "@repo/core/services/BodyMeasurementService";
import { HeartRateService } from "@repo/core/services/HeartRateService";
import { MobilityService } from "@repo/core/services/MobilityService";
import { NutritionService } from "@repo/core/services/NutritionService";
import { StepsService } from "@repo/core/services/StepsService";
import { VitalSignsService } from "@repo/core/services/VitalSignsService";
import { WorkoutService } from "@repo/core/services/WorkoutService";
import { useEffect, useState } from "react";
import useGlobalStore from "@/store/global.store";
import useAuth from "./useAuth";

function useTrackHealth() {
	const { user, accessToken } = useAuth();

	const { trackerStates, setTrackerStates } = useGlobalStore();

	const [isUpdatingUserSteps, setIsUpdatingUserSteps] = useState(false);
	const [isUpdatingUserHeartRate, setIsUpdatingUserHeartRate] = useState(false);
	const [isUpdatingUserWorkout, setIsUpdatingUserWorkout] = useState(false);
	const [isUpdatingUserNutrition, setIsUpdatingUserNutrition] = useState(false);
	const [isUpdatingUserVitalSigns, setIsUpdatingUserVitalSigns] =
		useState(false);
	const [isUpdatingUserMobility, setIsUpdatingUserMobility] = useState(false);
	const [isUpdatingUserBodyMeasurements, setIsUpdatingUserBodyMeasurements] =
		useState(false);

	const saveUserStepsForDate = async (date: Date, steps: number) => {
		setIsUpdatingUserSteps(true);

		try {
			if (!user?.id) {
				throw new Error("User ID is required");
			}

			if (!accessToken) {
				throw new Error("Access token is required");
			}

			await StepsService.create(
				{
					userId: user.id,
					timestamp: date,
					stepsCount: steps,
				},
				accessToken,
			);
		} catch (error) {
			console.error(error);
		} finally {
			setIsUpdatingUserSteps(false);
		}
	};

	const saveUserBulkStepsForDate = async (
		steps: {
			timestamp: Date;
			stepsCount: number;
			hkId?: string;
		}[],
	) => {
		setIsUpdatingUserSteps(true);
		try {
			if (!accessToken) {
				throw new Error("Access token is required");
			}

			await StepsService.createBulkSteps(steps, accessToken);
		} catch (error) {
			console.error(error);
		} finally {
			setIsUpdatingUserSteps(false);
		}
	};

	const saveUserHeartRateForDate = async (
		date: Date,
		heartRate: number,
		hkId?: string,
	) => {
		setIsUpdatingUserHeartRate(true);
		try {
			if (!user?.id) {
				throw new Error("User ID is required");
			}

			if (!accessToken) {
				throw new Error("Access token is required");
			}

			await HeartRateService.create(
				{
					userId: user.id,
					timestamp: date,
					heartRateBPM: heartRate,
					hkId,
				},
				accessToken,
			);
		} catch (error) {
			console.error(error);
		} finally {
			setIsUpdatingUserHeartRate(false);
		}
	};

	const saveUserBulkHeartRateForDate = async (
		heartRates: {
			timestamp: hr.startDate;
			heartRateBPM: hr.value;
			hkId?: hr.id;
			source: hr.source;
			device: hr.device;
		}[],
	) => {
		setIsUpdatingUserHeartRate(true);

		if (heartRates.length === 0) {
			setIsUpdatingUserHeartRate(false);
			return;
		}

		try {
			if (!accessToken) {
				throw new Error("Access token is required");
			}
			await HeartRateService.createBulkHeartRate(heartRates, accessToken);
		} catch (error) {
		} finally {
			setIsUpdatingUserHeartRate(false);
		}
	};

	const saveUserWorkoutForDate = async (
		date: Date,
		workout: {
			userId: string;
			activityType: string;
			startDate: Date;
			endDate: Date;
			totalDistanceMeters: number;
			totalEnergyBurnedKcal: number;
			workoutDurationSeconds: number;
			averageHeartRateBPM?: number;
			firstHeartRateTime?: Date;
			lastHeartRateTime?: Date;
			highestHeartRate?: number;
			lowestHeartRate?: number;
			hkId?: string;
			source?: string;
		},
	) => {
		setIsUpdatingUserWorkout(true);
		try {
			if (!accessToken) {
				throw new Error("Access token is required");
			}
			await WorkoutService.create(workout, accessToken);
		} catch (error) {
			console.error(error);
		} finally {
			setIsUpdatingUserWorkout(false);
		}
	};

	const saveUserNutritionForDate = async (
		nutritions: {
			date: Date;
			hkId: string;
			quantity: number;
			quantityType: string;
			quantityUnit: string;
		}[],
	) => {
		setIsUpdatingUserNutrition(true);
		try {
			if (!accessToken) {
				throw new Error("Access token is required");
			}
			await NutritionService.create(nutritions, accessToken);
		} catch (error) {
			if (error instanceof Error) {
				console.error(error?.cause ?? error);
			} else {
				console.error(error);
			}
		} finally {
			setIsUpdatingUserNutrition(false);
		}
	};

	const saveUserVitalSignsForDate = async (
		date: Date,
		vitalSigns: {
			vitalType: string;
			vitalValue: number;
			vitalUnit: string;
		},
	) => {
		setIsUpdatingUserVitalSigns(true);
		try {
			if (!user?.id) {
				throw new Error("User ID is required");
			}

			if (!accessToken) {
				throw new Error("Access token is required");
			}
			await VitalSignsService.create(
				{
					userId: user.id,
					vitalType: vitalSigns.vitalType,
					vitalValue: vitalSigns.vitalValue,
					vitalUnit: vitalSigns.vitalUnit,
					timestamp: date,
				},
				accessToken,
			);
		} catch (error) {
			console.error(error);
		} finally {
			setIsUpdatingUserVitalSigns(false);
		}
	};

	const saveUserMobilityForDate = async (
		date: Date,
		mobility: {
			mobilityType: string;
			mobilityValue: number;
			mobilityUnit: string;
		},
	) => {
		setIsUpdatingUserMobility(true);
		try {
			if (!user?.id) {
				throw new Error("User ID is required");
			}

			if (!accessToken) {
				throw new Error("Access token is required");
			}
			await MobilityService.create(
				{
					userId: user.id,
					mobilityType: mobility.mobilityType,
					mobilityValue: mobility.mobilityValue,
					mobilityUnit: mobility.mobilityUnit,
					timestamp: date,
				},
				accessToken,
			);
		} catch (error) {
			console.error(error);
		} finally {
			setIsUpdatingUserMobility(false);
		}
	};

	const saveUserBodyMeasurementsForDate = async (
		date: Date,
		bodyMeasurements: {
			measurementType: string;
			measurementValue: number;
			measurementUnit: string;
		},
	) => {
		setIsUpdatingUserBodyMeasurements(true);
		try {
			if (!user?.id) {
				throw new Error("User ID is required");
			}

			if (!accessToken) {
				throw new Error("Access token is required");
			}
			await BodyMeasurementService.create(
				{
					userId: user.id,
					measurementType: bodyMeasurements.measurementType,
					measurementValue: bodyMeasurements.measurementValue,
					measurementUnit: bodyMeasurements.measurementUnit,
					timestamp: date,
				},
				accessToken,
			);
		} catch (error) {
			console.error(error);
		} finally {
			setIsUpdatingUserBodyMeasurements(false);
		}
	};

	// biome-ignore lint/correctness/useExhaustiveDependencies: <explanation>
	useEffect(() => {
		setTrackerStates({
			isSaving:
				isUpdatingUserSteps ||
				isUpdatingUserHeartRate ||
				isUpdatingUserWorkout ||
				isUpdatingUserNutrition ||
				isUpdatingUserVitalSigns ||
				isUpdatingUserMobility ||
				isUpdatingUserBodyMeasurements,
			error: null,
		});
	}, [
		isUpdatingUserSteps,
		isUpdatingUserHeartRate,
		isUpdatingUserWorkout,
		isUpdatingUserNutrition,
		isUpdatingUserVitalSigns,
		isUpdatingUserMobility,
		isUpdatingUserBodyMeasurements,
	]);

	return {
		trackerStates,
		saveUserStepsForDate,
		saveUserHeartRateForDate,
		saveUserWorkoutForDate,
		saveUserNutritionForDate,
		saveUserVitalSignsForDate,
		saveUserMobilityForDate,
		saveUserBodyMeasurementsForDate,
		saveUserBulkHeartRateForDate,
		saveUserBulkStepsForDate,
	};
}

export default useTrackHealth;
