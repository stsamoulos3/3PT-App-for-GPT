import {
	Box,
	Circle,
	Line,
	LinearGradient,
	RoundedRect,
	Text,
	useFont,
	vec,
} from "@shopify/react-native-skia";
import { Lato_400Regular, Lato_700Bold } from "@expo-google-fonts/lato";
import { Bar, CartesianChart, useChartPressState } from "victory-native";
import { Fragment, useCallback, useMemo } from "react";
import luxon from "luxon";
import { type SharedValue, useDerivedValue } from "react-native-reanimated";
import formatNumberWithPostfix from "@/helpers/formatNumberWithPostfix";

interface DataPoint {
	[key: string]: number;
}

interface BarChartProps {
	data: DataPoint[];
	xLabels?: (number | Date)[];
	maxY?: number;
	barColor?: string;
	xKey: string;
	yKeys: string[];
}

export const BarChart = ({
	data,
	xLabels,
	maxY,
	barColor = "red",
	xKey,
	yKeys,
}: BarChartProps) => {
	const font = useFont(Lato_400Regular, 12);
	const fontBold = useFont(Lato_700Bold, 12);
	const { state, isActive } = useChartPressState<{
		x: number;
		y: Record<string, number>;
	}>({ x: 0, y: { y: 0 } });

	const normalizedLabels = useMemo(
		() =>
			xLabels?.map((date) =>
				typeof date === "object" ? date.getTime() : date,
			),
		[xLabels],
	);

	const hasNegativeValues = useMemo(
		() => data.some((point) => yKeys.some((key) => point[key] < 0)),
		[data, yKeys],
	);

	if (data.length === 0) {
		return null;
	}

	const ToolTip = ({
		x,
		y,
		value,
	}: {
		x: SharedValue<number>;
		y: SharedValue<number>;
		value: SharedValue<number>;
	}) => {
		const activeValueWidth = useDerivedValue(
			() =>
				fontBold
					?.getGlyphWidths?.(
						fontBold.getGlyphIDs(data[value.value][yKeys[0]].toString()),
					)
					.reduce((sum, value) => sum + value, 0) || 0,
		);
		const activeValueX = useDerivedValue(
			() => x.value - activeValueWidth.value / 2,
		);

		const isNegative = data[value.value][yKeys[0]] < 0;

		if (x && y)
			return (
				<Text
					x={activeValueX.value + 6}
					y={y.value}
					color="black"
					text={formatNumberWithPostfix(data[value.value][yKeys[0]], 0)}
					font={fontBold}
					transform={[{ translateY: isNegative ? 16 : -4 }]}
				/>
			);
	};

	return (
		<CartesianChart
			data={data}
			xKey={xKey}
			yKeys={yKeys}
			domainPadding={{
				left: 20,
				right: 30,
				top: 20,
				bottom: hasNegativeValues ? 40 : 0,
			}}
			axisOptions={{
				domain: [
					Math.min(0, ...data.map((point) => point.y)),
					Math.max(maxY ?? 0, ...data.map((point) => point.y)),
				],
				xTicksNormalized: normalizedLabels ?? undefined,
				font,
				formatXLabel: xLabels
					? (value) => {
							if (xLabels?.[value]) {
								return (
									new Date(xLabels?.[value])?.toLocaleString("default", {
										month: "short",
										day: "numeric",
									}) ?? ""
								);
							}
							return "";
						}
					: undefined,
				formatYLabel(label) {
					return formatNumberWithPostfix(label, 0);
				},
				tickCount: {
					x: 7,
					y: 10,
				},
			}}
			chartPressState={state}
		>
			{({ points, chartBounds, yScale }: any) => (
				<Fragment>
					<Line
						p1={vec(chartBounds.left, yScale(0))}
						p2={vec(chartBounds.right, yScale(0))}
						color={barColor}
						strokeWidth={1}
					/>
					<Bar
						points={points.y}
						chartBounds={chartBounds}
						color={barColor}
						roundedCorners={{ topLeft: 4, topRight: 4 }}
						barWidth={16}
					/>
					{isActive && (
						<ToolTip
							x={state.x.position}
							y={state.y.y.position}
							value={state.matchedIndex}
						/>
					)}
				</Fragment>
			)}
		</CartesianChart>
	);
};
