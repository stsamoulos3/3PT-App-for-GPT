"use client";
import { vars } from "nativewind";

export const config = {
  light: vars({
    /* Primary - Medical Blue */
    "--color-primary-0": "243 248 253",
    "--color-primary-50": "236 243 251",
    "--color-primary-100": "217 231 248",
    "--color-primary-200": "191 213 242",
    "--color-primary-300": "166 195 236",
    "--color-primary-400": "115 157 219",
    "--color-primary-500": "65 118 204", // #4176CC
    "--color-primary-600": "52 94 163",
    "--color-primary-700": "39 71 122",
    "--color-primary-800": "26 47 82",
    "--color-primary-900": "13 24 41",
    "--color-primary-950": "7 12 20",

    /* Secondary - Sage Green (Calming Medical) */
    "--color-secondary-0": "242 249 247",
    "--color-secondary-50": "230 243 240",
    "--color-secondary-100": "204 231 225",
    "--color-secondary-200": "153 207 196",
    "--color-secondary-300": "102 183 167",
    "--color-secondary-400": "64 164 144",
    "--color-secondary-500": "38 147 125", // #26937D
    "--color-secondary-600": "30 118 100",
    "--color-secondary-700": "23 88 75",
    "--color-secondary-800": "15 59 50",
    "--color-secondary-900": "8 29 25",
    "--color-secondary-950": "4 15 13",

    /* Tertiary - Warm Purple (Gentle Support) */
    "--color-tertiary-0": "250 247 254",
    "--color-tertiary-50": "244 240 252",
    "--color-tertiary-100": "233 221 249",
    "--color-tertiary-200": "211 187 243",
    "--color-tertiary-300": "189 153 237",
    "--color-tertiary-400": "167 119 231",
    "--color-tertiary-500": "145 85 225", // #9155E1
    "--color-tertiary-600": "116 68 180",
    "--color-tertiary-700": "87 51 135",
    "--color-tertiary-800": "58 34 90",
    "--color-tertiary-900": "29 17 45",
    "--color-tertiary-950": "15 9 23",

    /* Error - Medical Alert Red */
    "--color-error-0": "254 243 242",
    "--color-error-50": "253 230 228",
    "--color-error-100": "251 198 193",
    "--color-error-200": "249 166 158",
    "--color-error-300": "246 134 123",
    "--color-error-400": "244 102 88",
    "--color-error-500": "239 68 68", // #EF4444
    "--color-error-600": "191 54 54",
    "--color-error-700": "143 41 41",
    "--color-error-800": "96 27 27",
    "--color-error-900": "48 14 14",
    "--color-error-950": "24 7 7",

    /* Success - Health Green */
    "--color-success-0": "242 251 246",
    "--color-success-50": "229 246 236",
    "--color-success-100": "191 236 211",
    "--color-success-200": "143 221 179",
    "--color-success-300": "95 206 147",
    "--color-success-400": "47 191 115",
    "--color-success-500": "34 197 94", // #22C55E
    "--color-success-600": "27 158 75",
    "--color-success-700": "20 118 56",
    "--color-success-800": "14 79 38",
    "--color-success-900": "7 39 19",
    "--color-success-950": "3 20 9",

    /* Warning - Medical Caution */
    "--color-warning-0": "254 252 240",
    "--color-warning-50": "254 249 225",
    "--color-warning-100": "253 243 199",
    "--color-warning-200": "252 233 147",
    "--color-warning-300": "250 223 95",
    "--color-warning-400": "249 213 43",
    "--color-warning-500": "245 194 17", // #F5C211
    "--color-warning-600": "196 155 14",
    "--color-warning-700": "147 116 10",
    "--color-warning-800": "98 78 7",
    "--color-warning-900": "49 39 3",
    "--color-warning-950": "24 19 2",

    /* Info - Complementary Blue */
    "--color-info-0": "241 247 254",
    "--color-info-50": "226 239 253",
    "--color-info-100": "196 223 251",
    "--color-info-200": "165 207 249",
    "--color-info-300": "134 191 247",
    "--color-info-400": "103 175 245",
    "--color-info-500": "72 159 243", // #489FF3
    "--color-info-600": "58 127 194",
    "--color-info-700": "43 95 146",
    "--color-info-800": "29 64 97",
    "--color-info-900": "14 32 49",
    "--color-info-950": "7 16 24",

    /* Typography - Clear & Legible */
    "--color-typography-0": "255 255 255",
    "--color-typography-50": "249 250 251",
    "--color-typography-100": "243 244 246",
    "--color-typography-200": "229 231 235",
    "--color-typography-300": "209 213 219",
    "--color-typography-400": "156 163 175",
    "--color-typography-500": "107 114 128",
    "--color-typography-600": "75 85 99",
    "--color-typography-700": "55 65 81",
    "--color-typography-800": "31 41 55",
    "--color-typography-900": "17 24 39",
    "--color-typography-950": "8 12 19",

    /* Background - Clean & Professional */
    "--color-background-0": "255 255 255",
    "--color-background-50": "249 250 251",
    "--color-background-100": "243 244 246",
    "--color-background-200": "229 231 235",
    "--color-background-300": "209 213 219",
    "--color-background-400": "156 163 175",
    "--color-background-500": "107 114 128",
    "--color-background-600": "75 85 99",
    "--color-background-700": "55 65 81",
    "--color-background-800": "31 41 55",
    "--color-background-900": "17 24 39",
    "--color-background-950": "8 12 19",

    /* Background Special - Medical Context */
    "--color-background-error": "254 242 242",
    "--color-background-warning": "255 251 235",
    "--color-background-success": "240 253 244",
    "--color-background-muted": "249 250 251",
    "--color-background-info": "239 246 255",

    /* Focus Ring Indicator - Updated */
    "--color-indicator-primary": "65 118 204", // Match primary-500
    "--color-indicator-info": "72 159 243", // Match info-500
    "--color-indicator-error": "239 68 68", // Match error-500
  }),
  dark: vars({
    /* Primary - Medical Blue */
    "--color-primary-0": "4 9 14",
    "--color-primary-50": "9 19 27",
    "--color-primary-100": "18 37 54",
    "--color-primary-200": "27 56 81",
    "--color-primary-300": "36 74 108",
    "--color-primary-400": "45 93 135",
    "--color-primary-500": "89 134 176",
    "--color-primary-600": "134 167 198",
    "--color-primary-700": "188 208 227",
    "--color-primary-800": "220 231 242",
    "--color-primary-900": "236 242 248",
    "--color-primary-950": "241 245 249",

    /* Secondary - Sage Green (Calming Medical) */
    "--color-secondary-0": "2 12 11",
    "--color-secondary-50": "5 24 21",
    "--color-secondary-100": "10 49 43",
    "--color-secondary-200": "15 73 64",
    "--color-secondary-300": "20 97 85",
    "--color-secondary-400": "25 122 107",
    "--color-secondary-500": "45 151 129",
    "--color-secondary-600": "82 183 159",
    "--color-secondary-700": "129 212 186",
    "--color-secondary-800": "179 235 218",
    "--color-secondary-900": "220 252 231",
    "--color-secondary-950": "236 253 245",

    /* Tertiary - Warm Purple (Gentle Support) */
    "--color-tertiary-0": "250 247 254",
    "--color-tertiary-50": "244 240 252",
    "--color-tertiary-100": "233 221 249",
    "--color-tertiary-200": "211 187 243",
    "--color-tertiary-300": "189 153 237",
    "--color-tertiary-400": "167 119 231",
    "--color-tertiary-500": "145 85 225", // #9155E1
    "--color-tertiary-600": "116 68 180",
    "--color-tertiary-700": "87 51 135",
    "--color-tertiary-800": "58 34 90",
    "--color-tertiary-900": "29 17 45",
    "--color-tertiary-950": "15 9 23",

    /* Error - Medical Alert Red */
    "--color-error-0": "254 243 242",
    "--color-error-50": "253 230 228",
    "--color-error-100": "251 198 193",
    "--color-error-200": "249 166 158",
    "--color-error-300": "246 134 123",
    "--color-error-400": "244 102 88",
    "--color-error-500": "239 68 68", // #EF4444
    "--color-error-600": "191 54 54",
    "--color-error-700": "143 41 41",
    "--color-error-800": "96 27 27",
    "--color-error-900": "48 14 14",
    "--color-error-950": "24 7 7",

    /* Success - Health Green */
    "--color-success-0": "242 251 246",
    "--color-success-50": "229 246 236",
    "--color-success-100": "191 236 211",
    "--color-success-200": "143 221 179",
    "--color-success-300": "95 206 147",
    "--color-success-400": "47 191 115",
    "--color-success-500": "34 197 94", // #22C55E
    "--color-success-600": "27 158 75",
    "--color-success-700": "20 118 56",
    "--color-success-800": "14 79 38",
    "--color-success-900": "7 39 19",
    "--color-success-950": "3 20 9",

    /* Warning - Medical Caution */
    "--color-warning-0": "254 252 240",
    "--color-warning-50": "254 249 225",
    "--color-warning-100": "253 243 199",
    "--color-warning-200": "252 233 147",
    "--color-warning-300": "250 223 95",
    "--color-warning-400": "249 213 43",
    "--color-warning-500": "245 194 17", // #F5C211
    "--color-warning-600": "196 155 14",
    "--color-warning-700": "147 116 10",
    "--color-warning-800": "98 78 7",
    "--color-warning-900": "49 39 3",
    "--color-warning-950": "24 19 2",

    /* Info - Complementary Blue */
    "--color-info-0": "241 247 254",
    "--color-info-50": "226 239 253",
    "--color-info-100": "196 223 251",
    "--color-info-200": "165 207 249",
    "--color-info-300": "134 191 247",
    "--color-info-400": "103 175 245",
    "--color-info-500": "72 159 243", // #489FF3
    "--color-info-600": "58 127 194",
    "--color-info-700": "43 95 146",
    "--color-info-800": "29 64 97",
    "--color-info-900": "14 32 49",
    "--color-info-950": "7 16 24",

    /* Typography - Clear & Legible */
    "--color-typography-0": "255 255 255",
    "--color-typography-50": "249 250 251",
    "--color-typography-100": "243 244 246",
    "--color-typography-200": "229 231 235",
    "--color-typography-300": "209 213 219",
    "--color-typography-400": "156 163 175",
    "--color-typography-500": "107 114 128",
    "--color-typography-600": "75 85 99",
    "--color-typography-700": "55 65 81",
    "--color-typography-800": "31 41 55",
    "--color-typography-900": "17 24 39",
    "--color-typography-950": "8 12 19",

    /* Background - Clean & Professional */
    "--color-background-0": "255 255 255",
    "--color-background-50": "249 250 251",
    "--color-background-100": "243 244 246",
    "--color-background-200": "229 231 235",
    "--color-background-300": "209 213 219",
    "--color-background-400": "156 163 175",
    "--color-background-500": "107 114 128",
    "--color-background-600": "75 85 99",
    "--color-background-700": "55 65 81",
    "--color-background-800": "31 41 55",
    "--color-background-900": "17 24 39",
    "--color-background-950": "8 12 19",

    /* Background Special - Medical Context */
    "--color-background-error": "254 242 242",
    "--color-background-warning": "255 251 235",
    "--color-background-success": "240 253 244",
    "--color-background-muted": "249 250 251",
    "--color-background-info": "239 246 255",

    /* Focus Ring Indicator - Updated */
    "--color-indicator-primary": "65 118 204", // Match primary-500
    "--color-indicator-info": "72 159 243", // Match info-500
    "--color-indicator-error": "239 68 68", // Match error-500
  }),
};
