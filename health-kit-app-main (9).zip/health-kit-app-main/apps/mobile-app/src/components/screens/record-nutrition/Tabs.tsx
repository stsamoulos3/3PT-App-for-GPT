import React, { useRef } from "react";
import { View, Animated, Dimensions, Pressable } from "react-native";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";

export const Tabs: React.FC<{
  activeTab: "all" | "myFoods";
  onTabChange: (tab: "all" | "myFoods") => void;
}> = ({ activeTab, onTabChange }) => {
  const tabIndicatorPosition = useRef(
    new Animated.Value(activeTab === "all" ? 0 : 1)
  ).current;
  const screenWidth = Dimensions.get("window").width;

  const animateTabChange = (tab: "all" | "myFoods") => {
    Animated.timing(tabIndicatorPosition, {
      toValue: tab === "all" ? 0 : 1,
      duration: 150,
      useNativeDriver: true,
    }).start(() => {
      onTabChange(tab);
    });
  };

  const translateX = tabIndicatorPosition.interpolate({
    inputRange: [0, 1],
    outputRange: [0, screenWidth / 2 - 16],
  });

  return (
    <View className="relative">
      <HStack className="rounded-full overflow-hidden py-2 px-4">
        <Pressable
          className="flex-1 py-3"
          onPress={() => activeTab !== "all" && animateTabChange("all")}
        >
          <Text
            className={`text-center font-semibold ${
              activeTab === "all" ? "text-primary-500" : "text-gray-500"
            }`}
          >
            All Foods
          </Text>
        </Pressable>
        <Pressable
          className="flex-1 py-3"
          onPress={() => activeTab !== "myFoods" && animateTabChange("myFoods")}
        >
          <Text
            className={`text-center font-semibold ${
              activeTab === "myFoods" ? "text-primary-500" : "text-gray-500"
            }`}
          >
            My Foods
          </Text>
        </Pressable>

        <Animated.View
          style={{
            position: "absolute",
            width: "50%",
            height: "100%",
            backgroundColor: "white",
            borderRadius: 9999,
            transform: [{ translateX }],
            top: 8,
            bottom: 8,
            left: 16,
            right: 16,
            zIndex: -1,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.1,
            shadowRadius: 2,
            elevation: 2,
          }}
        />
      </HStack>
    </View>
  );
};
