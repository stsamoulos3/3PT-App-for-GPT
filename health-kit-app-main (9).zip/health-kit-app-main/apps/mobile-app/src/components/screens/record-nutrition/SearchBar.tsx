import React from "react";
import { Animated, Pressable } from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { Input, InputField } from "@/components/ui/input";
import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { HStack } from "@/components/ui/hstack";

interface SearchBarProps {
  value: string;
  onChangeText: (text: string) => void;
  onScanPress: () => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  value,
  onChangeText,
  onScanPress,
}) => {
  return (
    <Animated.View className="mx-4 bg-white rounded-full z-10 flex-row items-center shadow-soft-1">
      <MaterialIcons
        name="search"
        size={24}
        color="#666"
        style={{ marginLeft: 16 }}
      />
      <Input variant="outline" className="flex-1 h-12 border-0">
        <InputField
          placeholder="Search for a food"
          value={value}
          onChangeText={onChangeText}
        />
      </Input>
      <Pressable onPress={onScanPress} className="mr-4">
        <HStack className="rounded-full items-center justify-center" space="sm">
          <Text>Scan</Text>
          <MaterialIcons name="qr-code-scanner" size={20} color="#666" />
        </HStack>
      </Pressable>
    </Animated.View>
  );
};
