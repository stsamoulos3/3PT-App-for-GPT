import { Pressable } from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { HStack } from "@/components/ui/hstack";
import { VStack } from "@/components/ui/vstack";
import { Text } from "@/components/ui/text";
import { Box } from "@/components/ui/box";
import type { Food } from "@repo/core/types/entities/food";
import { getBgColorFromName } from "@/helpers/getColorFromName";
import formatNumberWithPostfix from "@/helpers/formatNumberWithPostfix";

interface FoodItemProps {
	food: Food;
	onAdd: (food: Food) => void;
	onQuickAdd?: (food: Food) => void;
}

export const FoodItem: React.FC<FoodItemProps> = ({
	food,
	onAdd,
	onQuickAdd,
}) => {
	return (
		<Box className="bg-white rounded-xl p-4 border border-gray-100 my-1">
			<HStack className="justify-between items-center">
				<Pressable onPress={() => onAdd(food)} className="flex-1">
					<HStack className="items-center flex-1" space="sm">
						<Box
							className="w-16 h-16 rounded-full items-center justify-center"
							style={{
								backgroundColor: getBgColorFromName(food.foodName),
							}}
						>
							<Text className="font-bold text-typography-900 text-lg">
								{food.calories ? formatNumberWithPostfix(food.calories) : "-"}
							</Text>
							<Text className="text-xs text-typography-700">cal</Text>
						</Box>
						<VStack className="space-y-1 flex-1 w-full">
							<Text
								className="font-medium text-typography-900 "
								numberOfLines={2}
							>
								{food.foodName}
								{food.brandName ? `, ${food.brandName}` : ""}
							</Text>
							<Text className="text-xs text-typography-500">
								{Number(food.serving).toFixed(1)} {food.servingSize}
							</Text>
						</VStack>
					</HStack>
				</Pressable>
				<HStack space="xs">
					{onQuickAdd && (
						<Pressable
							className="w-10 h-10 rounded-full bg-green-50 items-center justify-center"
							onPress={() => onQuickAdd(food)}
						>
							<MaterialIcons name="flash-on" size={20} color="#22c55e" />
						</Pressable>
					)}
					<Pressable
						className="w-10 h-10 rounded-full bg-primary-50 items-center justify-center"
						onPress={() => onAdd(food)}
					>
						<MaterialIcons name="visibility" size={20} color="#4176CC" />
					</Pressable>
				</HStack>
			</HStack>
		</Box>
	);
};
