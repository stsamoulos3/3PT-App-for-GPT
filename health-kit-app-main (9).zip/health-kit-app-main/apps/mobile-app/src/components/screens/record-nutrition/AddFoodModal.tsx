import React, { useEffect, useMemo, useState } from "react";
import {
  Actionsheet,
  ActionsheetBackdrop,
  ActionsheetContent,
  ActionsheetDragIndicator,
  ActionsheetDragIndicatorWrapper,
  ActionsheetItem,
} from "@/components/ui/actionsheet";
import { Button, ButtonText } from "@/components/ui/button";
import { Input, InputField } from "@/components/ui/input";
import { Text } from "@/components/ui/text";
import { VStack } from "@/components/ui/vstack";
import { HStack } from "@/components/ui/hstack";
import FormBuilder, { FormField } from "@/components/common/FormBuilder";
import { useForm } from "react-hook-form";
import { ScrollView } from "react-native-gesture-handler";
import { Food } from "@repo/core/types/entities/food";
import { KeyboardAvoidingView } from "react-native";

interface AddFoodModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (foodData: Omit<Food, "id">) => void;
}

export function AddFoodModal({ isOpen, onClose, onSubmit }: AddFoodModalProps) {
  const {
    control,
    handleSubmit: handleFormSubmit,
    reset,
    trigger,
  } = useForm<Omit<Food, "id">>();

  const onSubmitForm = (data: Omit<Food, "id">) => {
    // Create a base nutrition facts object with required properties
    onSubmit(data);
    reset();
    onClose();
  };

  const [activeForm, setActiveForm] = useState<"food" | "nutrition">("food");

  const generateFoodFormFields = useMemo<
    FormField<Pick<Food, "brandName" | "foodName" | "serving">>[]
  >(
    () => [
      {
        name: "brandName",
        label: "Brand Name",
        placeholder: "e.g., Quaker, Kellogg's",
        type: "text",
      },
      {
        name: "foodName",
        label: "Food Name",
        placeholder: "e.g., Oatmeal, Cereal",
        type: "text",
        rules: { required: "Food name is required" },
      },
      {
        name: "serving",
        label: "Serving Size",
        placeholder: "e.g., 1 cup, 100 g",
        type: "text",
        rules: {
          required: "Serving size is required",
          validate(value) {
            const [size, unit] = value.split(" ");

            if (size === "" || !size) {
              return "Serving size is required";
            }

            if (unit === "" || !unit) {
              return "Serving unit is required";
            }

            return true;
          },
        },
      },
    ],
    []
  );

  const foodNutritionFormFields = useMemo<
    FormField<Omit<Food, "id" | "brandName" | "foodName" | "serving">>[]
  >(
    () => [
      {
        name: "calories",
        label: "Calories",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "totalFat",
        label: "Total Fat",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "saturatedFat",
        label: "Saturated Fat",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "polyunsaturatedFat",
        label: "Polyunsaturated Fat",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "monounsaturatedFat",
        label: "Monounsaturated Fat",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "cholesterol",
        label: "Cholesterol",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "sodium",
        label: "Sodium",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "totalCarbohydrates",
        label: "Total Carbohydrates",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "dietaryFiber",
        label: "Dietary Fiber",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "sugars",
        label: "Sugars",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "protein",
        label: "Protein",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "calcium",
        label: "Calcium",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "iron",
        label: "Iron",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "potassium",
        label: "Potassium",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "vitaminA",
        label: "Vitamin A",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
      {
        name: "vitaminC",
        label: "Vitamin C",
        placeholder: "e.g., 100",
        type: "number",
        keyboardType: "numeric",
      },
    ],
    []
  );

  useEffect(() => {
    if (isOpen) {
      setActiveForm("food");
    }

    return () => {
      reset();
    };
  }, [isOpen]);

  return (
    <Actionsheet isOpen={isOpen} onClose={onClose} useRNModal snapPoints={[60]}>
      <KeyboardAvoidingView
        behavior="position"
        style={{
          position: "relative",
          flex: 1,
          justifyContent: "flex-end",
        }}
      >
        <ActionsheetBackdrop />
        <ActionsheetContent>
          <ActionsheetDragIndicatorWrapper>
            <ActionsheetDragIndicator />
          </ActionsheetDragIndicatorWrapper>

          <VStack space="lg" className="px-4  w-full flex-1">
            <Text className="text-xl font-bold text-center">
              Add Custom Food
            </Text>

            <ScrollView className="h-3/4">
              <FormBuilder
                control={control}
                fields={
                  activeForm === "food"
                    ? generateFoodFormFields
                    : foodNutritionFormFields
                }
                showLabel
              />
            </ScrollView>

            <HStack space="sm">
              <Button
                variant="outline"
                onPress={() => {
                  if (activeForm === "food") {
                    onClose();
                  } else {
                    setActiveForm("food");
                  }
                }}
                className="flex-1"
              >
                <ButtonText>
                  {activeForm === "food" ? "Cancel" : "Back"}
                </ButtonText>
              </Button>
              <Button
                onPress={async () => {
                  if (activeForm === "food") {
                    const isValids = await Promise.all(
                      generateFoodFormFields.map((field) => trigger(field.name))
                    );

                    if (isValids.every((isValid) => isValid)) {
                      setActiveForm("nutrition");
                    }
                  } else {
                    const isValids = await Promise.all(
                      foodNutritionFormFields.map((field) =>
                        trigger(field.name)
                      )
                    );

                    if (isValids.every((isValid) => isValid)) {
                      handleFormSubmit(onSubmitForm)();
                    }
                  }
                }}
                className="flex-1"
              >
                <ButtonText>
                  {activeForm === "food" ? "Next" : "Add Food"}
                </ButtonText>
              </Button>
            </HStack>
          </VStack>
        </ActionsheetContent>
      </KeyboardAvoidingView>
    </Actionsheet>
  );
}
