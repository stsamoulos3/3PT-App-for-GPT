import React, { useState, useMemo } from "react";
import { ScrollView, Pressable } from "react-native";
import { Feather, MaterialIcons } from "@expo/vector-icons";
import {
	Modal,
	ModalBackdrop,
	ModalContent,
	ModalHeader,
	ModalCloseButton,
	ModalBody,
	ModalFooter,
} from "@/components/ui/modal";
import { HStack } from "@/components/ui/hstack";
import { VStack } from "@/components/ui/vstack";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { Box } from "@/components/ui/box";
import {
	Select,
	SelectBackdrop,
	SelectContent,
	SelectDragIndicator,
	SelectDragIndicatorWrapper,
	SelectInput,
	SelectItem,
	SelectPortal,
	SelectTrigger,
} from "@/components/ui/select";
import type { Food } from "@repo/core/types/entities/food";
import { getBgColorFromName } from "@/helpers/getColorFromName";
import formatNumberWithPostfix from "@/helpers/formatNumberWithPostfix";
import DatePicker from "react-native-date-picker";
import moment from "moment";

interface QuickAddFoodModalProps {
	isOpen: boolean;
	onClose: () => void;
	onSubmit: (data: {
		servings: number;
		servingSize: string;
		meal: "BREAKFAST" | "LUNCH" | "DINNER" | "SNACK";
		date: Date;
	}) => Promise<void>;
	food: Food | null;
}

export function QuickAddFoodModal({
	isOpen,
	onClose,
	onSubmit,
	food,
}: QuickAddFoodModalProps) {
	const [servings, setServings] = useState("1");
	const [servingSize, setServingSize] = useState("");
	const [meal, setMeal] = useState<"BREAKFAST" | "LUNCH" | "DINNER" | "SNACK">(
		() => {
			const hour = new Date().getHours();
			if (hour < 11) return "BREAKFAST";
			if (hour < 16) return "LUNCH";
			if (hour < 21) return "DINNER";
			return "SNACK";
		},
	);
	const [selectedDate, setSelectedDate] = useState<Date>(new Date());
	const [showDatePicker, setShowDatePicker] = useState(false);
	const [isSubmitting, setIsSubmitting] = useState(false);

	// Reset form when food changes
	React.useEffect(() => {
		if (food) {
			setServingSize(food.servingSize || "1 cup");
			setServings(food.serving || "1");
		}
	}, [food]);

	const macros = useMemo(() => {
		if (!food) return { calories: 0, carbs: 0, fat: 0, protein: 0 };
		const multiplier = Number(servings) / Number(food.serving || 1);
		return {
			calories: (food.calories || 0) * multiplier,
			carbs: (food.totalCarbohydrates || 0) * multiplier,
			fat: (food.totalFat || 0) * multiplier,
			protein: (food.protein || 0) * multiplier,
		};
	}, [food, servings]);

	const handleSubmit = async () => {
		if (!food) return;

		setIsSubmitting(true);
		try {
			await onSubmit({
				servings: Number(servings),
				servingSize,
				meal,
				date: selectedDate,
			});
		} finally {
			setIsSubmitting(false);
		}
	};

	const handleClose = () => {
		setServings("1");
		setSelectedDate(new Date());
		onClose();
	};

	if (!food) return null;

	return (
		<Modal isOpen={isOpen} onClose={handleClose} size="lg">
			<ModalBackdrop />
			<ModalContent className="bg-background-50">
				<ModalHeader className="border-b border-gray-200">
					<VStack space="xs">
						<Text className="text-xl font-bold text-typography-900">
							Quick Add Food
						</Text>
						<Text className="text-sm text-typography-600">
							{food.foodName}
							{food.brandName ? `, ${food.brandName}` : ""}
						</Text>
					</VStack>
					<ModalCloseButton>
						<MaterialIcons name="close" size={24} color="#666" />
					</ModalCloseButton>
				</ModalHeader>

				<ModalBody>
					<VStack space="lg">
						{/* Food Preview */}
						<Box className="bg-white rounded-xl p-4 border border-gray-100">
							<HStack className="items-center justify-between">
								<Box className="items-center">
									<Box
										className="w-20 h-20 rounded-full items-center justify-center mb-2"
										style={{
											backgroundColor: getBgColorFromName(food.foodName),
										}}
									>
										<Text className="text-2xl font-bold text-typography-900">
											{formatNumberWithPostfix(macros.calories)}
										</Text>
										<Text className="text-xs text-typography-700">cal</Text>
									</Box>
								</Box>

								<VStack className="space-y-2 flex-1 ml-4">
									<HStack className="items-center" space="sm">
										<Box
											className="w-3 h-3 rounded-full"
											style={{ backgroundColor: getBgColorFromName("Carbs") }}
										/>
										<Text className="text-typography-900 flex-1">Carbs</Text>
										<Text className="text-typography-900 font-semibold">
											{macros.carbs.toFixed(1)}g
										</Text>
									</HStack>
									<HStack className="items-center" space="sm">
										<Box
											className="w-3 h-3 rounded-full"
											style={{ backgroundColor: getBgColorFromName("Fat") }}
										/>
										<Text className="text-typography-900 flex-1">Fat</Text>
										<Text className="text-typography-900 font-semibold">
											{macros.fat.toFixed(1)}g
										</Text>
									</HStack>
									<HStack className="items-center" space="sm">
										<Box
											className="w-3 h-3 rounded-full"
											style={{ backgroundColor: getBgColorFromName("Protein") }}
										/>
										<Text className="text-typography-900 flex-1">Protein</Text>
										<Text className="text-typography-900 font-semibold">
											{macros.protein.toFixed(1)}g
										</Text>
									</HStack>
								</VStack>
							</HStack>
						</Box>

						{/* Serving Controls */}
						<VStack space="md">
							<Text className="text-lg font-semibold text-typography-900">
								Serving Information
							</Text>

							{/* Number of Servings */}
							<HStack className="justify-between items-center">
								<Text className="text-typography-900">Servings</Text>
								<Select
									selectedValue={servings}
									onValueChange={setServings}
									className="flex-1 w-full max-w-32"
								>
									<SelectTrigger variant="outline" size="md" className="flex-1">
										<SelectInput placeholder="Select" className="flex-1" />
										<Feather
											name="chevron-down"
											size={16}
											className="self-center pr-2"
										/>
									</SelectTrigger>
									<SelectPortal snapPoints={[50]}>
										<SelectBackdrop />
										<SelectContent>
											<SelectDragIndicatorWrapper>
												<SelectDragIndicator />
											</SelectDragIndicatorWrapper>
											<ScrollView className="flex-1 w-full">
												{Array.from(
													{ length: 20 },
													(_, i) => (i + 1) * 0.5,
												).map((amount) => (
													<SelectItem
														key={amount.toString()}
														value={amount.toString()}
														label={amount.toString()}
													/>
												))}
												<Box className="h-16" />
											</ScrollView>
										</SelectContent>
									</SelectPortal>
								</Select>
							</HStack>

							{/* Serving Size */}
							<HStack className="justify-between items-center">
								<Text className="text-typography-900">Size</Text>
								<Text className="text-typography-600">{servingSize}</Text>
							</HStack>

							{/* Meal Selection */}
							<HStack className="justify-between items-center">
								<Text className="text-typography-900">Meal</Text>
								<Select
									selectedValue={meal}
									onValueChange={(value) =>
										setMeal(value as "BREAKFAST" | "LUNCH" | "DINNER" | "SNACK")
									}
									className="flex-1 w-full max-w-40"
								>
									<SelectTrigger variant="outline" size="md" className="flex-1">
										<SelectInput placeholder="Select meal" className="flex-1" />
										<Feather
											name="chevron-down"
											size={16}
											className="self-center pr-2"
										/>
									</SelectTrigger>
									<SelectPortal snapPoints={[40]}>
										<SelectBackdrop />
										<SelectContent>
											<SelectDragIndicatorWrapper>
												<SelectDragIndicator />
											</SelectDragIndicatorWrapper>
											<SelectItem value="BREAKFAST" label="Breakfast" />
											<SelectItem value="LUNCH" label="Lunch" />
											<SelectItem value="DINNER" label="Dinner" />
											<SelectItem value="SNACK" label="Snack" />
										</SelectContent>
									</SelectPortal>
								</Select>
							</HStack>

							{/* Date Selection */}
							<HStack className="justify-between items-center">
								<Text className="text-typography-900">Date</Text>
								<Pressable
									onPress={() => setShowDatePicker(true)}
									className="flex-1 max-w-40 p-3 border border-gray-300 rounded-lg"
								>
									<HStack className="justify-between items-center">
										<Text className="text-typography-900">
											{moment(selectedDate).format("MMM DD, YYYY")}
										</Text>
										<MaterialIcons
											name="calendar-today"
											size={16}
											color="#666"
										/>
									</HStack>
								</Pressable>
							</HStack>
						</VStack>
					</VStack>
				</ModalBody>

				<ModalFooter className="border-t border-gray-200">
					<HStack space="md" className="w-full">
						<Button
							variant="outline"
							onPress={handleClose}
							className="flex-1"
							disabled={isSubmitting}
						>
							<ButtonText>Cancel</ButtonText>
						</Button>
						<Button
							onPress={handleSubmit}
							className="flex-1"
							disabled={isSubmitting}
						>
							<ButtonText>
								{isSubmitting ? "Adding..." : "Add to Log"}
							</ButtonText>
						</Button>
					</HStack>
				</ModalFooter>
			</ModalContent>

			{/* Date Picker */}
			<DatePicker
				modal
				mode="date"
				open={showDatePicker}
				date={selectedDate}
				onConfirm={(date) => {
					setShowDatePicker(false);
					setSelectedDate(date);
				}}
				onCancel={() => setShowDatePicker(false)}
			/>
		</Modal>
	);
}
