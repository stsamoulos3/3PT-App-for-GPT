import React from "react";
import { Box } from "@/components/ui/box";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";
import { Button, ButtonIcon, ButtonText } from "@/components/ui/button";
import { Feather, MaterialIcons } from "@expo/vector-icons";
import moment from "moment";

import type { FoodLog } from "@repo/core/types/entities/food";
import { VStack } from "@/components/ui/vstack";
import { Pressable, View, Alert, ScrollView } from "react-native";
import { router } from "expo-router";
import { useFood } from "@/hooks/useFood";
import {
	Modal,
	ModalBackdrop,
	ModalContent,
	ModalHeader,
	ModalCloseButton,
	ModalBody,
	ModalFooter,
} from "@/components/ui/modal";
import {
	Checkbox,
	CheckboxIndicator,
	CheckboxIcon,
	CheckboxLabel,
} from "@/components/ui/checkbox";
import { CheckIcon } from "@/components/ui/icon";
import DatePicker from "react-native-date-picker";
import formatNumberWithPostfix from "@/helpers/formatNumberWithPostfix";

const MEAL_TYPES = ["BREAKFAST", "LUNCH", "DINNER", "SNACK"];

interface MealsCardProps {
	isLoading: boolean;
	foodLogs: FoodLog[];
	fetchFoodLogs: () => void;
}

function MealsCard(props: MealsCardProps) {
	const [expandedDates, setExpandedDates] = React.useState<
		Record<string, boolean>
	>({});
	const [copyingDate, setCopyingDate] = React.useState<string | null>(null);
	const [showMealSelectionModal, setShowMealSelectionModal] =
		React.useState(false);
	const [selectedDate, setSelectedDate] = React.useState<string | null>(null);
	const [selectedMeals, setSelectedMeals] = React.useState<Set<string>>(
		new Set(),
	);
	const [targetDate, setTargetDate] = React.useState<Date>(new Date());
	const [showDatePicker, setShowDatePicker] = React.useState(false);

	const { recordFoodConsumption, deleteFoodLog } = useFood();

	const navigateToRecordFood = () => {
		router.navigate("/nutrition/record-food");
	};

	const getMealIcon = (meal: string) => {
		switch (meal) {
			case "BREAKFAST":
				return "🌅";
			case "LUNCH":
				return "🌞";
			case "DINNER":
				return "🌙";
			case "SNACK":
				return "🍎";
			default:
				return "🍽️";
		}
	};

	// Group foodLogs by date first, then by meal type
	const groupedByDate = React.useMemo(() => {
		const dateGroups: Record<string, Record<string, FoodLog[]>> = {};

		for (const log of props.foodLogs) {
			const date = moment(log.date).format("YYYY-MM-DD");
			if (!dateGroups[date]) {
				dateGroups[date] = {
					BREAKFAST: [],
					LUNCH: [],
					DINNER: [],
					SNACK: [],
				};
			}
			if (log.meal) {
				dateGroups[date][log.meal.toUpperCase()]?.push(log);
			}
		}

		return dateGroups;
	}, [props.foodLogs]);

	const toggleDateExpansion = (date: string) => {
		setExpandedDates((prev) => ({
			...prev,
			[date]: !prev[date],
		}));
	};

	const getTotalCaloriesForDate = (logs: Record<string, FoodLog[]>) => {
		return Object.values(logs)
			.flat()
			.reduce(
				(total, log) => total + (log.food?.calories ?? 0) * log.servings,
				0,
			);
	};

	const openMealSelectionModal = (date: string) => {
		const mealsForDate = groupedByDate[date];
		if (!mealsForDate) return;

		const allFoodLogs = Object.values(mealsForDate).flat();

		if (allFoodLogs.length === 0) {
			Alert.alert(
				"No meals found",
				"There are no meals to copy from this date.",
			);
			return;
		}

		setSelectedDate(date);
		setSelectedMeals(new Set(allFoodLogs.map((log) => log.id)));
		setTargetDate(new Date());
		setShowMealSelectionModal(true);
	};

	const toggleMealSelection = (mealId: string) => {
		setSelectedMeals((prev) => {
			const newSet = new Set(prev);
			if (newSet.has(mealId)) {
				newSet.delete(mealId);
			} else {
				newSet.add(mealId);
			}
			return newSet;
		});
	};

	const selectAllMeals = () => {
		if (!selectedDate) return;
		const mealsForDate = groupedByDate[selectedDate];
		const allFoodLogs = Object.values(mealsForDate).flat();
		setSelectedMeals(new Set(allFoodLogs.map((log) => log.id)));
	};

	const deselectAllMeals = () => {
		setSelectedMeals(new Set());
	};

	const copySelectedMeals = async () => {
		if (!selectedDate) return;

		const mealsForDate = groupedByDate[selectedDate];
		const allFoodLogs = Object.values(mealsForDate).flat();
		const selectedFoodLogs = allFoodLogs.filter((log) =>
			selectedMeals.has(log.id),
		);

		if (selectedFoodLogs.length === 0) {
			Alert.alert(
				"No meals selected",
				"Please select at least one meal to copy.",
			);
			return;
		}

		setShowMealSelectionModal(false);
		setCopyingDate(selectedDate);

		let successCount = 0;
		let failedCount = 0;

		for (const log of selectedFoodLogs) {
			if (!log.food) continue;

			const success = await recordFoodConsumption({
				foodId: log.foodId,
				servings: log.servings,
				servingSize: log.servingSize,
				meal: log.meal as "BREAKFAST" | "LUNCH" | "DINNER" | "SNACK",
				date: targetDate,
			});

			if (success) {
				successCount++;
			} else {
				failedCount++;
			}
		}

		setCopyingDate(null);
		setSelectedDate(null);
		setSelectedMeals(new Set());

		const targetDateFormatted = moment(targetDate).format("MMMM D, YYYY");
		const isToday = moment(targetDate).isSame(moment(), "day");
		const targetLabel = isToday ? "today" : targetDateFormatted;

		if (failedCount === 0) {
			Alert.alert(
				"Success!",
				`Successfully copied ${successCount} meal${successCount > 1 ? "s" : ""} to ${targetLabel}.`,
				[
					{
						text: "OK",
						onPress: () => props.fetchFoodLogs(),
					},
				],
			);
		} else {
			Alert.alert(
				"Partially Completed",
				`Copied ${successCount} meal${successCount > 1 ? "s" : ""} successfully to ${targetLabel}. ${failedCount} meal${failedCount > 1 ? "s" : ""} failed to copy.`,
				[
					{
						text: "OK",
						onPress: () => props.fetchFoodLogs(),
					},
				],
			);
		}
	};

	const getMealsForSelectedDate = () => {
		if (!selectedDate) return [];
		const mealsForDate = groupedByDate[selectedDate];
		return Object.values(mealsForDate).flat();
	};

	const handleDeleteFoodLog = (logId: string, foodName: string) => {
		Alert.alert(
			"Delete Food Log",
			`Are you sure you want to delete "${foodName}"?`,
			[
				{
					text: "Cancel",
					style: "cancel",
				},
				{
					text: "Delete",
					style: "destructive",
					onPress: async () => {
						const success = await deleteFoodLog(logId);
						if (success) {
							props.fetchFoodLogs();
						}
					},
				},
			],
		);
	};

	return (
		<Box className="mb-4 flex-col gap-4 py-4">
			<HStack className="justify-between items-center px-4 pb-4 border-b border-background-200">
				<Text size="lg" className="font-semibold text-typography-900">
					Meals History
				</Text>
				<Button
					variant="outline"
					size="sm"
					className="w-8 h-8 rounded-full"
					onPress={() => {
						props.fetchFoodLogs();
					}}
				>
					<ButtonIcon className="items-center justify-center">
						<Feather name="refresh-cw" color={"#4176CC"} />
					</ButtonIcon>
				</Button>
			</HStack>

			<VStack className="" space="sm">
				{props.isLoading ? (
					<Text className="text-typography-500 text-center pb-4 px-2">
						Loading meals...
					</Text>
				) : Object.keys(groupedByDate).length === 0 ? (
					<Text className="text-typography-500 text-center pb-4 px-2">
						No meals recorded
					</Text>
				) : (
					<VStack space="md" className="pb-2">
						{Object.entries(groupedByDate)
							.sort(
								([dateA], [dateB]) =>
									new Date(dateB).getTime() - new Date(dateA).getTime(),
							)
							.map(([date, mealGroups]) => (
								<Box
									key={date}
									className="bg-white rounded-xl shadow-soft-1 p-3 px-4 border border-gray-100"
								>
									<Pressable onPress={() => toggleDateExpansion(date)}>
										<HStack className="justify-between items-center">
											<VStack>
												<Text className="text-base font-semibold text-typography-900">
													{moment(date).format("MMMM D, YYYY")}
												</Text>
												<Text className="text-typography-500 text-sm">
													{formatNumberWithPostfix(
														getTotalCaloriesForDate(mealGroups),
														0,
													)}{" "}
													kcal
												</Text>
											</VStack>
											<HStack space="sm" className="items-center">
												{/* Copy Meals Button */}
												<Pressable
													onPress={() => openMealSelectionModal(date)}
													disabled={copyingDate === date}
													className="w-8 h-8 items-center justify-center rounded-full bg-[#e8f4fd]"
												>
													{copyingDate === date ? (
														<MaterialIcons
															name="hourglass-empty"
															size={16}
															color="#4a7aff"
														/>
													) : (
														<Feather name="copy" size={16} color="#4a7aff" />
													)}
												</Pressable>
												{/* Expand/Collapse Button */}
												<View className="w-6 h-6 items-center justify-center rounded-full bg-[#e6efff]">
													<MaterialIcons
														name={
															expandedDates[date]
																? "expand-less"
																: "expand-more"
														}
														size={20}
														color="#4a7aff"
													/>
												</View>
											</HStack>
										</HStack>
									</Pressable>

									{expandedDates[date] && (
										<VStack space="md" className="mt-4">
											{MEAL_TYPES.map((mealType) => (
												<VStack key={mealType} space="xs">
													<Text className="font-semibold text-typography-800 text-base pb-1 pt-2">
														{getMealIcon(mealType)}{" "}
														{mealType.charAt(0) +
															mealType.slice(1).toLowerCase()}
													</Text>
													{mealGroups[mealType].length === 0 ? (
														<Text className="text-typography-400 text-xs pb-2 pl-2">
															No foods recorded
														</Text>
													) : (
														mealGroups[mealType].map((log, index) => (
															<Box
																key={log.id || index}
																className="bg-background-50 p-3 rounded-lg border border-background-200"
															>
																<HStack className="justify-between items-center">
																	<HStack
																		className="items-center flex-1"
																		space="sm"
																	>
																		<VStack>
																			<Text className="text-typography-900 font-medium">
																				{log.food?.foodName}
																			</Text>
																			<Text className="text-typography-500 text-sm">
																				{log.servings} {log.servingSize}
																			</Text>
																		</VStack>
																	</HStack>
																	<Text className="text-typography-900 font-semibold">
																		{formatNumberWithPostfix(
																			(log.food?.calories ?? 0) * log.servings,
																			0,
																		)}{" "}
																		kcal
																	</Text>
																	<HStack space="xs" className="ml-2">
																		<Pressable
																			onPress={() =>
																				router.navigate(
																					`/nutrition/edit-food-log?logId=${log.id}`,
																				)
																			}
																		>
																			<Feather
																				name="edit"
																				size={18}
																				color="#4176CC"
																			/>
																		</Pressable>
																		<Pressable
																			onPress={() =>
																				handleDeleteFoodLog(
																					log.id,
																					log.food?.foodName || "this food",
																				)
																			}
																		>
																			<Feather
																				name="trash-2"
																				size={18}
																				color="#dc2626"
																			/>
																		</Pressable>
																	</HStack>
																</HStack>
															</Box>
														))
													)}
												</VStack>
											))}
										</VStack>
									)}
								</Box>
							))}
					</VStack>
				)}

				<Pressable
					onPress={navigateToRecordFood}
					className="bg-primary-50 p-3 rounded-lg"
				>
					<Text className="text-primary-500 text-center font-semibold">
						Add Food
					</Text>
				</Pressable>
			</VStack>

			{/* Meal Selection Modal */}
			<Modal
				isOpen={showMealSelectionModal}
				onClose={() => setShowMealSelectionModal(false)}
				size="lg"
			>
				<ModalBackdrop />
				<ModalContent className="max-h-[80%]">
					<ModalHeader>
						<Text className="text-lg font-semibold">Copy Meals</Text>

						<ModalCloseButton>
							<Feather name="x" size={20} />
						</ModalCloseButton>
					</ModalHeader>

					<ModalBody>
						<VStack space="md" className="min-h-[300px]">
							{/* Target Date Selection */}
							<VStack space="sm">
								<Text className="text-sm text-typography-500">
									From:{" "}
									{selectedDate
										? moment(selectedDate).format("MMMM D, YYYY")
										: ""}
								</Text>
								<Text className="text-sm font-semibold text-typography-900">
									Copy to:
								</Text>
								<Pressable
									onPress={() => setShowDatePicker(true)}
									className="flex-row items-center px-4 py-3 bg-background-100 rounded-lg border border-background-200"
									style={{ minHeight: 48 }}
								>
									<Feather
										name="calendar"
										size={20}
										color="#4176CC"
										style={{ marginRight: 10 }}
									/>
									<Text size="lg" className="text-typography-900 flex-1">
										{moment(targetDate).format("MMMM D, YYYY")}
									</Text>
								</Pressable>
								<HStack space="sm" className="flex-wrap">
									<Button
										variant="outline"
										size="sm"
										onPress={() => setTargetDate(new Date())}
									>
										<ButtonText>Today</ButtonText>
									</Button>
									<Button
										variant="outline"
										size="sm"
										onPress={() =>
											setTargetDate(moment().add(1, "day").toDate())
										}
									>
										<ButtonText>Tomorrow</ButtonText>
									</Button>
									<Button
										variant="outline"
										size="sm"
										onPress={() =>
											setTargetDate(moment().subtract(1, "day").toDate())
										}
									>
										<ButtonText>Yesterday</ButtonText>
									</Button>
								</HStack>
							</VStack>

							{/* Meals Selection */}
							<HStack space="sm" className="justify-between items-center">
								<Text className="text-base font-semibold text-typography-900">
									Select meals:
								</Text>
								<HStack space="sm" className="justify-end">
									<Button variant="link" size="sm" onPress={selectAllMeals}>
										<ButtonText className="text-primary-500">
											Select All
										</ButtonText>
									</Button>
									<Button variant="link" size="sm" onPress={deselectAllMeals}>
										<ButtonText className="text-typography-500">
											Deselect All
										</ButtonText>
									</Button>
								</HStack>
							</HStack>

							<ScrollView
								style={{ maxHeight: 300 }}
								showsVerticalScrollIndicator={false}
							>
								<VStack space="sm">
									{MEAL_TYPES.map((mealType) => {
										const mealsForType = selectedDate
											? groupedByDate[selectedDate]?.[mealType] || []
											: [];

										if (mealsForType.length === 0) return null;

										return (
											<VStack key={mealType} space="xs">
												<Text className="font-semibold text-typography-800 text-base py-2">
													{getMealIcon(mealType)}{" "}
													{mealType.charAt(0) + mealType.slice(1).toLowerCase()}
												</Text>
												{mealsForType.map((log, index) => (
													<Pressable
														key={log.id || index}
														onPress={() => toggleMealSelection(log.id)}
														className="bg-background-50 p-3 rounded-lg border border-background-200"
													>
														<HStack className="items-center" space="sm">
															<Checkbox
																value=""
																isChecked={selectedMeals.has(log.id)}
																onChange={() => toggleMealSelection(log.id)}
																aria-label={`Select ${log.food?.foodName}`}
															>
																<CheckboxIndicator>
																	<CheckboxIcon as={CheckIcon} />
																</CheckboxIndicator>
															</Checkbox>
															<VStack className="flex-1">
																<Text className="text-typography-900 font-medium">
																	{log.food?.foodName}
																</Text>
																<HStack className="justify-between items-center">
																	<Text className="text-typography-500 text-sm">
																		{log.servings} {log.servingSize}
																	</Text>
																	<Text className="text-typography-900 font-semibold text-sm">
																		{formatNumberWithPostfix(
																			(log.food?.calories ?? 0) * log.servings,
																			0,
																		)}{" "}
																		kcal
																	</Text>
																</HStack>
															</VStack>
														</HStack>
													</Pressable>
												))}
											</VStack>
										);
									})}

									{/* Fallback message if no meals found */}
									{selectedDate &&
										Object.values(groupedByDate[selectedDate] || {}).flat()
											.length === 0 && (
											<Text className="text-typography-500 text-center py-8">
												No meals found for this date
											</Text>
										)}
								</VStack>
							</ScrollView>
						</VStack>
					</ModalBody>

					<ModalFooter>
						<HStack space="sm" className="w-full">
							<Button
								variant="outline"
								className="flex-1"
								onPress={() => setShowMealSelectionModal(false)}
							>
								<ButtonText>Cancel</ButtonText>
							</Button>
							<Button
								className="flex-1"
								onPress={copySelectedMeals}
								disabled={selectedMeals.size === 0}
							>
								<ButtonText>
									Copy {selectedMeals.size} Meal
									{selectedMeals.size !== 1 ? "s" : ""}
								</ButtonText>
							</Button>
						</HStack>
					</ModalFooter>
				</ModalContent>
			</Modal>

			{/* Date Picker */}
			<DatePicker
				modal
				mode="date"
				open={showDatePicker}
				date={targetDate}
				onConfirm={(date) => {
					setShowDatePicker(false);
					setTargetDate(date);
				}}
				onCancel={() => setShowDatePicker(false)}
			/>
		</Box>
	);
}

export default MealsCard;
