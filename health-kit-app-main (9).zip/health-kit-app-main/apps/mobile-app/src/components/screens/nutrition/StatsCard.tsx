import { Box } from "@/components/ui/box";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";

import type { Food, FoodLog } from "@repo/core/types/entities/food";
import { VStack } from "@/components/ui/vstack";
import { router } from "expo-router";
import { useMemo } from "react";
import { NutritionToHKUnit } from "@/services/HealthService";
import formatNumberWithPostfix from "@/helpers/formatNumberWithPostfix";

interface StatsCardProps {
	isLoading: boolean;
	foodLogs: FoodLog[];
}

const metaKeys: (keyof Food)[] = [
	"serving",
	"brandName",
	"foodName",
	"id",
	"servingSize",
	"userId",
	"createdAt",
	"updatedAt",
	"nixId",
	"calories",
	"totalFat",
	"protein",
	"totalCarbohydrates",
	"synced",
];
function StatsCard(props: StatsCardProps) {
	const navigateToRecordFood = () => {
		router.navigate("/nutrition/record-food");
	};

	const getMealIcon = (meal: string) => {
		switch (meal) {
			case "BREAKFAST":
				return "🌅";
			case "LUNCH":
				return "🌞";
			case "DINNER":
				return "🌙";
			case "SNACK":
				return "🍎";
			default:
				return "🍽️";
		}
	};

	const nutritionStats = useMemo(() => {
		const nuts = {} as Record<string, number>;

		for (const log of props.foodLogs) {
			for (const key of Object.keys(log.food ?? {})) {
				if (metaKeys.includes(key as keyof Food)) continue;
				if (Number(log.food?.[key as keyof Food]) === 0) continue;

				if (nuts[key]) {
					nuts[key] += Number(log.food?.[key as keyof Food]);
				} else {
					nuts[key] = Number(log.food?.[key as keyof Food]);
				}
			}
		}

		return nuts;
	}, [props.foodLogs]);

	return (
		<Box className="bg-backgrxound-0 rounded-2xl mb-4 shadow-soft-1 flex-col gap-4 py-4">
			<HStack className="justify-between items-center px-4 pb-4 border-b border-background-200">
				<Text size="lg" className="font-semibold text-typography-900">
					All Nutrition
				</Text>
			</HStack>

			<VStack className="px-4" space="sm">
				{props.isLoading ? (
					<Text className="text-typography-500 text-center pb-4">
						Loading meals...
					</Text>
				) : props.foodLogs.length === 0 ? (
					<Text className="text-typography-500 text-center pb-4">
						No meals recorded today
					</Text>
				) : (
					<VStack space="sm">
						{Object.keys(nutritionStats).map((nut) => (
							<HStack key={nut} className="justify-between items-center">
								<Text>{nut.charAt(0).toUpperCase() + nut.slice(1)}</Text>
								<Text>
									{formatNumberWithPostfix(
										nutritionStats[nut as keyof typeof nutritionStats],
										2,
									)}{" "}
									{NutritionToHKUnit[nut as keyof typeof NutritionToHKUnit]}
								</Text>
							</HStack>
						))}
					</VStack>
				)}
			</VStack>
		</Box>
	);
}

export default StatsCard;
