import React, { useState } from "react";
import { Box } from "@/components/ui/box";
import { Button, ButtonIcon, ButtonText } from "@/components/ui/button";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";
import { Feather } from "@expo/vector-icons";
import {
  Actionsheet,
  ActionsheetBackdrop,
  ActionsheetContent,
  ActionsheetDragIndicator,
  ActionsheetDragIndicatorWrapper,
  ActionsheetItem,
  ActionsheetItemText,
} from "@/components/ui/actionsheet";

export const DateRangeSelector = ({
  selectedDate,
  formatDate,
  changeDate,
  setLast7Days,
  setCurrentWeek,
  setLast3Days,
  setToday,
}: {
  selectedDate: {
    startDate: Date;
    endDate: Date;
  };
  formatDate: (date: Date) => string;
  changeDate: (direction: "left" | "right") => void;
  setLast7Days?: () => void;
  setCurrentWeek?: () => void;
  setLast3Days?: () => void;
  setToday?: () => void;
}) => {
  const [showPresets, setShowPresets] = useState(false);

  const presetOptions = [
    {
      label: "Today",
      onPress: () => {
        setToday?.();
        setShowPresets(false);
      },
    },
    {
      label: "Last 3 Days",
      onPress: () => {
        setLast3Days?.();
        setShowPresets(false);
      },
    },
    {
      label: "Last 7 Days",
      onPress: () => {
        setLast7Days?.();
        setShowPresets(false);
      },
    },
    {
      label: "Current Week",
      onPress: () => {
        setCurrentWeek?.();
        setShowPresets(false);
      },
    },
  ];

  return (
    <>
      <Box className="bg-background-0 rounded-2xl mb-4 p-4 shadow-soft-1">
        <HStack className="justify-between items-center">
          <Button
            variant="outline"
            size="sm"
            className="w-8 h-8 rounded-full"
            onPress={() => changeDate("left")}
          >
            <ButtonIcon className="items-center justify-center">
              <Feather name="chevron-left" />
            </ButtonIcon>
          </Button>

          <Button
            variant="link"
            onPress={() => setShowPresets(true)}
            className="flex-1 mx-2"
          >
            <Text
              size="lg"
              className="font-semibold text-typography-900 text-center"
            >
              {formatDate(selectedDate.startDate)} -{" "}
              {formatDate(selectedDate.endDate)}
            </Text>
          </Button>

          <Button
            variant="outline"
            size="sm"
            className="w-8 h-8 rounded-full"
            onPress={() => changeDate("right")}
          >
            <ButtonIcon className="items-center justify-center">
              <Feather name="chevron-right" />
            </ButtonIcon>
          </Button>
        </HStack>
      </Box>

      <Actionsheet isOpen={showPresets} onClose={() => setShowPresets(false)}>
        <ActionsheetBackdrop />
        <ActionsheetContent>
          <ActionsheetDragIndicatorWrapper>
            <ActionsheetDragIndicator />
          </ActionsheetDragIndicatorWrapper>

          <Text size="lg" className="font-semibold text-typography-900 mb-4">
            Select Date Range
          </Text>

          {presetOptions.map((option, index) => (
            <ActionsheetItem key={index} onPress={option.onPress}>
              <ActionsheetItemText>{option.label}</ActionsheetItemText>
            </ActionsheetItem>
          ))}
        </ActionsheetContent>
      </Actionsheet>
    </>
  );
};
