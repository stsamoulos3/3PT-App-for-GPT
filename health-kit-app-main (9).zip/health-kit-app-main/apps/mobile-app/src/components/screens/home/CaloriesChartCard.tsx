import { Feather, MaterialIcons } from "@expo/vector-icons";
import { HKQuantityTypeIdentifier } from "@kingstinct/react-native-healthkit";
import { DateTime } from "luxon";
import moment from "moment";
import { useCallback, useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Platform } from "react-native";
import { BarChart } from "@/components/ui/bar-chart";
import { Box } from "@/components/ui/box";
import { Button, ButtonIcon, ButtonText } from "@/components/ui/button";
import { HStack } from "@/components/ui/hstack";
import {
	Modal,
	ModalBackdrop,
	ModalBody,
	ModalCloseButton,
	ModalContent,
	ModalFooter,
	ModalHeader,
} from "@/components/ui/modal";
import { Text } from "@/components/ui/text";
import { VStack } from "@/components/ui/vstack";
import formatNumberWithPostfix from "@/helpers/formatNumberWithPostfix";
import useAuth from "@/hooks/useAuth";
import { useFood } from "@/hooks/useFood";
import { HealthService } from "@/services/HealthService";

interface ActivityCardProps {
	startDate: Date;
	endDate: Date;
}

interface CaloriesData {
	quantityType: HKQuantityTypeIdentifier;
	value: number;
	timestamp: string;
	unit: string;
}

interface NetCaloriesData {
	value: number;
	timestamp: string;
}

const DAILY_ACTIVITY_CALORIES = 200;
const THERMOGENESIS_CALORIES = 200;

export const CaloriesChartCard = ({
	startDate,
	endDate,
}: ActivityCardProps) => {
	const { user, accessToken } = useAuth();
	const [burntCaloriesData, setBurntCaloriesData] = useState<CaloriesData[]>(
		[],
	);
	const [netCaloriesBurned, setNetCaloriesBurned] = useState<NetCaloriesData[]>(
		[],
	);
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [showInfoModal, setShowInfoModal] = useState(false);
	const { getFoodLog } = useFood();

	const getNutritionData = useCallback(async () => {
		const data = await getFoodLog({
			startDate: moment().subtract(7, "day").toISOString(),
			endDate: moment().toISOString(),
		});

		return data;
	}, [getFoodLog]);

	const getBurntCalories = useCallback(async () => {
		if (Platform.OS !== "ios") {
			return;
		}

		try {
			setIsLoading(true);
			setError(null);

			if (!accessToken) {
				return;
			}

			const [results, nutritionData] = await Promise.all([
				HealthService.getBurntCalories(
					moment().subtract(7, "day").toDate(),
					moment().toDate(),
					user?.vo2Max ?? 0,
					DateTime.now().diff(
						DateTime.fromJSDate(new Date(user?.dob ?? "")),
						"years",
					).years,
					user?.gender === "male",
					accessToken,
				),
				getNutritionData(),
			]);

			setNetCaloriesBurned(
				nutritionData.map((calorie) => ({
					value: (calorie.food?.calories ?? 0) * (calorie.servings ?? 1),
					timestamp: calorie.date,
				})),
			);

			setBurntCaloriesData(
				results.map((result) => ({
					quantityType: HKQuantityTypeIdentifier.dietaryEnergyConsumed,
					value: Number.parseFloat(result.measuredCalories.toFixed(2)),
					timestamp: result.start,
					unit: "kcal",
				})),
			);
		} catch (error) {
			console.error("Error fetching calories data:", error);
			setError("Failed to fetch calories data. Please try again.");
		} finally {
			setIsLoading(false);
		}
	}, [accessToken, getNutritionData, user?.dob, user?.gender, user?.vo2Max]);

	useEffect(() => {
		getBurntCalories();
	}, [getBurntCalories]);

	const days = useMemo(() => {
		const result: moment.Moment[] = [];

		for (let i = 6; i >= 0; i--) {
			result.push(moment().subtract(i, "days"));
		}
		return result;
	}, []);

	const caloriesByDay = useMemo(() => {
		return days.map((day) => {
			const dayWorkouts =
				burntCaloriesData?.filter((calories) => {
					return moment(calories.timestamp).isSame(day, "day");
				}) ?? [];

			const dayNetCalories =
				netCaloriesBurned.filter((calories) => {
					return moment(calories.timestamp).isSame(day, "day");
				}) ?? [];

			const totalWorkoutCalories =
				dayWorkouts?.reduce((acc, calories) => acc + calories.value, 0) ?? 0;

			const totalConsumedCalories =
				dayNetCalories?.reduce((acc, calories) => acc + calories.value, 0) ?? 0;

			const rmr = user?.rmr ?? 0;

			// if no calories consumed, return 0
			if (totalConsumedCalories === 0) {
				return {
					x: days.indexOf(day),
					y: 0,
				};
			}

			const dailyNetCalories =
				totalConsumedCalories -
				rmr -
				totalWorkoutCalories -
				DAILY_ACTIVITY_CALORIES -
				THERMOGENESIS_CALORIES;

			return {
				x: days.indexOf(day),
				y: Number.parseFloat(dailyNetCalories.toFixed(2)),
			};
		});
	}, [days, burntCaloriesData, netCaloriesBurned, user?.rmr]);

	const totalCalories = useMemo(() => {
		if (caloriesByDay.length === 0) return 0;
		return caloriesByDay.reduce((acc, calories) => acc + calories.y, 0);
	}, [caloriesByDay]);

	if (error) {
		return (
			<Box className="bg-background-0 rounded-2xl mb-4 shadow-soft-1 py-4">
				<Text className="text-error-500 text-center px-4">{error}</Text>
				<Button
					variant="outline"
					size="sm"
					className="mx-auto mt-2"
					onPress={getBurntCalories}
				>
					<ButtonIcon className="items-center justify-center">
						<Feather name="refresh-cw" color={"#4176CC"} />
					</ButtonIcon>
					<Text>Retry</Text>
				</Button>
			</Box>
		);
	}

	return (
		<Box className="bg-background-0 rounded-2xl mb-4 shadow-soft-1 py-4">
			<HStack className="justify-between items-center px-4 pb-4 border-b border-background-200">
				<HStack className="items-center gap-2">
					<Text size="lg" className="font-semibold text-typography-900">
						Weekly Nutrition Summary
					</Text>
				</HStack>
				<Button
					variant="outline"
					size="sm"
					className="w-8 h-8 rounded-full"
					onPress={getBurntCalories}
					disabled={isLoading}
				>
					<ButtonIcon className="items-center justify-center">
						{isLoading ? (
							<ActivityIndicator color="#4176CC" />
						) : (
							<Feather name="refresh-cw" color={"#4176CC"} />
						)}
					</ButtonIcon>
				</Button>
			</HStack>
			<HStack className="justify-between items-start p-4">
				<VStack>
					<Text bold className="text-typography-900">
						7 days net calories
					</Text>
					<HStack className="items-baseline gap-1">
						<Text size="2xl" className="text-primary-500" bold>
							{totalCalories.toLocaleString()}
						</Text>
						<Text bold size="sm" className="text-typography-900">
							Cal
						</Text>
					</HStack>
				</VStack>
				<Button
					variant="outline"
					size="sm"
					className="w-8 h-8 rounded-full"
					onPress={() => setShowInfoModal(true)}
				>
					<ButtonIcon className="items-center justify-center">
						<Feather name="info" color={"#4176CC"} size={12} />
					</ButtonIcon>
				</Button>
			</HStack>
			<Box className="max-h-[300px] h-72 px-4">
				{isLoading ? (
					<Box className="flex-1 items-center justify-center">
						<ActivityIndicator size="large" color="#4176CC" />
					</Box>
				) : caloriesByDay.length > 0 ? (
					<BarChart
						data={caloriesByDay}
						xLabels={days.map((day) => day.toDate())}
						barColor="#4176CC"
						maxY={Math.max(...caloriesByDay.map((point) => point.y))}
						xKey="x"
						yKeys={["y"]}
					/>
				) : (
					<Box className="flex-1 items-center justify-center">
						<Text className="text-typography-500">No data available</Text>
					</Box>
				)}
			</Box>

			{/* Information Modal */}
			<Modal
				isOpen={showInfoModal}
				onClose={() => setShowInfoModal(false)}
				size="lg"
			>
				<ModalBackdrop />
				<ModalContent className="max-h-[90%]">
					<ModalHeader>
						<Text className="text-lg font-semibold">
							What Are Daily Net Calories?
						</Text>
						<ModalCloseButton>
							<MaterialIcons name="close" size={20} />
						</ModalCloseButton>
					</ModalHeader>

					<ModalBody>
						<VStack space="md">
							<Text className="text-sm text-typography-700">
								Daily Net Calories show how many calories are left after
								accounting for your body's energy needs and activity. It's a
								simple way to track your progress toward healthy, sustainable
								weight loss.
							</Text>

							<VStack space="sm">
								<Text className="text-base font-semibold text-typography-900">
									How It's Calculated:
								</Text>
								<Text className="text-sm text-typography-700">
									Calories Consumed{"\n"}(from all food and drink. Log in this
									app!)
								</Text>
								<Text className="text-sm text-typography-700 font-semibold">
									− Resting Metabolic Rate (RMR)
								</Text>
								<Text className="text-sm text-typography-700">
									(calories your body burns at rest, set in your profile)
								</Text>
								<Text className="text-sm text-typography-700 font-semibold">
									− Workout Calories Burned
								</Text>
								<Text className="text-sm text-typography-700">
									(from exercise tracked or entered)
								</Text>
								<Text className="text-sm text-typography-700 font-semibold">
									− Non-Exercise Movement
								</Text>
								<Text className="text-sm text-typography-700">
									(200 calories estimate for everyday movement like walking or
									standing)
								</Text>
								<Text className="text-sm text-typography-700 font-semibold">
									− Thermogenesis
								</Text>
								<Text className="text-sm text-typography-700">
									(200 calories estimate for digestion the energy used to
									process food)
								</Text>
								<Text className="text-sm text-typography-700 font-semibold">
									= Daily Net Calories
								</Text>
							</VStack>

							<VStack space="sm">
								<Text className="text-base font-semibold text-typography-900">
									Why It Matters
								</Text>
								<Text className="text-sm text-typography-700">
									We aim for a steady daily deficit of 500 calories, which
									typically supports 1 pound of weight loss per week — a safe
									and research-backed approach.
								</Text>
							</VStack>

							<VStack space="sm">
								<Text className="text-base font-semibold text-typography-900">
									Note:
								</Text>
								<Text className="text-sm text-typography-700">
									Your RMR may change as your body changes, and require a new
									test.
								</Text>
							</VStack>

							<Text className="text-sm text-typography-700 font-semibold">
								Please Note: This will not populate for a day if Nutrition is
								not logged.
							</Text>
						</VStack>
					</ModalBody>

					<ModalFooter>
						<Button
							variant="outline"
							size="sm"
							onPress={() => setShowInfoModal(false)}
						>
							<ButtonText>Close</ButtonText>
						</Button>
					</ModalFooter>
				</ModalContent>
			</Modal>
		</Box>
	);
};
