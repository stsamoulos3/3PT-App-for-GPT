import Healthkit, {
	type GenericQueryOptions,
	type HKQuantitySample,
	HKQuantityTypeIdentifier,
	queryQuantitySamples,
} from "@kingstinct/react-native-healthkit";
import { DateTime } from "luxon";
import moment from "moment";
import { useCallback, useEffect, useRef, useState } from "react";
import { Platform } from "react-native";
import type {
	HealthValue,
	HKWorkoutQueriedSampleType,
} from "react-native-health";
import useAuth from "@/hooks/useAuth";
import useTrackHealth from "@/hooks/useTrackHealth";
import { HealthService } from "@/services/HealthService";
import useTrackerStore from "@/store/tracker.store";

interface ExtendedHealthValue extends HealthValue {
	isAdded: boolean;
	source: string;
	device?: string;
}

interface HeartRateCardProps {
	startDate: Date;
	endDate: Date;
}

export const HeartRateCard = ({ startDate, endDate }: HeartRateCardProps) => {
	const [heartRates, setHeartRates] = useState<ExtendedHealthValue[]>([]);
	const [latestHeartRate, setLatestHeartRate] = useState<number>(0);
	const [averageHeartRate, setAverageHeartRate] = useState<string>("0");
	const [heartRateSubscription, setHeartRateSubscription] = useState(false);
	const heartRateSubscriptionRef = useRef<(() => void) | null>(null);
	const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null);
	const { saveUserBulkHeartRateForDate } = useTrackHealth();
	const { activeWorkout } = useTrackerStore();
	const { accessToken } = useAuth();

	// Helper function to check if a timestamp falls within any workout period
	const isWithinWorkoutPeriod = useCallback(
		(timestamp: string, workouts: HKWorkoutQueriedSampleType[]) => {
			const sampleTime = new Date(timestamp).getTime();

			if (activeWorkout && !activeWorkout.isPaused) {
				const workoutStart = new Date(activeWorkout.startTime).getTime();
				const workoutEnd = new Date().getTime();
				if (sampleTime >= workoutStart && sampleTime <= workoutEnd) {
					return true;
				}
			}

			return workouts.some((workout) => {
				const workoutStart = new Date(workout.start).getTime();
				const workoutEnd = new Date(workout.end || new Date()).getTime();
				return sampleTime >= workoutStart && sampleTime <= workoutEnd;
			});
		},
		[activeWorkout],
	);

	const getHeartRate = useCallback(async () => {
		console.log("getHeartRate");
		if (Platform.OS !== "ios") {
			return;
		}

		try {
			// Get heart rate samples for the day

			const queryOptions: Omit<GenericQueryOptions, "anchor"> = {
				from: startDate,
				to: endDate || new Date(),
				ascending: true,
			};

			const heartRateResults = (await queryQuantitySamples(
				HKQuantityTypeIdentifier.heartRate,
				queryOptions,
			)) as HKQuantitySample<HKQuantityTypeIdentifier.heartRate>[];

			if (!accessToken) {
				return;
			}

			// Get all workouts for the day to determine workout periods
			const workouts = await HealthService.getWorkouts(
				startDate,
				endDate,
				accessToken,
			);

			if (!heartRateResults || heartRateResults.length === 0) {
				setHeartRates([]);
				return;
			}

			// Apply workout-aware filtering
			const lastWorkoutAdded = DateTime.fromISO(
				heartRateResults[0]?.startDate.toISOString(),
			);
			let lastNonWorkoutAdded = DateTime.fromISO(
				heartRateResults[0]?.startDate.toISOString(),
			);

			const heartRates = heartRateResults.reduce((filtered, hr) => {
				const currentDateTime = DateTime.fromISO(hr.startDate.toISOString());
				const isInWorkout = isWithinWorkoutPeriod(
					hr.startDate.toISOString(),
					workouts,
				);

				if (isInWorkout) {
					// During workout: 15 seconds interval
					const diffInMillis =
						currentDateTime.diff(lastWorkoutAdded).milliseconds;
					// if (diffInMillis >= 15000) {
					// 	lastWorkoutAdded = currentDateTime;
					filtered.push({
						id: hr.uuid,
						startDate: hr.startDate.toISOString(),
						endDate: hr.endDate.toISOString(),
						value: hr.quantity,
						isAdded: true,
						device: hr.sourceRevision?.source.name,
						source: "workout",
					});
					// } else {
					// 	filtered.push({
					// 		id: hr.uuid,
					// 		startDate: hr.startDate.toISOString(),
					// 		endDate: hr.endDate.toISOString(),
					// 		value: hr.quantity,
					// 		isAdded: false,
					// 		device: hr.sourceRevision?.source.name,
					// 		source: "workout",
					// 	});
					// }
				} else {
					// Outside workout: 2 minutes interval
					const diffInMillis =
						currentDateTime.diff(lastNonWorkoutAdded).milliseconds;
					if (diffInMillis >= 120000) {
						lastNonWorkoutAdded = currentDateTime;
						filtered.push({
							id: hr.uuid,
							startDate: hr.startDate.toISOString(),
							endDate: hr.endDate.toISOString(),
							value: hr.quantity,
							isAdded: true,
							device: hr.sourceRevision?.source.name,
							source: "non-workout",
						});
					} else {
						filtered.push({
							id: hr.uuid,
							startDate: hr.startDate.toISOString(),
							endDate: hr.endDate.toISOString(),
							value: hr.quantity,
							isAdded: false,
							device: hr.sourceRevision?.source.name,
							source: "non-workout",
						});
					}
				}

				return filtered;
			}, [] as ExtendedHealthValue[]);

			setHeartRates(heartRates);
		} catch (error) {
			console.error("Error fetching heart rate:", error);
		}
	}, [startDate, endDate, isWithinWorkoutPeriod, accessToken]);

	// // Setup polling during active workouts
	useEffect(() => {
		if (activeWorkout && !activeWorkout.isPaused) {
			// Poll every 30 seconds during active workout to get new heart rate data
			pollingIntervalRef.current = setInterval(() => {
				getHeartRate();
			}, 30000);
		} else {
			// Clear polling when workout is not active
			if (pollingIntervalRef.current) {
				clearInterval(pollingIntervalRef.current);
				pollingIntervalRef.current = null;
			}
		}

		return () => {
			if (pollingIntervalRef.current) {
				clearInterval(pollingIntervalRef.current);
				pollingIntervalRef.current = null;
			}
		};
	}, [activeWorkout, getHeartRate]);

	// Fetch heart rate data when dates change
	useEffect(() => {
		getHeartRate();
	}, [getHeartRate]); // Only depend on actual data dependencies, not the function itself

	useEffect(() => {
		if (heartRates.length > 0) {
			saveUserBulkHeartRateForDate(
				heartRates
					.filter((hr) => hr.isAdded) // Only save filtered heart rates
					.map((hr) => ({
						timestamp: hr.startDate,
						heartRateBPM: hr.value,
						hkId: hr.id,
						source: hr.source,
						device: hr.device,
					})),
			);
		}
	}, [heartRates]);

	// biome-ignore lint/correctness/useExhaustiveDependencies: <explanation>
	const setupHeartRateSubscription = useCallback(async () => {
		if (heartRateSubscription) return;

		heartRateSubscriptionRef.current = await Healthkit.subscribeToChanges(
			HKQuantityTypeIdentifier.heartRate,
			async () => {
				try {
					const heartRateResults = await queryQuantitySamples(
						HKQuantityTypeIdentifier.heartRate,
						{
							// start of today
							from: moment().startOf("day").toDate(),
							to: moment().endOf("day").toDate(),
						},
					);

					if (heartRateResults && heartRateResults.length > 0) {
						// Get the most recent heart rate reading
						const latestHeartRate =
							heartRateResults[heartRateResults.length - 1]?.quantity;

						setLatestHeartRate(latestHeartRate);
						setAverageHeartRate(
							(
								heartRateResults.reduce(
									(sum, current) => sum + current.quantity,
									0,
								) / heartRateResults.length
							).toFixed(0),
						);
					}
				} catch (error) {
					console.error("Error fetching heart rate:", error);
				}
			},
		);

		setHeartRateSubscription(true);
	}, [getHeartRate]);

	useEffect(() => {
		setupHeartRateSubscription();
	}, [setupHeartRateSubscription]);

	return null;
};
