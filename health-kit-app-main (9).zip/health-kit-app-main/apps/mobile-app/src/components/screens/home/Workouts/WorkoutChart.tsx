import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { HStack } from "@/components/ui/hstack";
import { Fragment, useMemo } from "react";
import { BarChart } from "@/components/ui/bar-chart";
import { VStack } from "@/components/ui/vstack";
import moment from "moment";
import { Workout } from "@repo/core/types/entities/workout";

interface ActivityCardProps {
  startDate: Date;
  endDate: Date;
  workouts: Workout[];
}

export const WorkoutChart = ({
  startDate,
  endDate,
  workouts,
}: ActivityCardProps) => {
  const days = useMemo(() => {
    const result: moment.Moment[] = [];
    const daysBetween = moment(endDate).diff(moment(startDate), "days");
    for (let i = daysBetween; i > -1; i--) {
      result.push(moment(endDate).subtract(i, "days"));
    }
    return result;
  }, [endDate, startDate]);

  const workoutsByDay = useMemo(() => {
    return days.map((day, idx) => {
      const dayWorkouts = workouts.filter((workout) => {
        return moment(workout.startDate).isSame(day, "day");
      });

      const totalDuration = dayWorkouts.reduce(
        (acc, workout) => acc + workout.workoutDurationSeconds / 60,
        0
      );

      return {
        x: idx,
        y: Math.round(totalDuration),
      };
    });
  }, [days, workouts]);

  const averageDuration = useMemo(() => {
    if (workoutsByDay.length === 0) return 0;
    return (
      workoutsByDay.reduce((acc, workout) => acc + workout.y, 0) /
      workoutsByDay.length
    );
  }, [workoutsByDay]);

  return (
    <Fragment>
      <HStack className="justify-between items-center px-4">
        <VStack>
          <Text bold className="text-typography-900">
            Average Workout Duration
          </Text>
          <HStack className="items-baseline gap-1">
            <Text size="2xl" className="text-primary-500" bold>
              {averageDuration.toFixed(2)}
            </Text>
            <Text bold size="sm" className="text-typography-900">
              min
            </Text>
          </HStack>
        </VStack>
      </HStack>
      <Box className="max-h-[300px] h-72 px-4">
        <BarChart
          data={workoutsByDay}
          xLabels={days.map((d) => d.toDate())}
          barColor="#4176CC"
          maxY={Math.max(...workoutsByDay.map((point) => point.y))}
          xKey="x"
          yKeys={["y"]}
        />
      </Box>
    </Fragment>
  );
};
