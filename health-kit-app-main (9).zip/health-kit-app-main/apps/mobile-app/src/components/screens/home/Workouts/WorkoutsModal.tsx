import { VStack } from "@/components/ui/vstack";

import { Modal, ModalBackdrop, ModalContent } from "@/components/ui/modal";

import useTrackerStore from "@/store/tracker.store";
import { HKWorkoutActivityType } from "@kingstinct/react-native-healthkit";
import { ScrollView } from "react-native";
import { InputField } from "@/components/ui/input";
import { Input } from "@/components/ui/input";
import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { Button } from "@/components/ui/button";
import { HStack } from "@/components/ui/hstack";
import { Feather } from "@expo/vector-icons";
import { useState, useEffect } from "react";
import { useWorkout } from "@/hooks/useWorkout";

interface WorkoutsModalProps {
  isWorkoutsModalOpen: boolean;
  setIsWorkoutsModalOpen: (isWorkoutsModalOpen: boolean) => void;
}

function WorkoutsModal({
  isWorkoutsModalOpen,
  setIsWorkoutsModalOpen,
}: WorkoutsModalProps) {
  const { setActiveWorkout } = useTrackerStore();
  const { getRecentWorkoutTypes } = useWorkout();

  const [searchQuery, setSearchQuery] = useState("");
  const [recentWorkoutTypes, setRecentWorkoutTypes] = useState<string[]>([]);

  useEffect(() => {
    if (isWorkoutsModalOpen && !searchQuery.trim()) {
      // Fetch recent workout types when modal opens and there's no search query
      getRecentWorkoutTypes(10).then((data) => {
        console.log("data", data);
        setRecentWorkoutTypes(data);
      });
    }
  }, [isWorkoutsModalOpen, searchQuery]);

  const allWorkoutTypes = Object.entries(HKWorkoutActivityType)
    .filter(([key]) => isNaN(Number(key)))
    .map(([key, value]) => ({
      name: key,
      value: value as HKWorkoutActivityType,
    }));

  const workoutTypes = searchQuery.trim()
    ? allWorkoutTypes.filter((workout) =>
        workout.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : recentWorkoutTypes.length > 0
      ? // Show recent workout types first, then other popular ones
        [
          ...recentWorkoutTypes
            .map((activityType) =>
              allWorkoutTypes.find(
                (workout) =>
                  workout.name.toLowerCase() === activityType.toLowerCase()
              )
            )
            .filter(
              (
                workout
              ): workout is { name: string; value: HKWorkoutActivityType } =>
                workout !== undefined
            ),
          // Add some popular workout types if we don't have enough recent ones
          ...allWorkoutTypes
            .filter((workout) =>
              ["running", "walking", "cycling", "swimming", "yoga"].includes(
                workout.name.toLowerCase()
              )
            )
            .filter(
              (workout) =>
                !recentWorkoutTypes.some(
                  (recent) =>
                    recent.toLowerCase() === workout.name.toLowerCase()
                )
            ),
        ].slice(0, 10)
      : // Fallback to popular workout types if no recent ones
        allWorkoutTypes.filter((workout) =>
          [
            "running",
            "walking",
            "cycling",
            "swimming",
            "yoga",
            "hiit",
          ].includes(workout.name.toLowerCase())
        );

  const handleStartWorkout = (type: HKWorkoutActivityType) => {
    const now = new Date();
    setActiveWorkout({
      type,
      startTime: now,
      endTime: now,
      calories: 0,
      distance: 0,
      steps: 0,
      breaks: [],
      breakDurations: 0,
      isPaused: false,
      isCompleted: false,
    });
    setIsWorkoutsModalOpen(false);
  };

  return (
    <Modal
      isOpen={isWorkoutsModalOpen}
      onClose={() => setIsWorkoutsModalOpen(false)}
      className="rounded-3xl border-none"
    >
      <ModalBackdrop />
      <ModalContent
        initial={{
          opacity: 0,
          scale: 0.95,
        }}
        animate={{
          opacity: 1,
          scale: 1,
        }}
        exit={{
          opacity: 0,
          scale: 0.95,
        }}
        transition={{
          type: "timing",
          duration: 300,
        }}
        className="rounded-3xl border-none"
      >
        <Box className="bg-white  h-[60vh] w-full items-center justify-center">
          <VStack space="md" className="w-full flex-1">
            <HStack className="justify-between items-center w-full">
              <Text size="xl" className="font-bold">
                Select Workout Type
              </Text>
            </HStack>
            <Box>
              <Input
                variant="outline"
                size="md"
                isDisabled={false}
                isInvalid={false}
                isReadOnly={false}
                className="rounded-3xl"
              >
                <InputField
                  placeholder="Search for a workout"
                  onChangeText={setSearchQuery}
                />
              </Input>
            </Box>
            {!searchQuery.trim() && recentWorkoutTypes.length > 0 && (
              <Text size="lg" className="font-semibold text-typography-900">
                Most Recent
              </Text>
            )}
            <ScrollView className="flex-1">
              <VStack space="sm">
                {workoutTypes.map((workout) => (
                  <HStack
                    key={workout.name}
                    className="justify-between items-center p-4 bg-gray-50 rounded-lg"
                  >
                    <Text size="md" numberOfLines={2} className="w-3/4">
                      {workout.name
                        .split(/(?=[A-Z])/)
                        .map(
                          (word) => word.charAt(0).toUpperCase() + word.slice(1)
                        )
                        .join(" ")}
                    </Text>
                    <Button
                      size="sm"
                      variant="solid"
                      onPress={() => handleStartWorkout(workout.value)}
                      className="p-0 w-14 h-8 "
                    >
                      <Feather name="play" size={16} color="white" />
                    </Button>
                  </HStack>
                ))}
              </VStack>
            </ScrollView>
          </VStack>
        </Box>
      </ModalContent>
    </Modal>
  );
}

export default WorkoutsModal;
