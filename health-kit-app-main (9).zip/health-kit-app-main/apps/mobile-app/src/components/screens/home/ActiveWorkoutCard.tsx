import { Feather } from "@expo/vector-icons";
import Healthkit, {
	HKQuantityTypeIdentifier,
	HKWorkoutActivityType,
	queryQuantitySamples,
	saveWorkoutSample,
	UnitOfEnergy,
	UnitOfLength,
} from "@kingstinct/react-native-healthkit";
import { PersonalizedCalorieCalculator } from "@repo/core/services/PersonalizedCalorieCalculator";
import { WorkoutSource } from "@repo/core/types/entities/workout";
import moment from "moment";
import React, {
	useCallback,
	useEffect,
	useMemo,
	useRef,
	useState,
} from "react";
import { Dimensions, Pressable, StyleSheet, View } from "react-native";
import Animated, {
	Extrapolation,
	interpolate,
	useAnimatedStyle,
	useSharedValue,
	withSpring,
} from "react-native-reanimated";
import { Box } from "@/components/ui/box";
import { Button, ButtonIcon, ButtonText } from "@/components/ui/button";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";
import { useStreaks } from "@/hooks/useStreaks";
import useTrackHealth from "@/hooks/useTrackHealth";
import { HealthService } from "@/services/HealthService";
import { HeartRateDeviceService } from "@/services/HeartRateDeviceService";
import useAuthStore from "@/store/auth.store";
import useTrackerStore, { type HeartRateDevice } from "@/store/tracker.store";
import { DeviceDisconnectionAlert } from "./DeviceDisconnectionAlert";
import { HeartRateDeviceSelector } from "./HeartRateDeviceSelector";

const ActiveWorkoutCard = () => {
	// Timer state
	const [timer, setTimer] = useState(0);
	const [steps, setSteps] = useState(0);
	const [distance, setDistance] = useState(0);
	const [burntCalories, setBurntCalories] = useState(0);
	const [currentHeartRate, setCurrentHeartRate] = useState(0);
	const [averageHeartRate, setAverageHeartRate] = useState(0);

	// Heart rate device management
	const [isDeviceSelectorOpen, setIsDeviceSelectorOpen] = useState(false);
	const [isDisconnectionAlertOpen, setIsDisconnectionAlertOpen] =
		useState(false);
	const [disconnectedDevice, setDisconnectedDevice] =
		useState<HeartRateDevice | null>(null);

	const heartRateSubscriptionRef = useRef<(() => void) | null>(null);
	const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);
	const heartRateReadingsRef = useRef<number[]>([]);

	// Heart rate timeout and device monitoring
	const heartRateTimeoutRef = useRef<(() => void) | null>(null);
	const deviceConnectionMonitorRef = useRef<(() => void) | null>(null);
	const heartRateDeviceService = HeartRateDeviceService.getInstance();

	// Animation state with Reanimated
	const animationProgress = useSharedValue(0);

	// Workout state
	const workoutStartTimeRef = useRef<number | null>(null);
	const metricsIntervalRef = useRef<NodeJS.Timeout | null>(null);
	const lastBreakEndTimeRef = useRef<number | null>(null);
	const totalBreakTimeRef = useRef<number>(0);

	const {
		activeWorkout,
		setActiveWorkout,
		selectedHeartRateDevice,
		availableHeartRateDevices,
		setSelectedHeartRateDevice,
		setAvailableHeartRateDevices,
		setIsHeartRateDeviceDisconnected,
		updateDeviceConnectionStatus,
	} = useTrackerStore();
	const { user, accessToken } = useAuthStore();
	const { saveUserWorkoutForDate } = useTrackHealth();
	const { refetch: refetchStreaks } = useStreaks();

	// Add this ref to track if we've already animated in
	const hasAnimatedIn = useRef(false);

	const displayTimer = useMemo(() => {
		// Calculate active time by subtracting break time from total elapsed time
		const activeSeconds = Math.max(0, timer);

		const minutes = Math.floor(activeSeconds / 60);
		const seconds = Math.floor(activeSeconds % 60);

		return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
	}, [timer]);

	// Load available heart rate devices on mount
	useEffect(() => {
		const loadDevices = async () => {
			try {
				const devices = await heartRateDeviceService.getAvailableDevices();
				setAvailableHeartRateDevices(devices);
			} catch (error) {
				console.error("[ActiveWorkoutCard] Error loading devices:", error);
			}
		};

		loadDevices();
	}, [isDeviceSelectorOpen]);

	// Device disconnection handler
	const handleDeviceDisconnection = useCallback(
		(device: HeartRateDevice) => {
			setDisconnectedDevice(device);
			setIsHeartRateDeviceDisconnected(true);
			setIsDisconnectionAlertOpen(true);
			updateDeviceConnectionStatus(device.id, false);
		},
		[setIsHeartRateDeviceDisconnected, updateDeviceConnectionStatus],
	);

	const fetchLatestMetrics = useCallback(async () => {
		// Early return if no active workout or paused - prevents data from previous workouts
		if (!activeWorkout || activeWorkout.isPaused) {
			return;
		}

		// Additional safety check: ensure we have a valid start time
		if (!activeWorkout.startTime) {
			return;
		}

		try {
			// Store the current workout start time to ensure we're fetching for the right workout
			const currentWorkoutStartTime = activeWorkout.startTime;

			// Use the enhanced heart rate service to get device-specific data
			const heartRateSamples =
				await heartRateDeviceService.getHeartRateSamplesForDevice(
					selectedHeartRateDevice,
					moment(currentWorkoutStartTime).toDate(),
					new Date(),
				);

			// Double-check that we still have the same active workout (prevent race conditions)
			if (
				!activeWorkout ||
				activeWorkout.startTime !== currentWorkoutStartTime
			) {
				return;
			}

			// Process heart rate data
			if (heartRateSamples && heartRateSamples.length > 0) {
				// Update heart rate readings array with only workout-period readings
				heartRateReadingsRef.current = heartRateSamples
					.filter((item) => item?.quantity && typeof item.quantity === "number")
					.map((item) => item.quantity);

				// Calculate average heart rate with proper bounds checking
				const validReadings = heartRateReadingsRef.current.filter(
					(rate) => rate > 0 && rate < 300,
				); // Reasonable heart rate bounds
				const calculatedAverage =
					validReadings.length > 0
						? validReadings.reduce((acc, itm) => acc + itm, 0) /
							validReadings.length
						: 0;

				setAverageHeartRate(calculatedAverage);

				// Set current heart rate to the most recent valid reading, but only if it's fresh
				const latestHeartRateSample =
					heartRateSamples[heartRateSamples.length - 1];
				if (
					latestHeartRateSample &&
					typeof latestHeartRateSample.quantity === "number" &&
					latestHeartRateSample.quantity > 0 &&
					latestHeartRateSample.quantity < 300
				) {
					// Check if the reading is fresh (within last 15 seconds)
					const timeSinceLastReading = moment().diff(
						moment(latestHeartRateSample.startDate),
						"seconds",
					);

					if (timeSinceLastReading < 15) {
						// Only update if data is fresh
						setCurrentHeartRate(latestHeartRateSample.quantity);
					} else {
						// Data is stale, respect the timeout
						setCurrentHeartRate(0);
					}
				}
			} else {
				// No heart rate data available
				heartRateReadingsRef.current = [];
				setCurrentHeartRate(0);
				setAverageHeartRate(0);
			}

			// Calculate real-time calories using personalized method
			if (currentHeartRate > 0 && timer > 0) {
				// Calculate personalized calories based on user's selected method
				let personalizedCalories: {
					MODEL1: number;
					MODEL2: number;
					MODEL3: number;
					MODEL4: number;
				} = {
					MODEL1: 0,
					MODEL2: 0,
					MODEL3: 0,
					MODEL4: 0,
				};

				const userCalProfile =
					await PersonalizedCalorieCalculator.getUserCoefficients(accessToken!);

				const heartRates =
					await heartRateDeviceService.getHeartRateSamplesForDevice(
						selectedHeartRateDevice,
						activeWorkout.startTime,
					);

				try {
					if (heartRates.length > 0 && timer > 0 && userCalProfile) {
						let prevHeartRate = heartRates[0];
						personalizedCalories = heartRates.reduce(
							(acc, itm) => {
								const duration = moment(itm.startDate).diff(
									prevHeartRate.startDate,
									"seconds",
								);

								const data =
									PersonalizedCalorieCalculator.calculateRealTimeCalories(
										itm.quantity,
										duration,
										userCalProfile,
									);
								prevHeartRate = itm;

								acc = {
									MODEL1: acc.MODEL1 + data.model1,
									MODEL2: acc.MODEL2 + data.model2,
									MODEL3: acc.MODEL3 + data.model3,
									MODEL4: 0,
								};

								return acc;
							},
							{ MODEL1: 0, MODEL2: 0, MODEL3: 0, MODEL4: 0 },
						);
					}
				} catch (error) {
					console.warn(
						"Failed to calculate personalized calories for final workout, using fallback:",
						error,
					);
				}

				// Also get HealthKit calories for comparison/fallback
				const burntCaloriesResults = await queryQuantitySamples(
					HKQuantityTypeIdentifier.activeEnergyBurned,
					{
						from: moment(activeWorkout.startTime).toDate(),
						to: moment(activeWorkout.endTime ?? new Date()).toDate(),
						unit: UnitOfEnergy.Kilocalories,
					},
				);
				const healthKitCalories =
					burntCaloriesResults?.reduce((acc, itm) => acc + itm?.quantity, 0) ||
					0;

				personalizedCalories = {
					...personalizedCalories,
					MODEL4: healthKitCalories,
				};

				// Use personalized calories if available, otherwise fall back to HealthKit
				const burntCalories =
					personalizedCalories[user?.calorieCountingMethod ?? "MODEL4"] ||
					healthKitCalories;
				setBurntCalories(burntCalories);
			}

			// Note: updateActivity is not available in the LiveActivities module
			// We'll update the metrics when ending the workout instead
		} catch (error) {
			console.error("Error fetching latest metrics:", error);
		}
	}, [
		activeWorkout,
		selectedHeartRateDevice,
		heartRateDeviceService,
		currentHeartRate,
		timer,
		accessToken,
		user,
	]);

	// Calculate elapsed time accounting for breaks
	const calculateElapsedTime = useCallback(() => {
		if (!activeWorkout || !workoutStartTimeRef.current) return 0;

		const now = Date.now();
		const totalElapsedTime = Math.floor(
			(now - workoutStartTimeRef.current) / 1000,
		);

		// If we're in a break, don't count the current break time
		if (activeWorkout.isPaused && lastBreakEndTimeRef.current) {
			const currentBreakTime = Math.floor(
				(now - lastBreakEndTimeRef.current) / 1000,
			);
			return totalElapsedTime - totalBreakTimeRef.current - currentBreakTime;
		}

		return totalElapsedTime - totalBreakTimeRef.current;
	}, [activeWorkout]);

	// Update timer based on actual elapsed time
	const updateTimer = useCallback(() => {
		const elapsedTime = calculateElapsedTime();
		setTimer(elapsedTime);
	}, [calculateElapsedTime]);

	const handleStartWorkout = async () => {
		const startTime = new Date();
		workoutStartTimeRef.current = startTime.getTime();
		lastBreakEndTimeRef.current = null;
		totalBreakTimeRef.current = 0;

		// Reset timer and heart rate data when starting a new workout
		setTimer(0);
		setSteps(0);
		setDistance(0);
		setBurntCalories(0);
		setCurrentHeartRate(0);
		setAverageHeartRate(0);
		heartRateReadingsRef.current = []; // Clear previous heart rate readings

		// Clear any existing subscription before starting new one
		if (heartRateSubscriptionRef.current) {
			heartRateSubscriptionRef.current();
			heartRateSubscriptionRef.current = null;
		}

		// Clear any existing heart rate timeout monitoring
		if (heartRateTimeoutRef.current) {
			heartRateTimeoutRef.current();
			heartRateTimeoutRef.current = null;
		}

		// Clear any existing device connection monitoring
		if (deviceConnectionMonitorRef.current) {
			deviceConnectionMonitorRef.current();
			deviceConnectionMonitorRef.current = null;
		}

		setActiveWorkout({
			type: HKWorkoutActivityType.running,
			startTime: startTime,
			endTime: startTime,
			calories: 0,
			distance: 0,
			steps: 0,
			breaks: [],
			breakDurations: 0,
			isPaused: false,
			isCompleted: false,
		});

		// Start heart rate timeout monitoring
		heartRateTimeoutRef.current =
			heartRateDeviceService.startHeartRateTimeoutMonitoring(
				selectedHeartRateDevice,
				() => {},
				15, // 15 seconds timeout
			);

		// Start device connection monitoring if a specific device is selected
		if (selectedHeartRateDevice) {
			deviceConnectionMonitorRef.current =
				heartRateDeviceService.startDeviceConnectionMonitoring(
					selectedHeartRateDevice,
					handleDeviceDisconnection,
					30, // Check every 30 seconds
				);
		}

		// Animate in with a single progress value
		animationProgress.value = withSpring(1, {
			damping: 15,
			stiffness: 100,
			mass: 0.8,
		});
	};

	const handlePauseWorkout = async () => {
		if (!activeWorkout) return;

		// Clear the intervals when pausing
		if (timerIntervalRef.current) {
			clearInterval(timerIntervalRef.current);
			timerIntervalRef.current = null;
		}

		if (metricsIntervalRef.current) {
			clearInterval(metricsIntervalRef.current);
			metricsIntervalRef.current = null;
		}

		// Pause heart rate and device monitoring
		if (heartRateTimeoutRef.current) {
			heartRateTimeoutRef.current();
			heartRateTimeoutRef.current = null;
		}

		if (deviceConnectionMonitorRef.current) {
			deviceConnectionMonitorRef.current();
			deviceConnectionMonitorRef.current = null;
		}

		// Record the start of the break
		lastBreakEndTimeRef.current = Date.now();

		const _activeWorkout = {
			...activeWorkout,
			breaks: [
				...activeWorkout.breaks,
				{
					startTime: new Date(),
					endTime: new Date(),
				},
			],
			isPaused: true,
		};

		setActiveWorkout(_activeWorkout);
	};

	const handleResumeWorkout = async () => {
		if (!activeWorkout) return;

		// Create a copy of the breaks array to avoid mutating state directly
		const breaksCopy = [...activeWorkout.breaks];
		const lastBreak = breaksCopy[breaksCopy.length - 1];

		// Update the last break's end time
		const breakEndTime = new Date();
		breaksCopy[breaksCopy.length - 1] = {
			...lastBreak,
			endTime: breakEndTime,
		};

		// Calculate and add the break duration to total break time
		if (lastBreakEndTimeRef.current) {
			const breakDuration = Math.floor(
				(Date.now() - lastBreakEndTimeRef.current) / 1000,
			);
			totalBreakTimeRef.current += breakDuration;
			lastBreakEndTimeRef.current = null;
		}

		setActiveWorkout({
			...activeWorkout,
			breaks: breaksCopy,
			isPaused: false,
		});

		// Resume heart rate timeout monitoring
		heartRateTimeoutRef.current =
			heartRateDeviceService.startHeartRateTimeoutMonitoring(
				selectedHeartRateDevice,
				() => {},
				15,
			);

		// Resume device connection monitoring if a specific device is selected
		if (selectedHeartRateDevice) {
			deviceConnectionMonitorRef.current =
				heartRateDeviceService.startDeviceConnectionMonitoring(
					selectedHeartRateDevice,
					handleDeviceDisconnection,
					30,
				);
		}
	};

	const handleEndWorkout = async () => {
		if (!activeWorkout) return;

		// IMMEDIATELY clear intervals and subscription to prevent further updates
		if (timerIntervalRef.current) {
			clearInterval(timerIntervalRef.current);
			timerIntervalRef.current = null;
		}

		if (metricsIntervalRef.current) {
			clearInterval(metricsIntervalRef.current);
			metricsIntervalRef.current = null;
		}

		// IMMEDIATELY stop heart rate and device monitoring
		if (heartRateTimeoutRef.current) {
			heartRateTimeoutRef.current();
			heartRateTimeoutRef.current = null;
		}

		if (deviceConnectionMonitorRef.current) {
			deviceConnectionMonitorRef.current();
			deviceConnectionMonitorRef.current = null;
		}

		// IMMEDIATELY unsubscribe from heart rate to prevent further updates
		if (heartRateSubscriptionRef.current) {
			heartRateSubscriptionRef.current();
			heartRateSubscriptionRef.current = null;
		}

		// Get final workout statistics using the enhanced service
		const workoutStats = await heartRateDeviceService.getWorkoutHeartRateStats(
			selectedHeartRateDevice,
			moment(activeWorkout.startTime).toDate(),
			new Date(),
		);

		// Get steps since workout started
		const stepsResults = await queryQuantitySamples(
			HKQuantityTypeIdentifier.stepCount,
			{
				from: moment(activeWorkout.startTime).toDate(),
				to: moment(activeWorkout.endTime ?? new Date()).toDate(),
			},
		);

		// Get distance since workout started
		const distanceResults = await queryQuantitySamples(
			HKQuantityTypeIdentifier.distanceWalkingRunning,
			{
				from: moment(activeWorkout.startTime).toDate(),
				to: moment(activeWorkout.endTime ?? new Date()).toDate(),
				unit: UnitOfLength.Miles,
			},
		);

		// Calculate personalized calories based on user's selected method
		let personalizedCalories: {
			MODEL1: number;
			MODEL2: number;
			MODEL3: number;
			MODEL4: number;
		} = {
			MODEL1: 0,
			MODEL2: 0,
			MODEL3: 0,
			MODEL4: 0,
		};

		const userCalProfile =
			await PersonalizedCalorieCalculator.getUserCoefficients(accessToken!);

		const heartRates =
			await heartRateDeviceService.getHeartRateSamplesForDevice(
				selectedHeartRateDevice,
				activeWorkout.startTime,
			);

		try {
			if (heartRates.length > 0 && timer > 0 && userCalProfile) {
				let prevHeartRate = heartRates[0];
				personalizedCalories = heartRates.reduce(
					(acc, itm) => {
						const duration = moment(itm.startDate).diff(
							prevHeartRate.startDate,
							"seconds",
						);

						const data =
							PersonalizedCalorieCalculator.calculateRealTimeCalories(
								itm.quantity,
								duration,
								userCalProfile,
							);
						prevHeartRate = itm;

						acc = {
							MODEL1: acc.MODEL1 + data.model1,
							MODEL2: acc.MODEL2 + data.model2,
							MODEL3: acc.MODEL3 + data.model3,
							MODEL4: 0,
						};

						return acc;
					},
					{ MODEL1: 0, MODEL2: 0, MODEL3: 0, MODEL4: 0 },
				);
			}
		} catch (error) {
			console.warn(
				"Failed to calculate personalized calories for final workout, using fallback:",
				error,
			);
		}

		// Also get HealthKit calories for comparison/fallback
		const burntCaloriesResults = await queryQuantitySamples(
			HKQuantityTypeIdentifier.activeEnergyBurned,
			{
				from: moment(activeWorkout.startTime).toDate(),
				to: moment(activeWorkout.endTime ?? new Date()).toDate(),
				unit: UnitOfEnergy.Kilocalories,
			},
		);

		const steps =
			stepsResults?.reduce((acc, itm) => acc + itm?.quantity, 0) || 0;
		const distance =
			distanceResults?.reduce((acc, itm) => acc + itm?.quantity, 0) || 0;
		const healthKitCalories =
			burntCaloriesResults?.reduce((acc, itm) => acc + itm?.quantity, 0) || 0;

		personalizedCalories = {
			...personalizedCalories,
			MODEL4: healthKitCalories,
		};

		// Use personalized calories if available, otherwise fall back to HealthKit
		const burntCalories =
			personalizedCalories[user?.calorieCountingMethod ?? "MODEL4"] ||
			healthKitCalories;

		// Store the final workout data before clearing state
		const finalWorkout = {
			...activeWorkout,
			endTime: moment(activeWorkout.endTime ?? new Date()).toDate(),
			calories: burntCalories,
			distance: distance,
			steps: steps,
			isCompleted: true,
		};

		const finalBurntCalories = burntCalories;
		const finalDistance = Number(distance) * 1609.344; // Convert to meters

		// Save workout data to HealthKit first
		const savedWorkoutId = `manual_${Date.now()}_${user?.id}`;

		// Save workout data to backend immediately
		try {
			if (!user?.id) {
				throw new Error("User ID is required to save workout");
			}

			const workoutData = {
				userId: user.id,
				activityType:
					HKWorkoutActivityType[finalWorkout.type].toUpperCase() || "Unknown",
				startDate: new Date(finalWorkout.startTime),
				endDate: new Date(),
				totalDistanceMeters: finalDistance,
				totalEnergyBurnedKcal: finalBurntCalories,
				workoutDurationSeconds: timer,
				averageHeartRateBPM:
					workoutStats.average > 0 ? workoutStats.average : undefined,
				firstHeartRateTime:
					workoutStats.count > 0 ? new Date(finalWorkout.startTime) : undefined,
				lastHeartRateTime: workoutStats.count > 0 ? new Date() : undefined,
				highestHeartRate: workoutStats.max > 0 ? workoutStats.max : undefined,
				lowestHeartRate: workoutStats.min > 0 ? workoutStats.min : undefined,
				hkId: savedWorkoutId,
				source: WorkoutSource.MANUAL,
				...personalizedCalories,
			};

			await saveUserWorkoutForDate(
				new Date(finalWorkout.startTime),
				workoutData,
			);

			// Refresh streak data after successfully saving workout
			await refetchStreaks();
		} catch (error) {
			console.error("[EndWorkout] Error saving workout to backend:", error);
		}

		// IMMEDIATELY clear all workout state to prevent data leakage
		setTimer(0);
		setSteps(0);
		setDistance(0);
		setBurntCalories(0);
		setCurrentHeartRate(0);
		setAverageHeartRate(0);
		heartRateReadingsRef.current = [];
		workoutStartTimeRef.current = null;
		lastBreakEndTimeRef.current = null;
		totalBreakTimeRef.current = 0;
		setActiveWorkout(null);

		// Animate out AFTER clearing state
		animationProgress.value = withSpring(0, {
			damping: 15,
			stiffness: 100,
			mass: 0.8,
		});
	};

	// Device selection handlers
	const handleDeviceSelect = (device: HeartRateDevice | null) => {
		setSelectedHeartRateDevice(device);

		// Restart monitoring with new device if workout is active
		if (activeWorkout && !activeWorkout.isPaused) {
			// Stop existing monitoring
			if (heartRateTimeoutRef.current) {
				heartRateTimeoutRef.current();
			}
			if (deviceConnectionMonitorRef.current) {
				deviceConnectionMonitorRef.current();
			}

			if (device) {
				deviceConnectionMonitorRef.current =
					heartRateDeviceService.startDeviceConnectionMonitoring(
						device,
						handleDeviceDisconnection,
						30,
					);
			}
		}
	};

	const handleContinueWithoutDevice = () => {
		// Stop device-specific monitoring
		if (deviceConnectionMonitorRef.current) {
			deviceConnectionMonitorRef.current();
			deviceConnectionMonitorRef.current = null;
		}
	};

	// Separate effect for timer management
	useEffect(() => {
		// Clear any existing timer interval
		if (timerIntervalRef.current) {
			clearInterval(timerIntervalRef.current);
			timerIntervalRef.current = null;
		}

		// Start timer if there's an active workout and it's not paused
		if (activeWorkout && !activeWorkout.isPaused) {
			// Set the workout start time if it's not already set
			if (!workoutStartTimeRef.current) {
				workoutStartTimeRef.current =
					activeWorkout.startTime?.getTime?.() ??
					new Date(activeWorkout.startTime).getTime();
			}

			// Update timer immediately
			updateTimer();

			// Then set up interval for regular updates
			timerIntervalRef.current = setInterval(updateTimer, 200);
		}

		// Cleanup function
		return () => {
			if (timerIntervalRef.current) {
				clearInterval(timerIntervalRef.current);
				timerIntervalRef.current = null;
			}
		};
	}, [activeWorkout, updateTimer]);

	// Separate effect for metrics polling
	useEffect(() => {
		// Clear any existing metrics interval
		if (metricsIntervalRef.current) {
			clearInterval(metricsIntervalRef.current);
			metricsIntervalRef.current = null;
		}

		// Start metrics polling if there's an active workout and it's not paused
		if (activeWorkout && !activeWorkout.isPaused) {
			// Fetch initial metrics
			fetchLatestMetrics();

			// Set up metrics polling interval (every 5 seconds)
			metricsIntervalRef.current = setInterval(fetchLatestMetrics, 1000);
		}

		// Cleanup function
		return () => {
			if (metricsIntervalRef.current) {
				clearInterval(metricsIntervalRef.current);
				metricsIntervalRef.current = null;
			}
		};
	}, [activeWorkout, fetchLatestMetrics]);

	// Replace the animation effect with this version
	useEffect(() => {
		if (activeWorkout && !hasAnimatedIn.current) {
			// Only animate in if we haven't already
			hasAnimatedIn.current = true;

			// Animate in with a single progress value
			animationProgress.value = withSpring(1, {
				damping: 15,
				stiffness: 100,
				mass: 0.8,
			});
		} else if (!activeWorkout && hasAnimatedIn.current) {
			// Only animate out if we were previously showing the workout
			hasAnimatedIn.current = false;

			// Animate out with a single progress value
			animationProgress.value = withSpring(0, {
				damping: 15,
				stiffness: 100,
				mass: 0.8,
			});
		}
	}, [activeWorkout === null]); // Only trigger when workout starts or ends

	// Create animated styles with interpolated values
	const animatedStyle = useAnimatedStyle(() => {
		// Interpolate values based on a single progress value
		const translateY = interpolate(
			animationProgress.value,
			[0, 1],
			[-200, 0],
			Extrapolation.CLAMP,
		);

		const scale = interpolate(
			animationProgress.value,
			[0, 1],
			[0.9, 1],
			Extrapolation.CLAMP,
		);

		const opacity = interpolate(
			animationProgress.value,
			[0, 1],
			[0, 1],
			Extrapolation.CLAMP,
		);

		return {
			transform: [{ translateY }, { scale }],
			opacity,
			shadowColor: "#000",
			shadowOffset: { width: 0, height: 2 },
			shadowOpacity: 0.1,
			shadowRadius: 8,
			elevation: 5,
		};
	});

	// Cleanup effect for heart rate subscription and monitoring
	useEffect(() => {
		return () => {
			if (heartRateSubscriptionRef.current) {
				console.log("[HeartRate] Cleaning up subscription on unmount");
				heartRateSubscriptionRef.current();
				heartRateSubscriptionRef.current = null;
			}

			if (heartRateTimeoutRef.current) {
				heartRateTimeoutRef.current();
				heartRateTimeoutRef.current = null;
			}

			if (deviceConnectionMonitorRef.current) {
				deviceConnectionMonitorRef.current();
				deviceConnectionMonitorRef.current = null;
			}
		};
	}, []);

	if (!activeWorkout) {
		return <Animated.View style={animatedStyle} />;
	}

	return (
		<>
			<Animated.View style={animatedStyle}>
				<Box
					className="rounded-3xl mx-4 my-2 overflow-hidden shadow-soft-1"
					style={styles.cardContainer}
				>
					{/* Header with workout type and timer */}
					<Box className="bg-primary-500 px-6 py-4">
						<HStack className="justify-between items-center">
							<Text size="xl" className="text-white font-bold">
								{activeWorkout?.type
									? HKWorkoutActivityType?.[activeWorkout.type]
											?.slice(0, 1)
											?.toUpperCase() +
										HKWorkoutActivityType?.[activeWorkout.type]?.slice(1)
									: "Unknown"}
							</Text>
							<Pressable
								onPress={() => setIsDeviceSelectorOpen(true)}
								className="flex-row items-center bg-white/20 px-3 py-1 rounded-full"
							>
								<Feather name="activity" size={16} color="white" />
								<Text size="sm" className="text-white ml-1">
									{selectedHeartRateDevice?.name.substring(0, 10) || "All"}
									{selectedHeartRateDevice?.name &&
									selectedHeartRateDevice.name.length > 10
										? "..."
										: ""}
								</Text>
							</Pressable>
						</HStack>
					</Box>

					{/* Stats Grid */}
					<Box className="bg-white px-6 py-4">
						<HStack className="flex-wrap justify-between">
							{/* Current Heart Rate */}
							<Box className="w-full mb-4 bg-gray-50 rounded-xl p-3">
								<HStack className="items-center mb-1">
									<Feather name="activity" size={16} color="#4176CC" />
									<Text size="sm" className="text-typography-500 ml-1">
										Current Heart Rate
									</Text>
								</HStack>
								<Text size="2xl" className="font-bold text-typography-900">
									{Math.round(currentHeartRate || 0)}
									<Text size="sm" className="text-typography-500 ml-1">
										BPM
									</Text>
								</Text>
							</Box>

							{/* Average Heart Rate */}
							<Box className="w-full mb-4 bg-gray-50 rounded-xl p-3">
								<HStack className="items-center mb-1">
									<Feather name="trending-up" size={16} color="#4176CC" />
									<Text size="sm" className="text-typography-500 ml-1">
										Average Heart Rate
									</Text>
								</HStack>
								<Text size="2xl" className="text-typography-900 font-bold">
									{Math.round(averageHeartRate || 0)}
									<Text size="sm" className="text-typography-500 ml-1">
										BPM
									</Text>
								</Text>
							</Box>

							{/* Calories Burned */}
							<Box className="w-full mb-4 bg-orange-50 rounded-xl p-3">
								<HStack className="items-center mb-1">
									<Feather name="zap" size={16} color="#F97316" />
									<Text size="sm" className="text-typography-500 ml-1">
										Calories Burned
									</Text>
								</HStack>
								<Text size="2xl" className="text-typography-900 font-bold">
									{Math.round(burntCalories || 0)}
									<Text size="sm" className="text-typography-500 ml-1">
										kcal
									</Text>
								</Text>
							</Box>
						</HStack>
					</Box>

					{/* Controls */}
					<Box className="bg-white px-6 py-4 border-t border-gray-200">
						<HStack
							className="justify-between items-center"
							style={{
								display: activeWorkout?.isCompleted ? "none" : "flex",
							}}
						>
							<Button
								variant="solid"
								size="lg"
								className={`w-16 h-16 rounded-full items-center justify-center p-0 ${
									!activeWorkout || activeWorkout?.isPaused
										? "bg-primary-500"
										: "bg-white border-2 border-primary-500"
								}`}
								onPress={() => {
									if (activeWorkout) {
										if (activeWorkout.isPaused) {
											handleResumeWorkout();
										} else {
											handlePauseWorkout();
										}
									} else {
										handleStartWorkout();
									}
								}}
							>
								{activeWorkout ? (
									activeWorkout.isPaused ? (
										<Feather name="play" size={20} color={"white"} />
									) : (
										<Feather name="pause" size={20} color="#4176CC" />
									)
								) : (
									<Feather name="play" size={20} color="white" />
								)}
							</Button>
							<Text
								size="5xl"
								className="text-primary-500 font-bold tracking-wider"
							>
								{displayTimer}
							</Text>

							{activeWorkout && (
								<Button
									variant="outline"
									size="lg"
									className="w-16 h-16 rounded-full  items-center justify-center p-0 bg-red-500 border-2 border-red-500"
									onPress={handleEndWorkout}
								>
									<HStack space="xs" className="items-center">
										<Text className="text-white font-bold">Stop</Text>
									</HStack>
								</Button>
							)}
						</HStack>
					</Box>
				</Box>
			</Animated.View>

			{/* Device Selection Modal */}
			<HeartRateDeviceSelector
				isOpen={isDeviceSelectorOpen}
				onClose={() => setIsDeviceSelectorOpen(false)}
				devices={availableHeartRateDevices}
				onDeviceSelect={handleDeviceSelect}
				selectedDevice={selectedHeartRateDevice}
			/>

			{/* Device Disconnection Alert */}
			<DeviceDisconnectionAlert
				isOpen={isDisconnectionAlertOpen}
				onClose={() => setIsDisconnectionAlertOpen(false)}
				onPauseWorkout={handlePauseWorkout}
				onContinueWithoutDevice={handleContinueWithoutDevice}
				disconnectedDevice={disconnectedDevice}
			/>
		</>
	);
};

const styles = StyleSheet.create({
	cardContainer: {
		shadowColor: "#000",
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.1,
		shadowRadius: 8,
		elevation: 5,
	},
});

export default ActiveWorkoutCard;
