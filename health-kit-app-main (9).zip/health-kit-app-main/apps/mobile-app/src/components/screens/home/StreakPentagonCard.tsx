import type React from "react";
import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { HStack } from "@/components/ui/hstack";
import { VStack } from "@/components/ui/vstack";
import { AnimatedPentagonBadge } from "@/components/common/Pentagon";
import { MaterialIcons } from "@expo/vector-icons";

interface StreakData {
    currentWorkoutStreak: number;
    longestWorkoutStreak: number;
    currentFoodStreak: number;
    longestFoodStreak: number;
    lastWorkoutDate: string | null;
    lastFoodLogDate: string | null;
    lastActiveAt: string;
}

interface StreakPentagonCardProps {
    streaks: StreakData;
    isLoading?: boolean;
}

export const StreakPentagonCard: React.FC<StreakPentagonCardProps> = ({
    streaks,
    isLoading = false,
}) => {
    if (isLoading) {
        return (
            <Box className="bg-white rounded-xl shadow-sm p-4 mb-4">
                <VStack space="md">
                    <Box className="h-4 bg-gray-200 rounded animate-pulse" />
                    <HStack space="md" className="justify-center">
                        <Box className="h-20 w-20 bg-gray-200 rounded animate-pulse" />
                    </HStack>
                </VStack>
            </Box>
        );
    }

    const formatLastActive = (dateString: string) => {
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now.getTime() - date.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays === 0) return "Today";
        if (diffDays === 1) return "Yesterday";
        if (diffDays < 7) return `${diffDays} days ago`;
        return date.toLocaleDateString();
    };

    // Calculate total streak score (workout + food streaks)
    const totalStreakScore = Math.min(
        5,
        Math.floor((streaks.currentWorkoutStreak + streaks.currentFoodStreak) / 2),
    );

    console.log("[StreakPentagonCard] streaks", streaks);

    return (
        <Box className="bg-background-0 rounded-2xl mb-4 shadow-soft-1 py-4">
            <VStack space="md">
                {/* Pentagon Badge */}
                <HStack className="justify-center">
                    <AnimatedPentagonBadge
                        completedCount={Math.min(5, streaks.currentWorkoutStreak)}
                        totalCount={5}
                        size={80}
                        fillColor="#4176CC"
                        strokeColor="#000000"
                        inactiveColor="#e5e7eb"
                        label={'of 5 workouts completed'}
                    />
                    <AnimatedPentagonBadge
                        completedCount={streaks.currentFoodStreak}
                        totalCount={5}
                        size={80}
                        fillColor="#4176CC"
                        strokeColor="#000000"
                        inactiveColor="#4176CC"
                        label={'Consecutive Days Food Logged'}
                    />
                </HStack>
            </VStack>
        </Box>
    );
};
