import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { HStack } from "@/components/ui/hstack";
import { VStack } from "@/components/ui/vstack";
import { useEffect, useState } from "react";
import { HealthKit } from "../../../helpers/healthkit";
import useTrackHealth from "@/hooks/useTrackHealth";

export const ProfileCard = () => {
  const [profileData, setProfileData] = useState({
    biologicalSex: "",
    dateOfBirth: new Date(),
    age: 0,
    height: 0,
    weight: 0,
  });

  const { saveUserPersonalInfo } = useTrackHealth();

  useEffect(() => {
    const fetchProfileData = async () => {
      // Get biological sex
      HealthKit.getBiologicalSex(null, (err: Object, results: any) => {
        if (results) {
          const sexMap: { [key: string]: string } = {
            "not set": "Not Set",
            male: "Male",
            female: "Female",
            other: "Other",
          };
          setProfileData((prev) => ({
            ...prev,
            biologicalSex: sexMap[results.value] || "Not Set",
          }));
        }
      });
      // Get date of birth
      HealthKit.getDateOfBirth(null, (err: Object, results: any) => {
        if (results) {
          const birthDate = new Date(results.value);
          const age = results.age; // Approximate age in years
          setProfileData((prev) => ({ ...prev, dateOfBirth: birthDate, age }));
        }
      });
      // Get latest height
      HealthKit.getLatestHeight(
        {
          unit: "cm",
        },
        (err: Object, results: any) => {
          if (results) {
            const heightInCm = Math.round(results.value);
            setProfileData((prev) => ({ ...prev, height: heightInCm }));
          }
        }
      );
      // Get latest weight
      HealthKit.getLatestWeight(
        {
          unit: "kg",
        },
        (err: Object, results: any) => {
          if (results) {
            const weightInKg = Math.round(results.value);
            setProfileData((prev) => ({ ...prev, weight: weightInKg }));
          }
        }
      );
    };

    fetchProfileData();
  }, []);

  useEffect(() => {
    if (
      profileData.biologicalSex &&
      profileData.dateOfBirth &&
      profileData.height &&
      profileData.weight
    ) {
      saveUserPersonalInfo({
        dob: profileData.dateOfBirth,
        gender: profileData.biologicalSex,
        height: profileData.height,
        weight: profileData.weight,
      });
    }
  }, [profileData]);

  return (
    <Box className="bg-background-0 rounded-2xl mb-4 shadow-soft-1">
      <HStack className="justify-between items-center p-4 border-b border-background-200">
        <Text size="lg" className="font-semibold text-typography-900">
          Profile
        </Text>
      </HStack>
      <Box className="p-4">
        <HStack className="flex-wrap justify-between gap-1 w-full">
          <Box className="w-[49%] bg-background-100 rounded-xl p-4 mb-3">
            <VStack>
              <Text size="sm" className="text-typography-500 mb-1">
                Sex
              </Text>
              <Text size="lg" className="font-semibold text-typography-900">
                {profileData.biologicalSex}
              </Text>
            </VStack>
          </Box>

          <Box className="w-[49%] bg-background-100 rounded-xl p-4 mb-3">
            <VStack>
              <Text size="sm" className="text-typography-500 mb-1">
                Age
              </Text>
              <Text size="lg" className="font-semibold text-typography-900">
                {profileData.age}
              </Text>
            </VStack>
          </Box>

          <Box className="w-[49%] bg-background-100 rounded-xl p-4 mb-3">
            <VStack>
              <Text size="sm" className="text-typography-500 mb-1">
                Height
              </Text>
              <Text size="lg" className="font-semibold text-typography-900">
                {profileData.height} cm
              </Text>
            </VStack>
          </Box>

          <Box className="w-[49%] bg-background-100 rounded-xl p-4 mb-3">
            <VStack>
              <Text size="sm" className="text-typography-500 mb-1">
                Weight
              </Text>
              <Text size="lg" className="font-semibold text-typography-900">
                {profileData.weight} kg
              </Text>
            </VStack>
          </Box>
        </HStack>
      </Box>
    </Box>
  );
};
