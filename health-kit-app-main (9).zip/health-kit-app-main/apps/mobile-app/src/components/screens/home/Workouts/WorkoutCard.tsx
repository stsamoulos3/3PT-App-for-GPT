import { useEffect, useState, useMemo, useCallback } from "react";
import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { Button, ButtonIcon, ButtonText } from "@/components/ui/button";
import { HStack } from "@/components/ui/hstack";
import {
	Platform,
	Pressable,
	ScrollView,
	Alert,
	KeyboardAvoidingView,
} from "react-native";
import { Feather, MaterialIcons } from "@expo/vector-icons";
import useAuth from "@/hooks/useAuth";
import { HealthService } from "@/services/HealthService";
import { WorkoutChart } from "./WorkoutChart";
import { Modal, ModalBackdrop } from "@/components/ui/modal";
import { Input, InputField } from "@/components/ui/input";
import { VStack } from "@/components/ui/vstack";
import { WorkoutService } from "@repo/core/services/WorkoutService";
import { toUTCForStorage } from "@repo/core/helpers/dateUtils";
import { type Workout, WorkoutSource } from "@repo/core/types/entities/workout";
import moment from "moment";
import { useWorkout } from "@/hooks/useWorkout";
import DatePicker from "react-native-date-picker";
import { Divider } from "@/components/ui/divider";
import { View } from "react-native";
import { useMutation } from "@tanstack/react-query";
import useTrackHealth from "@/hooks/useTrackHealth";
import { PersonalizedCalorieCalculator } from "@repo/core/services/PersonalizedCalorieCalculator";
import { HeartRateDeviceService } from "@/services/HeartRateDeviceService";
import {
	HKQuantityTypeIdentifier,
	queryQuantitySamples,
	UnitOfEnergy,
	UnitOfLength,
} from "@kingstinct/react-native-healthkit";

interface ActivityCardProps {
	startDate: Date;
	endDate: Date;
}

export const WorkoutCard = ({ startDate, endDate }: ActivityCardProps) => {
	const { user, accessToken } = useAuth();
	const [workouts, setWorkouts] = useState<Workout[]>([]);
	const [isModalVisible, setIsModalVisible] = useState(false);
	const [selectedWorkout, setSelectedWorkout] = useState<Workout | null>(null);
	const [editMiles, setEditMiles] = useState("");
	const [showStartPicker, setShowStartPicker] = useState(false);
	const [showEndPicker, setShowEndPicker] = useState(false);
	const [editStartDate, setEditStartDate] = useState<Date | null>(null);
	const [editEndDate, setEditEndDate] = useState<Date | null>(null);
	const [expandedDates, setExpandedDates] = useState<Record<string, boolean>>(
		{},
	);

	const { saveUserWorkoutForDate } = useTrackHealth();

	const { updateWorkout, deleteWorkout } = useWorkout();

	const heartRateDeviceService = HeartRateDeviceService.getInstance();

	// Group workouts by date
	const groupedByDate = useMemo(() => {
		const dateGroups: Record<string, Workout[]> = {};

		for (const workout of workouts) {
			const date = moment(workout.startDate).format("YYYY-MM-DD");
			if (!dateGroups[date]) {
				dateGroups[date] = [];
			}
			dateGroups[date].push(workout);
		}

		return dateGroups;
	}, [workouts]);

	const toggleDateExpansion = (date: string) => {
		setExpandedDates((prev) => ({
			...prev,
			[date]: !prev[date],
		}));
	};

	const getTotalCaloriesForDate = (workouts: Workout[]) => {
		return workouts.reduce(
			(total, workout) => total + (workout.totalEnergyBurnedKcal || 0),
			0,
		);
	};

	const getTotalDurationForDate = (workouts: Workout[]) => {
		return workouts.reduce(
			(total, workout) => total + (workout.workoutDurationSeconds || 0),
			0,
		);
	};

	const formatDuration = (seconds: number) => {
		const hours = Math.floor(seconds / 3600);
		const minutes = Math.floor((seconds % 3600) / 60);

		if (hours > 0) {
			return `${hours}h ${minutes}m`;
		}
		return `${minutes}m`;
	};

	const getWorkouts = useCallback(async () => {
		console.log("getWorkouts");
		try {
			if (!accessToken) {
				return;
			}

			const workouts = await WorkoutService.list(
				{
					filter: {
						startDate: moment(startDate).startOf("day").toISOString(),
						endDate: moment(endDate).endOf("day").toISOString(),
					},
				},
				accessToken,
			);

			setWorkouts(
				workouts?.data.map((workout: Workout) => ({
					...workout,
					startDate: moment(workout.startDate).toDate(),
					endDate: moment(workout.endDate).toDate(),
				})),
			);
		} catch (error) {
			console.error("Error fetching workouts:", error);
		}
	}, [accessToken, startDate, endDate]);

	const syncHealthkitWorkouts = async () => {
		if (Platform.OS !== "ios") {
			return;
		}

		const results = await HealthService.getWorkoutsFromHealthKit(
			startDate,
			endDate,
		);

		const averageHeartRates = await Promise.all(
			results.map((workout) =>
				HealthService.getAverageHeartRateDuringWorkout(workout),
			),
		);

		const workoutsWithHeartRates = results.map((workout, index) => ({
			...workout,
			averageHeartRateBPM: averageHeartRates[index].averageHeartRate,
			firstHeartRateTime:
				averageHeartRates[index].firstHeartRateSample?.startDate,
			lastHeartRateTime:
				averageHeartRates[index].lastHeartRateSample?.startDate,
			highestHeartRate: averageHeartRates[index].highestHeartRate,
			lowestHeartRate: averageHeartRates[index].lowestHeartRate,
			hkId: workout.id,
		}));

		console.log(workoutsWithHeartRates[0]);

		if (!user?.id) {
			return;
		}

		await Promise.all(
			workoutsWithHeartRates.map(
				async (workout) =>
					await saveUserWorkoutForDate(startDate, {
						activityType: workout.activityName,
						startDate: new Date(workout.start),
						endDate: new Date(workout.end),
						totalDistanceMeters: workout.distance,
						totalEnergyBurnedKcal: workout.calories,
						workoutDurationSeconds: workout.duration,
						averageHeartRateBPM: workout.averageHeartRateBPM,
						firstHeartRateTime: workout.firstHeartRateTime
							? new Date(workout.firstHeartRateTime)
							: undefined,
						lastHeartRateTime: workout.lastHeartRateTime
							? new Date(workout.lastHeartRateTime)
							: undefined,
						highestHeartRate: workout.highestHeartRate,
						lowestHeartRate: workout.lowestHeartRate,
						userId: user?.id,
						hkId: workout.id,
						source:
							workout.sourceName === "3PT Health"
								? WorkoutSource.MANUAL
								: workout.sourceName === "Health"
									? WorkoutSource.HEALTHKIT
									: workout.sourceName,
					}),
			),
		);

		getWorkouts();
	};

	const { mutate: syncHealthkitWorkoutsMutation } = useMutation({
		mutationKey: ["sync-healthkit-workouts", startDate, endDate],
		mutationFn: syncHealthkitWorkouts,
	});

	useEffect(() => {
		getWorkouts();
		syncHealthkitWorkoutsMutation();
	}, [getWorkouts, syncHealthkitWorkoutsMutation]);

	useEffect(() => {
		// Set up automatic refresh every 30 seconds to pick up new workouts
		const refreshInterval = setInterval(() => {
			getWorkouts();
		}, 30000);

		// Cleanup interval on unmount or date change
		return () => clearInterval(refreshInterval);
	}, [getWorkouts]);

	const handleEditWorkout = (workout: Workout) => {
		setSelectedWorkout(workout);
		setEditStartDate(new Date(workout.startDate));
		setEditEndDate(new Date(workout.endDate));
		setEditMiles(
			workout.totalDistanceMeters
				? workout.totalDistanceMeters.toFixed(2)
				: "0",
		);
		setIsModalVisible(true);
	};

	const getWorkoutMetrics = async (startDate: Date, endDate: Date) => {
		let distance = 0;
		let burntCalories = 0;
		let averageHeartRate = 0;
		let firstHeartRateTime = null;
		let lastHeartRateTime = null;
		let highestHeartRate = 0;
		let lowestHeartRate = 0;

		// Get distance since workout started
		const distanceResults = await queryQuantitySamples(
			HKQuantityTypeIdentifier.distanceWalkingRunning,
			{
				from: moment(editStartDate).toDate(),
				to: moment(editEndDate).toDate(),
				unit: UnitOfLength.Miles,
			},
		);

		const burntCaloriesResults = await queryQuantitySamples(
			HKQuantityTypeIdentifier.activeEnergyBurned,
			{
				from: moment(editStartDate).toDate(),
				to: moment(editEndDate).toDate(),
				unit: UnitOfEnergy.Kilocalories,
			},
		);

		distance =
			distanceResults?.reduce((acc, itm) => acc + itm?.quantity, 0) || 0;
		burntCalories =
			burntCaloriesResults?.reduce((acc, itm) => acc + itm?.quantity, 0) || 0;

		const heartRateResults = await queryQuantitySamples(
			HKQuantityTypeIdentifier.heartRate,
			{
				from: moment(startDate).toDate(),
				to: moment(endDate).toDate(),
			},
		);

		// Fix: Proper heart rate data handling
		if (heartRateResults && heartRateResults.length > 0) {
			// Calculate average heart rate with proper bounds checking
			const validReadings = heartRateResults.filter(
				(rate) => rate.quantity > 0 && rate.quantity < 300,
			); // Reasonable heart rate bounds
			const calculatedAverage =
				validReadings.length > 0
					? validReadings.reduce((acc, itm) => acc + itm.quantity, 0) /
					validReadings.length
					: 0;

			// Set current heart rate to the most recent valid reading
			const latestHeartRate =
				heartRateResults[heartRateResults.length - 1]?.quantity;

			averageHeartRate = calculatedAverage;
			firstHeartRateTime = heartRateResults[0]?.startDate;
			lastHeartRateTime =
				heartRateResults[heartRateResults.length - 1]?.startDate;
			highestHeartRate = heartRateResults.reduce(
				(max, itm) => Math.max(max, itm.quantity),
				0,
			);
			lowestHeartRate = heartRateResults.reduce(
				(min, itm) => Math.min(min, itm.quantity),
				0,
			);
		}

		return {
			distance,
			burntCalories,
			averageHeartRate,
			firstHeartRateTime,
			lastHeartRateTime,
			highestHeartRate,
			lowestHeartRate,
		};
	};

	const handleSaveWorkout = async () => {
		if (!selectedWorkout) {
			return;
		}

		try {
			const {
				distance,
				burntCalories,
				averageHeartRate,
				firstHeartRateTime,
				lastHeartRateTime,
				highestHeartRate,
				lowestHeartRate,
			} = await getWorkoutMetrics(
				editStartDate || selectedWorkout.startDate,
				editEndDate || selectedWorkout.endDate,
			);

			if (!selectedWorkout.hkId) {
				return;
			}

			// Calculate personalized calories (MODEL1-3) and include HealthKit (MODEL4)
			let personalizedCalories: { MODEL1: number; MODEL2: number; MODEL3: number; MODEL4: number } = {
				MODEL1: 0,
				MODEL2: 0,
				MODEL3: 0,
				MODEL4: 0,
			};

			try {
				const userCalProfile = accessToken
					? await PersonalizedCalorieCalculator.getUserCoefficients(accessToken)
					: null;

				const start = (editStartDate || selectedWorkout.startDate) as Date;
				const end = (editEndDate || selectedWorkout.endDate) as Date;

				const heartRates = await heartRateDeviceService.getHeartRateSamplesForDevice(
					null,
					start,
					end,
				);

				if (heartRates.length > 0 && userCalProfile) {
					let prevHeartRate = heartRates[0];
					personalizedCalories = heartRates.reduce(
						(acc, itm) => {
							const duration = moment(itm.startDate).diff(
								prevHeartRate.startDate,
								"seconds",
							);

							const data = PersonalizedCalorieCalculator.calculateRealTimeCalories(
								itm.quantity,
								duration,
								userCalProfile,
							);
							prevHeartRate = itm;

							return {
								MODEL1: acc.MODEL1 + data.model1,
								MODEL2: acc.MODEL2 + data.model2,
								MODEL3: acc.MODEL3 + data.model3,
								MODEL4: 0,
							};
						},
						{ MODEL1: 0, MODEL2: 0, MODEL3: 0, MODEL4: 0 },
					);
				}
			} catch (error) {
				console.warn(
					"Failed to calculate personalized calories for workout update, using fallback:",
					error,
				);
			}

			// MODEL4 always reflects HealthKit calories for the window
			personalizedCalories = {
				...personalizedCalories,
				MODEL4: burntCalories,
			};


			// Choose final calories by user preference, fallback to HealthKit
			const method = (
				user?.calorieCountingMethod ?? "MODEL4"
			) as keyof typeof personalizedCalories;
			const finalBurntCalories = personalizedCalories[method] || burntCalories;

			await updateWorkout(selectedWorkout.hkId, {
				totalDistanceMeters: distance,
				totalEnergyBurnedKcal: finalBurntCalories,
				startDate: toUTCForStorage(editStartDate || selectedWorkout.startDate),
				endDate: toUTCForStorage(editEndDate || selectedWorkout.endDate),
				workoutDurationSeconds: moment(
					editEndDate || selectedWorkout.endDate,
				).diff(moment(editStartDate || selectedWorkout.startDate), "seconds"),
				averageHeartRateBPM: averageHeartRate,
				firstHeartRateTime: firstHeartRateTime ?? undefined,
				lastHeartRateTime: lastHeartRateTime ?? undefined,
				highestHeartRate: highestHeartRate,
				lowestHeartRate: lowestHeartRate,
				MODEL1: personalizedCalories.MODEL1,
				MODEL2: personalizedCalories.MODEL2,
				MODEL3: personalizedCalories.MODEL3,
				MODEL4: personalizedCalories.MODEL4,
			});
			getWorkouts();
		} catch (error) {
			console.error("Error updating workout:", error);
		}
		setIsModalVisible(false);
		setSelectedWorkout(null);
	};

	const handleDeleteWorkout = (workout: Workout) => {
		Alert.alert(
			"Delete Workout",
			`Are you sure you want to delete this ${workout.activityType} workout?`,
			[
				{
					text: "Cancel",
					style: "cancel",
				},
				{
					text: "Delete",
					style: "destructive",
					onPress: async () => {
						try {
							if (!workout.hkId) {
								return;
							}

							await deleteWorkout(workout.hkId);
							getWorkouts();
						} catch (error) {
							console.error("Error deleting workout:", error);
							Alert.alert(
								"Error",
								"Failed to delete workout. Please try again.",
							);
						}
					},
				},
			],
		);
	};

	return (
		<Box className="bg-background-0 rounded-2xl mb-4 shadow-soft-1 flex-col gap-4 py-4">
			<HStack className="justify-between items-center px-4 pb-4 border-b border-background-200">
				<Text size="lg" className="font-semibold text-typography-900">
					Workouts
				</Text>
				<Button
					variant="outline"
					size="sm"
					className="w-8 h-8 rounded-full"
					onPress={() => {
						syncHealthkitWorkoutsMutation();
						getWorkouts();
					}}
				>
					<ButtonIcon className="items-center justify-center">
						<Feather name="refresh-cw" color={"#4176CC"} />
					</ButtonIcon>
				</Button>
			</HStack>
			<WorkoutChart
				startDate={startDate}
				endDate={endDate}
				workouts={workouts}
			/>
			<Box className="px-4">
				{workouts.length === 0 ? (
					<Text size="md" className="text-typography-500 text-center py-5">
						No workouts recorded
					</Text>
				) : (
					<VStack space="md" className="pb-2">
						{Object.entries(groupedByDate)
							.sort(
								([dateA], [dateB]) =>
									new Date(dateB).getTime() - new Date(dateA).getTime(),
							)
							.map(([date, dayWorkouts]) => {
								if (dayWorkouts.length === 0) return null;

								return (
									<Box
										key={date}
										className="bg-white rounded-xl p-3 px-4 border border-gray-100"
									>
										<Pressable onPress={() => toggleDateExpansion(date)}>
											<HStack className="justify-between items-center">
												<VStack>
													<Text className="text-base font-semibold text-typography-900">
														{moment(date).format("MMMM D, YYYY")}
													</Text>
													<HStack space="md">
														<Text className="text-typography-500 text-sm">
															{dayWorkouts.length} workout
															{dayWorkouts.length !== 1 ? "s" : ""}
														</Text>
														{getTotalCaloriesForDate(dayWorkouts) > 0 && (
															<Text className="text-typography-500 text-sm">
																{Math.round(
																	getTotalCaloriesForDate(dayWorkouts),
																)}{" "}
																kcal
															</Text>
														)}
														<Text className="text-typography-500 text-sm">
															{formatDuration(
																getTotalDurationForDate(dayWorkouts),
															)}
														</Text>
													</HStack>
												</VStack>
												<View className="w-6 h-6 items-center justify-center rounded-full bg-[#e6efff]">
													<MaterialIcons
														name={
															expandedDates[date]
																? "expand-less"
																: "expand-more"
														}
														size={20}
														color="#4a7aff"
													/>
												</View>
											</HStack>
										</Pressable>

										{expandedDates[date] && (
											<VStack space="md" className="mt-4">
												{dayWorkouts.map((workout, index) => (
													<Box
														key={workout.hkId || index}
														className="bg-background-50 rounded-xl p-4 border border-background-200"
													>
														<HStack className="justify-between items-center mb-2">
															<Text
																size="md"
																className="font-semibold text-typography-900 flex-1 mr-2"
															>
																{workout.activityType}
															</Text>

															<HStack space="sm">
																{workout.source === WorkoutSource.MANUAL && (
																	<Pressable
																		onPress={() => handleEditWorkout(workout)}
																		className="p-1"
																	>
																		<Feather
																			name="edit"
																			size={18}
																			color="#4176CC"
																		/>
																	</Pressable>
																)}
																<Pressable
																	onPress={() => handleDeleteWorkout(workout)}
																	className="p-1"
																>
																	<Feather
																		name="trash-2"
																		size={18}
																		color="#ef4444"
																	/>
																</Pressable>
															</HStack>
														</HStack>
														<HStack className="justify-between items-center mb-2">
															{workout.averageHeartRateBPM ? (
																<Text
																	size="sm"
																	className="text-typography-500 flex-1 text-left"
																>
																	{workout.averageHeartRateBPM.toFixed(0)} BPM
																</Text>
															) : (
																<Box className="flex-1" />
															)}
															<Text
																size="sm"
																className="text-typography-500 flex-1 text-right"
															>
																{HealthService.formatWorkoutDuration(
																	workout.startDate?.toISOString(),
																	workout.endDate?.toISOString(),
																)}
															</Text>
														</HStack>
														<HStack className="justify-between items-center">
															<Text
																size="sm"
																className="text-typography-500 flex-1"
															>
																{HealthService.formatWorkoutTime(
																	workout.startDate.toISOString(),
																	false,
																)}{" "}
																-{" "}
																{HealthService.formatWorkoutTime(
																	workout.endDate.toISOString(),
																	true,
																)}
															</Text>
															{workout.totalEnergyBurnedKcal ? (
																<Text
																	size="sm"
																	className="text-warning-500 flex-1 text-center"
																>
																	{Math.round(workout.totalEnergyBurnedKcal)}{" "}
																	cal
																</Text>
															) : null}
															{workout.totalDistanceMeters ? (
																<Text
																	size="sm"
																	className="text-primary-500 flex-1 text-right"
																>
																	{workout.totalDistanceMeters.toFixed(2)} miles
																</Text>
															) : (
																<Text
																	size="sm"
																	className="text-typography-500 flex-1 text-right"
																>
																	-
																</Text>
															)}
														</HStack>
													</Box>
												))}
											</VStack>
										)}
									</Box>
								);
							})}
					</VStack>
				)}
			</Box>

			{selectedWorkout && (
				<Modal
					isOpen={isModalVisible}
					onClose={() => {
						setIsModalVisible(false);
						setSelectedWorkout(null);
					}}
				>
					<ModalBackdrop />
					<KeyboardAvoidingView
						behavior={Platform.OS === "ios" ? "padding" : "height"}
						className="flex-1 w-full items-center justify-center"
					>
						<Box className="p-6 bg-background-0 rounded-2xl w-11/12 max-w-md shadow-lg border border-background-200">
							<Text size="xl" className="font-bold mb-6 text-typography-900">
								Edit Workout
							</Text>
							<VStack space="lg">
								<Text size="md" className="text-typography-600 mb-1">
									Activity:
								</Text>
								<Text
									size="lg"
									className="font-semibold mb-2 text-typography-900"
								>
									{selectedWorkout.activityType}
								</Text>
								<Divider />
								<Text size="md" className="text-typography-600 mb-1">
									Start Date & Time
								</Text>
								<Pressable
									onPress={() => setShowStartPicker(true)}
									className="flex-row items-center px-4 py-3 bg-background-100 rounded-lg border border-background-200 mb-2"
									style={{ minHeight: 48 }}
								>
									<Feather
										name="calendar"
										size={20}
										color="#4176CC"
										style={{ marginRight: 10 }}
									/>
									<Text size="lg" className="text-typography-900 flex-1">
										{editStartDate
											? editStartDate.toLocaleString()
											: "Select start date & time"}
									</Text>
								</Pressable>
								<DatePicker
									modal
									mode="datetime"
									locale={moment.locale()}
									open={showStartPicker}
									maximumDate={editEndDate || new Date()}
									date={editStartDate || new Date()}
									onConfirm={(date) => {
										setShowStartPicker(false);
										setEditStartDate(date);
									}}
									onCancel={() => setShowStartPicker(false)}
								/>
								<Divider />
								<Text size="md" className="text-typography-600 mb-1">
									End Date & Time
								</Text>
								<Pressable
									onPress={() => setShowEndPicker(true)}
									className="flex-row items-center px-4 py-3 bg-background-100 rounded-lg border border-background-200 mb-2"
									style={{ minHeight: 48 }}
								>
									<Feather
										name="clock"
										size={20}
										color="#4176CC"
										style={{ marginRight: 10 }}
									/>
									<Text size="lg" className="text-typography-900 flex-1">
										{editEndDate
											? editEndDate.toLocaleString()
											: "Select end date & time"}
									</Text>
								</Pressable>
								<DatePicker
									modal
									mode="datetime"
									locale={moment.locale()}
									open={showEndPicker}
									minimumDate={editStartDate || new Date()}
									date={editEndDate || new Date()}
									onConfirm={(date) => {
										setShowEndPicker(false);
										setEditEndDate(date);
									}}
									onCancel={() => setShowEndPicker(false)}
								/>
								<Divider />
								<Text size="md" className="text-typography-600 mb-1">
									Distance (miles)
								</Text>
								<Input>
									<InputField
										type="text"
										value={editMiles}
										onChangeText={setEditMiles}
										placeholder="0.00"
										keyboardType="numeric"
										className="font-semibold text-lg"
									/>
								</Input>
								<Divider />
								<HStack space="md" className="mt-4 justify-end">
									<Button
										variant="outline"
										className="border-background-200"
										onPress={() => {
											setIsModalVisible(false);
											setSelectedWorkout(null);
										}}
									>
										<ButtonText className="text-typography-600">
											Cancel
										</ButtonText>
									</Button>
									<Button
										className="bg-primary-500"
										onPress={handleSaveWorkout}
									>
										<ButtonText className="text-white font-bold">
											Save
										</ButtonText>
									</Button>
								</HStack>
							</VStack>
						</Box>
					</KeyboardAvoidingView>
				</Modal>
			)}
		</Box>
	);
};
