import React, { useEffect } from "react";
import {
  Modal,
  ModalBackdrop,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "@/components/ui/modal";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { VStack } from "@/components/ui/vstack";
import { HStack } from "@/components/ui/hstack";
import { Feather } from "@expo/vector-icons";
import { ScrollView, Pressable } from "react-native";
import { Box } from "@/components/ui/box";
import useTrackerStore, { HeartRateDevice } from "@/store/tracker.store";

interface HeartRateDeviceSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  devices: HeartRateDevice[];
  onDeviceSelect: (device: HeartRateDevice | null) => void;
  selectedDevice: HeartRateDevice | null;
}

export function HeartRateDeviceSelector({
  isOpen,
  onClose,
  devices,
  onDeviceSelect,
  selectedDevice,
}: HeartRateDeviceSelectorProps) {
  const handleDeviceSelect = (device: HeartRateDevice) => {
    onDeviceSelect(device);
    onClose();
  };

  const handleRemoveDevice = () => {
    onDeviceSelect(null);
    onClose();
  };

  const getDeviceIcon = (device: HeartRateDevice) => {
    const deviceName = device.name.toLowerCase();
    if (deviceName.includes("apple watch") || deviceName.includes("watch")) {
      return "watch";
    } else if (deviceName.includes("heart") || deviceName.includes("hrm")) {
      return "heart";
    } else if (
      deviceName.includes("polar") ||
      deviceName.includes("garmin") ||
      deviceName.includes("wahoo")
    ) {
      return "activity";
    }
    return "bluetooth";
  };

  const getConnectionStatusColor = (device: HeartRateDevice) => {
    return device.isConnected ? "text-success-600" : "text-error-600";
  };

  const getConnectionStatusText = (device: HeartRateDevice) => {
    if (device.isConnected) {
      return device.lastDataTime
        ? `Connected - Last data: ${new Date(device.lastDataTime).toLocaleTimeString()}`
        : "Connected";
    }
    return "Disconnected";
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalBackdrop />
      <ModalContent className="max-h-[80%]">
        <ModalHeader>
          <Text size="xl" className="font-bold text-typography-900">
            Select Heart Rate Source
          </Text>
        </ModalHeader>

        <ModalBody>
          <VStack space="md">
            <Text size="md" className="text-typography-700">
              Choose which source to use for heart rate monitoring during your
              workout:
            </Text>

            <ScrollView
              className="max-h-80"
              showsVerticalScrollIndicator={false}
            >
              <VStack space="sm">
                {/* Option to use no specific device */}
                <Pressable
                  onPress={handleRemoveDevice}
                  className={`p-4 rounded-lg border-2 ${
                    !selectedDevice
                      ? "border-primary-500 bg-primary-50"
                      : "border-gray-200 bg-gray-50"
                  }`}
                >
                  <HStack className="justify-between items-center">
                    <VStack space="xs" className="flex-1">
                      <HStack space="sm" className="items-center">
                        <Feather name="smartphone" size={20} color="#666" />
                        <Text
                          size="md"
                          className="font-semibold text-typography-900"
                        >
                          All Available Sources
                        </Text>
                        {!selectedDevice && (
                          <Feather
                            name="check-circle"
                            size={16}
                            color="#4176CC"
                          />
                        )}
                      </HStack>
                      <Text size="sm" className="text-typography-600">
                        Use heart rate data from any connected source
                      </Text>
                    </VStack>
                  </HStack>
                </Pressable>

                {/* Device list */}
                {devices.map((device) => (
                  <Pressable
                    key={device.id}
                    onPress={() => handleDeviceSelect(device)}
                    className={`p-4 rounded-lg border-2 ${
                      selectedDevice?.id === device.id
                        ? "border-primary-500 bg-primary-50"
                        : "border-gray-200 bg-gray-50"
                    }`}
                  >
                    <HStack className="justify-between items-center">
                      <VStack space="xs" className="flex-1">
                        <HStack space="sm" className="items-center">
                          <Text
                            size="md"
                            className="font-semibold text-typography-900"
                          >
                            {device.name}
                          </Text>
                          {selectedDevice?.id === device.id && (
                            <Feather
                              name="check-circle"
                              size={16}
                              color="#4176CC"
                            />
                          )}
                        </HStack>
                        <Text
                          size="sm"
                          className={`${getConnectionStatusColor(device)}`}
                        >
                          {getConnectionStatusText(device)}
                        </Text>
                        {device.bundleIdentifier && (
                          <Text size="xs" className="text-typography-500">
                            {device.bundleIdentifier}
                          </Text>
                        )}
                      </VStack>
                    </HStack>
                  </Pressable>
                ))}

                {devices.length === 0 && (
                  <Box className="p-8 items-center">
                    <Feather name="bluetooth" size={48} color="#ccc" />
                    <Text
                      size="md"
                      className="text-typography-500 mt-4 text-center"
                    >
                      No heart rate sources found.
                    </Text>
                    <Text
                      size="sm"
                      className="text-typography-400 mt-2 text-center"
                    >
                      Make sure your source is connected and has provided heart
                      rate data recently.
                    </Text>
                  </Box>
                )}
              </VStack>
            </ScrollView>
          </VStack>
        </ModalBody>

        <ModalFooter>
          <Button variant="outline" onPress={onClose} className="w-full">
            <ButtonText>Close</ButtonText>
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}
