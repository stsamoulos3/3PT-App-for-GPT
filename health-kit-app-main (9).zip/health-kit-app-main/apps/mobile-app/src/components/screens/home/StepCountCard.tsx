import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { Button, ButtonIcon, ButtonText } from "@/components/ui/button";
import { HStack } from "@/components/ui/hstack";
import { VStack } from "@/components/ui/vstack";
import { Progress, ProgressFilledTrack } from "@/components/ui/progress";
import { useEffect, useState } from "react";
import useTrackHealth from "@/hooks/useTrackHealth";
import { Feather } from "@expo/vector-icons";
import { HealthService } from "@/services/HealthService";
import { Platform } from "react-native";

interface StepCountCardProps {
  date: Date;
}

export const StepCountCard = ({ date }: StepCountCardProps) => {
  const [steps, setSteps] = useState<
    { value: number; startDate: string; endDate: string }[]
  >([]);
  const [dailyGoal, setDailyGoal] = useState(10000); // Default daily goal

  const { saveUserBulkStepsForDate } = useTrackHealth();

  const getSteps = async () => {
    if (Platform.OS !== "ios") {
      return;
    }
    try {
      const steps = await HealthService.getStepCount(date);
      setSteps(steps);
    } catch (error) {
      console.error("Error fetching steps:", error);
    }
  };

  useEffect(() => {
    getSteps();
  }, [date]);

  useEffect(() => {
    if (steps.length > 0) {
      saveUserBulkStepsForDate(
        steps.map((step) => ({
          timestamp: new Date(step.startDate),
          stepsCount: step.value,
        }))
      );
    }
  }, [steps]);

  const progress = Math.min(
    (steps?.reduce((acc, step) => acc + step.value, 0) / dailyGoal) * 100,
    100
  );

  return (
    <Box className="bg-background-0 rounded-2xl mb-4 shadow-soft-1">
      <HStack className="justify-between items-center p-4 border-b border-background-200">
        <Text size="lg" className="font-semibold text-typography-900">
          Step Count
        </Text>
        <Button
          variant="outline"
          size="sm"
          className="w-8 h-8 rounded-full"
          onPress={getSteps}
        >
          <ButtonIcon className="items-center justify-center">
            <Feather name="refresh-cw" color={"#4176CC"} />
          </ButtonIcon>
        </Button>
      </HStack>
      <VStack className="p-5 items-center">
        <VStack className="items-center mb-4">
          <Text size="4xl" className="font-bold text-primary-500">
            {steps?.reduce((acc, step) => acc + step.value, 0) || 0}
          </Text>
          <Text size="md" className="text-typography-500 mt-1">
            steps
          </Text>
        </VStack>

        <VStack className="w-full mt-2">
          <Progress
            value={progress}
            className="h-2 bg-background-100 rounded-full overflow-hidden"
          >
            <ProgressFilledTrack className="h-full bg-primary-500" />
          </Progress>
          <Text size="sm" className="text-typography-500 mt-2 text-center">
            Daily Goal: {dailyGoal.toLocaleString()} steps
          </Text>
        </VStack>
      </VStack>
    </Box>
  );
};
