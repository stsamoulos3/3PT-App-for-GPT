import type React from "react";
import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { HStack } from "@/components/ui/hstack";
import { VStack } from "@/components/ui/vstack";
import { MaterialIcons } from "@expo/vector-icons";

interface StreakData {
    currentWorkoutStreak: number;
    longestWorkoutStreak: number;
    currentFoodStreak: number;
    longestFoodStreak: number;
    lastWorkoutDate: string | null;
    lastFoodLogDate: string | null;
    lastActiveAt: string;
}

interface StreakCardProps {
    streaks: StreakData;
    isLoading?: boolean;
}

export const StreakCard: React.FC<StreakCardProps> = ({
    streaks,
    isLoading = false,
}) => {
    if (isLoading) {
        return (
            <Box className="bg-white rounded-xl shadow-sm p-4 mb-4">
                <VStack space="md">
                    <Box className="h-4 bg-gray-200 rounded animate-pulse" />
                    <HStack space="md" className="justify-between">
                        <Box className="flex-1 h-16 bg-gray-200 rounded animate-pulse" />
                        <Box className="flex-1 h-16 bg-gray-200 rounded animate-pulse" />
                    </HStack>
                </VStack>
            </Box>
        );
    }

    const formatLastActive = (dateString: string) => {
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now.getTime() - date.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays === 0) return "Today";
        if (diffDays === 1) return "Yesterday";
        if (diffDays < 7) return `${diffDays} days ago`;
        return date.toLocaleDateString();
    };

    return (
        <Box className="bg-white rounded-xl shadow-sm p-4 mb-4">
            <VStack space="md">
                <HStack className="items-center justify-between">
                    <Text className="text-lg font-semibold text-gray-900">
                        Your Streaks
                    </Text>
                    <HStack className="items-center space-xs">
                        <MaterialIcons name="calendar-today" size={16} color="#6b7280" />
                        <Text className="text-sm text-gray-500">
                            Last active: {formatLastActive(streaks.lastActiveAt)}
                        </Text>
                    </HStack>
                </HStack>

                <HStack space="md" className="justify-between">
                    {/* Workout Streak */}
                    <Box className="flex-1 bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-4">
                        <VStack space="xs" className="items-center">
                            <HStack className="items-center space-xs">
                                <MaterialIcons name="local-fire-department" size={16} color="#ea580c" />
                                <Text className="text-sm font-medium text-orange-700">
                                    Workout
                                </Text>
                            </HStack>
                            <Text className="text-2xl font-bold text-orange-900">
                                {streaks.currentWorkoutStreak}
                            </Text>
                            <Text className="text-xs text-orange-600 text-center">
                                {streaks.currentWorkoutStreak === 1 ? "day" : "days"}
                            </Text>
                            {streaks.longestWorkoutStreak > streaks.currentWorkoutStreak && (
                                <Text className="text-xs text-orange-500 text-center">
                                    Best: {streaks.longestWorkoutStreak}
                                </Text>
                            )}
                        </VStack>
                    </Box>

                    {/* Food Streak */}
                    <Box className="flex-1 bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4">
                        <VStack space="xs" className="items-center">
                            <HStack className="items-center space-xs">
                                <MaterialIcons name="local-fire-department" size={16} color="#16a34a" />
                                <Text className="text-sm font-medium text-green-700">Food</Text>
                            </HStack>
                            <Text className="text-2xl font-bold text-green-900">
                                {streaks.currentFoodStreak}
                            </Text>
                            <Text className="text-xs text-green-600 text-center">
                                {streaks.currentFoodStreak === 1 ? "day" : "days"}
                            </Text>
                            {streaks.longestFoodStreak > streaks.currentFoodStreak && (
                                <Text className="text-xs text-green-500 text-center">
                                    Best: {streaks.longestFoodStreak}
                                </Text>
                            )}
                        </VStack>
                    </Box>
                </HStack>

                {/* Last Activity Info */}
                <HStack space="md" className="justify-between">
                    <Box className="flex-1">
                        <Text className="text-xs text-gray-500">Last Workout</Text>
                        <Text className="text-sm font-medium text-gray-900">
                            {streaks.lastWorkoutDate
                                ? new Date(streaks.lastWorkoutDate).toLocaleDateString()
                                : "Never"}
                        </Text>
                    </Box>
                    <Box className="flex-1">
                        <Text className="text-xs text-gray-500">Last Food Log</Text>
                        <Text className="text-sm font-medium text-gray-900">
                            {streaks.lastFoodLogDate
                                ? new Date(streaks.lastFoodLogDate).toLocaleDateString()
                                : "Never"}
                        </Text>
                    </Box>
                </HStack>
            </VStack>
        </Box>
    );
};
