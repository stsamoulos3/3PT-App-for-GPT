import React, { Key } from "react";
import { Box } from "@/components/ui/box";
import { Button, ButtonIcon, ButtonText } from "@/components/ui/button";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";
import { VStack } from "@/components/ui/vstack";
import { Feather } from "@expo/vector-icons";
import { HKWorkoutActivityType } from "@kingstinct/react-native-healthkit";
import { useState } from "react";
import useTrackerStore from "@/store/tracker.store";
import { Modal, ModalBackdrop } from "@/components/ui/modal";
import { ScrollView } from "react-native";
import { Input, InputField } from "@/components/ui/input";
import { Menu, MenuItem, MenuItemLabel } from "@/components/ui/menu";
import { router } from "expo-router";
import WorkoutsModal from "./Workouts/WorkoutsModal";

export const ActionFab = () => {
  const [isWorkoutsModalOpen, setIsWorkoutsModalOpen] = useState(false);

  const handleSelectionChange = (value: Set<Key> | string) => {
    if (!(value instanceof Set)) return;

    if (value.has("Start Workout")) {
      setIsWorkoutsModalOpen(true);
    } else if (value.has("Add Food")) {
      router.push("/nutrition/record-food");
    }
  };

  return (
    <>
      {/* open a menu list of actions */}
      <Menu
        placement="bottom right"
        offset={5}
        onSelectionChange={handleSelectionChange}
        selectionMode="single"
        trigger={({ ...triggerProps }) => {
          return (
            <Button
              size="lg"
              variant="solid"
              className="absolute bottom-4 right-4 rounded-full w-14 h-14 p-0 items-center justify-center"
              {...triggerProps}
            >
              <Feather name="plus" size={24} color="white" />
            </Button>
          );
        }}
        className="border-primary-500 border-opacity-50 rounded-xl"
      >
        <MenuItem
          key="Start Workout"
          textValue="Start Workout"
          className="gap-2"
        >
          <Feather name="play" size={16} color="#4176CC" />
          <MenuItemLabel size="md">Start Workout</MenuItemLabel>
        </MenuItem>
        <MenuItem key="Add Food" textValue="Add Food" className="gap-2">
          <Feather name="plus" size={16} color="#4176CC" />
          <MenuItemLabel size="md">Add Food</MenuItemLabel>
        </MenuItem>
      </Menu>

      <WorkoutsModal
        isWorkoutsModalOpen={isWorkoutsModalOpen}
        setIsWorkoutsModalOpen={setIsWorkoutsModalOpen}
      />
    </>
  );
};
