import React from "react";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { VStack } from "@/components/ui/vstack";
import { HStack } from "@/components/ui/hstack";
import { AlertCircleIcon } from "@/components/ui/icon";
import useTrackerStore, { HeartRateDevice } from "@/store/tracker.store";
import {
  Modal,
  ModalBackdrop,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
} from "@/components/ui/modal";

interface DeviceDisconnectionAlertProps {
  isOpen: boolean;
  onClose: () => void;
  onPauseWorkout: () => void;
  onContinueWithoutDevice: () => void;
  disconnectedDevice: HeartRateDevice | null;
}

export function DeviceDisconnectionAlert({
  isOpen,
  onClose,
  onPauseWorkout,
  onContinueWithoutDevice,
  disconnectedDevice,
}: DeviceDisconnectionAlertProps) {
  const { setIsHeartRateDeviceDisconnected } = useTrackerStore();

  const handlePauseWorkout = () => {
    onPauseWorkout();
    setIsHeartRateDeviceDisconnected(false);
    onClose();
  };

  const handleContinueWithoutDevice = () => {
    onContinueWithoutDevice();
    setIsHeartRateDeviceDisconnected(false);
    onClose();
  };

  const handleClose = () => {
    setIsHeartRateDeviceDisconnected(false);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose}>
      <ModalBackdrop />
      <ModalContent>
        <ModalHeader>
          <Text size="xl" className="font-bold text-typography-900">
            Device Warning
          </Text>
        </ModalHeader>
        <ModalBody>
          <VStack space="md">
            <Text size="md" className="text-typography-700">
              Your heart rate source "
              {disconnectedDevice?.name || "Unknown Source"}" seems to be
              disconnected.
            </Text>

            <Text size="md" className="text-typography-700">
              Would you like to pause your workout to reconnect the source, or
              continue without heart rate monitoring?
            </Text>
          </VStack>
        </ModalBody>

        <ModalFooter>
          <VStack space="sm" className="w-full">
            <Button className="w-full" onPress={handlePauseWorkout}>
              <ButtonText>Pause Workout</ButtonText>
            </Button>

            <Button
              variant="outline"
              className="w-full"
              onPress={handleContinueWithoutDevice}
            >
              <ButtonText>Continue</ButtonText>
            </Button>
          </VStack>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}
