import { HStack } from "@/components/ui/hstack";

import { Box } from "@/components/ui/box";
import { NutritionToHKUnit } from "@/services/HealthService";
import { VStack } from "@/components/ui/vstack";
import { getBgColorFromName } from "@/helpers/getColorFromName";
import { Text } from "@/components/ui/text";
import formatNumberWithPostfix from "@/helpers/formatNumberWithPostfix";

const FactGroup = ({
  title,
  data,
}: {
  title: string;
  data: Record<string, number>;
}) => {
  return (
    <Box>
      <Text className="text-typography-900 font-medium">{title}</Text>
      <HStack className="flex-wrap justify-between">
        {Object.entries(data)
          .sort((a, b) => b[1] - a[1])
          .map(([key, value], index) => (
            <Box key={index} className="w-[48%] mb-3 bg-gray-50 rounded-lg p-3">
              <HStack className="items-center" space="md">
                <Box
                  className="w-3 h-3 rounded-full"
                  style={{
                    backgroundColor: getBgColorFromName(key),
                  }}
                />
                <VStack>
                  <Text className="text-typography-900 flex-1">
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </Text>
                  <Text className="text-typography-500 text-xs">
                    {value
                      ? `${formatNumberWithPostfix(value)} ${
                          NutritionToHKUnit[
                            key as keyof typeof NutritionToHKUnit
                          ]
                        }`
                      : "-"}
                  </Text>
                </VStack>
              </HStack>
            </Box>
          ))}
      </HStack>
    </Box>
  );
};

export default FactGroup;
