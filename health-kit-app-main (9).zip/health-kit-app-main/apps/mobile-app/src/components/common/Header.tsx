import { HStack } from "../ui/hstack";
import { Text } from "../ui/text";
import { View } from "react-native";
import { Logo } from "./Logo";

export default function Header({ title }: { title: string }) {
  return (
    <HStack className="justify-between items-center mb-6">
      <Text size="3xl" className="font-bold text-typography-900">
        {title}
      </Text>
      <View className=" items-center">
        <Logo size="lg" />
      </View>
    </HStack>
  );
}
