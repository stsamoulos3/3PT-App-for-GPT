import React, { useEffect, useState } from "react";
import { Pressable, ScrollView, TextInput, TextInputProps } from "react-native";
import { VStack } from "@/components/ui/vstack";
import { Input, InputField, InputIcon, InputSlot } from "@/components/ui/input";
import { Textarea, TextareaInput } from "@/components/ui/textarea";
import { Box } from "@/components/ui/box";
import {
  useForm,
  Control,
  Controller,
  FieldValues,
  Path,
  RegisterOptions,
  PathValue,
} from "react-hook-form";
import { FormControl, FormControlError } from "@/components/ui/form-control";
import { Text } from "../ui/text";
import { MaterialIcons } from "@expo/vector-icons";
import {
  Select,
  SelectTrigger,
  SelectInput,
  SelectPortal,
  SelectContent,
  SelectDragIndicatorWrapper,
  SelectDragIndicator,
  SelectItem,
  SelectIcon,
  SelectBackdrop,
  SelectSectionHeaderText,
} from "@/components/ui/select";
import { Calendar, CalendarList, Agenda } from "react-native-calendars";
import { Platform } from "react-native";
import { Modal, ModalBackdrop, ModalContent } from "../ui/modal";
import { Button } from "../ui/button";
import DateTimePicker from "@react-native-community/datetimepicker";
import DatePicker from "react-native-date-picker";
import { formatDate } from "@repo/core/helpers/dateFormatters";
import { toUTCForStorage } from "@repo/core/helpers/dateUtils";
import {
  Checkbox,
  CheckboxIndicator,
  CheckboxLabel,
  CheckboxIcon,
} from "@/components/ui/checkbox";

export type InputType =
  | "text"
  | "email"
  | "password"
  | "phone"
  | "textarea"
  | "number"
  | "select"
  | "date"
  | "checkbox";

export interface SelectOption {
  label: string;
  value: string | number;
}

export interface FormField<T extends FieldValues> extends TextInputProps {
  name: keyof T;
  placeholder: string;
  label?: string;
  type?: InputType;
  multiline?: boolean;
  numberOfLines?: number;
  secureTextEntry?: boolean;
  rules?: {
    validate?: (value: any) => string | boolean | Promise<string | boolean>;
    required?: string;
  };
  minimumDate?: Date;
  maximumDate?: Date;
  options?: SelectOption[];
  onLinkPress?: () => void;
}

interface FormBuilderProps<T extends FieldValues> {
  fields: FormField<T>[];
  defaultValues?: Partial<T>;
  control: Control<T>;
  showLabel?: boolean;
}

const getKeyboardType = (type?: InputType) => {
  switch (type) {
    case "email":
      return "email-address";
    case "phone":
      return "phone-pad";
    default:
      return "default";
  }
};

export default function FormBuilder<T extends FieldValues>({
  fields,
  defaultValues,
  control,
  showLabel = false,
}: FormBuilderProps<T>) {
  return (
    <VStack space="lg" className="w-full gap-4">
      {fields.map((field, index) => (
        <FormField
          key={`${field.name as string}-${index}`}
          field={field}
          index={index}
          control={control}
          showLabel={showLabel}
        />
      ))}
    </VStack>
  );
}

const FormField = <T extends FieldValues>({
  field,
  index,
  control,
  showLabel = true,
}: {
  field: FormField<T>;
  index: number;
  control: Control<T>;
  showLabel?: boolean;
}) => {
  const [secureText, setSecureText] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);

  useEffect(() => {
    setSecureText(field.type === "password");
  }, [field.type]);

  const commonProps = {
    placeholder: field.placeholder,
    keyboardType: field.keyboardType || getKeyboardType(field.type),
    secureTextEntry: secureText,
  };

  return (
    <Controller
      key={index}
      control={control}
      name={field.name as Path<T>}
      rules={field.rules}
      render={({ field: { value, onChange, ref }, fieldState: { error } }) => (
        <FormControl isInvalid={!!error}>
          {showLabel && (
            <Text size="lg" className="text-typography-600 mb-2">
              {field.label || field.placeholder}{" "}
              {field.rules?.required && <Text size="sm">*</Text>}
            </Text>
          )}
          {field.type === "date" ? (
            <>
              <Pressable
                onPress={() => {
                  setShowDatePicker(true);
                }}
              ></Pressable>
              <Button
                onPress={() => setShowDatePicker(true)}
                variant="outline"
                className={`h-16 rounded-lg justify-start ${error ? "border-error-700" : "border-primary-500"}`}
              >
                <Text size="lg" className="text-typography-900">
                  {value ? formatDate(value) : field.placeholder}
                </Text>
              </Button>
              {showDatePicker && (
                <DatePicker
                  modal
                  mode="date"
                  date={value ? new Date(value) : new Date()}
                  minimumDate={field.minimumDate || undefined}
                  maximumDate={field.maximumDate || undefined}
                  onDateChange={onChange}
                  open={showDatePicker}
                  onCancel={() => setShowDatePicker(false)}
                  onConfirm={(date) => {
                    setShowDatePicker(false);
                    onChange(toUTCForStorage(date));
                  }}
                />
              )}
            </>
          ) : field.type === "select" ? (
            <Select
              selectedValue={value}
              onValueChange={onChange}
              className="h-16 rounded-lg"
            >
              <SelectTrigger
                className={`h-16 rounded-lg ${error ? "border-error-700" : "border-primary-500"}`}
                size="xl"
              >
                <SelectInput
                  placeholder={field.placeholder}
                  size="lg"
                  className="flex-1 text-typography-900"
                  value={
                    field.options?.find((option) => option.value === value)
                      ?.label
                  }
                />
                <SelectIcon
                  as={() => (
                    <MaterialIcons
                      className="mr-4"
                      name="arrow-drop-down"
                      size={24}
                      color="gray"
                    />
                  )}
                />
              </SelectTrigger>
              <SelectPortal snapPoints={[50]}>
                <SelectBackdrop />
                <SelectContent>
                  <SelectSectionHeaderText>
                    {field.placeholder}
                  </SelectSectionHeaderText>
                  <SelectDragIndicatorWrapper>
                    <SelectDragIndicator />
                  </SelectDragIndicatorWrapper>
                  {field.options?.map((option) => (
                    <SelectItem
                      key={option.value}
                      label={option.label}
                      value={option.value.toString()}
                      className="text-4xl text-typography-900"
                      textStyle={{
                        size: "xl",
                      }}
                    ></SelectItem>
                  ))}
                </SelectContent>
              </SelectPortal>
            </Select>
          ) : field.type === "checkbox" ? (
            <Checkbox
              value=""
              isChecked={value}
              onChange={onChange}
              size="md"
              className="flex-row items-center"
            >
              <CheckboxIndicator>
                <CheckboxIcon
                  as={() => (
                    <MaterialIcons name="check" size={16} color="white" />
                  )}
                />
              </CheckboxIndicator>
              <CheckboxLabel className="ml-2 flex-1">
                <Text className="text-sm text-typography-600">
                  By checking "Agree," I confirm that I have read, understood,
                  and consent to Three Point Healthcare's{" "}
                  <Text
                    className="text-primary-500 underline"
                    onPress={field.onLinkPress}
                  >
                    User Agreement
                  </Text>
                  .
                </Text>
              </CheckboxLabel>
            </Checkbox>
          ) : field.type === "textarea" ? (
            <Textarea className="min-h-[100] rounded-lg" size="lg">
              <TextareaInput
                {...commonProps}
                defaultValue={field.defaultValue?.toString()}
                value={value}
                onChangeText={onChange}
                className="rounded-lg p-4"
                multiline
                numberOfLines={field.numberOfLines || 4}
              />
            </Textarea>
          ) : (
            <Input className="h-16 rounded-lg" size="lg">
              <InputField
                {...commonProps}
                value={value?.toString()}
                onChangeText={(text) =>
                  onChange(field.type === "number" ? Number(text) : text)
                }
                className="rounded-lg p-4"
                placeholderClassName="text-typography-200"
              />
              {field.type === "email" && (
                <InputSlot className="p-4">
                  <MaterialIcons name="email" size={24} color="gray" />
                </InputSlot>
              )}
              {field.type === "password" && (
                <InputSlot className="p-4 h-full">
                  <Pressable onPress={() => setSecureText(!secureText)}>
                    <MaterialIcons
                      name={secureText ? "visibility" : "visibility-off"}
                      size={24}
                      color="gray"
                    />
                  </Pressable>
                </InputSlot>
              )}
            </Input>
          )}
          {error && (
            <FormControlError>
              <Text size="sm">{error.message}</Text>
            </FormControlError>
          )}
        </FormControl>
      )}
    />
  );
};
