// components/ui/pentagon-badge/AnimatedPentagonBadge.tsx
import type { FC } from "react";
import { View } from "react-native";
import Svg, { Path, Text as SvgText } from "react-native-svg";
import { Text } from "@/components/ui/text";
import { VStack } from "@/components/ui/vstack";

interface AnimatedPentagonBadgeProps {
	completedCount: number;
	totalCount?: number;
	size?: number;
	fillColor?: string;
	strokeColor?: string;
	inactiveColor?: string;
	label?: string;
}

export const AnimatedPentagonBadge: FC<AnimatedPentagonBadgeProps> = ({
	completedCount,
	totalCount = 5,
	size = 60,
	fillColor = "#4176CC",
	strokeColor = "#000000",
	inactiveColor = "#e5e7eb",
	label,
}) => {
	// Pentagon coordinates (centered, pointing up)
	const centerX = size / 2;
	const centerY = size / 2;
	const radius = size * 0.35;

	// Calculate pentagon points
	const getPoints = () => {
		const points = [];
		for (let i = 0; i < 5; i++) {
			const angle = (i * 2 * Math.PI) / 5 - Math.PI / 2; // Start from top
			const x = centerX + radius * Math.cos(angle);
			const y = centerY + radius * Math.sin(angle);
			points.push({ x, y });
		}
		return points;
	};

	const points = getPoints();

	// Create individual side paths
	const getSides = () => {
		const sides = [];
		for (let i = 0; i < 5; i++) {
			const currentPoint = points[i];
			const nextPoint = points[(i + 1) % 5];

			// Create a line segment for each side
			const path = `M ${currentPoint.x} ${currentPoint.y} L ${nextPoint.x} ${nextPoint.y}`;
			sides.push({
				id: `side-${i}`,
				path,
				highlighted: i < completedCount,
			});
		}
		return sides;
	};

	const sides = getSides();

	return (
		<VStack className="items-center flex-row flex-1">
			<View style={{ width: size, height: size }}>
				<Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
					{/* Individual pentagon sides */}
					{sides.map((side) => (
						<Path
							key={side.id}
							d={side.path}
							fill="transparent"
							stroke={side.highlighted ? fillColor : inactiveColor}
							strokeWidth={4}
							strokeLinecap="round"
							strokeLinejoin="round"
						/>
					))}

					{/* Center count text */}
					<SvgText
						x={centerX}
						y={centerY + size * 0.08} // Slight offset for better vertical centering
						textAnchor="middle"
						fontSize={size * 0.3}
						fontWeight="bold"
						fill={completedCount > 0 ? fillColor : inactiveColor}
					>
						{completedCount}
					</SvgText>
				</Svg>
			</View>

			{label && (
				<Text size="sm" className="text-typography-600 text-left flex-1 ">
					{label}
				</Text>
			)}
		</VStack>
	);
};
