import React from "react";
import { ScrollView } from "react-native";
import {
  Modal,
  ModalBackdrop,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  ModalCloseButton,
} from "@/components/ui/modal";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { VStack } from "@/components/ui/vstack";
import { MaterialIcons } from "@expo/vector-icons";

interface UserAgreementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function UserAgreementModal({
  isOpen,
  onClose,
}: UserAgreementModalProps) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} size="lg">
      <ModalBackdrop />
      <ModalContent className="max-h-[90%]">
        <ModalHeader>
          <Text className="text-lg font-semibold">
            3PT Health App – User Agreement and Consent
          </Text>
          <ModalCloseButton>
            <MaterialIcons name="close" size={20} />
          </ModalCloseButton>
        </ModalHeader>

        <ModalBody>
          <ScrollView showsVerticalScrollIndicator={false}>
            <VStack space="md">
              <Text className="text-sm text-typography-700">
                Welcome to the 3PT Health App—a digital health and wellness
                platform designed to help you track key metrics like heart rate,
                nutrition, weight, and more.
              </Text>
              <Text className="text-sm text-typography-700">
                Whether you're a 3PT patient or simply here to monitor your
                wellness, your privacy and trust are important to us.
              </Text>
              <Text className="text-sm text-typography-700">
                By continuing, you agree to the following:
              </Text>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  1. Data Collection & Use
                </Text>
                <Text className="text-sm text-typography-700">
                  3PT collects personal and health-related data you provide
                  directly or through connected third-party services (e.g.,
                  Apple HealthKit, Polar AccessLink). This data may include
                  metrics such as heart rate, VO₂ max, weight, nutrition, and
                  resting metabolic rate (RMR).
                </Text>
                <Text className="text-sm text-typography-700">
                  • If you are a 3PT patient, this data may be used in your
                  clinical treatment and is governed by our Notice of Privacy
                  Practices under HIPAA.
                </Text>
                <Text className="text-sm text-typography-700">
                  • If you are not receiving clinical care from 3PT, the data is
                  collected for wellness and informational purposes only and is
                  not considered Protected Health Information (PHI).
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  2. Third-Party Data Integrations
                </Text>
                <Text className="text-sm text-typography-700">
                  By enabling integrations, you authorize 3PT to access and use
                  data from external services you connect, such as:
                </Text>
                <Text className="text-sm text-typography-700">
                  • Apple HealthKit{"\n"}• Polar AccessLink{"\n"}• Other
                  connected fitness or nutrition platforms
                </Text>
                <Text className="text-sm text-typography-700">
                  This may include heart rate, steps, calories, weight, resting
                  metabolic rate (RMR), VO₂ Max, and other biometrics. This data
                  will never be sold or shared for advertising purposes. You can
                  disconnect integrations at any time in your settings.
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  3. Ongoing Health Monitoring
                </Text>
                <Text className="text-sm text-typography-700">
                  I understand that this app may track and store biometric data
                  for wellness insights. If I am working with a 3PT provider,
                  this data may also be used in my treatment. If I am not
                  working with a provider, this data is for personal use only
                  and should not be interpreted as clinical advice.
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  4. Remote Therapeutic Monitoring (RTM) – For 3PT Patients Only
                </Text>
                <Text className="text-sm text-typography-700">
                  If I am an active 3PT patient, I understand that certain data
                  collected through the app may be used to support Remote
                  Therapeutic Monitoring (RTM) services, which may be billed to
                  my insurance. Non-patients will not be billed and are not
                  eligible for RTM under this platform unless they enter into a
                  treatment relationship with 3PT.
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  5. Privacy & Security
                </Text>
                <Text className="text-sm text-typography-700">
                  I have read and agree to the Notice of Privacy Practices,
                  which outlines:
                </Text>
                <Text className="text-sm text-typography-700">
                  • What data is collected{"\n"}• How it is stored and secured
                  {"\n"}• Who has access{"\n"}• My ability to request, correct,
                  or delete my data
                </Text>
                <Text className="text-sm text-typography-700">
                  We protect your data using industry-standard encryption and
                  secure storage methods. All data access is governed by
                  applicable privacy laws including HIPAA and state-level
                  regulations.
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  6. Terms of Use and Disclaimers
                </Text>
                <Text className="text-sm text-typography-700">
                  This app is for wellness tracking and informational purposes
                  only. It is not a substitute for medical care unless you are
                  under the treatment of a licensed 3PT provider. 3PT disclaims
                  liability for:
                </Text>
                <Text className="text-sm text-typography-700">
                  • Decisions made using app-generated insights{"\n"}•
                  Third-party service interruptions{"\n"}• Inaccurate data
                  inputs from external integrations
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  7. Accuracy of Content and User-Generated Data
                </Text>
                <Text className="text-sm text-typography-700">
                  3PT makes no guarantees regarding the accuracy, completeness,
                  reliability, or timeliness of any content available through
                  the 3PT Health App. This includes—but is not limited
                  to—biometric data, nutrition tracking, exercise
                  recommendations, or other health insights.
                </Text>
                <Text className="text-sm text-typography-700">
                  We do not commit to updating or verifying such content
                  regularly, and we disclaim liability for reliance on
                  information presented through the Services.
                </Text>
                <Text className="text-sm text-typography-700">
                  Some content, including nutrition logs, goals, exercise
                  inputs, or notes, may be user-generated or derived from
                  external sources. These entries:
                </Text>
                <Text className="text-sm text-typography-700">
                  • Are the sole responsibility of the user who submitted them
                  {"\n"}• Are not reviewed or validated by licensed health
                  professionals{"\n"}• Should not be relied upon for medical,
                  diagnostic, or treatment decisions
                </Text>
                <Text className="text-sm text-typography-700">
                  Our nutrition, exercise, and wellness databases may include
                  information contributed by users or third parties. While we
                  strive for usefulness, we do not guarantee the safety,
                  accuracy, completeness, or reliability of this
                  information—particularly with respect to food safety,
                  allergens, or interactions with medications.
                </Text>
                <Text className="text-sm text-typography-700">
                  Portions of the app may incorporate machine learning, AI
                  tools, or third-party algorithms. Any insights or
                  recommendations generated by such systems may:
                </Text>
                <Text className="text-sm text-typography-700">
                  • Contain errors or outdated information{"\n"}• Reflect biases
                  inherent in source data{"\n"}• Be incomplete or inappropriate
                  for your specific health profile
                </Text>
                <Text className="text-sm text-typography-700">
                  You are responsible for verifying any recommendations and
                  should consult a qualified healthcare professional before
                  making decisions based on app content. 3PT assumes no
                  liability for harm, loss, or misinterpretation resulting from
                  reliance on app content, including AI-generated outputs or
                  community-sourced data.
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  8. De-Identified Data & Research Use
                </Text>
                <Text className="text-sm text-typography-700">
                  You consent to the use of your de-identified and/or aggregated
                  data to support:
                </Text>
                <Text className="text-sm text-typography-700">
                  • Research and development{"\n"}• Health outcomes analysis
                  {"\n"}• Internal quality improvement{"\n"}• Commercial
                  partnerships or tools
                </Text>
                <Text className="text-sm text-typography-700">
                  No data used in this way will include your name, contact
                  details, or any information that could reasonably identify
                  you.
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  9. Illinois Biometric Privacy Notice (BIPA Compliance)
                </Text>
                <Text className="text-sm text-typography-700">
                  If you are an Illinois resident, you acknowledge and consent
                  to 3PT collecting and processing biometric
                  information—including but not limited to heart rate, resting
                  metabolic rate (RMR), and other biometric data—as defined
                  under Illinois' BIPA.
                </Text>
                <Text className="text-sm text-typography-700">
                  In accordance with the Illinois Biometric Information Privacy
                  Act (BIPA), you:
                </Text>
                <Text className="text-sm text-typography-700">
                  • Consent to the collection and use of your biometric data for
                  the purposes described above{"\n"}• Understand that biometric
                  data that can reasonably identify me will be securely deleted
                  within three (3) years of my last interaction with 3PT, or
                  when the original purpose has been fulfilled, whichever comes
                  first. However, 3PT may retain de-identified or aggregated
                  biometric data for research, quality improvement, or analytics
                  purposes, consistent with applicable laws.{"\n"}• Understand
                  that 3PT will use industry-standard safeguards to protect this
                  data{"\n"}• Acknowledge that 3PT will not sell, lease, or
                  profit from your biometric data without your explicit written
                  consent
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  10. User-Generated Content & Community Standards
                </Text>
                <Text className="text-sm text-typography-700">
                  If you post or upload any content (e.g., comments, goals,
                  notes), you agree that:
                </Text>
                <Text className="text-sm text-typography-700">
                  • You are solely responsible for your submissions{"\n"}• Your
                  content will not be unlawful, harmful, or offensive{"\n"}• 3PT
                  reserves the right to remove any content at our discretion
                </Text>
                <Text className="text-sm text-typography-700">
                  You may not use the app to harass, impersonate others, or
                  interfere with others' use.
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  11. Account Termination
                </Text>
                <Text className="text-sm text-typography-700">
                  3PT reserves the right to suspend or terminate your account
                  if:
                </Text>
                <Text className="text-sm text-typography-700">
                  • You violate these terms{"\n"}• Your conduct is harmful to
                  the app or other users{"\n"}• Required by law or regulatory
                  request
                </Text>
                <Text className="text-sm text-typography-700">
                  If terminated, 3PT may retain your data only as required by
                  law or for contractual obligations.
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  12. Modifications to Terms
                </Text>
                <Text className="text-sm text-typography-700">
                  These Terms of Service may be updated from time to time.
                  Material changes will be communicated to you through the app
                  or via email. Continued use of the app after such changes
                  constitutes your acceptance.
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  13. Dispute Resolution; Arbitration; Class Action Waiver
                </Text>
                <Text className="text-sm text-typography-700">
                  To the fullest extent permitted by law, you and 3PT agree to
                  resolve any disputes, claims, or controversies arising out of
                  or relating to this Agreement or your use of the 3PT Health
                  App through final and binding arbitration, rather than in
                  court. The arbitration shall be conducted by a single
                  arbitrator in accordance with the rules of the American
                  Arbitration Association (AAA) or a similar established
                  alternative dispute resolution provider. The arbitration shall
                  take place in Cook County, Illinois, or virtually at the
                  mutual discretion of the parties. The arbitrator's decision
                  shall be final and binding, and judgment may be entered in any
                  court of competent jurisdiction.
                </Text>
                <Text className="text-sm font-semibold text-typography-900">
                  Class Action Waiver and Jury Trial Waiver:
                </Text>
                <Text className="text-sm text-typography-700">
                  • All arbitration and dispute resolution proceedings shall be
                  conducted solely on an individual basis. You waive any right
                  to pursue or participate in any claim as part of a class,
                  collective, consolidated, or representative action.{"\n"}• You
                  agree not to serve as a class representative or participate as
                  a member of a class in any proceeding involving others' claims
                  against 3PT.{"\n"}• You waive the right to a trial by jury and
                  agree that disputes will not be litigated in state or federal
                  courts of general jurisdiction, except as expressly permitted
                  by law or this Agreement.
                </Text>
                <Text className="text-sm text-typography-700">
                  Together, these terms constitute and operate as the Class
                  Action Waiver.
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  14. Medical Disclaimer & Emergency Response
                </Text>
                <Text className="text-sm text-typography-700">
                  The 3PT Health App is not monitored in real time, and 3PT does
                  not have any obligation to review, act upon, or respond to the
                  information you submit through the app on an ongoing or
                  immediate basis.
                </Text>
                <Text className="text-sm text-typography-700">
                  This app is not intended to diagnose, treat, monitor, or
                  manage medical emergencies or critical health events.
                </Text>
                <Text className="text-sm font-semibold text-error-700">
                  If you are experiencing a medical emergency, do not use this
                  app. You should call 911 immediately or seek care from the
                  nearest emergency medical provider.
                </Text>
                <Text className="text-sm text-typography-700">
                  By using this app, you acknowledge and agree that:
                </Text>
                <Text className="text-sm text-typography-700">
                  • 3PT is not liable for any delayed review of submitted data
                  {"\n"}• The app does not replace in-person clinical judgment
                  or emergency response{"\n"}• Any data submitted is for
                  self-monitoring or care augmentation purposes only
                </Text>
              </VStack>

              <VStack space="sm">
                <Text className="text-base font-semibold text-typography-900">
                  15. Consent and Revocation
                </Text>
                <Text className="text-sm text-typography-700">
                  You may revoke permissions (e.g., for integrations, data use)
                  or request account deletion at any time via app settings or by
                  contacting support.
                </Text>
              </VStack>
            </VStack>
          </ScrollView>
        </ModalBody>

        <ModalFooter>
          <Button onPress={onClose} className="w-full">
            <ButtonText>Close</ButtonText>
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}
