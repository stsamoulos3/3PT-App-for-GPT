import React from "react";
import { Image, View } from "react-native";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  size = "md",
  showText = false,
}) => {
  const logoSizes = {
    sm: { width: 32, height: 32 },
    md: { width: 40, height: 40 },
    lg: { width: 80, height: 40 },
  };

  const textSizes = {
    sm: "lg",
    md: "xl",
    lg: "2xl",
  } as const;

  return (
    <HStack className="items-center" space="sm">
      <Image
        source={require("@/assets/images/logo.png")}
        style={logoSizes[size]}
        resizeMode="contain"
      />
      {showText && (
        <Text size={textSizes[size]} className="font-bold text-primary-500">
          3PT Health
        </Text>
      )}
    </HStack>
  );
};
