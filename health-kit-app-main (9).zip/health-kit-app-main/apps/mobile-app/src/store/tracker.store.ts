import { HKWorkoutActivityType } from "@kingstinct/react-native-healthkit";
import { createJSONStorage, persist } from "zustand/middleware";
import { create } from "zustand";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface WorkoutTracker {
  type: HKWorkoutActivityType;
  startTime: Date;
  endTime: Date;
  calories: number;
  distance: number;
  steps: number;
  breaks: {
    startTime: Date;
    endTime: Date;
  }[];
  breakDurations: number;
  isPaused: boolean;
  isCompleted: boolean;
}

interface HeartRateDevice {
  id: string;
  name: string;
  bundleIdentifier: string;
  isConnected: boolean;
  lastDataTime?: Date;
}

interface TrackerStore {
  activeWorkout: WorkoutTracker | null;
  setActiveWorkout: (workout: WorkoutTracker | null) => void;

  // Heart rate device management
  selectedHeartRateDevice: HeartRateDevice | null;
  availableHeartRateDevices: HeartRateDevice[];
  isHeartRateDeviceDisconnected: boolean;

  setSelectedHeartRateDevice: (device: HeartRateDevice | null) => void;
  setAvailableHeartRateDevices: (devices: HeartRateDevice[]) => void;
  setIsHeartRateDeviceDisconnected: (disconnected: boolean) => void;
  updateDeviceConnectionStatus: (
    deviceId: string,
    isConnected: boolean
  ) => void;
}

const initialState: Omit<
  TrackerStore,
  | "setActiveWorkout"
  | "setSelectedHeartRateDevice"
  | "setAvailableHeartRateDevices"
  | "setIsHeartRateDeviceDisconnected"
  | "updateDeviceConnectionStatus"
> = {
  activeWorkout: null,
  selectedHeartRateDevice: null,
  availableHeartRateDevices: [],
  isHeartRateDeviceDisconnected: false,
};

const useTrackerStore = create<TrackerStore>()(
  persist(
    (set, get) => ({
      ...initialState,
      setActiveWorkout: (workout: WorkoutTracker | null) =>
        set({ activeWorkout: workout }),

      setSelectedHeartRateDevice: (device: HeartRateDevice | null) =>
        set({ selectedHeartRateDevice: device }),

      setAvailableHeartRateDevices: (devices: HeartRateDevice[]) =>
        set({ availableHeartRateDevices: devices }),

      setIsHeartRateDeviceDisconnected: (disconnected: boolean) =>
        set({ isHeartRateDeviceDisconnected: disconnected }),

      updateDeviceConnectionStatus: (deviceId: string, isConnected: boolean) =>
        set((state) => ({
          availableHeartRateDevices: state.availableHeartRateDevices.map(
            (device) =>
              device.id === deviceId
                ? {
                    ...device,
                    isConnected,
                    lastDataTime: isConnected
                      ? new Date()
                      : device.lastDataTime,
                  }
                : device
          ),
          selectedHeartRateDevice:
            state.selectedHeartRateDevice?.id === deviceId
              ? {
                  ...state.selectedHeartRateDevice,
                  isConnected,
                  lastDataTime: isConnected
                    ? new Date()
                    : state.selectedHeartRateDevice.lastDataTime,
                }
              : state.selectedHeartRateDevice,
        })),
    }),
    {
      name: "tracker-store",
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

export default useTrackerStore;
export type { HeartRateDevice };
