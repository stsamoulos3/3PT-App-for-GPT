import AsyncStorage from "@react-native-async-storage/async-storage";
import moment from "moment";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

interface GlobalStore {
  selectedDate: {
    startDate: Date;
    endDate: Date;
  };
  setSelectedDate: (selectedDate: { startDate: Date; endDate: Date }) => void;
  showActionsheet: boolean;
  setShowActionsheet: (showActionsheet: boolean) => void;
  keyboardDidShow: boolean;
  setKeyboardDidShow: (keyboardDidShow: boolean) => void;
  trackerStates: {
    isSaving: boolean;
    error: string | null;
  };
  setTrackerStates: (trackerStates: {
    isSaving: boolean;
    error: string | null;
  }) => void;
  apiCallStates: {
    isUpdatingUserPersonalInfo: boolean;
    isUpdatingUserSteps: boolean;
    isUpdatingUserHeartRate: boolean;
    isUpdatingUserWorkout: boolean;
    isUpdatingUserNutrition: boolean;
    isUpdatingUserVitalSigns: boolean;
    isUpdatingUserMobility: boolean;
    isUpdatingUserBodyMeasurements: boolean;
  };
  setApiCallStates: (apiCallStates: {
    isUpdatingUserPersonalInfo: boolean;
    isUpdatingUserSteps: boolean;
    isUpdatingUserHeartRate: boolean;
    isUpdatingUserWorkout: boolean;
    isUpdatingUserNutrition: boolean;
    isUpdatingUserVitalSigns: boolean;
    isUpdatingUserMobility: boolean;
    isUpdatingUserBodyMeasurements: boolean;
  }) => void;
}

const initialState: GlobalStore = {
  selectedDate: {
    startDate: moment().subtract(6, "days").toDate(),
    endDate: moment().toDate(),
  },
  setSelectedDate: () => {},
  showActionsheet: false,
  setShowActionsheet: () => {},
  keyboardDidShow: false,
  setKeyboardDidShow: () => {},
  trackerStates: {
    isSaving: false,
    error: null,
  },
  setTrackerStates: () => {},
  apiCallStates: {
    isUpdatingUserPersonalInfo: false,
    isUpdatingUserSteps: false,
    isUpdatingUserHeartRate: false,
    isUpdatingUserWorkout: false,
    isUpdatingUserNutrition: false,
    isUpdatingUserVitalSigns: false,
    isUpdatingUserMobility: false,
    isUpdatingUserBodyMeasurements: false,
  },
  setApiCallStates: () => {},
};

const useGlobalStore = create<GlobalStore>()(
  persist(
    (set) => ({
      ...initialState,
      setSelectedDate: (selectedDate) => set({ selectedDate }),
      setShowActionsheet: (showActionsheet) => set({ showActionsheet }),
      setKeyboardDidShow: (keyboardDidShow) => set({ keyboardDidShow }),
      setTrackerStates: (trackerStates) => set({ trackerStates }),
      setApiCallStates: (apiCallStates) => set({ apiCallStates }),
    }),
    {
      name: "global-store",
      storage: createJSONStorage(() => AsyncStorage),
      partialize(state) {
        const { selectedDate, ...rest } = state;
        return {
          ...rest,
        };
      },
      onRehydrateStorage(state) {
        return (state) => {
          if (state?.showActionsheet) {
            state.setShowActionsheet(false);
          }
          if (state?.keyboardDidShow) {
            state.setKeyboardDidShow(false);
          }
          if (state?.trackerStates) {
            state.setTrackerStates(initialState.trackerStates);
          }
          if (state?.apiCallStates) {
            state.setApiCallStates(initialState.apiCallStates);
          }

          state?.setSelectedDate({
            startDate: moment().startOf("day").subtract(6, "days").toDate(),
            endDate: moment().endOf("day").toDate(),
          });
        };
      },
    }
  )
);

export default useGlobalStore;
