import { type StreakData, UserService } from "@repo/core/services/UserService";
import { create } from "zustand";

interface StreakStore {
	streaks: StreakData | null;
	isLoading: boolean;
	error: string | null;
	fetchStreaks: (userId: string, accessToken: string) => Promise<void>;
	updateStreaks: (userId: string, accessToken: string) => Promise<void>;
	setStreaks: (streaks: StreakData) => void;
	clearError: () => void;
}

export const useStreakStore = create<StreakStore>((set, get) => ({
	streaks: null,
	isLoading: false,
	error: null,

	fetchStreaks: async (userId: string, accessToken: string) => {
		try {
			set({ isLoading: true, error: null });
			const response = await UserService.getUserStreaks(userId, accessToken);
			set({ streaks: response.streaks, isLoading: false });
		} catch (err) {
			set({
				error: err instanceof Error ? err.message : "Failed to fetch streaks",
				isLoading: false,
			});
		}
	},

	updateStreaks: async (userId: string, accessToken: string) => {
		try {
			set({ error: null });
			const response = await UserService.updateUserStreaks(userId, accessToken);
			set({ streaks: response.streaks });
		} catch (err) {
			set({
				error: err instanceof Error ? err.message : "Failed to update streaks",
			});
		}
	},

	setStreaks: (streaks: StreakData) => {
		set({ streaks });
	},

	clearError: () => {
		set({ error: null });
	},
}));
