-- AlterTable
ALTER TABLE "UserVo2Profile" ADD COLUMN     "hrRerIntercept" DOUBLE PRECISION,
ADD COLUMN     "hrRerSlope" DOUBLE PRECISION;
