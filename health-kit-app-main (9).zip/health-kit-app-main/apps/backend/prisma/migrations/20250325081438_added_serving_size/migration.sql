-- AlterTable
ALTER TABLE "Food" ADD COLUMN     "servingSize" TEXT;
