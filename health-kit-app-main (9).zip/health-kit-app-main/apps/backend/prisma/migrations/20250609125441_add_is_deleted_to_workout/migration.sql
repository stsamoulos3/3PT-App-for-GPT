-- AlterTable
ALTER TABLE "Workout" ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;
