import { prisma } from "./db/client";

/**
 * Test script to verify PNOE calculations match doctor's Excel
 * Expected results for HR=138:
 * - VO2 Method (Weir): 11.40 kcal/min
 * - EE Method (Direct): 11.31 kcal/min
 */

async function testCalculations(userId: string) {
  console.log("=== Testing PNOE Calculations ===\n");
  
  const testHR = 138;
  const testDuration = 1; // 1 minute for per-minute comparison
  
  // Get user's coefficients
  const [vo2Profile, eeCoefficient] = await Promise.all([
    prisma.userVo2Profile.findUnique({ where: { userId } }),
    prisma.userEeCoefficient.findUnique({ where: { userId } })
  ]);
  
  console.log("User Coefficients:");
  console.log("VO2 Profile:", vo2Profile ? {
    hrVo2Slope: vo2Profile.hrVo2Slope,
    hrVo2Intercept: vo2Profile.hrVo2Intercept,
    hrRerSlope: vo2Profile.hrRerSlope,
    hrRerIntercept: vo2Profile.hrRerIntercept
  } : "Not found");
  
  console.log("EE Coefficient:", eeCoefficient ? {
    hrMultiplier: eeCoefficient.hrMultiplier,
    hrEeIntercept: eeCoefficient.hrEeIntercept
  } : "Not found");
  
  console.log("\n=== Test Calculations for HR=" + testHR + " ===\n");
  
  // Test VO2 Method (Weir Equation)
  if (vo2Profile && vo2Profile.hrVo2Slope && vo2Profile.hrRerSlope) {
    const estimatedVo2 = vo2Profile.hrVo2Slope * testHR + (vo2Profile.hrVo2Intercept || 0);
    const estimatedRer = Math.max(0.7, Math.min(1.0, 
      vo2Profile.hrRerSlope * testHR + (vo2Profile.hrRerIntercept || 0.85)
    ));
    const vco2 = estimatedVo2 * estimatedRer;
    const weirCaloriesPerMin = ((estimatedVo2 * 3.9) + (vco2 * 1.1)) / 1000;
    
    console.log("VO2 Method (Weir Equation):");
    console.log(`  VO2 = ${testHR} × ${vo2Profile.hrVo2Slope} + ${vo2Profile.hrVo2Intercept} = ${estimatedVo2.toFixed(2)} ml/min`);
    console.log(`  RER = ${testHR} × ${vo2Profile.hrRerSlope} + ${vo2Profile.hrRerIntercept} = ${estimatedRer.toFixed(3)}`);
    console.log(`  VCO2 = ${estimatedVo2.toFixed(2)} × ${estimatedRer.toFixed(3)} = ${vco2.toFixed(2)} ml/min`);
    console.log(`  Weir: ((${estimatedVo2.toFixed(2)} × 3.9) + (${vco2.toFixed(2)} × 1.1)) / 1000 = ${weirCaloriesPerMin.toFixed(2)} kcal/min`);
    console.log(`  Expected: 11.40 kcal/min`);
    console.log(`  Difference: ${(weirCaloriesPerMin - 11.40).toFixed(2)} kcal/min\n`);
  }
  
  // Test EE Method (Direct Regression)
  if (eeCoefficient && eeCoefficient.hrEeIntercept) {
    const eeCaloriesPerMin = eeCoefficient.hrMultiplier * testHR + eeCoefficient.hrEeIntercept;
    
    console.log("EE Method (Direct Regression):");
    console.log(`  EE = ${testHR} × ${eeCoefficient.hrMultiplier.toFixed(6)} + ${eeCoefficient.hrEeIntercept.toFixed(6)}`);
    console.log(`  EE = ${eeCaloriesPerMin.toFixed(2)} kcal/min`);
    console.log(`  Expected: 11.31 kcal/min`);
    console.log(`  Difference: ${(eeCaloriesPerMin - 11.31).toFixed(2)} kcal/min\n`);
  }
  
  console.log("=== Comparison with Doctor's Excel ===");
  console.log("Doctor's values for HR=138:");
  console.log("  Model 1 (Weir): 11.40 kcal/min");
  console.log("  Model 2 (HR->EE): 11.31 kcal/min");
  console.log("  Model 3 (Personalized): 11.27 kcal/min");
}

// Run test
if (process.argv[2]) {
  testCalculations(process.argv[2])
    .then(() => {
      console.log("\nTest completed");
      process.exit(0);
    })
    .catch((error) => {
      console.error("Test failed:", error);
      process.exit(1);
    });
} else {
  console.log("Usage: bun run test-pnoe-calculations.ts <userId>");
  process.exit(1);
}