import { createRoute, z } from "@hono/zod-openapi";
import jsonContent from "../../helpers/json-content";
import {
	CreateWorkoutParams,
	CreateWorkoutResponse,
	DeleteWorkoutResponse,
	GetRecentWorkoutTypesParams,
	GetRecentWorkoutTypesResponse,
	GetWorkoutResponse,
	ListWorkoutParams,
	ListWorkoutResponse,
	UpdateWorkoutParams,
	UpdateWorkoutResponse,
} from "./models";

const listWorkoutRoute = createRoute({
	method: "get",
	path: "/",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		query: ListWorkoutParams,
	},
	responses: {
		200: jsonContent(ListWorkoutResponse, "List Workout Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Workout"],
});

const getWorkoutRoute = createRoute({
	method: "get",
	path: "/{id}",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: z.object({
			id: z.string(),
		}),
	},
	responses: {
		200: jsonContent(GetWorkoutResponse, "Get Workout Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Workout"],
});

const createWorkoutRoute = createRoute({
	method: "post",
	path: "/",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		body: jsonContent(CreateWorkoutParams, "Create Workout Request"),
	},
	responses: {
		200: jsonContent(CreateWorkoutResponse, "Create Workout Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Workout"],
});

const updateWorkoutRoute = createRoute({
	method: "put",
	path: "/{id}",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: z.object({
			id: z.string(),
		}),
		body: jsonContent(UpdateWorkoutParams, "Update Workout Request"),
	},
	responses: {
		200: jsonContent(UpdateWorkoutResponse, "Update Workout Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Workout"],
});

const deleteWorkoutRoute = createRoute({
	method: "delete",
	path: "/{hkId}",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: z.object({
			hkId: z.string({ description: "HK id of the workout" }),
		}),
	},
	responses: {
		200: jsonContent(DeleteWorkoutResponse, "Delete Workout Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Workout"],
});

const getRecentWorkoutTypesRoute = createRoute({
	method: "get",
	path: "/recent-types",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		query: GetRecentWorkoutTypesParams,
	},
	responses: {
		200: jsonContent(
			GetRecentWorkoutTypesResponse,
			"Get Recent Workout Types Response",
		),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Workout"],
});

const workoutRoutes = {
	listWorkoutRoute,
	getWorkoutRoute,
	createWorkoutRoute,
	updateWorkoutRoute,
	deleteWorkoutRoute,
	getRecentWorkoutTypesRoute,
};

export default workoutRoutes;

export type ListWorkoutRoute = typeof workoutRoutes.listWorkoutRoute;
export type GetWorkoutRoute = typeof workoutRoutes.getWorkoutRoute;
export type CreateWorkoutRoute = typeof workoutRoutes.createWorkoutRoute;
export type UpdateWorkoutRoute = typeof workoutRoutes.updateWorkoutRoute;
export type DeleteWorkoutRoute = typeof workoutRoutes.deleteWorkoutRoute;
export type GetRecentWorkoutTypesRoute =
	typeof workoutRoutes.getRecentWorkoutTypesRoute;
