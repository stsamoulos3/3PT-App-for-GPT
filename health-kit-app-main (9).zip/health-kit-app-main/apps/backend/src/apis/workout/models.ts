import { z } from "zod";

export const WorkoutSchema = z.object({
	id: z.string(),
	userId: z.string(),
	activityType: z.string(),
	startDate: z.coerce.date(),
	endDate: z.coerce.date(),
	totalDistanceMeters: z.number(),
	totalEnergyBurnedKcal: z.number(),
	workoutDurationSeconds: z.number(),
	averageHeartRateBPM: z.number().optional().nullable(),
	firstHeartRateTime: z.coerce.date().optional().nullable(),
	lastHeartRateTime: z.coerce.date().optional().nullable(),
	highestHeartRate: z.number().optional().nullable(),
	lowestHeartRate: z.number().optional().nullable(),
	hkId: z.string().optional().nullable(),
	createdAt: z.coerce.date(),
	updatedAt: z.coerce.date(),
	source: z.string().optional().nullable(),
	MODEL1: z.number().optional().nullable(),
	MODEL2: z.number().optional().nullable(),
	MODEL3: z.number().optional().nullable(),
	MODEL4: z.number().optional().nullable(),
});

export const ListWorkoutParams = z.object({
	page: z.coerce.number().optional().openapi("page", { default: 1 }),
	limit: z.coerce.number().optional().openapi("limit", { default: 10 }),
	filter: z.string().optional().openapi("filter"),
});

export const ListWorkoutResponse = z.object({
	data: z.array(WorkoutSchema),
	pagination: z.object({
		page: z.number(),
		limit: z.number(),
		total: z.number(),
	}),
});

export const GetWorkoutQuery = z.object({
	id: z.string(),
});

export const GetWorkoutResponse = WorkoutSchema;

export const CreateWorkoutParams = z.object({
	userId: z.string(),
	activityType: z.string(),
	startDate: z.coerce.date(),
	endDate: z.coerce.date(),
	totalDistanceMeters: z.number(),
	totalEnergyBurnedKcal: z.number(),
	workoutDurationSeconds: z.number(),
	averageHeartRateBPM: z.number().optional().nullable(),
	firstHeartRateTime: z.coerce.date().optional().nullable(),
	lastHeartRateTime: z.coerce.date().optional().nullable(),
	highestHeartRate: z.number().optional().nullable(),
	lowestHeartRate: z.number().optional().nullable(),
	hkId: z.string().optional().nullable(),
	source: z.string().optional().nullable(),
	MODEL1: z.number().optional().nullable(),
	MODEL2: z.number().optional().nullable(),
	MODEL3: z.number().optional().nullable(),
	MODEL4: z.number().optional().nullable(),
});

export const CreateWorkoutResponse = WorkoutSchema;

export const UpdateWorkoutParams = z.object({
	activityType: z.string().optional(),
	startDate: z.coerce.date().optional(),
	endDate: z.coerce.date().optional(),
	totalDistanceMeters: z.number().optional(),
	totalEnergyBurnedKcal: z.number().optional(),
	workoutDurationSeconds: z.number().optional(),
	averageHeartRateBPM: z.number().optional().nullable(),
	firstHeartRateTime: z.coerce.date().optional().nullable(),
	lastHeartRateTime: z.coerce.date().optional().nullable(),
	highestHeartRate: z.number().optional().nullable(),
	lowestHeartRate: z.number().optional().nullable(),
	hkId: z.string().optional().nullable(),
	source: z.string().optional().nullable(),
	MODEL1: z.number().optional().nullable(),
	MODEL2: z.number().optional().nullable(),
	MODEL3: z.number().optional().nullable(),
	MODEL4: z.number().optional().nullable(),
});

export const DeleteWorkoutParams = z.object({
	id: z.string(),
});

export const DeleteWorkoutResponse = z.object({
	message: z.string(),
});

export const UpdateWorkoutResponse = WorkoutSchema;

export const GetRecentWorkoutTypesParams = z.object({
	limit: z.coerce.number().optional().default(10),
});

export const GetRecentWorkoutTypesResponse = z.array(z.string());
