import type { AppRouteHandler } from "../../lib/types";
import type {
	CreateWorkoutRoute,
	DeleteWorkoutRoute,
	GetWorkoutRoute,
	ListWorkoutRoute,
	UpdateWorkoutRoute,
	GetRecentWorkoutTypesRoute,
} from "./routes";
import WorkoutService from "./service";
import AuthHelper from "../../helpers/auth";
import UserService from "../user/service";

const listWorkoutHandler: AppRouteHandler<ListWorkoutRoute> = async (c) => {
	const { page, limit, filter } = c.req.valid("query");

	const xApiKey = c.req.header("x-api-key");
	if (!xApiKey) {
		throw new Error("x-api-key header is required", {
			cause: "AUTHORIZATION_HEADER_REQUIRED",
		});
	}

	const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
		throw new Error("Invalid x-api-key header", {
			cause: "INVALID_API_KEY",
		});
	});

	try {
		return c.json(
			await WorkoutService.listWorkout(user.id, { page, limit, filter }),
			200,
		);
	} catch (error: any) {
		return c.json({ cause: error.cause }, 400);
	}
};

const getWorkoutHandler: AppRouteHandler<GetWorkoutRoute> = async (c) => {
	const { id } = c.req.valid("param");
	try {
		return c.json(await WorkoutService.getWorkout(id), 200);
	} catch (error: any) {
		return c.json({ cause: error.cause }, 400);
	}
};

const createWorkoutHandler: AppRouteHandler<CreateWorkoutRoute> = async (c) => {
	const params = c.req.valid("json");
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		const workout = await WorkoutService.createWorkout(user.id, params);

		// Update streaks after creating workout
		await UserService.updateUserStreaks(user.id);

		return c.json(workout, 200);
	} catch (error: any) {
		return c.json({ cause: error.cause }, 400);
	}
};

const updateWorkoutHandler: AppRouteHandler<UpdateWorkoutRoute> = async (c) => {
	const { id } = c.req.valid("param");
	const params = await c.req.json();

	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}

		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		const workout = await WorkoutService.updateWorkout(user.id, id, params);

		// Update streaks after updating workout
		await UserService.updateUserStreaks(user.id);

		return c.json(workout, 200);
	} catch (error: any) {
		return c.json({ cause: error.cause }, 400);
	}
};

const deleteWorkoutHandler: AppRouteHandler<DeleteWorkoutRoute> = async (c) => {
	const { hkId } = c.req.valid("param");

	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		const result = await WorkoutService.deleteWorkout(user.id, hkId);

		// Update streaks after deleting workout
		await UserService.updateUserStreaks(user.id);

		return c.json(result, 200);
	} catch (error: any) {
		return c.json({ cause: error.cause }, 400);
	}
};

const getRecentWorkoutTypesHandler: AppRouteHandler<
	GetRecentWorkoutTypesRoute
> = async (c) => {
	const { limit } = c.req.valid("query");

	console.log("limit", limit);

	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		const data = await WorkoutService.getRecentWorkoutTypes(user.id, 10);
		console.log("data", data);

		return c.json(data, 200);
	} catch (error: unknown) {
		console.log("error", error);
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const workoutHandlers = {
	listWorkoutHandler,
	getWorkoutHandler,
	createWorkoutHandler,
	updateWorkoutHandler,
	deleteWorkoutHandler,
	getRecentWorkoutTypesHandler,
};

export default workoutHandlers;
