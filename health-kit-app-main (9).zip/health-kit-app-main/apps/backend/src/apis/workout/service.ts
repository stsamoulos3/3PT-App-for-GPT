import type { z } from "zod";
import type {
	CreateWorkoutParams,
	CreateWorkoutResponse,
	GetWorkoutResponse,
	ListWorkoutParams,
	ListWorkoutResponse,
	UpdateWorkoutParams,
	UpdateWorkoutResponse,
} from "./models";
import { prisma } from "../../db/client";
import { WorkoutSource } from "../../../../../packages/core/types/entities/workout";

// biome-ignore lint/complexity/noStaticOnlyClass: <explanation>
export default class WorkoutService {
	static async listWorkout(
		userId: string,
		params: z.infer<typeof ListWorkoutParams>,
	): Promise<z.infer<typeof ListWorkoutResponse>> {
		const { page = 1, limit = 10000, filter } = params;

		const filterObject = filter ? JSON.parse(filter) : {};

		Object.assign(filterObject, {
			userId,
			isDeleted: false, // Only include non-deleted workouts
		});

		const [workoutResources, total] = await Promise.all([
			prisma.workout.findMany({
				where: filterObject,
				orderBy: {
					startDate: "desc",
				},
				skip: (page - 1) * limit,
				take: limit,
			}),
			prisma.workout.count({
				where: filterObject,
			}),
		]).catch((error: Error) => {
			throw new Error("Failed to list workouts", {
				cause: error.message,
			});
		});

		return {
			data: workoutResources,
			pagination: { page, limit, total },
		};
	}

	static async getWorkout(
		id: string,
	): Promise<z.infer<typeof GetWorkoutResponse>> {
		const workout = await prisma.workout.findFirst({
			where: {
				id,
				isDeleted: false, // Only return non-deleted workouts
			},
		});

		if (!workout) {
			throw new Error("Workout not found", {
				cause: "WORKOUT_NOT_FOUND",
			});
		}

		return workout;
	}

	static async createWorkout(
		userId: string,
		params: z.infer<typeof CreateWorkoutParams>,
	): Promise<z.infer<typeof CreateWorkoutResponse>> {
		const { hkId, ...rest } = params;

		if (!hkId) {
			throw new Error("hkId is required", {
				cause: "HK_ID_REQUIRED",
			});
		}

		const existingWorkout = await prisma.workout.findFirst({
			where: {
				hkId,
				userId,
			},
		});

		if (existingWorkout) {
			if (existingWorkout.source === WorkoutSource.HEALTHKIT) {
				const { hkId: _, ...rest } = params;

				if (!existingWorkout.hkId) {
					throw new Error("hkId is required", {
						cause: "HK_ID_REQUIRED",
					});
				}

				const updatedWorkout = await WorkoutService.updateWorkout(
					userId,
					existingWorkout.hkId,
					{
						...rest,
					},
				);
				return updatedWorkout;
			}

			return existingWorkout;
		}

		console.log("params", params);

		const workout = await prisma.workout
			.create({
				data: {
					...params,
					userId,
				},
			})
			.catch((error: Error) => {
				throw new Error("Failed to create workout", {
					cause: error.message,
				});
			});

		return workout;
	}

	static async updateWorkout(
		userId: string,
		id: string,
		params: z.infer<typeof UpdateWorkoutParams>,
	): Promise<z.infer<typeof UpdateWorkoutResponse>> {
		if (!id) {
			throw new Error("hkId is required", {
				cause: "HK_ID_REQUIRED",
			});
		}

		const updatedWorkout = await prisma.workout.update({
			where: { userId_hkId: { userId, hkId: id } },
			data: params,
		});

		return updatedWorkout;
	}

	static async findWorkoutByDate(
		userId: string,
		startDate: string,
		endDate: string,
	) {
		const steps = await prisma.workout.findFirst({
			where: {
				userId,
				startDate: startDate,
				endDate: endDate,
			},
		});

		return steps;
	}

	static async deleteWorkout(userId: string, hkId: string) {
		const workout = await prisma.workout.findFirst({
			where: {
				hkId,
				userId,
				isDeleted: false, // Only find non-deleted workouts
			},
		});

		if (!workout) {
			throw new Error("Workout not found", {
				cause: "WORKOUT_NOT_FOUND",
			});
		}

		// Soft delete by setting both isDeleted flag and deletedAt timestamp
		await prisma.workout.update({
			where: { id: workout.id },
			data: {
				isDeleted: true,
				deletedAt: new Date(),
			},
		});

		return { message: "Workout deleted successfully" };
	}

	static async getRecentWorkoutTypes(userId: string, limit: 10) {
		// Get recent distinct workout activity types
		const recentWorkouts = await prisma.workout.findMany({
			where: {
				userId,
				isDeleted: false, // Only include non-deleted workouts
			},
			select: { activityType: true, createdAt: true },
			orderBy: { createdAt: "desc" },
			distinct: ["activityType"],
			take: limit,
		});

		console.log("recentWorkouts", recentWorkouts);

		// Remove duplicates and get unique activity types
		const uniqueActivityTypes = Array.from(
			new Set(recentWorkouts.map((workout) => workout.activityType)),
		).slice(0, limit);

		return uniqueActivityTypes;
	}
}
