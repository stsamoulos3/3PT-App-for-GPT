import { createRouter } from "../../lib/create-app";
import workoutHandlers from "./handlers";
import workoutRoutes from "./routes";

const router = createRouter()
  .openapi(workoutRoutes.listWorkoutRoute, workoutHandlers.listWorkoutHandler)
  .openapi(
    workoutRoutes.getRecentWorkoutTypesRoute,
    workoutHandlers.getRecentWorkoutTypesHandler
  )
  .openapi(
    workoutRoutes.deleteWorkoutRoute,
    workoutHandlers.deleteWorkoutHandler
  )
  .openapi(workoutRoutes.getWorkoutRoute, workoutHandlers.getWorkoutHandler)
  .openapi(
    workoutRoutes.createWorkoutRoute,
    workoutHandlers.createWorkoutHandler
  )
  .openapi(
    workoutRoutes.updateWorkoutRoute,
    workoutHandlers.updateWorkoutHandler
  );

export default router;
