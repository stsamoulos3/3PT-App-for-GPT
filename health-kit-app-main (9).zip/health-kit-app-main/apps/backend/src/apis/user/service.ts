import type { z } from "zod";
import { prisma } from "../../db/client";
import AuthHelper from "../../helpers/auth";
import { generateSignedUrl } from "../../helpers/s3";
import type {
	CalculatePersonalizedCaloriesParams,
	CalculatePersonalizedCaloriesResponse,
	CreateUserParams,
	CreateUserResponse,
	GetPnoeDataStatusResponse,
	GetUserCoefficientsParams,
	GetUserCoefficientsResponse,
	GetUserFileSignedUrlResponse,
	GetUserFilesResponse,
	GetUserResponse,
	ListUserParams,
	ListUserResponse,
	ProcessPnoeDataResponse,
	UpdateUserParams,
	UpdateUserResponse,
} from "./models";
import PnoeProcessingService from "./pnoe-processing.service";

// biome-ignore lint/complexity/noStaticOnlyClass: <explanation>
export default class UserService {
	static async listUser(
		params: z.infer<typeof ListUserParams>,
	): Promise<z.infer<typeof ListUserResponse>> {
		const { page = 1, limit = 10, filter } = params;

		const filterObject = filter ? JSON.parse(filter) : {};

		const [userResources, total] = await Promise.all([
			prisma.user.findMany({
				where: filterObject,
				skip: (page - 1) * limit,
				take: limit,
			}),
			prisma.user.count({
				where: filterObject,
			}),
		]);

		return {
			data: userResources,
			pagination: { page, limit, total },
		};
	}

	static async findOne(
		userId: string,
	): Promise<z.infer<typeof GetUserResponse>> {
		const user = await prisma.user.findUnique({
			where: { id: userId },
		});

		if (!user) {
			throw new Error("User not found", { cause: "NOT_FOUND" });
		}

		return user;
	}

	static async createUser(
		params: z.infer<typeof CreateUserParams>,
	): Promise<z.infer<typeof CreateUserResponse>> {
		const user = await prisma.user.create({
			data: {
				...params,
				password: "",
			},
		});

		return user;
	}

	static async updateUser(
		userId: string,
		params: z.infer<typeof UpdateUserParams>,
	): Promise<z.infer<typeof UpdateUserResponse>> {
		const user = await prisma.user.update({
			where: { id: userId },
			data: params,
		});

		return user;
	}

	// Streak calculation methods
	static async calculateWorkoutStreak(userId: string): Promise<{
		currentStreak: number;
		longestStreak: number;
		lastWorkoutDate: Date | null;
	}> {
		// Get all workouts for the user, ordered by date
		const workouts = await prisma.workout.findMany({
			where: {
				userId,
				isDeleted: false,
			},
			select: {
				startDate: true,
			},
			orderBy: {
				startDate: "desc",
			},
		});

		if (workouts.length === 0) {
			return {
				currentStreak: 0,
				longestStreak: 0,
				lastWorkoutDate: null,
			};
		}

		const workoutDates = workouts.map((w) => new Date(w.startDate));
		const uniqueDates = [...new Set(workoutDates.map((d) => d.toDateString()))];

		// Calculate current streak
		let currentStreak = 0;
		let longestStreak = 0;
		let tempStreak = 0;

		const today = new Date();
		const yesterday = new Date(today);
		yesterday.setDate(yesterday.getDate() - 1);

		// Check if user worked out today or yesterday to start current streak
		const hasRecentWorkout = uniqueDates.some((dateStr) => {
			const date = new Date(dateStr);
			return (
				date.toDateString() === today.toDateString() ||
				date.toDateString() === yesterday.toDateString()
			);
		});

		if (hasRecentWorkout) {
			// Calculate current streak from today backwards
			const checkDate = new Date(today);
			while (true) {
				const dateStr = checkDate.toDateString();
				if (uniqueDates.includes(dateStr)) {
					currentStreak++;
					tempStreak++;
					checkDate.setDate(checkDate.getDate() - 1);
				} else {
					break;
				}
			}
		}

		// Calculate longest streak
		const sortedDates = uniqueDates
			.map((d) => new Date(d))
			.sort((a, b) => a.getTime() - b.getTime());

		let currentLongestStreak = 0;
		let previousDate: Date | null = null;

		for (const date of sortedDates) {
			if (previousDate) {
				const diffDays = Math.floor(
					(date.getTime() - previousDate.getTime()) / (1000 * 60 * 60 * 24),
				);
				if (diffDays === 1) {
					currentLongestStreak++;
				} else {
					longestStreak = Math.max(longestStreak, currentLongestStreak + 1);
					currentLongestStreak = 0;
				}
			} else {
				currentLongestStreak = 1;
			}
			previousDate = date;
		}

		longestStreak = Math.max(longestStreak, currentLongestStreak);

		return {
			currentStreak,
			longestStreak,
			lastWorkoutDate: workoutDates[0],
		};
	}

	static async calculateFoodStreak(userId: string): Promise<{
		currentStreak: number;
		longestStreak: number;
		lastFoodLogDate: Date | null;
	}> {
		// Get all food logs for the user, ordered by date
		const foodLogs = await prisma.foodLog.findMany({
			where: {
				userId,
			},
			select: {
				date: true,
			},
			orderBy: {
				date: "desc",
			},
		});

		if (foodLogs.length === 0) {
			return {
				currentStreak: 0,
				longestStreak: 0,
				lastFoodLogDate: null,
			};
		}

		const foodLogDates = foodLogs.map((f) => new Date(f.date));
		const uniqueDates = [...new Set(foodLogDates.map((d) => d.toDateString()))];

		// Calculate current streak
		let currentStreak = 0;
		let longestStreak = 0;

		const today = new Date();
		const yesterday = new Date(today);
		yesterday.setDate(yesterday.getDate() - 1);

		// Check if user logged food today or yesterday to start current streak
		const hasRecentFoodLog = uniqueDates.some((dateStr) => {
			const date = new Date(dateStr);
			return (
				date.toDateString() === today.toDateString() ||
				date.toDateString() === yesterday.toDateString()
			);
		});

		if (hasRecentFoodLog) {
			// Calculate current streak from today backwards
			const checkDate = new Date(today);
			while (true) {
				const dateStr = checkDate.toDateString();
				if (uniqueDates.includes(dateStr)) {
					currentStreak++;
					checkDate.setDate(checkDate.getDate() - 1);
				} else {
					break;
				}
			}
		}

		// Calculate longest streak
		const sortedDates = uniqueDates
			.map((d) => new Date(d))
			.sort((a, b) => a.getTime() - b.getTime());

		let currentLongestStreak = 0;
		let previousDate: Date | null = null;

		for (const date of sortedDates) {
			if (previousDate) {
				const diffDays = Math.floor(
					(date.getTime() - previousDate.getTime()) / (1000 * 60 * 60 * 24),
				);
				if (diffDays === 1) {
					currentLongestStreak++;
				} else {
					longestStreak = Math.max(longestStreak, currentLongestStreak + 1);
					currentLongestStreak = 0;
				}
			} else {
				currentLongestStreak = 1;
			}
			previousDate = date;
		}

		longestStreak = Math.max(longestStreak, currentLongestStreak);

		return {
			currentStreak,
			longestStreak,
			lastFoodLogDate: foodLogDates[0],
		};
	}

	static async updateUserStreaks(userId: string): Promise<void> {
		const [workoutStreak, foodStreak] = await Promise.all([
			UserService.calculateWorkoutStreak(userId),
			UserService.calculateFoodStreak(userId),
		]);

		await prisma.user.update({
			where: { id: userId },
			data: {
				currentWorkoutStreak: workoutStreak.currentStreak,
				longestWorkoutStreak: Math.max(
					workoutStreak.longestStreak,
					workoutStreak.currentStreak,
				),
				currentFoodStreak: foodStreak.currentStreak,
				longestFoodStreak: Math.max(
					foodStreak.longestStreak,
					foodStreak.currentStreak,
				),
				lastWorkoutDate: workoutStreak.lastWorkoutDate,
				lastFoodLogDate: foodStreak.lastFoodLogDate,
				lastActiveAt: new Date(),
			},
		});
	}

	static async updateLastActive(userId: string): Promise<void> {
		await prisma.user.update({
			where: { id: userId },
			data: {
				lastActiveAt: new Date(),
			},
		});
	}

	static async getUserFiles(
		userId: string,
	): Promise<z.infer<typeof GetUserFilesResponse>> {
		const files = await prisma.userFile.findMany({
			where: { userId },
			orderBy: { createdAt: "desc" },
		});

		return {
			files: files.map((file) => ({
				id: file.id,
				fileName: file.fileName,
				filePath: file.filePath,
				fileSize: file.fileSize,
				mimeType: file.mimeType,
				description: file.description,
				uploadedBy: file.uploadedBy,
				createdAt: file.createdAt,
				updatedAt: file.updatedAt,
			})),
		};
	}

	static async generateUserFileSignedUrl(
		userId: string,
		fileId: string,
		expiresIn = 3600,
	): Promise<z.infer<typeof GetUserFileSignedUrlResponse>> {
		// Find the file and verify ownership
		const file = await prisma.userFile.findUnique({
			where: { id: fileId },
		});

		if (!file) {
			throw new Error("File not found");
		}

		if (file.userId !== userId) {
			throw new Error("Access denied");
		}

		// Generate signed URL
		const signedUrl = await generateSignedUrl(file.filePath, expiresIn);

		// Calculate expiration time
		const expiresAt = new Date(Date.now() + expiresIn * 1000).toISOString();

		return {
			signedUrl,
			expiresAt,
		};
	}

	// PNOE Data Processing Methods

	static async processPnoeData(
		userId: string,
	): Promise<z.infer<typeof ProcessPnoeDataResponse>> {
		try {
			await PnoeProcessingService.processPnoeData(userId);

			return {
				success: true,
				message: "PNOE data processed successfully",
				processedAt: new Date(),
			};
		} catch (error) {
			console.error(`Error processing PNOE data for user ${userId}:`, error);
			throw new Error("Failed to process PNOE data", {
				cause: "PROCESSING_ERROR",
			});
		}
	}

	static async getUserCoefficients(
		userId: string,
	): Promise<z.infer<typeof GetUserCoefficientsResponse>> {
		try {
			const coefficients =
				await PnoeProcessingService.getUserCoefficients(userId);
			return {
				...coefficients,
				calorieCountingMethod:
					coefficients?.user.calorieCountingMethod ?? "MODEL4",
			} as z.infer<typeof GetUserCoefficientsResponse>;
		} catch (error) {
			console.error(`Error getting coefficients for user ${userId}:`, error);
			throw new Error("Failed to get user coefficients", {
				cause: "NOT_FOUND",
			});
		}
	}

	static async getPnoeDataStatus(
		userId: string,
	): Promise<z.infer<typeof GetPnoeDataStatusResponse>> {
		try {
			const hasPnoeData = await PnoeProcessingService.userHasPnoeData(userId);

			// Get available methods based on what data exists
			const availableMethods: Array<"MODEL1" | "MODEL2" | "MODEL3" | "MODEL4"> =
				[];

			let lastProcessedAt: Date | null = null;

			if (hasPnoeData) {
				const userCalProfile = await prisma.userCalProfile.findFirst({
					where: { userId },
				});

				if (
					userCalProfile?.hrVo2Slope &&
					userCalProfile.hrVo2Intercept &&
					userCalProfile.hrRerIntercept &&
					userCalProfile.hrRerIntercept
				)
					availableMethods.push("MODEL1");

				if (userCalProfile?.hrEeSlope && userCalProfile?.hrEeIntercept)
					availableMethods.push("MODEL2");

				if (userCalProfile?.o2RerSlope && userCalProfile.o2RerIntercept)
					availableMethods.push("MODEL3");

				availableMethods.push("MODEL4");

				lastProcessedAt = userCalProfile?.updatedAt ?? null;
			}

			// Get last processed date (using the most recent created date from any coefficient table)

			return {
				hasPnoeData,
				lastProcessedAt,
				availableMethods,
			};
		} catch (error) {
			console.error(`Error getting PNOE status for user ${userId}:`, error);
			throw new Error("Failed to get PNOE data status", {
				cause: "STATUS_ERROR",
			});
		}
	}
}
