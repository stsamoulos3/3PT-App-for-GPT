import Papa from "papaparse";
import { prisma } from "../../db/client";
import { generateSignedUrl } from "../../helpers/s3";

// Interface for raw PNOE CSV data
interface PnoeDataRow {
	"T(sec)": number;
	PHASE: string;
	"HR(bpm)": number;
	"VO2(ml/min)": number;
	"VCO2(ml/min)": number;
	RER: number;
	"VE(l/min)": number;
	FEO2: number;
	FECO2: number;
	FETO2: number;
	FETCO2: number;
	"PETO2 (mmHg)": number;
	"PETCO2(mmHg)": number;
	FIO2: number;
	FICO2: number;
	"VT(l)": number;
	"BF(bpm)": number;
	"EE(kcal/day)": number;
	"EE(kcal/min)": number;
	"CARBS(kcal)": number;
	"CARBS(%)": number;
	"FAT(kcal)": number;
	"FAT(%)": number;
	MET: number;
	"CUMULATIVE EE(kcal)": number;
	"BP(kPa)": number;
	Watts: number;
	Speed: number;
}

// Interface for VO2 Master CSV data
interface Vo2MasterDataRow {
	Time: number;
	VO2: number;
	HR: number;
	Rf: number;
	Tv: number;
	Ve: number;
	EqO2: number;
	FeO2: number;
	Pressure: number;
	Temp: number;
	HUM: number;
	RR: number;
	Calorie: number;
	HRV: number;
}

// biome-ignore lint/complexity/noStaticOnlyClass: We want this
export default class PnoeProcessingService {
	/**
	 * Process PNOE CSV data for a user and store coefficient tables
	 */
	static async processPnoeData(userId: string): Promise<void> {
		console.log(`Starting PNOE data processing for user ${userId}`);
		try {
			// First, find the user's pnoe.csv file
			console.log(`Looking for pnoe.csv file for user ${userId}`);
			const file = await prisma.userFile.findFirst({
				where: {
					OR: [
						{
							userId,
							fileName: "pnoe.csv",
						},
						{
							userId,
							fileName: "vo2_master.csv",
						},
					],
				},
				orderBy: {
					createdAt: "desc",
				},
			});

			if (!file) {
				await prisma.user.update({
					where: { id: userId },
					data: { calorieCountingMethod: "MODEL4" },
				});
				console.log(
					`Neither PNOE CSV nor VO2 Master CSV file found for user ${userId}`,
				);
				throw new Error("No PNOE or VO2 Master CSV file found for user");
			}

			// Clean existing coefficient data for the user
			console.log(`Cleaning existing coefficient data for user ${userId}`);
			await PnoeProcessingService.cleanExistingData(userId);
			console.log(`Successfully cleaned existing data for user ${userId}`);

			// Process PNOE data if available
			if (file.fileName === "pnoe.csv") {
				console.log(
					`Found PNOE file for user ${userId} at path: ${file.filePath} uploaded by ${file.uploadedBy} at ${file.createdAt}`,
				);

				// Get signed URL to download the file
				console.log(`Generating signed URL for PNOE file for user ${userId}`);
				const signedUrl = await generateSignedUrl(file.filePath, 3600);
				console.log(`Successfully generated signed URL for user ${userId}`);

				// Download and parse the CSV
				console.log(`Downloading PNOE CSV file for user ${userId}`);
				const response = await fetch(signedUrl);
				if (!response.ok) {
					console.log(
						`Failed to download PNOE CSV file for user ${userId}. Status: ${response.status}`,
					);
					throw new Error("Failed to download PNOE CSV file");
				}

				console.log(`Successfully downloaded PNOE CSV file for user ${userId}`);
				const csvContent = await response.text();
				console.log(
					`CSV content length: ${csvContent.length} characters for user ${userId}`,
				);

				console.log(`Parsing PNOE CSV data for user ${userId}`);
				const pnoeData = PnoeProcessingService.parsePnoeCsv(csvContent);
				console.log(`Parsed ${pnoeData.length} data rows for user ${userId}`);

				if (pnoeData.length === 0) {
					console.log(`No valid data found in PNOE CSV for user ${userId}`);
					throw new Error("No valid data found in PNOE CSV");
				}

				// Process data for each calculation method
				console.log(`Processing coefficient data for user ${userId}`);
				await Promise.all([
					PnoeProcessingService.processCalProfile(userId, pnoeData),
				]);
				console.log(
					`Successfully processed all coefficient types for user ${userId}`,
				);

				// Set default calorie counting method to MODEL3 for PNOE
				console.log(
					`Setting default calorie counting method to MODEL3 for PNOE user ${userId}`,
				);
				await prisma.user.update({
					where: { id: userId },
					data: { calorieCountingMethod: "MODEL3" },
				});
			}

			// Process VO2 Master data if available (and no PNOE data)
			if (file.fileName === "vo2_master.csv") {
				console.log(
					`Found VO2 Master file for user ${userId} at path: ${file.filePath} uploaded by ${file.uploadedBy} at ${file.createdAt}`,
				);

				// Get signed URL to download the file
				console.log(
					`Generating signed URL for VO2 Master file for user ${userId}`,
				);
				const signedUrl = await generateSignedUrl(file.filePath, 3600);
				console.log(`Successfully generated signed URL for user ${userId}`);

				// Download and parse the CSV
				console.log(`Downloading VO2 Master CSV file for user ${userId}`);
				const response = await fetch(signedUrl);
				if (!response.ok) {
					console.log(
						`Failed to download VO2 Master CSV file for user ${userId}. Status: ${response.status}`,
					);
					throw new Error("Failed to download VO2 Master CSV file");
				}

				console.log(
					`Successfully downloaded VO2 Master CSV file for user ${userId}`,
				);
				const csvContent = await response.text();
				console.log(
					`CSV content length: ${csvContent.length} characters for user ${userId}`,
				);

				console.log(`Parsing VO2 Master CSV data for user ${userId}`);
				const vo2MasterData =
					PnoeProcessingService.parseVo2MasterCsv(csvContent);
				console.log(
					`Parsed ${vo2MasterData.length} data rows for user ${userId}`,
				);

				if (vo2MasterData.length === 0) {
					console.log(
						`No valid data found in VO2 Master CSV for user ${userId}`,
					);
					throw new Error("No valid data found in VO2 Master CSV");
				}

				// Process VO2 Master data
				console.log(
					`Processing VO2 Master coefficient data for user ${userId}`,
				);
				await PnoeProcessingService.processVo2MasterData(userId, vo2MasterData);
				console.log(
					`Successfully processed VO2 Master coefficients for user ${userId}`,
				);

				// Set default calorie counting method to MODEL2 for VO2 Master
				console.log(
					`Setting default calorie counting method to MODEL2 for VO2 Master user ${userId}`,
				);
				await prisma.user.update({
					where: { id: userId },
					data: { calorieCountingMethod: "MODEL2" },
				});
			}

			console.log(`Successfully processed metabolic data for user ${userId}`);
		} catch (error) {
			console.error(
				`Error processing metabolic data for user ${userId}:`,
				error,
			);
			throw error;
		}
	}

	/**
	 * Detect CSV delimiter
	 */
	private static detectDelimiter(line: string): string {
		const delimiters = [",", ";", "\t", "|"];
		let maxDelimiter = ",";
		let maxCount = 0;

		for (const delimiter of delimiters) {
			const count = line.split(delimiter).length;
			if (count > maxCount) {
				maxCount = count;
				maxDelimiter = delimiter;
			}
		}

		return maxDelimiter;
	}

	/**
	 * Parse CSV content into typed data rows
	 */
	private static parsePnoeCsv(csvContent: string): PnoeDataRow[] {
		console.log("Starting CSV parsing");
		const lines = csvContent.trim().split("\n");
		console.log(`CSV has ${lines.length} lines`);

		if (lines.length < 2) {
			console.log("CSV file has insufficient lines");
			throw new Error("CSV file must have at least a header and one data row");
		}

		const delimiter = PnoeProcessingService.detectDelimiter(lines[1]);

		console.log(delimiter);

		const headers = lines[0].split(delimiter).map((h) => h.trim());
		console.log(`CSV headers: ${headers.join(", ")}`);
		console.log(`Found ${headers.length} headers`);

		const result = Papa.parse<PnoeDataRow>(csvContent, {
			dynamicTyping: true,
			header: true,
			skipEmptyLines: true,
		});

		console.log(
			`CSV parsing complete. Total valid rows: ${result.data.length}`,
		);
		return result.data;
	}

	/**
	 * Parse VO2 Master CSV content into typed data rows
	 */
	private static parseVo2MasterCsv(csvContent: string): Vo2MasterDataRow[] {
		console.log("Starting VO2 Master CSV parsing");
		const lines = csvContent.trim().split("\n");
		console.log(`CSV has ${lines.length} lines`);

		if (lines.length < 2) {
			console.log("CSV file has insufficient lines");
			throw new Error("CSV file must have at least a header and one data row");
		}

		const delimiter = PnoeProcessingService.detectDelimiter(lines[1]);

		console.log(delimiter);

		const headers = lines[0].split(delimiter).map((h) => h.trim());
		console.log(`CSV headers: ${headers.join(", ")}`);
		console.log(`Found ${headers.length} headers`);

		const result = Papa.parse<Vo2MasterDataRow>(csvContent, {
			dynamicTyping: true,
			header: true,
			skipEmptyLines: true,
		});

		console.log(
			`VO2 Master CSV parsing complete. Total valid rows: ${result.data.length}`,
		);
		return result.data;
	}

	/**
	 * Clean existing coefficient data for a user
	 */
	private static async cleanExistingData(userId: string): Promise<void> {
		await Promise.all([
			prisma.userCalProfile.deleteMany({ where: { userId } }),
		]);
	}

	/**
	 * Process Cal profile and regression coefficients
	 */
	private static async processCalProfile(
		userId: string,
		data: PnoeDataRow[],
	): Promise<void> {
		const hrValues = data
			.map((row) => row["HR(bpm)"])
			.map((str: string | number) =>
				typeof str === "string" ? Number(str.replace(",", "")) : str,
			);
		const vo2Values = data
			.map((row) => row["VO2(ml/min)"])
			.map((str: string | number) =>
				typeof str === "string" ? Number(str.replace(",", "")) : str,
			);
		const rerValues = data
			.map((row) => row["RER"])
			.map((str: string | number) =>
				typeof str === "string" ? Number(str.replace(",", "")) : str,
			);
		const eeValues = data
			.map((row) => row["EE(kcal/min)"])
			.map((str: string | number) =>
				typeof str === "string" ? Number(str.replace(",", "")) : str,
			);

		if (hrValues.length === 0 || vo2Values.length === 0) return;

		// Calculate VO2 max (highest value)
		const estimatedVo2Max = Math.max(...vo2Values);

		// Calculate resting metabolic rate (lowest EE value)
		const restingMetabolicRate =
			eeValues.length > 0 ? Math.min(...eeValues) : null;

		// Simple linear regression for HR -> VO2 relationship
		const vo2Regression = PnoeProcessingService.calculateLinearRegression(
			hrValues,
			vo2Values,
		);

		// Calculate HR -> RER regression for Weir equation
		let rerRegression = { slope: 0, intercept: 0.85, r2: 0 }; // Default RER if no data
		if (rerValues.length > 0 && rerValues.length === hrValues.length) {
			rerRegression = PnoeProcessingService.calculateLinearRegression(
				hrValues,
				rerValues,
			);
		}

		// Calculate HR -> EE regression
		let eeRegression = { slope: 0, intercept: 0.85, r2: 0 };
		console.log(eeValues.length, hrValues.length);

		if (eeValues.length > 0 && eeValues.length === hrValues.length) {
			eeRegression = PnoeProcessingService.calculateLinearRegression(
				hrValues,
				eeValues,
			);
		}

		// Calculate O2 vs RER
		let o2Regression = { slope: 0, intercept: 0.85, r2: 0 };
		if (rerValues.length > 0 && rerValues.length === hrValues.length) {
			o2Regression = PnoeProcessingService.calculateLinearRegression(
				rerValues,
				eeValues.map((item, index) => (item * 1000) / vo2Values[index]),
			);
		}

		console.log("HR to VO2 SLOPE: ", vo2Regression.slope);
		console.log("HR to RER SLOPE: ", rerRegression.slope);
		console.log("HR to VO2 INTERCEPT: ", vo2Regression.intercept);
		console.log("HR to RER INTERCEPT: ", rerRegression.intercept);
		console.log("HR to EE SLOPE", eeRegression.slope);
		console.log("HR to EE INTERCEPT", eeRegression.intercept);
		console.log("O2 vs RER SLOPE", o2Regression.slope);
		console.log("O2 vs RER INTERCEPT", o2Regression.intercept);

		const existingProfile = await prisma.userCalProfile.findUnique({
			where: { userId },
		});

		if (existingProfile) {
			// Update existing profile with VO2 Master data
			await prisma.userCalProfile.update({
				where: { userId },
				data: {
					vo2EfficiencyCoefficient: vo2Regression.slope,
					hrVo2Slope: vo2Regression.slope,
					hrVo2Intercept: vo2Regression.intercept,
					hrRerSlope: rerRegression.slope,
					hrRerIntercept: rerRegression.intercept,
					hrEeSlope: eeRegression.slope,
					hrEeIntercept: eeRegression.intercept,
					o2RerSlope: o2Regression.slope,
					o2RerIntercept: o2Regression.intercept,
				},
			});
		} else {
			// Create new profile with VO2 Master data only
			await prisma.userCalProfile.create({
				data: {
					userId,
					vo2EfficiencyCoefficient: vo2Regression.slope,
					hrVo2Slope: vo2Regression.slope,
					hrVo2Intercept: vo2Regression.intercept,
					hrRerSlope: rerRegression.slope,
					hrRerIntercept: rerRegression.intercept,
					hrEeSlope: eeRegression.slope,
					hrEeIntercept: eeRegression.intercept,
					o2RerSlope: o2Regression.slope,
					o2RerIntercept: o2Regression.intercept,
					estimatedVo2Max: estimatedVo2Max,
				},
			});
		}
	}

	/**
	 * Process VO2 Master data for HR-Calorie coefficients
	 */
	private static async processVo2MasterData(
		userId: string,
		data: Vo2MasterDataRow[],
	): Promise<void> {
		// Extract HR and Calorie values
		const hrValues = data
			.map((row) => row.HR)
			.map((val: string | number) =>
				typeof val === "string" ? Number(val.replace(",", "")) : val,
			)
			.filter((val: number) => !Number.isNaN(val) && val > 0);

		// Convert Calorie to kcal/min (assuming the values are kcal/hour)
		const calorieValues = data
			.map((row) => row.Calorie)
			.map((val: string | number) =>
				typeof val === "string" ? Number(val.replace(",", "")) : val,
			)
			.filter((val: number) => !Number.isNaN(val) && val > 0)
			.map((val) => val / 60); // Convert to kcal/min

		if (hrValues.length === 0 || calorieValues.length === 0) {
			console.log("No valid HR or Calorie data found in VO2 Master CSV");
			return;
		}

		// Ensure we have the same number of HR and Calorie values
		const minLength = Math.min(hrValues.length, calorieValues.length);
		const hrValuesFiltered = hrValues.slice(0, minLength);
		const calorieValuesFiltered = calorieValues.slice(0, minLength);

		// Calculate HR -> EE (Energy Expenditure) regression
		const eeRegression = PnoeProcessingService.calculateLinearRegression(
			hrValuesFiltered,
			calorieValuesFiltered,
		);

		console.log("VO2 Master HR to EE SLOPE", eeRegression.slope);
		console.log("VO2 Master HR to EE INTERCEPT", eeRegression.intercept);

		// Calculate resting metabolic rate (lowest calorie value)
		const restingMetabolicRate = Math.min(...calorieValuesFiltered);

		// For VO2 Master, we'll only update the HR-EE coefficients
		// Check if user already has a profile
		const existingProfile = await prisma.userCalProfile.findUnique({
			where: { userId },
		});

		if (existingProfile) {
			// Update existing profile with VO2 Master data
			await prisma.userCalProfile.update({
				where: { userId },
				data: {
					hrEeSlope: eeRegression.slope,
					hrEeIntercept: eeRegression.intercept,
					restingMetabolicRate: restingMetabolicRate,
				},
			});
		} else {
			// Create new profile with VO2 Master data only
			await prisma.userCalProfile.create({
				data: {
					userId,
					hrEeSlope: eeRegression.slope,
					hrEeIntercept: eeRegression.intercept,
					restingMetabolicRate: restingMetabolicRate,
					// Set default values for other fields
					estimatedVo2Max: 0,
					vo2EfficiencyCoefficient: 0,
					hrVo2Slope: 0,
					hrVo2Intercept: 0,
					hrRerSlope: 0,
					hrRerIntercept: 0,
					o2RerSlope: 0,
					o2RerIntercept: 0,
				},
			});
		}
	}

	/**
	 * Calculate linear regression coefficients
	 */
	private static calculateLinearRegression(
		xValues: number[],
		yValues: number[],
	): {
		slope: number;
		intercept: number;
		r2: number;
	} {
		const n = Math.min(xValues.length, yValues.length);
		if (n === 0) return { slope: 0, intercept: 0, r2: 0 };

		const xMean = xValues.slice(0, n).reduce((a, b) => a + b, 0) / n;
		const yMean = yValues.slice(0, n).reduce((a, b) => a + b, 0) / n;

		let numerator = 0;
		let denominator = 0;
		let totalSumOfSquares = 0;

		for (let i = 0; i < n; i++) {
			const xDiff = xValues[i] - xMean;
			const yDiff = yValues[i] - yMean;
			numerator += xDiff * yDiff;
			denominator += xDiff * xDiff;
			totalSumOfSquares += yDiff * yDiff;
		}

		const slope = denominator === 0 ? 0 : numerator / denominator;
		const intercept = yMean - slope * xMean;

		// Calculate R-squared
		let residualSumOfSquares = 0;
		for (let i = 0; i < n; i++) {
			const predicted = slope * xValues[i] + intercept;
			const residual = yValues[i] - predicted;
			residualSumOfSquares += residual * residual;
		}

		const r2 =
			totalSumOfSquares === 0
				? 0
				: 1 - residualSumOfSquares / totalSumOfSquares;

		return { slope, intercept, r2 };
	}

	/**
	 * Get user's processed PNOE data for a specific calculation method
	 */
	static async getUserCoefficients(userId: string) {
		return await prisma.userCalProfile.findUnique({
			where: { userId },
			include: {
				user: {
					select: {
						calorieCountingMethod: true,
					},
				},
			},
		});
	}

	/**
	 * Check if user has processed PNOE data
	 */
	static async userHasPnoeData(userId: string): Promise<boolean> {
		const calProfile = await prisma.userCalProfile.findUnique({
			where: { userId },
		});

		if (calProfile) {
			return true;
		}

		return false;
	}
}
