import { createRouter } from "../../lib/create-app";
import userHandlers from "./handlers";
import userRoutes from "./routes";

const router = createRouter()
	.openapi(userRoutes.listUserRoute, userHandlers.listUserHandler)
	.openapi(
		userRoutes.getUserFromTokenRoute,
		userHandlers.getUserFromTokenHandler,
	)
	.openapi(userRoutes.createUserRoute, userHandlers.createUserHandler)
	.openapi(userRoutes.updateUserRoute, userHandlers.updateUserHandler)
	.openapi(userRoutes.getUserStreaksRoute, userHandlers.getUserStreaksHandler)
	.openapi(
		userRoutes.updateUserStreaksRoute,
		userHandlers.updateUserStreaksHandler,
	)
	.openapi(userRoutes.getUserFilesRoute, userHandlers.getUserFilesHandler)
	.openapi(
		userRoutes.getUserFileSignedUrlRoute,
		userHandlers.getUserFileSignedUrlHandler,
	)
	.openapi(userRoutes.processPnoeDataRoute, userHandlers.processPnoeDataHandler)
	.openapi(
		userRoutes.getUserCoefficientsRoute,
		userHandlers.getUserCoefficientsHandler,
	)
	.openapi(
		userRoutes.getPnoeDataStatusRoute,
		userHandlers.getPnoeDataStatusHandler,
	)
	.openapi(userRoutes.getUserRoute, userHandlers.getUserHandler);

export default router;
