import { createRoute, z } from "@hono/zod-openapi";
import errorContent from "../../helpers/error-content";
import jsonContent from "../../helpers/json-content";
import {
	CalculatePersonalizedCaloriesParams,
	CalculatePersonalizedCaloriesResponse,
	CreateUserParams,
	CreateUserResponse,
	GetPnoeDataStatusResponse,
	GetUserCoefficientsParams,
	GetUserCoefficientsResponse,
	GetUserFileSignedUrlParams,
	GetUserFileSignedUrlQuery,
	GetUserFileSignedUrlResponse,
	GetUserFilesResponse,
	GetUserResponse,
	ListUserParams,
	ListUserResponse,
	ProcessPnoeDataResponse,
	UpdateUserParams,
	UpdateUserResponse,
	UserStreaksResponse,
} from "./models";

const listUserRoute = createRoute({
	method: "get",
	path: "/",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		query: ListUserParams,
	},
	responses: {
		200: jsonContent(ListUserResponse, "List User Response"),
		400: errorContent,
	},
	tags: ["User"],
});

const getUserRoute = createRoute({
	method: "get",
	path: "/{id}",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: z.object({
			id: z.string(),
		}),
	},
	responses: {
		200: jsonContent(GetUserResponse, "Get User Response"),
		400: errorContent,
		404: errorContent,
	},
	tags: ["User"],
});

const getUserFromTokenRoute = createRoute({
	method: "get",
	path: "/me",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
	},
	responses: {
		200: jsonContent(GetUserResponse, "Get User Response"),
		400: errorContent,
		404: errorContent,
	},
	tags: ["User"],
});

const createUserRoute = createRoute({
	method: "post",
	path: "/",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		body: jsonContent(CreateUserParams, "Create User Body"),
	},
	responses: {
		200: jsonContent(CreateUserResponse, "Create User Response"),
		400: errorContent,
	},
	tags: ["User"],
});

const updateUserRoute = createRoute({
	method: "put",
	path: "/{id}",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: z.object({
			id: z.string(),
		}),
		body: jsonContent(UpdateUserParams, "Update User Body"),
	},
	responses: {
		200: jsonContent(UpdateUserResponse, "Update User Response"),
		400: errorContent,
		404: errorContent,
	},
	tags: ["User"],
});

const getUserStreaksRoute = createRoute({
	method: "get",
	path: "/{id}/streaks",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: z.object({
			id: z.string(),
		}),
	},
	responses: {
		200: jsonContent(UserStreaksResponse, "User Streaks Response"),
		400: errorContent,
		404: errorContent,
	},
	tags: ["User"],
});

const updateUserStreaksRoute = createRoute({
	method: "post",
	path: "/{id}/streaks/update",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: z.object({
			id: z.string(),
		}),
	},
	responses: {
		200: jsonContent(UserStreaksResponse, "Updated User Streaks Response"),
		400: errorContent,
		404: errorContent,
	},
	tags: ["User"],
});

const getUserFilesRoute = createRoute({
	method: "get",
	path: "/me/files",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
	},
	responses: {
		200: jsonContent(GetUserFilesResponse, "Get User Files Response"),
		400: errorContent,
	},
	tags: ["User"],
});

const getUserFileSignedUrlRoute = createRoute({
	method: "get",
	path: "/me/files/{fileId}/signed-url",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: GetUserFileSignedUrlParams,
		query: GetUserFileSignedUrlQuery,
	},
	responses: {
		200: jsonContent(
			GetUserFileSignedUrlResponse,
			"Get User File Signed URL Response",
		),
		400: errorContent,
		404: errorContent,
	},
	tags: ["User"],
});

// PNOE Data Processing Routes

const processPnoeDataRoute = createRoute({
	method: "post",
	path: "/me/pnoe/process",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
	},
	responses: {
		200: jsonContent(ProcessPnoeDataResponse, "Process PNOE Data Response"),
		400: errorContent,
		404: errorContent,
	},
	tags: ["User", "PNOE"],
});

const getUserCoefficientsRoute = createRoute({
	method: "get",
	path: "/me/pnoe/coefficients",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
	},
	responses: {
		200: jsonContent(
			GetUserCoefficientsResponse,
			"Get User Coefficients Response",
		),
		400: errorContent,
		404: errorContent,
	},
	tags: ["User", "PNOE"],
});

const calculatePersonalizedCaloriesRoute = createRoute({
	method: "post",
	path: "/me/calories/calculate",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		body: jsonContent(
			CalculatePersonalizedCaloriesParams,
			"Calculate Personalized Calories Body",
		),
	},
	responses: {
		200: jsonContent(
			CalculatePersonalizedCaloriesResponse,
			"Calculate Personalized Calories Response",
		),
		400: errorContent,
		404: errorContent,
	},
	tags: ["User", "PNOE"],
});

const getPnoeDataStatusRoute = createRoute({
	method: "get",
	path: "/me/pnoe/status",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
	},
	responses: {
		200: jsonContent(
			GetPnoeDataStatusResponse,
			"Get PNOE Data Status Response",
		),
		400: errorContent,
		404: errorContent,
	},
	tags: ["User", "PNOE"],
});

const userRoutes = {
	listUserRoute,
	getUserRoute,
	getUserFromTokenRoute,
	createUserRoute,
	updateUserRoute,
	getUserStreaksRoute,
	updateUserStreaksRoute,
	getUserFilesRoute,
	getUserFileSignedUrlRoute,
	processPnoeDataRoute,
	getUserCoefficientsRoute,
	calculatePersonalizedCaloriesRoute,
	getPnoeDataStatusRoute,
};

export default userRoutes;

export type ListUserRoute = typeof listUserRoute;
export type GetUserRoute = typeof getUserRoute;
export type GetUserFromTokenRoute = typeof getUserFromTokenRoute;
export type CreateUserRoute = typeof createUserRoute;
export type UpdateUserRoute = typeof updateUserRoute;
export type GetUserStreaksRoute = typeof getUserStreaksRoute;
export type UpdateUserStreaksRoute = typeof updateUserStreaksRoute;
export type GetUserFilesRoute = typeof getUserFilesRoute;
export type GetUserFileSignedUrlRoute = typeof getUserFileSignedUrlRoute;
export type ProcessPnoeDataRoute = typeof processPnoeDataRoute;
export type GetUserCoefficientsRoute = typeof getUserCoefficientsRoute;
export type CalculatePersonalizedCaloriesRoute =
	typeof calculatePersonalizedCaloriesRoute;
export type GetPnoeDataStatusRoute = typeof getPnoeDataStatusRoute;
