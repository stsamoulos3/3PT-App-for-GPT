import AuthHelper from "../../helpers/auth";
import type { AppRouteHandler } from "../../lib/types";
import type {
	CalculatePersonalizedCaloriesRoute,
	CreateUserRoute,
	GetPnoeDataStatusRoute,
	GetUserCoefficientsRoute,
	GetUserFileSignedUrlRoute,
	GetUserFilesRoute,
	GetUserFromTokenRoute,
	GetUserRoute,
	GetUserStreaksRoute,
	ListUserRoute,
	ProcessPnoeDataRoute,
	UpdateUserRoute,
	UpdateUserStreaksRoute,
} from "./routes";
import UserService from "./service";

const listUserHandler: AppRouteHandler<ListUserRoute> = async (c) => {
	const { page, limit, filter } = c.req.valid("query");
	try {
		return c.json(await UserService.listUser({ page, limit, filter }), 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getUserHandler: AppRouteHandler<GetUserRoute> = async (c) => {
	const { id } = c.req.valid("param");
	try {
		return c.json(await UserService.findOne(id), 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getUserFromTokenHandler: AppRouteHandler<GetUserFromTokenRoute> = async (
	c,
) => {
	const xApiKey = c.req.header("x-api-key");
	if (!xApiKey) {
		return c.json({ cause: "UNAUTHORIZED" }, 400);
	}
	try {
		const user = await AuthHelper.verifyToken(xApiKey);
		return c.json(user, 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const createUserHandler: AppRouteHandler<CreateUserRoute> = async (c) => {
	const params = await c.req.json();
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		return c.json(await UserService.createUser(params), 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const updateUserHandler: AppRouteHandler<UpdateUserRoute> = async (c) => {
	const { id } = c.req.valid("param");
	const params = await c.req.json();

	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}

		await AuthHelper.verifyToken(xApiKey).catch((e) => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		return c.json(await UserService.updateUser(id, params), 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getUserStreaksHandler: AppRouteHandler<GetUserStreaksRoute> = async (
	c,
) => {
	console.log("[getUserStreaksHandler]");

	const xApiKey = c.req.header("x-api-key");
	if (!xApiKey) {
		return c.json({ cause: "UNAUTHORIZED" }, 400);
	}

	console.log("[getUserStreaksHandler] xApiKey", xApiKey);

	try {
		const user = await AuthHelper.verifyToken(xApiKey);
		const userId = c.req.valid("param").id;

		console.log("[getUserStreaksHandler] userId", userId);
		// Get user with streak data
		const userData = await UserService.findOne(userId);

		console.log("[getUserStreaksHandler] userData", userData);

		const streaks = {
			currentWorkoutStreak: userData.currentWorkoutStreak,
			longestWorkoutStreak: userData.longestWorkoutStreak,
			currentFoodStreak: userData.currentFoodStreak,
			longestFoodStreak: userData.longestFoodStreak,
			lastWorkoutDate: userData.lastWorkoutDate,
			lastFoodLogDate: userData.lastFoodLogDate,
			lastActiveAt: userData.lastActiveAt,
		};

		console.log("[getUserStreaksHandler] streaks", streaks);

		return c.json({ streaks }, 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const updateUserStreaksHandler: AppRouteHandler<
	UpdateUserStreaksRoute
> = async (c) => {
	const xApiKey = c.req.header("x-api-key");
	if (!xApiKey) {
		return c.json({ cause: "UNAUTHORIZED" }, 400);
	}

	try {
		const user = await AuthHelper.verifyToken(xApiKey);
		const userId = c.req.valid("param").id;

		// Update user streaks
		await UserService.updateUserStreaks(userId);

		// Get updated user data
		const userData = await UserService.findOne(userId);

		const streaks = {
			currentWorkoutStreak: userData.currentWorkoutStreak,
			longestWorkoutStreak: userData.longestWorkoutStreak,
			currentFoodStreak: userData.currentFoodStreak,
			longestFoodStreak: userData.longestFoodStreak,
			lastWorkoutDate: userData.lastWorkoutDate,
			lastFoodLogDate: userData.lastFoodLogDate,
			lastActiveAt: userData.lastActiveAt,
		};

		return c.json({ streaks }, 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getUserFilesHandler: AppRouteHandler<GetUserFilesRoute> = async (c) => {
	const xApiKey = c.req.header("x-api-key");
	if (!xApiKey) {
		return c.json({ cause: "UNAUTHORIZED" }, 400);
	}

	try {
		const user = await AuthHelper.verifyToken(xApiKey);
		const files = await UserService.getUserFiles(user.id);
		return c.json(files, 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getUserFileSignedUrlHandler: AppRouteHandler<
	GetUserFileSignedUrlRoute
> = async (c) => {
	const xApiKey = c.req.header("x-api-key");
	if (!xApiKey) {
		return c.json({ cause: "UNAUTHORIZED" }, 400);
	}

	try {
		const user = await AuthHelper.verifyToken(xApiKey);
		const { fileId } = c.req.valid("param");
		const { expiresIn } = c.req.valid("query");

		const result = await UserService.generateUserFileSignedUrl(
			user.id,
			fileId,
			Number.parseInt(expiresIn || "3600"),
		);

		return c.json(result, 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			if (
				error.message === "File not found" ||
				error.message === "Access denied"
			) {
				return c.json({ cause: error.message }, 404);
			}
			return c.json(
				{
					cause: typeof error.cause === "string" ? error.cause : error.message,
				},
				400,
			);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

// PNOE Data Processing Handlers

const processPnoeDataHandler: AppRouteHandler<ProcessPnoeDataRoute> = async (
	c,
) => {
	const xApiKey = c.req.header("x-api-key");
	if (!xApiKey) {
		return c.json({ cause: "UNAUTHORIZED" }, 400);
	}

	try {
		const user = await AuthHelper.verifyToken(xApiKey);
		const result = await UserService.processPnoeData(user.id);
		return c.json(result, 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json(
				{
					cause: typeof error.cause === "string" ? error.cause : error.message,
				},
				400,
			);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getUserCoefficientsHandler: AppRouteHandler<
	GetUserCoefficientsRoute
> = async (c) => {
	const xApiKey = c.req.header("x-api-key");
	if (!xApiKey) {
		return c.json({ cause: "UNAUTHORIZED" }, 400);
	}

	try {
		const user = await AuthHelper.verifyToken(xApiKey);
		const result = await UserService.getUserCoefficients(user.id);
		return c.json(result, 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json(
				{
					cause: typeof error.cause === "string" ? error.cause : error.message,
				},
				404,
			);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getPnoeDataStatusHandler: AppRouteHandler<
	GetPnoeDataStatusRoute
> = async (c) => {
	const xApiKey = c.req.header("x-api-key");
	if (!xApiKey) {
		return c.json({ cause: "UNAUTHORIZED" }, 400);
	}

	try {
		const user = await AuthHelper.verifyToken(xApiKey);
		const result = await UserService.getPnoeDataStatus(user.id);
		return c.json(result, 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json(
				{
					cause: typeof error.cause === "string" ? error.cause : error.message,
				},
				400,
			);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const userHandlers = {
	listUserHandler,
	getUserHandler,
	getUserFromTokenHandler,
	createUserHandler,
	updateUserHandler,
	getUserStreaksHandler,
	updateUserStreaksHandler,
	getUserFilesHandler,
	getUserFileSignedUrlHandler,
	processPnoeDataHandler,
	getUserCoefficientsHandler,
	getPnoeDataStatusHandler,
};

export default userHandlers;
