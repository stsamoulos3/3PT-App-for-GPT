import { z } from "zod";

export const CalorieCountingMethodEnum = z.enum([
	"MODEL1",
	"MODEL2",
	"MODEL3",
	"MODEL4",
]);

export const UserSchema = z.object({
	id: z.string(),
	first_name: z.string(),
	last_name: z.string(),
	email: z.string(),
	dob: z.date().nullable(),
	gender: z.string().nullable(),
	is3PTPatient: z.boolean().nullable(),
	patientId: z.string().nullable(),
	isMultidisciplinaryPatient: z.boolean().nullable(),
	rmr: z.number().nullable(),
	prescribedExerciseHR: z.number().nullable(),
	hourlyCaloriesAtHR: z.number().nullable(),
	prescribedDailyCalories: z.number().nullable(),
	vo2Max: z.number().nullable(),
	user_agreement: z.string().nullable(),
	calorieCountingMethod: CalorieCountingMethodEnum.nullable().optional(),
	emailVerified: z.boolean(),
	emailVerificationToken: z.string().nullable(),
	currentWorkoutStreak: z.number(),
	longestWorkoutStreak: z.number(),
	currentFoodStreak: z.number(),
	longestFoodStreak: z.number(),
	lastWorkoutDate: z.date().nullable(),
	lastFoodLogDate: z.date().nullable(),
	lastActiveAt: z.date(),
	createdAt: z.date(),
	updatedAt: z.date(),
});

export const CreateUserParams = UserSchema.omit({
	id: true,
	createdAt: true,
	updatedAt: true,
	emailVerified: true,
	emailVerificationToken: true,
	currentWorkoutStreak: true,
	longestWorkoutStreak: true,
	currentFoodStreak: true,
	longestFoodStreak: true,
	lastWorkoutDate: true,
	lastFoodLogDate: true,
	lastActiveAt: true,
});
export const UpdateUserParams = CreateUserParams.partial().extend({
	dob: z
		.string()
		.transform((val) => (val ? new Date(val) : null))
		.nullable()
		.optional(),
	calorieCountingMethod: CalorieCountingMethodEnum.nullable().optional(),
});
export const GetUserResponse = UserSchema;

export const CreateUserResponse = UserSchema;

export const UpdateUserResponse = UserSchema;

export const ListUserParams = z.object({
	page: z.number().optional(),
	limit: z.number().optional(),
	filter: z.string().optional(),
});

export const ListUserResponse = z.object({
	data: z.array(UserSchema),
	pagination: z.object({
		page: z.number(),
		limit: z.number(),
		total: z.number(),
	}),
});

// Streak-related models
export const StreakResponse = z.object({
	currentWorkoutStreak: z.number(),
	longestWorkoutStreak: z.number(),
	currentFoodStreak: z.number(),
	longestFoodStreak: z.number(),
	lastWorkoutDate: z.date().nullable(),
	lastFoodLogDate: z.date().nullable(),
	lastActiveAt: z.date(),
});

export const UserStreaksResponse = z.object({
	streaks: StreakResponse,
});

// User Files models
export const UserFileSchema = z.object({
	id: z.string(),
	fileName: z.string(),
	filePath: z.string(),
	fileSize: z.number(),
	mimeType: z.string(),
	description: z.string().nullable(),
	uploadedBy: z.string(),
	createdAt: z.date(),
	updatedAt: z.date(),
});

export const GetUserFilesResponse = z.object({
	files: z.array(UserFileSchema),
});

export const GetUserFileSignedUrlParams = z.object({
	fileId: z.string(),
});

export const GetUserFileSignedUrlQuery = z.object({
	expiresIn: z.string().optional().default("3600"), // Default 1 hour
});

export const GetUserFileSignedUrlResponse = z.object({
	signedUrl: z.string(),
	expiresAt: z.string(),
});

// PNOE Data Processing models
export const ProcessPnoeDataResponse = z.object({
	success: z.boolean(),
	message: z.string(),
	processedAt: z.date(),
});

export const GetUserCoefficientsParams = z.object({
	method: CalorieCountingMethodEnum,
});

export const Vo2ProfileSchema = z.object({
	id: z.string(),
	estimatedVo2Max: z.number(),
	vo2EfficiencyCoefficient: z.number(),
	restingMetabolicRate: z.number().nullable(),
	hrVo2Slope: z.number().nullable(),
	hrVo2Intercept: z.number().nullable(),
	hrEeSlope: z.number().nullable(),
	hrEeIntercept: z.number().nullable(),
	o2RerSlope: z.number().nullable(),
	o2RerIntercept: z.number().nullable(),
});

export const GetUserCoefficientsResponse = Vo2ProfileSchema.nullable().and(
	z.object({
		calorieCountingMethod: CalorieCountingMethodEnum,
	}),
);

export const CalculatePersonalizedCaloriesParams = z.object({
	currentHeartRate: z.number(),
	durationMinutes: z.number(),
});

export const CalculatePersonalizedCaloriesResponse = z.object({
	calculatedCalories: z.number(),
	method: CalorieCountingMethodEnum,
	heartRate: z.number(),
	durationMinutes: z.number(),
	hasPnoeData: z.boolean(),
});

export const GetPnoeDataStatusResponse = z.object({
	hasPnoeData: z.boolean(),
	lastProcessedAt: z.date().nullable(),
	availableMethods: z.array(CalorieCountingMethodEnum),
});
