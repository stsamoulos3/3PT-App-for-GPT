import { z } from "zod";

export const HeartRateSchema = z.object({
	id: z.string(),
	workoutId: z.string().optional().nullable(),
	userId: z.string(),
	timestamp: z.coerce.date(),
	heartRateBPM: z.number(),
	hkId: z.string().optional().nullable(),
	createdAt: z.coerce.date(),
	updatedAt: z.coerce.date(),
});

export const CreateHeartRateParams = z.object({
	workoutId: z.string().optional().nullable(),
	timestamp: z.string(),
	heartRateBPM: z.number(),
	hkId: z.string().optional().nullable(),
	source: z.string().optional().nullable(),
	device: z.string().optional().nullable(),
});

export const CreateBulkHeartRateParams = z.array(CreateHeartRateParams);
