import { Point } from "@influxdata/influxdb-client";
import type { z } from "zod";
import { queryApi, writeApi } from "../../db/influx";
import type { CreateBulkHeartRateParams } from "./models";

// biome-ignore lint/complexity/noStaticOnlyClass: i want this
export default class HeartRateService {
	static async createBulkHeartRate(
		userId: string,
		params: z.infer<typeof CreateBulkHeartRateParams>,
	): Promise<string> {
		const points = params.map((param) => {
			const point = new Point("heart_rate_v2")
				.tag("userId", userId) // low cardinality
				.tag("type", param.source ?? "") // low cardinality
				.tag("source", param.device ?? "") // low cardinality
				.stringField("hkId", param.hkId ?? "") // high cardinality → keep as field
				.floatField("heartRateBPM", param.heartRateBPM)
				.timestamp(new Date(param.timestamp));
			return point;
		});

		writeApi.writePoints(points);
		await writeApi.flush();

		return "success";
	}

	static async createBulkHeartRateWithInflux(
		userId: string,
		params: z.infer<typeof CreateBulkHeartRateParams>,
	): Promise<string> {
		const start = performance.now();

		try {
			// Write to InfluxDB
			const points = params.map((param) => {
				const point = new Point("heart_rate")
					.tag("userId", userId)
					.tag("hkId", param.hkId ?? "")
					.floatField("heartRateBPM", param.heartRateBPM)
					.timestamp(new Date(param.timestamp));
				return point;
			});

			writeApi.writePoints(points);
			await writeApi.flush();

			return "success";
		} catch (error) {
			console.error("Error writing data:", error);
			throw error;
		}
	}

	static async getHeartRatesByTimeRange(
		userId: string,
		startTime: Date,
		endTime: Date,
	) {
		const query = `
      from(bucket: "${process.env.INFLUX_BUCKET}")
        |> range(start: ${startTime.toISOString()}, stop: ${endTime.toISOString()})
        |> filter(fn: (r) => r["_measurement"] == "heart_rate")
        |> filter(fn: (r) => r["userId"] == "${userId}")
        |> aggregateWindow(every: 1m, fn: mean)
    `;

		const results: any[] = [];
		for await (const { values, tableMeta } of queryApi.iterateRows(query)) {
			results.push({
				timestamp:
					values[tableMeta.columns.findIndex((col) => col.label === "_time")],
				heartRateBPM:
					values[tableMeta.columns.findIndex((col) => col.label === "_value")],
			});
		}

		return results;
	}
}
