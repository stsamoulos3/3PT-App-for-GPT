import { AppRouteHandler } from "../../lib/types";
import { CreateBulkHeartRateRoute } from "./routes";
import HeartRateService from "./service";
import AuthHelper from "../../helpers/auth";

const createBulkHeartRateHandler: AppRouteHandler<
  CreateBulkHeartRateRoute
> = async (c) => {
  try {
    const params = c.req.valid("json");

    const xApiKey = c.req.header("x-api-key");
    if (!xApiKey) {
      throw new Error("x-api-key header is required", {
        cause: "AUTHORIZATION_HEADER_REQUIRED",
      });
    }

    const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
      throw new Error("Invalid x-api-key header", {
        cause: "INVALID_API_KEY",
      });
    });

    await HeartRateService.createBulkHeartRate(user.id, params);

    return c.json({ message: "Synced With InfluxDB" }, 200);
  } catch (e: any) {
    return c.json({ cause: e.cause }, 400);
  }
};

const heartRateHandlers = {
  createBulkHeartRateHandler,
};

export default heartRateHandlers;
