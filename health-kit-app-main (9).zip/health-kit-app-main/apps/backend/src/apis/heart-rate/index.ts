import { createRouter } from "../../lib/create-app";
import heartRateHandlers from "./handlers";
import heartRateRoutes from "./routes";

const router = createRouter().openapi(
  heartRateRoutes.createBulkHeartRateRoute,
  heartRateHandlers.createBulkHeartRateHandler
);

export default router;
