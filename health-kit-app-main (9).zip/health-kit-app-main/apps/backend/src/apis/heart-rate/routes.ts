import { createRoute, z } from "@hono/zod-openapi";
import { CreateBulkHeartRateParams } from "./models";
import jsonContent from "../../helpers/json-content";

const createBulkHeartRateRoute = createRoute({
  method: "post",
  path: "/bulk",
  request: {
    headers: z.object({
      "x-api-key": z.string(),
    }),
    body: jsonContent(
      CreateBulkHeartRateParams,
      "Create Bulk Heart Rate Request"
    ),
  },
  responses: {
    200: jsonContent(
      z.object({ message: z.string() }),
      "Create Bulk Heart Rate Response"
    ),
    400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
  },
  tags: ["Heart Rate"],
});

const heartRateRoutes = {
  createBulkHeartRateRoute,
};

export default heartRateRoutes;

export type CreateBulkHeartRateRoute = typeof createBulkHeartRateRoute;
