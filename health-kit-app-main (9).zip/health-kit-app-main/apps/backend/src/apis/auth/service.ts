import { z } from "zod";
import {
  ChangePasswordBody,
  ChangePasswordResponse,
  CheckEmailBody,
  CheckEmailResponse,
  SignInBody,
  SignInResponse,
  SignUpBody,
  SignUpResponse,
  ForgotPasswordBody,
  ForgotPasswordResponse,
  ResetPasswordBody,
  ResetPasswordResponse,
  VerifyEmailBody,
  VerifyEmailResponse,
  ResendVerificationBody,
  ResendVerificationResponse,
} from "./models";
import { prisma } from "../../db/client";
import AuthHelper from "../../helpers/auth";
import emailHelper from "../../helpers/email";

export default class AuthService {
  static async checkEmail(
    params: z.infer<typeof CheckEmailBody>
  ): Promise<z.infer<typeof CheckEmailResponse>> {
    const { email } = params;

    const sanitizedEmail = email.toLowerCase().trim();

    const exists = await prisma.user.findUnique({
      where: {
        email: sanitizedEmail,
      },
    });

    return {
      exists: exists ? true : false,
    };
  }

  static async signIn(
    params: z.infer<typeof SignInBody>
  ): Promise<z.infer<typeof SignInResponse>> {
    // Implementation for signing in
    const { email, password } = params;

    const sanitizedEmail = email.toLowerCase().trim();

    const user = await prisma.user.findUnique({
      where: { email: sanitizedEmail },
    });

    if (!user) {
      throw new Error("User not found", {
        cause: "USER_NOT_FOUND",
      });
    }

    console.log(user.password, password);

    const isPasswordValid = await AuthHelper.compare(
      password,
      user.password
    ).catch(() => false);

    if (!isPasswordValid) {
      throw new Error("Invalid credentials", {
        cause: "INVALID_CREDENTIALS",
      });
    }

    const token = await AuthHelper.signToken({
      id: user.id,
      email: user.email,
    });

    return {
      access_token: token,
      refresh_token: token,
      user,
    };
  }

  static async signUp(
    params: z.infer<typeof SignUpBody>
  ): Promise<z.infer<typeof SignUpResponse>> {
    // Implementation for signing up
    const { email, password, first_name, last_name, user_agreement } = params;

    const sanitizedEmail = email.toLowerCase().trim();

    const isEmailAlreadyTaken = await prisma.user.findUnique({
      where: { email: sanitizedEmail },
    });

    if (isEmailAlreadyTaken) {
      throw new Error("Email already taken", {
        cause: "EMAIL_ALREADY_TAKEN",
      });
    }

    const hashedPassword = await AuthHelper.hash(password);

    console.log(hashedPassword);

    // Generate email verification token
    const emailVerificationToken = AuthHelper.generateSecureToken();

    const user = await prisma.user.create({
      data: {
        first_name,
        last_name,
        email: sanitizedEmail,
        password: hashedPassword,
        user_agreement: user_agreement ? "accepted" : null,
        emailVerificationToken,
        emailVerified: false,
      },
    });

    // Send verification email
    try {
      await emailHelper.sendEmailVerification(
        user.email,
        emailVerificationToken
      );
      console.log(`Verification email sent to ${user.email}`);
    } catch (error) {
      console.error("Failed to send verification email:", error);
      // Don't fail the signup if email fails, but log it
    }

    const access_token = await AuthHelper.signToken({
      id: user.id,
      email: user.email,
    });

    const refresh_token = await AuthHelper.signToken({
      id: user.id,
      email: user.email,
    });

    return {
      access_token,
      refresh_token,
      user,
    };
  }

  static async changePassword(
    userId: string,
    params: z.infer<typeof ChangePasswordBody>
  ): Promise<z.infer<typeof ChangePasswordResponse>> {
    // Implementation for changing password

    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw new Error("User not found", {
        cause: "USER_NOT_FOUND",
      });
    }

    const isPasswordValid = await AuthHelper.compare(
      params.currentPassword,
      user.password
    ).catch(() => false);

    if (!isPasswordValid) {
      throw new Error("Invalid current password", {
        cause: "INVALID_CURRENT_PASSWORD",
      });
    }

    const hashedPassword = await AuthHelper.hash(params.newPassword);

    await prisma.user.update({
      where: { id: userId },
      data: { password: hashedPassword },
    });

    // Send password change confirmation email
    try {
      await emailHelper.sendPasswordChangeConfirmation(user.email);
      console.log(`Password change confirmation sent to ${user.email}`);
    } catch (error) {
      console.error("Failed to send password change confirmation:", error);
      // Don't fail the password change if email fails
    }

    return {
      message: "Password changed successfully",
    };
  }

  static async forgotPassword(
    params: z.infer<typeof ForgotPasswordBody>
  ): Promise<z.infer<typeof ForgotPasswordResponse>> {
    const { email } = params;
    const sanitizedEmail = email.toLowerCase().trim();

    const user = await prisma.user.findUnique({
      where: { email: sanitizedEmail },
    });

    if (!user) {
      // For security reasons, we don't reveal if email exists
      return {
        message:
          "If an account with that email exists, you will receive a password reset email.",
      };
    }

    // Generate a secure token
    const resetToken = AuthHelper.generateSecureToken();
    const tokenExpiry = new Date(Date.now() + 3600000); // 1 hour from now

    // Store the reset token in database (you might want to add a password_reset_tokens table)
    await prisma.user.update({
      where: { id: user.id },
      data: {
        // You'll need to add these fields to your User model
        resetToken: resetToken,
        resetTokenExpiry: tokenExpiry,
      },
    });

    // Send password reset email
    try {
      await emailHelper.sendPasswordReset(user.email, resetToken);
      console.log(`Password reset email sent to ${user.email}`);
    } catch (error) {
      console.error("Failed to send password reset email:", error);
      // Don't reveal email sending failures for security
    }

    return {
      message:
        "If an account with that email exists, you will receive a password reset email.",
    };
  }

  static async resetPassword(
    params: z.infer<typeof ResetPasswordBody>
  ): Promise<z.infer<typeof ResetPasswordResponse>> {
    const { token, newPassword } = params;

    console.log("[AuthService -> resetPassword] token", token);

    const user = await prisma.user.findFirst({
      where: {
        resetToken: token,
        resetTokenExpiry: {
          gt: new Date(),
        },
      },
    });

    console.log("[AuthService -> resetPassword] user", user);

    if (!user) {
      throw new Error("Invalid or expired reset token", {
        cause: "INVALID_RESET_TOKEN",
      });
    }

    const hashedPassword = await AuthHelper.hash(newPassword);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        password: hashedPassword,
        resetToken: null,
        resetTokenExpiry: null,
      },
    });

    console.log("[AuthService -> resetPassword] password updated");

    return {
      message: "Password reset successfully",
    };
  }

  static async verifyEmail(
    params: z.infer<typeof VerifyEmailBody>
  ): Promise<z.infer<typeof VerifyEmailResponse>> {
    const { token } = params;

    console.log("[AuthService -> verifyEmail] token", token);

    const user = await prisma.user.findFirst({
      where: {
        emailVerificationToken: token,
      },
    });

    if (!user) {
      throw new Error("Invalid verification token", {
        cause: "INVALID_VERIFICATION_TOKEN",
      });
    }

    await prisma.user.update({
      where: { id: user.id },
      data: {
        emailVerified: true,
        emailVerificationToken: null,
      },
    });

    // Send welcome email
    try {
      await emailHelper.sendWelcomeEmail(user.email, user.first_name);
      console.log(`Welcome email sent to ${user.email}`);
    } catch (error) {
      console.error("Failed to send welcome email:", error);
      // Don't fail the verification if welcome email fails
    }

    return {
      message: "Email verified successfully",
    };
  }

  static async resendVerification(
    params: z.infer<typeof ResendVerificationBody>
  ): Promise<z.infer<typeof ResendVerificationResponse>> {
    const { email } = params;
    const sanitizedEmail = email.toLowerCase().trim();

    const user = await prisma.user.findUnique({
      where: { email: sanitizedEmail },
    });

    if (!user) {
      throw new Error("User not found", {
        cause: "USER_NOT_FOUND",
      });
    }

    if (user.emailVerified) {
      throw new Error("Email already verified", {
        cause: "EMAIL_ALREADY_VERIFIED",
      });
    }

    const verificationToken = AuthHelper.generateSecureToken();

    await prisma.user.update({
      where: { id: user.id },
      data: {
        emailVerificationToken: verificationToken,
      },
    });

    // Send verification email
    try {
      await emailHelper.sendEmailVerification(user.email, verificationToken);
      console.log(`Verification email resent to ${user.email}`);
    } catch (error) {
      console.error("Failed to resend verification email:", error);
      throw new Error("Failed to send verification email", {
        cause: "EMAIL_SEND_FAILED",
      });
    }

    return {
      message: "Verification email sent",
    };
  }
}
