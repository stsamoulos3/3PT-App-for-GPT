import { createRoute, OpenAPIHono, z } from "@hono/zod-openapi";
import {
  ChangePasswordBody,
  ChangePasswordResponse,
  CheckEmailBody,
  CheckEmailResponse,
  SignInBody,
  SignInResponse,
  SignUpBody,
  SignUpResponse,
  ForgotPasswordBody,
  ForgotPasswordResponse,
  ResetPasswordBody,
  ResetPasswordResponse,
  VerifyEmailBody,
  VerifyEmailResponse,
  ResendVerificationBody,
  ResendVerificationResponse,
} from "./models";
import AuthService from "./service";
import jsonContent from "../../helpers/json-content";
import errorContent from "../../helpers/error-content";

const checkEmailRoute = createRoute({
  method: "post",
  path: "/check",

  request: {
    body: jsonContent(CheckEmailBody, "Check Email Body"),
  },
  responses: {
    200: jsonContent(CheckEmailResponse, "Check Email Response"),
  },

  // responses: authModels.checkEmailParams.responses,
});

const signInRoute = createRoute({
  method: "post",
  path: "/sign-in",
  request: {
    body: jsonContent(SignInBody, "Sign In Body"),
  },
  responses: {
    200: jsonContent(SignInResponse, "Sign In Response"),
    400: errorContent,
  },
  tags: ["Auth"],
});

const signUpRoute = createRoute({
  method: "post",
  path: "/sign-up",
  request: {
    body: jsonContent(SignUpBody, "Sign Up Body"),
  },
  responses: {
    200: jsonContent(SignUpResponse, "Sign Up Response"),
    400: errorContent,
  },
  tags: ["Auth"],
});

const changePasswordRoute = createRoute({
  method: "post",
  path: "/change-password",
  request: {
    headers: z.object({
      "x-api-key": z.string(),
    }),
    body: jsonContent(ChangePasswordBody, "Change Password Body"),
  },
  responses: {
    200: jsonContent(ChangePasswordResponse, "Change Password Response"),
    400: errorContent,
  },
});

const forgotPasswordRoute = createRoute({
  method: "post",
  path: "/forgot-password",
  request: {
    body: jsonContent(ForgotPasswordBody, "Forgot Password Body"),
  },
  responses: {
    200: jsonContent(ForgotPasswordResponse, "Forgot Password Response"),
    400: errorContent,
  },
  tags: ["Auth"],
});

const resetPasswordRoute = createRoute({
  method: "post",
  path: "/reset-password",
  request: {
    body: jsonContent(ResetPasswordBody, "Reset Password Body"),
  },
  responses: {
    200: jsonContent(ResetPasswordResponse, "Reset Password Response"),
    400: errorContent,
  },
  tags: ["Auth"],
});

const verifyEmailRoute = createRoute({
  method: "post",
  path: "/verify-email",
  request: {
    body: jsonContent(VerifyEmailBody, "Verify Email Body"),
  },
  responses: {
    200: jsonContent(VerifyEmailResponse, "Verify Email Response"),
    400: errorContent,
  },
  tags: ["Auth"],
});

const resendVerificationRoute = createRoute({
  method: "post",
  path: "/resend-verification",
  request: {
    body: jsonContent(ResendVerificationBody, "Resend Verification Body"),
  },
  responses: {
    200: jsonContent(
      ResendVerificationResponse,
      "Resend Verification Response"
    ),
    400: errorContent,
  },
  tags: ["Auth"],
});

const authRoutes = {
  checkEmailRoute,
  signInRoute,
  signUpRoute,
  changePasswordRoute,
  forgotPasswordRoute,
  resetPasswordRoute,
  verifyEmailRoute,
  resendVerificationRoute,
};

export default authRoutes;

export type CheckEmailRoute = typeof authRoutes.checkEmailRoute;
export type SignInRoute = typeof authRoutes.signInRoute;
export type SignUpRoute = typeof authRoutes.signUpRoute;
export type ChangePasswordRoute = typeof authRoutes.changePasswordRoute;
export type ForgotPasswordRoute = typeof authRoutes.forgotPasswordRoute;
export type ResetPasswordRoute = typeof authRoutes.resetPasswordRoute;
export type VerifyEmailRoute = typeof authRoutes.verifyEmailRoute;
export type ResendVerificationRoute = typeof authRoutes.resendVerificationRoute;
