import { createRouter } from "../../lib/create-app";
import authHandlers from "./handlers";
import authRoutes from "./routes";

const router = createRouter()
  .openapi(authRoutes.resetPasswordRoute, authHandlers.resetPasswordHandler)
  .openapi(authRoutes.checkEmailRoute, authHandlers.checkEmailHandler)
  .openapi(authRoutes.signInRoute, authHandlers.signInHandler)
  .openapi(authRoutes.signUpRoute, authHandlers.signUpHandler)
  .openapi(authRoutes.changePasswordRoute, authHandlers.changePasswordHandler)
  .openapi(authRoutes.forgotPasswordRoute, authHandlers.forgotPasswordHandler)
  .openapi(authRoutes.verifyEmailRoute, authHandlers.verifyEmailHandler)
  .openapi(
    authRoutes.resendVerificationRoute,
    authHandlers.resendVerificationHandler
  );

export default router;
