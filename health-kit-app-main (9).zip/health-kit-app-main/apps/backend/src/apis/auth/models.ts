import { z } from "@hono/zod-openapi";
import { UserSchema } from "../user/models";

export const CheckEmailBody = z.object({
	email: z.string().email(),
});

export const CheckEmailResponse = z.object({
	exists: z.boolean(),
});

export const SignInBody = z.object({
	email: z.string().email(),
	password: z.string(),
});

export const SignInResponse = z.object({
	access_token: z.string(),
	refresh_token: z.string(),
	user: UserSchema,
});

export const SignUpBody = z
	.object({
		email: z.string().email(),
		password: z.string(),
		first_name: z.string(),
		last_name: z.string(),
		user_agreement: z.boolean().optional(),
	})
	.openapi("SignUp");

export const SignUpResponse = z.object({
	access_token: z.string(),
	refresh_token: z.string(),
	user: UserSchema,
});

export const ChangePasswordBody = z.object({
	currentPassword: z.string(),
	newPassword: z.string(),
});

export const ChangePasswordResponse = z.object({
	message: z.string(),
});

// Forgot Password models
export const ForgotPasswordBody = z.object({
	email: z.string().email(),
});

export const ForgotPasswordResponse = z.object({
	message: z.string(),
});

// Reset Password models
export const ResetPasswordBody = z.object({
	token: z.string(),
	newPassword: z.string().min(8),
});

export const ResetPasswordResponse = z.object({
	message: z.string(),
});

// Email Verification models
export const VerifyEmailBody = z.object({
	token: z.string(),
});

export const VerifyEmailResponse = z.object({
	message: z.string(),
});

export const ResendVerificationBody = z.object({
	email: z.string().email(),
});

export const ResendVerificationResponse = z.object({
	message: z.string(),
});
