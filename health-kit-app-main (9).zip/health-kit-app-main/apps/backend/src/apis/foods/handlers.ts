import type { AppRouteHandler } from "../../lib/types";
import type {
	SearchFoodsRoute,
	CreateFoodRoute,
	GetFoodRoute,
	CreateFoodLogRoute,
	GetFoodLogRoute,
	UpdateFoodLogRoute,
	GetFoodLogByIdRoute,
	DeleteFoodLogRoute,
	GetRecentFoodsRoute,
} from "./routes";
import FoodService from "./service";
import AuthHelper from "../../helpers/auth";
import UserService from "../user/service";

const searchFoodsHandler: AppRouteHandler<SearchFoodsRoute> = async (c) => {
	const { q, barcode, hardFetch } = c.req.valid("query");
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		return c.json(
			await FoodService.searchFoods(user.id, { q, barcode, hardFetch }),
			200,
		);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const createFoodHandler: AppRouteHandler<CreateFoodRoute> = async (c) => {
	const params = c.req.valid("json");
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		return c.json(await FoodService.createFood(user.id, params), 201);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getFoodHandler: AppRouteHandler<GetFoodRoute> = async (c) => {
	const { id } = c.req.valid("param");
	const { hardFetch } = c.req.valid("query");
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		return c.json(
			await FoodService.getFood(user.id, id, hardFetch ?? false),
			200,
		);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const createFoodLogHandler: AppRouteHandler<CreateFoodLogRoute> = async (c) => {
	const params = c.req.valid("json");
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		const foodLog = await FoodService.createFoodLog(user.id, params);

		// Update streaks after creating food log
		await UserService.updateUserStreaks(user.id);

		return c.json(foodLog, 201);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getFoodLogsHandler: AppRouteHandler<GetFoodLogRoute> = async (c) => {
	const { startDate, endDate, meal } = c.req.valid("query");
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		return c.json(
			await FoodService.getFoodLogs(user.id, { startDate, endDate, meal }),
			200,
		);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getFoodLogByIdHandler: AppRouteHandler<GetFoodLogByIdRoute> = async (
	c,
) => {
	const { id } = c.req.valid("param");
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		return c.json(await FoodService.getFoodLogById(user.id, id), 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const updateFoodLogHandler: AppRouteHandler<UpdateFoodLogRoute> = async (c) => {
	const { id } = c.req.valid("param");
	const params = c.req.valid("json");
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		const foodLog = await FoodService.updateFoodLog(id, params);

		// Update streaks after updating food log
		await UserService.updateUserStreaks(user.id);

		return c.json(foodLog, 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const deleteFoodLogHandler: AppRouteHandler<DeleteFoodLogRoute> = async (c) => {
	const { id } = c.req.valid("param");
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		const result = await FoodService.deleteFoodLog(user.id, id);

		// Update streaks after deleting food log
		await UserService.updateUserStreaks(user.id);

		return c.json(result, 200);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const getRecentFoodsHandler: AppRouteHandler<GetRecentFoodsRoute> = async (
	c,
) => {
	const { limit, search } = c.req.valid("query");
	try {
		const xApiKey = c.req.header("x-api-key");
		if (!xApiKey) {
			throw new Error("x-api-key header is required", {
				cause: "AUTHORIZATION_HEADER_REQUIRED",
			});
		}
		const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
			throw new Error("Invalid x-api-key header", {
				cause: "INVALID_API_KEY",
			});
		});

		return c.json(
			await FoodService.getRecentFoods(user.id, limit, search),
			200,
		);
	} catch (error: unknown) {
		if (error instanceof Error) {
			return c.json({ cause: error.cause }, 400);
		}
		return c.json({ cause: "INTERNAL_SERVER_ERROR" }, 400);
	}
};

const foodHandlers = {
	searchFoodsHandler,
	createFoodHandler,
	getFoodHandler,
	createFoodLogHandler,
	getFoodLogsHandler,
	getFoodLogByIdHandler,
	updateFoodLogHandler,
	deleteFoodLogHandler,
	getRecentFoodsHandler,
};

export default foodHandlers;
