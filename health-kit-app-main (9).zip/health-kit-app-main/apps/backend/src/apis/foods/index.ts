import { createRouter } from "../../lib/create-app";

import foodRoutes from "./routes";
import foodHandlers from "./handlers";

const router = createRouter()
  // Food routes
  .openapi(foodRoutes.searchFoodsRoute, foodHandlers.searchFoodsHandler)
  .openapi(foodRoutes.getRecentFoodsRoute, foodHandlers.getRecentFoodsHandler)
  .openapi(foodRoutes.createFoodRoute, foodHandlers.createFoodHandler)
  .openapi(foodRoutes.getFoodLogRoute, foodHandlers.getFoodLogsHandler)
  .openapi(foodRoutes.getFoodRoute, foodHandlers.getFoodHandler)
  .openapi(foodRoutes.getFoodLogByIdRoute, foodHandlers.getFoodLogByIdHandler)
  .openapi(foodRoutes.createFoodLogRoute, foodHandlers.createFoodLogHandler)
  .openapi(foodRoutes.updateFoodLogRoute, foodHandlers.updateFoodLogHandler)
  .openapi(foodRoutes.deleteFoodLogRoute, foodHandlers.deleteFoodLogHandler);

export default router;
