import type { z } from "zod";
import { prisma } from "../../db/client";
import type {
	CreateFoodParams,
	CreateFoodLogParams,
	GetFoodLogParams,
	SearchFoodsParams,
	UpdateFoodLogParams,
	UpdateFoodLogResponse,
	FoodSchema,
} from "./models";
import { NutranixService } from "../../external/NutranixService";
import type { Food } from "@repo/core/types/entities/food";
import {
	Multiplier,
	NutritionAttributeIdToKey,
} from "../../helpers/nutranixAttToKey";
import type { MealType } from "../../../prisma/generated/prisma";

// biome-ignore lint/complexity/noStaticOnlyClass: <explanation>
export default class FoodService {
	static async searchFoods(
		userId: string,
		params: z.infer<typeof SearchFoodsParams>,
	) {
		const { q, barcode, hardFetch } = params;

		console.log(
			"[FoodService -> searchFoods] Searching for foods",
			q,
			barcode,
			hardFetch,
		);

		if (barcode) {
			const nutranixFood = await NutranixService.getProductByBarcode({
				barcode,
			});

			if (!nutranixFood) {
				throw new Error("Food not found", {
					cause: "FOOD_NOT_FOUND",
				});
			}

			const existingFood = await prisma.food.findFirst({
				where: {
					nixId: nutranixFood.nix_item_id,
				},
			});

			if (existingFood) {
				return [existingFood];
			}

			const food = await prisma.food.create({
				data: {
					calories: nutranixFood.nf_calories,
					foodName: nutranixFood.food_name,
					serving: nutranixFood.serving_qty.toString(),
					servingSize: nutranixFood.serving_unit,
					brandName: nutranixFood.brand_name,
					cholesterol: nutranixFood.nf_cholesterol,
					calcium: null,
					dietaryFiber: nutranixFood.nf_dietary_fiber,
					protein: nutranixFood.nf_protein,
					sodium: nutranixFood.nf_sodium,
					potassium: nutranixFood.nf_potassium,
					iron: null,
					sugars: nutranixFood.nf_sugars,
					monounsaturatedFat: null,
					polyunsaturatedFat: null,
					saturatedFat: nutranixFood.nf_saturated_fat,
					totalCarbohydrates: nutranixFood.nf_total_carbohydrate,
					totalFat: nutranixFood?.nf_total_fat,
					vitaminA: null,
					vitaminC: null,
					synced: true,
					nixId: nutranixFood.nix_item_id,
				},
			});

			return [food];
		}

		const [localFoods, nutranixFoods] = await Promise.all([
			prisma.food.findMany({
				where: {
					OR: [
						{ foodName: { contains: q ?? "", mode: "insensitive" } },
						{ brandName: { contains: q ?? "", mode: "insensitive" } },
					],
					AND: [
						{
							OR: [
								{ userId: null }, // System foods
								{ userId }, // User's custom foods
							],
						},
					],
				},
				orderBy: {
					createdAt: "desc",
				},
				take: 20,
			}),
			NutranixService.searchProducts(q ?? ""),
		]).catch((error) => {
			console.error(error);
			return [];
		});

		if (nutranixFoods.length === 0) {
			return localFoods;
		}

		const nixIds = nutranixFoods
			.map((food) => food?.nix_item_id || food?.tag_id)
			.filter((id) => id !== undefined)
			.filter((id) => id !== null);

		const existingFoods = await prisma.food.findMany({
			where: {
				OR: [{ nixId: { in: nixIds as string[] } }],
			},
		});

		const data = nutranixFoods
			.filter(
				(food) =>
					!existingFoods.some(
						(f) => f.nixId === food.nix_item_id || f.nixId === food.tag_id,
					),
			)
			.filter(
				(food) =>
					!localFoods.some(
						(f) => f.nixId === food.nix_item_id || f.nixId === food.tag_id,
					),
			)
			.map((food) => ({
				calories: food.nf_calories / (food.serving_qty ?? 1) || 0,
				foodName: food.food_name,
				serving: food.serving_qty?.toString() || "1",
				servingSize: food.serving_unit || "",
				brandName: food.brand_name || null,
				nixId: food?.nix_item_id ?? food?.tag_id,
			}));

		try {
			const createdFoods = await prisma.food.createManyAndReturn({
				data: data,
			});

			// const allFoods = [
			//   ...createdFoods,
			//   ...existingFoods.filter(
			//     (f) => !localFoods.some((lf) => lf.nixId === f.nixId)
			//   ),
			//   ...localFoods,
			// ];

			const allFoods = [
				...nutranixFoods.map((itm) => {
					const createdFood = createdFoods.find((f) =>
						[itm.nix_item_id, itm.tag_id].includes(f.nixId ?? ""),
					);
					const existingFood = existingFoods.find((f) =>
						[itm.nix_item_id, itm.tag_id].includes(f.nixId ?? ""),
					);
					return {
						...(createdFood ?? existingFood),
						serving: itm.serving_qty.toString(),
						calories: itm.nf_calories,
					} as z.infer<typeof FoodSchema>;
				}),
				...localFoods,
			];

			// sort alphabetically by foodName
			// return allFoods.sort((a, b) => {
			//   return a.foodName.localeCompare(b.foodName);
			// });

			return allFoods;
		} catch (error) {
			console.error(error);
			throw new Error("Failed to store nutranix foods in the database");
		}
	}

	static async getFood(userId: string, id: string, hardFetch?: boolean) {
		console.log("[FoodService -> getFood] Getting food", id, hardFetch);
		const food = await prisma.food.findFirst({
			where: {
				id,
				OR: [
					{ userId: null }, // System foods
					{ userId }, // User's custom foods
				],
			},
		});

		if (!food) {
			throw new Error("Food not found", {
				cause: "FOOD_NOT_FOUND",
			});
		}

		console.log(
			"[FoodService -> getFood] food",
			food.nixId,
			food.synced,
			hardFetch,
		);
		if (food.synced && !hardFetch) {
			return food;
		}

		try {
			const nutranixFoodWithNutrients =
				await NutranixService.getProductByBarcode({
					nixItemId: food.nixId ?? "",
				});

			console.log(
				"[FoodService -> getFood] nutranixFoodWithNutrients",
				nutranixFoodWithNutrients,
			);

			const data = {
				foodName: nutranixFoodWithNutrients.food_name,
				serving: nutranixFoodWithNutrients.serving_qty.toString(),
				servingSize: nutranixFoodWithNutrients.serving_unit,
				brandName: nutranixFoodWithNutrients.brand_name,
				synced: true,
			} as Partial<Food>;

			for (const nutrient of nutranixFoodWithNutrients.full_nutrients ?? []) {
				const nutrientId = nutrient.attr_id;
				const nutrientValue = nutrient.value;

				if (nutrientId in NutritionAttributeIdToKey) {
					Object.assign(data, {
						[NutritionAttributeIdToKey[nutrientId]]:
							nutrientValue *
							(Multiplier[NutritionAttributeIdToKey[nutrientId]] ?? 1),
					});
				}
			}

			// store the nutranix foods in the database
			const createdFood = await prisma.food.update({
				where: { id: food.id },
				data: data,
			});

			// console.log("Created", createdFoods.count, "foods");
			return createdFood;
		} catch (error) {
			console.error(error);
			return food;
		}
	}

	static async createFood(
		userId: string,
		params: z.infer<typeof CreateFoodParams>,
	) {
		const serving = params.serving.trim().split(" ");
		return await prisma.food.create({
			data: {
				...params,
				serving: serving[0],
				servingSize: serving[1],
				userId,
			},
		});
	}

	static async createFoodLog(
		userId: string,
		params: z.infer<typeof CreateFoodLogParams>,
	) {
		// Verify the food exists and user has access to it
		const food = await FoodService.getFood(userId, params.foodId);

		if (!food) {
			throw new Error("Food not found", {
				cause: "FOOD_NOT_FOUND",
			});
		}

		return await prisma.foodLog.create({
			data: {
				...params,
				servings: params.servings,
				servingSize: food.servingSize ?? "",
				userId,
				meal: params.meal as MealType,
			},
			include: {
				food: true,
			},
		});
	}

	static async getFoodLogs(
		userId: string,
		params: z.infer<typeof GetFoodLogParams>,
	) {
		const { startDate, endDate, meal } = params;

		return await prisma.foodLog.findMany({
			where: {
				userId,
				date: {
					gte: startDate,
					lte: endDate,
				},
				meal: meal as MealType,
			},
			include: {
				food: true,
			},
			orderBy: {
				date: "desc",
			},
		});
	}

	static async getFoodLogById(userId: string, id: string) {
		const foodLog = await prisma.foodLog.findUnique({
			where: { id, userId },
			include: {
				food: true,
			},
		});

		if (!foodLog) {
			throw new Error("Food log not found", {
				cause: "FOOD_LOG_NOT_FOUND",
			});
		}

		return foodLog;
	}

	static async updateFoodLog(
		id: string,
		params: z.infer<typeof UpdateFoodLogParams>,
	): Promise<z.infer<typeof UpdateFoodLogResponse>> {
		const foodLog = await prisma.foodLog.findUnique({
			where: { id },
			include: { food: true },
		});

		if (!foodLog) {
			throw new Error("Food log not found", {
				cause: "FOOD_LOG_NOT_FOUND",
			});
		}

		const updatedFoodLog = await prisma.foodLog.update({
			where: { id },
			data: {
				...params,
				meal: params.meal as MealType,
			},
			include: { food: true },
		});

		return updatedFoodLog;
	}

	static async deleteFoodLog(userId: string, id: string) {
		const foodLog = await prisma.foodLog.findFirst({
			where: { id, userId },
		});

		if (!foodLog) {
			throw new Error("Food log not found", {
				cause: "FOOD_LOG_NOT_FOUND",
			});
		}

		await prisma.foodLog.delete({
			where: { id },
		});

		return { message: "Food log deleted successfully" };
	}

	static async getRecentFoods(
		userId: string,
		limit = 10,
		search?: string | null,
	) {
		// Get recent foods from food logs
		const recentFoodLogs = await prisma.foodLog.findMany({
			where: { userId },
			include: { food: true },
			orderBy: { createdAt: "desc" },
			distinct: ["foodId"],
			take: limit,
			...(search && {
				where: {
					food: {
						foodName: { contains: search, mode: "insensitive" },
						brandName: { contains: search, mode: "insensitive" },
					},
				},
			}),
		});

		// Remove duplicates and get unique foods
		const uniqueFoods = new Map();
		for (const log of recentFoodLogs) {
			if (log.food && !uniqueFoods.has(log.food.id)) {
				uniqueFoods.set(log.food.id, log.food);
			}
			if (uniqueFoods.size >= limit) break;
		}

		return Array.from(uniqueFoods.values());
	}
}
