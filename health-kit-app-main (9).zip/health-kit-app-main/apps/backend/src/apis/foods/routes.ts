import { createRoute, z } from "@hono/zod-openapi";
import {
	SearchFoodsParams,
	SearchFoodsResponse,
	CreateFoodParams,
	CreateFoodResponse,
	GetFoodParams,
	GetFoodResponse,
	CreateFoodLogParams,
	CreateFoodLogResponse,
	GetFoodLogParams,
	GetFoodLogsResponse,
	GetFoodQuery,
	UpdateFoodLogParams,
	UpdateFoodLogResponse,
	GetFoodLogByIdResponse,
	GetFoodLogByIdParams,
	DeleteFoodLogParams,
	DeleteFoodLogResponse,
	GetRecentFoodsParams,
	GetRecentFoodsResponse,
} from "./models";
import jsonContent from "../../helpers/json-content";

const searchFoodsRoute = createRoute({
	method: "get",
	path: "/search",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		query: SearchFoodsParams,
	},
	responses: {
		200: jsonContent(SearchFoodsResponse, "Search Foods Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Food"],
});

const createFoodRoute = createRoute({
	method: "post",
	path: "/",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		body: jsonContent(CreateFoodParams, "Create Food Request"),
	},
	responses: {
		201: jsonContent(CreateFoodResponse, "Create Food Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Food"],
});

const getFoodRoute = createRoute({
	method: "get",
	path: "/{id}",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: GetFoodParams,
		query: GetFoodQuery,
	},
	responses: {
		200: jsonContent(GetFoodResponse, "Get Food Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Food"],
});

const createFoodLogRoute = createRoute({
	method: "post",
	path: "/log",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		body: jsonContent(CreateFoodLogParams, "Create Food Log Request"),
	},
	responses: {
		201: jsonContent(CreateFoodLogResponse, "Create Food Log Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Food"],
});

const getFoodLogRoute = createRoute({
	method: "get",
	path: "/log",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		query: GetFoodLogParams,
	},
	responses: {
		200: jsonContent(GetFoodLogsResponse, "Get Food Log Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Food"],
});

const getFoodLogByIdRoute = createRoute({
	method: "get",
	path: "/log/{id}",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: GetFoodLogByIdParams,
	},
	responses: {
		200: jsonContent(GetFoodLogByIdResponse, "Get Food Log Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Food"],
});

const updateFoodLogRoute = createRoute({
	method: "put",
	path: "/log/{id}",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		body: jsonContent(UpdateFoodLogParams, "Update Food Log Request"),
		params: z.object({
			id: z.string(),
		}),
	},
	responses: {
		200: jsonContent(UpdateFoodLogResponse, "Update Food Log Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Food"],
});

const deleteFoodLogRoute = createRoute({
	method: "delete",
	path: "/log/{id}",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		params: DeleteFoodLogParams,
	},
	responses: {
		200: jsonContent(DeleteFoodLogResponse, "Delete Food Log Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Food"],
});

const getRecentFoodsRoute = createRoute({
	method: "get",
	path: "/recent",
	request: {
		headers: z.object({
			"x-api-key": z.string(),
		}),
		query: GetRecentFoodsParams,
	},
	responses: {
		200: jsonContent(GetRecentFoodsResponse, "Get Recent Foods Response"),
		400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
	},
	tags: ["Food"],
});

const foodRoutes = {
	searchFoodsRoute,
	createFoodRoute,
	getFoodRoute,
	createFoodLogRoute,
	getFoodLogRoute,
	updateFoodLogRoute,
	getFoodLogByIdRoute,
	deleteFoodLogRoute,
	getRecentFoodsRoute,
};

export default foodRoutes;

export type SearchFoodsRoute = typeof searchFoodsRoute;
export type CreateFoodRoute = typeof createFoodRoute;
export type GetFoodRoute = typeof getFoodRoute;
export type CreateFoodLogRoute = typeof createFoodLogRoute;
export type GetFoodLogRoute = typeof getFoodLogRoute;
export type UpdateFoodLogRoute = typeof updateFoodLogRoute;
export type GetFoodLogByIdRoute = typeof getFoodLogByIdRoute;
export type DeleteFoodLogRoute = typeof deleteFoodLogRoute;
export type GetRecentFoodsRoute = typeof getRecentFoodsRoute;
