// import { MealType } from "@prisma/client";
import { z } from "zod";

export const NutritionFactsSchema = z.object({
	calories: z.number(),
	totalFat: z.number().optional().nullable(),
	saturatedFat: z.number().optional().nullable(),
	polyunsaturatedFat: z.number().optional().nullable(),
	monounsaturatedFat: z.number().optional().nullable(),
	cholesterol: z.number().optional().nullable(),
	sodium: z.number().optional().nullable(),
	totalCarbohydrates: z.number().optional().nullable(),
	dietaryFiber: z.number().optional().nullable(),
	sugars: z.number().optional().nullable(),
	protein: z.number().optional().nullable(),
	calcium: z.number().optional().nullable(),
	iron: z.number().optional().nullable(),
	potassium: z.number().optional().nullable(),
	vitaminA: z.number().optional().nullable(),
	vitaminC: z.number().optional().nullable(),
});

export const FoodSchema = z.object({
	id: z.string(),
	foodName: z.string(),
	brandName: z.string().optional().nullable(),
	serving: z.string(),
	userId: z.string().optional().nullable(),
	createdAt: z.coerce.date(),
	updatedAt: z.coerce.date(),
	...NutritionFactsSchema.shape,
});

export const SearchFoodsParams = z.object({
	q: z.string().optional().nullable(),
	barcode: z.string().optional().nullable(),
	hardFetch: z.coerce.boolean().optional().nullable(),
});

export const SearchFoodsResponse = z.array(FoodSchema);

export const CreateFoodParams = FoodSchema.omit({
	id: true,
	createdAt: true,
	updatedAt: true,
	userId: true,
});

export const CreateFoodResponse = FoodSchema;

export const GetFoodParams = z.object({
	id: z.string(),
});

export const GetFoodQuery = z.object({
	hardFetch: z.coerce.boolean().optional().nullable(),
});

export const GetFoodResponse = FoodSchema;

export const FoodLogSchema = z.object({
	id: z.string(),
	userId: z.string(),
	foodId: z.string(),
	date: z.coerce.date(),
	servings: z.number(),
	servingSize: z.string(),
	meal: z.string(), // z.nativeEnum(MealType),
	createdAt: z.coerce.date(),
	updatedAt: z.coerce.date(),
	food: FoodSchema.optional(),
});

export const CreateFoodLogParams = z.object({
	foodId: z.string(),
	servings: z.number(),
	servingSize: z.string(),
	meal: z.string(), // z.nativeEnum(MealType),
	date: z.coerce.date(),
});

export const CreateFoodLogResponse = FoodLogSchema;

export const GetFoodLogParams = z.object({
	startDate: z.coerce.date().optional(),
	endDate: z.coerce.date().optional(),
	meal: z.string().optional(), // z.nativeEnum(MealType).optional(),
});

export const GetFoodLogsResponse = z.array(FoodLogSchema);

export const GetFoodLogByIdParams = z.object({
	id: z.string(),
});

export const GetFoodLogByIdResponse = FoodLogSchema;

export const UpdateFoodLogParams = z.object({
	servings: z.number().optional(),
	servingSize: z.string().optional(),
	meal: z.string().optional(), // z.nativeEnum(MealType).optional(),
});

export const UpdateFoodLogResponse = FoodLogSchema;

export const DeleteFoodLogParams = z.object({
	id: z.string(),
});

export const DeleteFoodLogResponse = z.object({
	message: z.string(),
});

export const GetRecentFoodsParams = z.object({
	search: z.string().optional().nullable().default(null),
	limit: z.coerce.number().optional().default(10),
});

export const GetRecentFoodsResponse = z.array(FoodSchema);
