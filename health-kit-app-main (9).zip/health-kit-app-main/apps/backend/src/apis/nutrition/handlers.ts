import { AppRouteHandler } from "../../lib/types";
import {
  CreateNutritionRoute,
  GetNutritionRoute,
  ListNutritionRoute,
  UpdateNutritionRoute,
} from "./routes";
import NutritionService from "./service";
import AuthHelper from "../../helpers/auth";

const listNutritionHandler: AppRouteHandler<ListNutritionRoute> = async (c) => {
  const { page, limit, filter } = c.req.valid("query");
  try {
    return c.json(
      await NutritionService.listNutrition({ page, limit, filter }),
      200
    );
  } catch (error: any) {
    return c.json({ cause: error.cause }, 400);
  }
};

const getNutritionHandler: AppRouteHandler<GetNutritionRoute> = async (c) => {
  const { id } = c.req.valid("param");
  try {
    return c.json(await NutritionService.getNutrition(id), 200);
  } catch (error: any) {
    return c.json({ cause: error.cause }, 400);
  }
};

const createNutritionHandler: AppRouteHandler<CreateNutritionRoute> = async (
  c
) => {
  const params = c.req.valid("json");
  try {
    const xApiKey = c.req.header("x-api-key");
    if (!xApiKey) {
      throw new Error("x-api-key header is required", {
        cause: "AUTHORIZATION_HEADER_REQUIRED",
      });
    }
    const user = await AuthHelper.verifyToken(xApiKey).catch(() => {
      throw new Error("Invalid x-api-key header", {
        cause: "INVALID_API_KEY",
      });
    });

    return c.json(await NutritionService.createNutrition(user.id, params), 200);
  } catch (error: any) {
    return c.json({ cause: error.cause }, 400);
  }
};

const updateNutritionHandler: AppRouteHandler<UpdateNutritionRoute> = async (
  c
) => {
  const { id } = c.req.valid("param");
  const params = await c.req.json();

  try {
    const xApiKey = c.req.header("x-api-key");
    if (!xApiKey) {
      throw new Error("x-api-key header is required", {
        cause: "AUTHORIZATION_HEADER_REQUIRED",
      });
    }

    await AuthHelper.verifyToken(xApiKey).catch(() => {
      throw new Error("Invalid x-api-key header", {
        cause: "INVALID_API_KEY",
      });
    });

    return c.json(await NutritionService.updateNutrition(id, params), 200);
  } catch (error: any) {
    return c.json({ cause: error.cause }, 400);
  }
};

const nutritionHandlers = {
  listNutritionHandler,
  getNutritionHandler,
  createNutritionHandler,
  updateNutritionHandler,
};

export default nutritionHandlers;
