import { z } from "zod";
import {
  CreateBulkNutritionParams,
  CreateNutritionResponse,
  GetNutritionResponse,
  ListNutritionParams,
  ListNutritionResponse,
  UpdateNutritionParams,
  UpdateNutritionResponse,
} from "./models";
import { prisma } from "../../db/client";

export default class NutritionService {
  static async listNutrition(
    params: z.infer<typeof ListNutritionParams>
  ): Promise<z.infer<typeof ListNutritionResponse>> {
    const { page = 1, limit = 10, filter } = params;

    const filterObject = filter ? JSON.parse(filter) : {};

    const [nutritionResources, total] = await Promise.all([
      prisma.nutrition.findMany({
        where: filterObject,
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.nutrition.count({
        where: filterObject,
      }),
    ]);

    return {
      data: nutritionResources,
      pagination: { page, limit, total },
    };
  }

  static async getNutrition(
    id: string
  ): Promise<z.infer<typeof GetNutritionResponse>> {
    const nutrition = await prisma.nutrition.findUnique({
      where: { id },
    });

    if (!nutrition) {
      throw new Error("Nutrition not found", {
        cause: "NUTRITION_NOT_FOUND",
      });
    }

    return nutrition;
  }

  static async createNutrition(
    userId: string,
    params: z.infer<typeof CreateBulkNutritionParams>
  ): Promise<z.infer<typeof CreateNutritionResponse>> {
    const existingNutritions = await prisma.nutrition.findMany({
      where: {
        hkId: {
          in: params.map((item) => item.hkId),
        },
      },
    });

    if (existingNutritions) {
      existingNutritions.map(
        async (existingNutrition) =>
          await this.updateNutrition(
            existingNutrition.id,
            params.find((item) => item.hkId === existingNutrition.hkId)!
          )
      );
    }

    const newNutritions = params.filter(
      (item) => !existingNutritions.find((ex) => ex.hkId === item.hkId)
    );

    if (newNutritions.length > 0)
      await prisma.nutrition
        .createMany({
          data: newNutritions.map((nut) => ({ userId, ...nut })),
        })
        .catch((error: any) => {
          throw new Error("Failed to create nutrition", {
            cause: error.message,
          });
        });

    return "Saved";
  }

  static async updateNutrition(
    id: string,
    params: z.infer<typeof UpdateNutritionParams>
  ): Promise<z.infer<typeof UpdateNutritionResponse>> {
    const nutrition = await prisma.nutrition
      .findUnique({
        where: { id },
      })
      .catch(() => {
        throw new Error("Nutrition not found", {
          cause: "NUTRITION_NOT_FOUND",
        });
      });

    if (!nutrition) {
      throw new Error("Nutrition not found", {
        cause: "NUTRITION_NOT_FOUND",
      });
    }

    const updatedNutrition = await prisma.nutrition.update({
      where: { id },
      data: params,
    });

    return updatedNutrition;
  }

  static async findNutritionByDate(userId: string, date: Date) {
    return await prisma.nutrition.findFirst({
      where: {
        userId,
        date,
      },
    });
  }
}
