import { createRouter } from "../../lib/create-app";
import nutritionHandlers from "./handlers";
import nutritionRoutes from "./routes";
import foodRoutes from "../foods/routes";
import foodHandlers from "../foods/handlers";

const router = createRouter()
  // Nutrition routes
  .openapi(
    nutritionRoutes.listNutritionRoute,
    nutritionHandlers.listNutritionHandler
  )
  .openapi(
    nutritionRoutes.getNutritionRoute,
    nutritionHandlers.getNutritionHandler
  )
  .openapi(
    nutritionRoutes.createNutritionRoute,
    nutritionHandlers.createNutritionHandler
  )
  .openapi(
    nutritionRoutes.updateNutritionRoute,
    nutritionHandlers.updateNutritionHandler
  );

export default router;
