import { createRoute, z } from "@hono/zod-openapi";
import {
  GetNutritionQuery,
  GetNutritionResponse,
  ListNutritionParams,
  ListNutritionResponse,
  CreateNutritionResponse,
  UpdateNutritionParams,
  UpdateNutritionResponse,
  CreateBulkNutritionParams,
} from "./models";
import jsonContent from "../../helpers/json-content";

const listNutritionRoute = createRoute({
  method: "get",
  path: "/",
  request: {
    headers: z.object({
      "x-api-key": z.string(),
    }),
    query: ListNutritionParams,
  },
  responses: {
    200: jsonContent(ListNutritionResponse, "List Nutrition Response"),
    400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
  },
  tags: ["Nutrition"],
});

const getNutritionRoute = createRoute({
  method: "get",
  path: "/{id}",
  request: {
    headers: z.object({
      "x-api-key": z.string(),
    }),
    params: z.object({
      id: z.string(),
    }),
  },
  responses: {
    200: jsonContent(GetNutritionResponse, "Get Nutrition Response"),
    400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
  },
  tags: ["Nutrition"],
});

const createNutritionRoute = createRoute({
  method: "post",
  path: "/",
  request: {
    headers: z.object({
      "x-api-key": z.string(),
    }),
    body: jsonContent(CreateBulkNutritionParams, "Create Nutrition Request"),
  },
  responses: {
    200: jsonContent(CreateNutritionResponse, "Create Nutrition Response"),
    400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
  },
  tags: ["Nutrition"],
});

const updateNutritionRoute = createRoute({
  method: "put",
  path: "/{id}",
  request: {
    headers: z.object({
      "x-api-key": z.string(),
    }),
    params: z.object({
      id: z.string(),
    }),
    body: jsonContent(UpdateNutritionParams, "Update Nutrition Request"),
  },
  responses: {
    200: jsonContent(UpdateNutritionResponse, "Update Nutrition Response"),
    400: jsonContent(z.object({ cause: z.string() }), "Bad Request"),
  },
  tags: ["Nutrition"],
});

const nutritionRoutes = {
  listNutritionRoute,
  getNutritionRoute,
  createNutritionRoute,
  updateNutritionRoute,
};

export default nutritionRoutes;

export type ListNutritionRoute = typeof listNutritionRoute;
export type GetNutritionRoute = typeof getNutritionRoute;
export type CreateNutritionRoute = typeof createNutritionRoute;
export type UpdateNutritionRoute = typeof updateNutritionRoute;
