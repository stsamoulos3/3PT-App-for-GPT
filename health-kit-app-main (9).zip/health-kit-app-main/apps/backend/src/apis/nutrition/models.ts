import { z } from "zod";

export const NutritionSchema = z.object({
  id: z.string(),
  userId: z.string(),
  date: z.coerce.date(),
  hkId: z.string(),
  quantity: z.coerce.number(),
  quantityType: z.string(),
  quantityUnit: z.string(),
  createdAt: z.coerce.date(),
  updatedAt: z.coerce.date(),
});

export const ListNutritionParams = z.object({
  page: z.coerce.number().optional().openapi("page", { default: 1 }),
  limit: z.coerce.number().optional().openapi("limit", { default: 10 }),
  filter: z.string().optional().openapi("filter"),
});

export const ListNutritionResponse = z.object({
  data: z.array(NutritionSchema),
  pagination: z.object({
    page: z.number(),
    limit: z.number(),
    total: z.number(),
  }),
});

export const GetNutritionQuery = z.object({
  id: z.string(),
});

export const GetNutritionResponse = NutritionSchema;

export const CreateBulkNutritionParams = z.array(
  NutritionSchema.omit({
    createdAt: true,
    id: true,
    updatedAt: true,
    userId: true,
  })
);

export const CreateNutritionResponse = z.string();

export const UpdateNutritionParams = z.object({
  date: z.coerce.date().optional(),
  caloriesConsumedKcal: z.number().optional(),
  proteinGrams: z.number().optional(),
  carbohydratesGrams: z.number().optional(),
  fatGrams: z.number().optional(),
});

export const UpdateNutritionResponse = NutritionSchema;
