import nodemailer from "nodemailer";
import { z } from "zod";

// Email configuration schema for validation
const EmailConfigSchema = z.object({
  host: z.string(),
  port: z.number(),
  secure: z.boolean().optional(),
  auth: z.object({
    user: z.string(),
    pass: z.string(),
  }),
});

// Email options schema
const EmailOptionsSchema = z.object({
  to: z.string().email(),
  subject: z.string(),
  html: z.string(),
  text: z.string().optional(),
});

type EmailConfig = z.infer<typeof EmailConfigSchema>;
type EmailOptions = z.infer<typeof EmailOptionsSchema>;

class EmailHelper {
  private transporter: nodemailer.Transporter;
  private fromAddress: string;
  private appName: string;
  private frontendUrl: string;

  constructor() {
    // Initialize configuration from environment variables
    const config: EmailConfig = {
      host: process.env.SMTP_HOST || "smtp.gmail.com",
      port: parseInt(process.env.SMTP_PORT || "587"),
      secure: process.env.SMTP_SECURE === "true",
      auth: {
        user: process.env.SMTP_USER || "",
        pass: process.env.SMTP_PASS || "",
      },
    };

    this.fromAddress = process.env.FROM_EMAIL || process.env.SMTP_USER || "";
    this.appName = process.env.APP_NAME || "3PT Healthcare";
    this.frontendUrl = process.env.FRONTEND_URL || "http://localhost:3000";

    // Validate configuration
    EmailConfigSchema.parse(config);

    if (!this.fromAddress) {
      throw new Error(
        "FROM_EMAIL or SMTP_USER must be defined in environment variables"
      );
    }

    // Create nodemailer transporter
    this.transporter = nodemailer.createTransport({
      host: config.host,
      port: config.port,
      secure: config.secure,
      auth: config.auth,
      tls: {
        rejectUnauthorized: true,
        minVersion: "TLSv1.2",
      },
    });
  }

  /**
   * Verify the email connection
   */
  async verifyConnection(): Promise<boolean> {
    try {
      await this.transporter.verify();
      return true;
    } catch (error) {
      console.error("Email connection verification failed:", error);
      return false;
    }
  }

  /**
   * Send a generic email
   */
  async sendEmail(options: EmailOptions): Promise<void> {
    const validatedOptions = EmailOptionsSchema.parse(options);

    const mailOptions = {
      from: `"${this.appName}" <${this.fromAddress}>`,
      to: validatedOptions.to,
      subject: validatedOptions.subject,
      html: validatedOptions.html,
      text: validatedOptions.text,
    };

    try {
      const info = await this.transporter.sendMail(mailOptions);
      console.log("Email sent successfully:", info.messageId);
    } catch (error) {
      console.error("Failed to send email:", error);
      throw new Error("Failed to send email");
    }
  }

  /**
   * Generate reset URL based on environment
   */
  private generateResetUrl(resetToken: string): string {
    const frontendUrl = this.frontendUrl;

    // Check if it's a mobile deep link or web URL
    if (
      frontendUrl.startsWith("exp://") ||
      frontendUrl.startsWith("healthapp://")
    ) {
      // Mobile deep link format
      return `${frontendUrl}/auth/reset-password?token=${resetToken}`;
    } else {
      // Web URL format
      return `${frontendUrl}/auth/reset-password?token=${resetToken}`;
    }
  }

  /**
   * Generate verification URL based on environment
   */
  private generateVerificationUrl(verificationToken: string): string {
    const frontendUrl = this.frontendUrl;

    // Check if it's a mobile deep link or web URL
    if (
      frontendUrl.startsWith("exp://") ||
      frontendUrl.startsWith("healthapp://")
    ) {
      // Mobile deep link format
      return `${frontendUrl}/auth/verify-email?token=${verificationToken}`;
    } else {
      // Web URL format
      return `${frontendUrl}/auth/verify-email?token=${verificationToken}`;
    }
  }

  /**
   * Send email verification email
   */
  async sendEmailVerification(
    email: string,
    verificationToken: string
  ): Promise<void> {
    const verificationUrl = this.generateVerificationUrl(verificationToken);

    const html = this.generateEmailVerificationTemplate(verificationUrl);
    const text = this.generateEmailVerificationText(verificationUrl);

    await this.sendEmail({
      to: email,
      subject: `Verify your ${this.appName} account`,
      html,
      text,
    });
  }

  /**
   * Send password reset email
   */
  async sendPasswordReset(email: string, resetToken: string): Promise<void> {
    const resetUrl = this.generateResetUrl(resetToken);

    const html = this.generatePasswordResetTemplate(resetUrl);
    const text = this.generatePasswordResetText(resetUrl);

    await this.sendEmail({
      to: email,
      subject: `Reset your ${this.appName} password`,
      html,
      text,
    });
  }

  /**
   * Send welcome email after successful verification
   */
  async sendWelcomeEmail(email: string, firstName?: string): Promise<void> {
    const html = this.generateWelcomeTemplate(firstName);
    const text = this.generateWelcomeText(firstName);

    await this.sendEmail({
      to: email,
      subject: `Welcome to ${this.appName}!`,
      html,
      text,
    });
  }

  /**
   * Send password change confirmation email
   */
  async sendPasswordChangeConfirmation(email: string): Promise<void> {
    const html = this.generatePasswordChangeTemplate();
    const text = this.generatePasswordChangeText();

    await this.sendEmail({
      to: email,
      subject: `${this.appName} password changed`,
      html,
      text,
    });
  }

  /**
   * Generate HTML template for email verification
   */
  private generateEmailVerificationTemplate(verificationUrl: string): string {
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verify Your Email</title>
        <style>
          * { box-sizing: border-box; }
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            line-height: 1.6; 
            color: rgb(55, 65, 81); 
            max-width: 600px; 
            margin: 0 auto; 
            padding: 0; 
            background-color: rgb(249, 250, 251);
          }
          .container {
            background-color: rgb(255, 255, 255);
            margin: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            overflow: hidden;
          }
          .header { 
            background: linear-gradient(135deg, rgb(65, 118, 204) 0%, rgb(72, 159, 243) 100%);
            color: white; 
            padding: 40px 30px; 
            text-align: center; 
          }
          .header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            letter-spacing: -0.025em;
          }
          .content { 
            background-color: rgb(255, 255, 255); 
            padding: 40px 30px; 
          }
          .content p {
            margin: 0 0 16px 0;
            font-size: 16px;
            color: rgb(55, 65, 81);
          }
          .button-container {
            text-align: center;
            margin: 32px 0;
          }
          .button { 
            display: inline-block; 
          background: linear-gradient(135deg, rgb(65, 118, 204) 0%, rgb(72, 159, 243) 100%);
            color: white; 
            padding: 16px 32px; 
            text-decoration: none; 
            border-radius: 8px; 
            font-weight: 600;
            font-size: 16px;
            transition: all 0.2s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
          }
          .button:hover {
            transform: translateY(-1px);
            box-shadow: 0 8px 12px -1px rgba(0, 0, 0, 0.15);
          }
          .link-box {
            background-color: rgb(249, 250, 251);
            padding: 16px;
            border-radius: 8px;
            border-left: 4px solid rgb(65, 118, 204);
            margin: 20px 0;
            word-break: break-all;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            color: rgb(75, 85, 99);
          }
          .warning-box {
            background-color: rgb(243, 248, 253);
            border: 1px solid rgb(191, 213, 242);
            padding: 20px;
            border-radius: 8px;
            margin: 24px 0;
            border-left: 4px solid rgb(65, 118, 204);
          }
          .warning-box strong {
            color: rgb(39, 71, 122);
            display: block;
            margin-bottom: 8px;
            font-size: 16px;
          }
          .footer { 
            background-color: rgb(249, 250, 251);
            margin-top: 32px; 
            padding: 24px 30px; 
            border-top: 1px solid rgb(229, 231, 235); 
            font-size: 14px; 
            color: rgb(107, 114, 128);
            text-align: center;
          }
          .logo {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
          }
          @media only screen and (max-width: 600px) {
            .container { margin: 10px; }
            .header, .content, .footer { padding: 24px 20px; }
            .header h1 { font-size: 24px; }
            .button { padding: 14px 28px; font-size: 15px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">${this.appName}</div>
            <h1>Verify Your Email Address</h1>
          </div>
          <div class="content">
            <p>Thank you for signing up for <strong>${this.appName}</strong>!</p>
            <p>To complete your registration and start using your account, please verify your email address by clicking the button below:</p>
            
            <div class="button-container">
              <a href="${verificationUrl}" class="button">Verify Email Address</a>
            </div>
            
            <p>If the button doesn't work, you can also copy and paste this link into your browser:</p>
            <div class="link-box">${verificationUrl}</div>
            
            <div class="warning-box">
              <strong>⏰ Important Security Information</strong>
              <p style="margin: 0;">This verification link will expire in <strong>24 hours</strong> for security reasons. If you didn't create an account with ${this.appName}, please ignore this email.</p>
            </div>
          </div>
          <div class="footer">
            <p style="margin: 0;">This is an automated message from <strong>${this.appName}</strong>. Please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Generate plain text for email verification
   */
  private generateEmailVerificationText(verificationUrl: string): string {
    return `
      Verify Your Email Address

      Thank you for signing up for ${this.appName}!

      To complete your registration and start using your account, please verify your email address by visiting this link:

      ${verificationUrl}

      Important: This verification link will expire in 24 hours for security reasons.

      If you didn't create an account with ${this.appName}, please ignore this email.

      ---
      This is an automated message from ${this.appName}. Please do not reply to this email.
    `;
  }

  /**
   * Generate HTML template for password reset
   */
  private generatePasswordResetTemplate(resetUrl: string): string {
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reset Your Password</title>
        <style>
          * { box-sizing: border-box; }
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            line-height: 1.6; 
            color: rgb(55, 65, 81); 
            max-width: 600px; 
            margin: 0 auto; 
            padding: 0; 
            background-color: rgb(249, 250, 251);
          }
          .container {
            background-color: rgb(255, 255, 255);
            margin: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            overflow: hidden;
          }
          .header { 
            background: linear-gradient(135deg, rgb(65, 118, 204) 0%, rgb(72, 159, 243) 100%);
            color: white; 
            padding: 40px 30px; 
            text-align: center; 
          }
          .header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            letter-spacing: -0.025em;
          }
          .content { 
            background-color: rgb(255, 255, 255); 
            padding: 40px 30px; 
          }
          .content p {
            margin: 0 0 16px 0;
            font-size: 16px;
            color: rgb(55, 65, 81);
          }
          .button-container {
            text-align: center;
            margin: 32px 0;
          }
          .button { 
            display: inline-block; 
            background: linear-gradient(135deg, rgb(65, 118, 204) 0%, rgb(52, 94, 163) 100%);
            color: white; 
            padding: 16px 32px; 
            text-decoration: none; 
            border-radius: 8px; 
            font-weight: 600;
            font-size: 16px;
            transition: all 0.2s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
          }
          .button:hover {
            transform: translateY(-1px);
            box-shadow: 0 8px 12px -1px rgba(0, 0, 0, 0.15);
          }
          .link-box {
            background-color: rgb(249, 250, 251);
            padding: 16px;
            border-radius: 8px;
            border-left: 4px solid rgb(65, 118, 204);
            margin: 20px 0;
            word-break: break-all;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            color: rgb(75, 85, 99);
          }
          .warning-box {
            background-color: rgb(243, 248, 253);
            border: 1px solid rgb(191, 213, 242);
            padding: 24px;
            border-radius: 8px;
            margin: 24px 0;
            border-left: 4px solid rgb(65, 118, 204);
          }
          .warning-box strong {
            color: rgb(39, 71, 122);
            display: block;
            margin-bottom: 12px;
            font-size: 16px;
          }
          .warning-box ul {
            margin: 8px 0;
            padding-left: 20px;
          }
          .warning-box li {
            margin-bottom: 6px;
            color: rgb(52, 94, 163);
          }
          .footer { 
            background-color: rgb(249, 250, 251);
            margin-top: 32px; 
            padding: 24px 30px; 
            border-top: 1px solid rgb(229, 231, 235); 
            font-size: 14px; 
            color: rgb(107, 114, 128);
            text-align: center;
          }
          .logo {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
          }
          @media only screen and (max-width: 600px) {
            .container { margin: 10px; }
            .header, .content, .footer { padding: 24px 20px; }
            .header h1 { font-size: 24px; }
            .button { padding: 14px 28px; font-size: 15px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">${this.appName}</div>
            <h1>Reset Your Password</h1>
          </div>
          <div class="content">
            <p>We received a request to reset the password for your <strong>${this.appName}</strong> account.</p>
            <p>To reset your password, click the button below:</p>
            
            <div class="button-container">
              <a href="${resetUrl}" class="button">Reset Password</a>
            </div>
            
            <p>If the button doesn't work, you can also copy and paste this link into your browser:</p>
            <div class="link-box">${resetUrl}</div>
            
            <div class="warning-box">
              <strong>🔒 Important Security Information</strong>
              <ul>
                <li>This password reset link will expire in <strong>1 hour</strong></li>
                <li>If you didn't request this password reset, please ignore this email</li>
                <li>For security, never share this link with anyone</li>
              </ul>
            </div>
            
            <p>If you continue to have problems, please contact our support team.</p>
          </div>
          <div class="footer">
            <p style="margin: 0;">This is an automated message from <strong>${this.appName}</strong>. Please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Generate plain text for password reset
   */
  private generatePasswordResetText(resetUrl: string): string {
    return `
      Reset Your Password

      We received a request to reset the password for your ${this.appName} account.

      To reset your password, visit this link:

      ${resetUrl}

      Important Security Information:
      - This password reset link will expire in 1 hour
      - If you didn't request this password reset, please ignore this email
      - For security, never share this link with anyone

      If you continue to have problems, please contact our support team.

      ---
      This is an automated message from ${this.appName}. Please do not reply to this email.
    `;
  }

  /**
   * Generate HTML template for welcome email
   */
  private generateWelcomeTemplate(firstName?: string): string {
    const greeting = firstName ? `Hi ${firstName}` : "Hello";

    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to ${this.appName}</title>
        <style>
          * { box-sizing: border-box; }
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            line-height: 1.6; 
            color: rgb(55, 65, 81); 
            max-width: 600px; 
            margin: 0 auto; 
            padding: 0; 
            background-color: rgb(249, 250, 251);
          }
          .container {
            background-color: rgb(255, 255, 255);
            margin: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            overflow: hidden;
          }
          .header { 
            background: linear-gradient(135deg, rgb(65, 118, 204) 0%, rgb(72, 159, 243) 100%);
            color: white; 
            padding: 40px 30px; 
            text-align: center; 
          }
          .header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            letter-spacing: -0.025em;
          }
          .content { 
            background-color: rgb(255, 255, 255); 
            padding: 40px 30px; 
          }
          .content p {
            margin: 0 0 16px 0;
            font-size: 16px;
            color: rgb(55, 65, 81);
          }
          .button-container {
            text-align: center;
            margin: 32px 0;
          }
          .button { 
            display: inline-block; 
            background: linear-gradient(135deg, rgb(65, 118, 204) 0%, rgb(72, 159, 243) 100%);
            color: white; 
            padding: 16px 32px; 
            text-decoration: none; 
            border-radius: 8px; 
            font-weight: 600;
            font-size: 16px;
            transition: all 0.2s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
          }
          .button:hover {
            transform: translateY(-1px);
            box-shadow: 0 8px 12px -1px rgba(0, 0, 0, 0.15);
          }
          .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 32px 0;
          }
          .feature-card {
            background-color: rgb(249, 250, 251);
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid rgb(65, 118, 204);
            text-align: center;
          }
          .feature-icon {
            font-size: 24px;
            margin-bottom: 8px;
          }
          .feature-title {
            font-weight: 600;
            color: rgb(55, 65, 81);
            margin-bottom: 8px;
          }
          .feature-desc {
            font-size: 14px;
            color: rgb(107, 114, 128);
            margin: 0;
          }
          .footer { 
            background-color: rgb(249, 250, 251);
            margin-top: 32px; 
            padding: 24px 30px; 
            border-top: 1px solid rgb(229, 231, 235); 
            font-size: 14px; 
            color: rgb(107, 114, 128);
            text-align: center;
          }
          .logo {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
          }
          .welcome-badge {
            background-color: rgba(65, 118, 204, 0.1);
            color: rgb(39, 71, 122);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            display: inline-block;
            margin-bottom: 16px;
          }
          @media only screen and (max-width: 600px) {
            .container { margin: 10px; }
            .header, .content, .footer { padding: 24px 20px; }
            .header h1 { font-size: 24px; }
            .button { padding: 14px 28px; font-size: 15px; }
            .features-grid { grid-template-columns: 1fr; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">${this.appName}</div>
            <h1>Welcome to ${this.appName}!</h1>
          </div>
          <div class="content">
            <div class="welcome-badge">✅ Account Verified</div>
            <p><strong>${greeting}</strong>,</p>
            <p>Congratulations! Your email has been verified and your <strong>${this.appName}</strong> account is now active.</p>
            <p>You can now start using all the features of ${this.appName} to track and improve your health journey.</p>
            
            <div class="features-grid">
              <div class="feature-card">
                <div class="feature-icon">🏃‍♂️</div>
                <div class="feature-title">Workout Logging</div>
                <p class="feature-desc">Track your fitness activities and progress</p>
              </div>
              <div class="feature-card">
                <div class="feature-icon">🥗</div>
                <div class="feature-title">Nutrition Insights</div>
                <p class="feature-desc">Log your meals and monitor nutrition</p>
              </div>
            </div>
            
            <div class="button-container">
              <a href="${this.frontendUrl}" class="button">Get Started</a>
            </div>
            
            <p>If you have any questions or need help getting started, feel free to reach out to our support team.</p>
            <p><strong>Thank you for choosing ${this.appName}!</strong></p>
          </div>
          <div class="footer">
            <p style="margin: 0;">This is an automated message from <strong>${this.appName}</strong>. Please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Generate plain text for welcome email
   */
  private generateWelcomeText(firstName?: string): string {
    const greeting = firstName ? `Hi ${firstName}` : "Hello";

    return `
      Welcome to ${this.appName}!

      ${greeting},

      Congratulations! Your email has been verified and your ${this.appName} account is now active.

      You can now start using all the features of ${this.appName} to track and improve your health journey.

      Get started: ${this.frontendUrl}

      If you have any questions or need help getting started, feel free to reach out to our support team.

      Thank you for choosing ${this.appName}!

      ---
      This is an automated message from ${this.appName}. Please do not reply to this email.
    `;
  }

  /**
   * Generate HTML template for password change confirmation
   */
  private generatePasswordChangeTemplate(): string {
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Changed</title>
        <style>
          * { box-sizing: border-box; }
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            line-height: 1.6; 
            color: rgb(55, 65, 81); 
            max-width: 600px; 
            margin: 0 auto; 
            padding: 0; 
            background-color: rgb(249, 250, 251);
          }
          .container {
            background-color: rgb(255, 255, 255);
            margin: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            overflow: hidden;
          }
          .header { 
            background: linear-gradient(135deg, rgb(65, 118, 204) 0%, rgb(72, 159, 243) 100%);
            color: white; 
            padding: 40px 30px; 
            text-align: center; 
          }
          .header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            letter-spacing: -0.025em;
          }
          .content { 
            background-color: rgb(255, 255, 255); 
            padding: 40px 30px; 
          }
          .content p {
            margin: 0 0 16px 0;
            font-size: 16px;
            color: rgb(55, 65, 81);
          }
          .content ul {
            margin: 16px 0;
            padding-left: 20px;
          }
          .content li {
            margin-bottom: 8px;
            color: rgb(75, 85, 99);
          }
          .confirmation-box {
            background-color: rgb(243, 248, 253);
            border: 1px solid rgb(191, 213, 242);
            padding: 20px;
            border-radius: 8px;
            margin: 24px 0;
            border-left: 4px solid rgb(65, 118, 204);
            text-align: center;
          }
          .confirmation-box .icon {
            font-size: 32px;
            margin-bottom: 12px;
          }
          .confirmation-box .timestamp {
            background-color: rgb(255, 255, 255);
            padding: 12px;
            border-radius: 6px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            color: rgb(75, 85, 99);
            margin-top: 12px;
          }
          .warning-box {
            background-color: rgb(243, 248, 253);
            border: 1px solid rgb(191, 213, 242);
            padding: 20px;
            border-radius: 8px;
            margin: 24px 0;
            border-left: 4px solid rgb(65, 118, 204);
          }
          .warning-box strong {
            color: rgb(39, 71, 122);
            display: block;
            margin-bottom: 8px;
            font-size: 16px;
          }
          .footer { 
            background-color: rgb(249, 250, 251);
            margin-top: 32px; 
            padding: 24px 30px; 
            border-top: 1px solid rgb(229, 231, 235); 
            font-size: 14px; 
            color: rgb(107, 114, 128);
            text-align: center;
          }
          .logo {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
          }
          @media only screen and (max-width: 600px) {
            .container { margin: 10px; }
            .header, .content, .footer { padding: 24px 20px; }
            .header h1 { font-size: 24px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">${this.appName}</div>
            <h1>Password Changed Successfully</h1>
          </div>
          <div class="content">
            <div class="confirmation-box">
              <div class="icon">🔐</div>
              <p style="margin: 0; font-weight: 600; color: rgb(39, 71, 122);">Your password has been successfully updated!</p>
              <div class="timestamp">
                Changed on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}
              </div>
            </div>
            
            <p>Your <strong>${this.appName}</strong> account password has been successfully changed.</p>
            
            <div class="warning-box">
              <strong>⚠️ Security Notice</strong>
              <p style="margin: 0;">If you did not make this change, please contact our support team immediately and change your password again.</p>
            </div>
            
            <p><strong>For your security, we recommend:</strong></p>
            <ul>
              <li>Using a strong, unique password</li>
              <li>Not sharing your password with anyone</li>
              <li>Signing out of ${this.appName} on shared devices</li>
              <li>Enabling two-factor authentication if available</li>
            </ul>
          </div>
          <div class="footer">
            <p style="margin: 0;">This is an automated message from <strong>${this.appName}</strong>. Please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Generate plain text for password change confirmation
   */
  private generatePasswordChangeText(): string {
    return `
      Password Changed Successfully

      Your ${this.appName} account password has been successfully changed.

      This email is to confirm that the password change was completed on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}.

      Security Notice:
      If you did not make this change, please contact our support team immediately and change your password again.

      For your security, we recommend:
      - Using a strong, unique password
      - Not sharing your password with anyone
      - Signing out of ${this.appName} on shared devices

      ---
      This is an automated message from ${this.appName}. Please do not reply to this email.
    `;
  }
}

// Create and export a singleton instance
const emailHelper = new EmailHelper();

export default emailHelper;
export { EmailHelper };
