import { Food } from "../../prisma/generated/prisma";

/**
 * Maps USDA nutrition attribute IDs to nutrition names
 * Based on the USDA FoodData Central database attribute IDs
 */
export const NutritionAttributeIdToKey: Record<number, keyof Food> = {
  // Core nutrients (2018 NFP = 1)
  208: "calories", // Energy (kcal)
  204: "totalFat", // Total lipid (fat)
  606: "saturatedFat", // Fatty acids, total saturated
  646: "polyunsaturatedFat", // Fatty acids, total polyunsaturated
  645: "monounsaturatedFat", // Fatty acids, total monounsaturated
  605: "transFat", // Fatty acids, trans
  601: "cholesterol", // Cholesterol
  307: "sodium", // Sodium, Na
  205: "totalCarbohydrates", // Carbohydrate, by difference
  291: "dietaryFiber", // Fiber, total dietary
  269: "sugars", // Sugars, total
  539: "addedSugar", // Added sugars
  203: "protein", // Protein
  301: "calcium", // Calcium, Ca
  303: "iron", // Iron, Fe
  306: "potassium", // Potassium, K
  318: "vitaminA", // Vitamin A, mcg
  401: "vitaminC", // Vitamin C, mg
  324: "vitaminD", // Vitamin D

  264: "caffeine", // Caffeine
  312: "copper", // Copper
  315: "manganese", // Manganese
  406: "niacin", // Niacin
  410: "pantothenicAcid", // Pantothenic acid
  305: "phosphorus", // Phosphorus
  317: "selenium", // Selenium
  404: "thiamin", // Thiamin
  415: "vitaminB6", // Vitamin B-6
  418: "vitaminB12", // Vitamin B-12
  323: "vitaminE", // Vitamin E
  430: "vitaminK", // Vitamin K
  255: "water", // Water
  309: "zinc", // Zinc
};

/**
 * Maps nutrition names to their corresponding units
 * Based on the USDA FoodData Central database units
 */
export enum NutritionUnit {
  // Core nutrients
  calories = "kcal",
  totalFat = "g",
  saturatedFat = "g",
  polyunsaturatedFat = "g",
  monounsaturatedFat = "g",
  transFat = "g",
  cholesterol = "mg",
  sodium = "mg",
  totalCarbohydrates = "g",
  dietaryFiber = "g",
  sugars = "g",
  addedSugar = "g",
  protein = "g",
  calcium = "mg",
  iron = "mg",
  potassium = "mg",
  vitaminA = "mcg",
  vitaminC = "mg",
  vitaminD = "mcg",

  caffeine = "mg",
  copper = "mg",
  manganese = "mg",
  niacin = "mg",
  pantothenicAcid = "mg",
  phosphorus = "mg",
  selenium = "mcg",
  thiamin = "mg",
  vitaminB6 = "mg",
  vitaminB12 = "mcg",
  vitaminE = "mg",
  vitaminK = "mcg",
  water = "g",
  zinc = "mg",
}

export const Multiplier: Partial<Record<keyof Food, number>> = {
  vitaminA: 0.3,
  vitaminD: 0.025,
};
