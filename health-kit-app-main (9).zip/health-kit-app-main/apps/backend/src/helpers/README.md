# Email Helper Documentation

## Overview

The email helper provides a comprehensive solution for sending transactional emails in the Health App backend. It uses Nodemailer with TypeScript and includes pre-built templates for common email types.

## Features

- 🔧 **TypeScript Support**: Full type safety with Zod validation
- 📧 **Multiple Email Types**: Verification, password reset, welcome, and confirmation emails
- 🎨 **HTML & Text Templates**: Beautiful HTML emails with plain text fallbacks
- 🔒 **Security**: TLS encryption, secure configuration validation
- ⚡ **Error Handling**: Graceful error handling with detailed logging
- 🌍 **Environment-based**: Configurable via environment variables

## Email Types

### 1. Email Verification

Sent when a user signs up to verify their email address.

```typescript
await emailHelper.sendEmailVerification(email, verificationToken);
```

### 2. Password Reset

Sent when a user requests to reset their password.

```typescript
await emailHelper.sendPasswordReset(email, resetToken);
```

### 3. Welcome Email

Sent after successful email verification.

```typescript
await emailHelper.sendWelcomeEmail(email, firstName);
```

### 4. Password Change Confirmation

Sent when a user successfully changes their password.

```typescript
await emailHelper.sendPasswordChangeConfirmation(email);
```

### 5. Generic Email

For custom email sending.

```typescript
await emailHelper.sendEmail({
  to: "user@example.com",
  subject: "Custom Subject",
  html: "<h1>Custom HTML</h1>",
  text: "Custom plain text",
});
```

## Environment Variables

Create a `.env` file in the backend root with the following variables:

```env
# Email Configuration
SMTP_HOST="smtp.gmail.com"          # SMTP server hostname
SMTP_PORT="587"                     # SMTP server port
SMTP_SECURE="false"                 # Use TLS (true for port 465, false for others)
SMTP_USER="your_email@gmail.com"    # SMTP username
SMTP_PASS="your_app_password"       # SMTP password or app password
FROM_EMAIL="your_email@gmail.com"   # From email address

# Application Settings
APP_NAME="Health App"               # Application name for email templates
FRONTEND_URL="http://localhost:3000" # Frontend URL for email links
```

## Frontend URL Configuration

The `FRONTEND_URL` environment variable determines where email links point to. Configure it based on your setup:

### **Web Application**

```env
# Development
FRONTEND_URL="http://localhost:3000"

# Production
FRONTEND_URL="https://your-app.com"

# Staging
FRONTEND_URL="https://staging.your-app.com"
```

### **Mobile Application (React Native/Expo)**

```env
# Expo Development
FRONTEND_URL="exp://192.168.1.100:8081"

# Custom Deep Links
FRONTEND_URL="healthapp://app"

# Universal Links (iOS/Android)
FRONTEND_URL="https://your-app.com"
```

### **Hybrid Setup**

For apps that support both web and mobile, you can:

1. **Use Universal Links**: Configure `https://your-app.com` that redirects to app if installed
2. **Environment-specific URLs**: Different backends for web vs mobile
3. **Dynamic URLs**: Detect user agent and send appropriate links

## Mobile Deep Link Setup

If using mobile deep links, you need to:

### **1. Configure Deep Links in Expo**

```json
// app.json
{
  "expo": {
    "scheme": "healthapp",
    "web": {
      "bundler": "metro"
    }
  }
}
```

### **2. Handle Reset Password Route**

Create a route in your mobile app to handle the reset password token:

```typescript
// app/(public)/auth/reset-password.tsx
import { useLocalSearchParams } from 'expo-router';

export default function ResetPasswordScreen() {
  const { token } = useLocalSearchParams();

  // Handle password reset with the token
  const handleResetPassword = async (newPassword: string) => {
    const response = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, newPassword }),
    });
    // Handle response
  };

  return (
    // Your reset password form UI
  );
}
```

### **3. Test Deep Links**

```bash
# Test on iOS Simulator
xcrun simctl openurl booted "healthapp://auth/reset-password?token=test123"

# Test on Android
adb shell am start -W -a android.intent.action.VIEW -d "healthapp://auth/reset-password?token=test123"
```

## SMTP Provider Configuration

### Gmail

1. Enable 2-factor authentication
2. Generate an app-specific password: [Google App Passwords](https://support.google.com/accounts/answer/185833)
3. Use the app password as `SMTP_PASS`

```env
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_SECURE="false"
```

### Outlook/Hotmail

```env
SMTP_HOST="smtp-mail.outlook.com"
SMTP_PORT="587"
SMTP_SECURE="false"
```

### Yahoo

```env
SMTP_HOST="smtp.mail.yahoo.com"
SMTP_PORT="587"
SMTP_SECURE="false"
```

### Custom SMTP

Use your provider's specific settings.

## Usage in Services

The email helper is already integrated into the auth service:

```typescript
import emailHelper from "../../helpers/email";

// In your service
try {
  await emailHelper.sendEmailVerification(user.email, token);
  console.log("Email sent successfully");
} catch (error) {
  console.error("Failed to send email:", error);
  // Handle error appropriately
}
```

## Error Handling

The email helper includes comprehensive error handling:

- **Configuration Validation**: Validates all environment variables
- **Connection Verification**: Tests SMTP connection on startup
- **Graceful Failures**: Logs errors without breaking application flow
- **Type Safety**: Validates email options with Zod schemas

## Testing Email Connection

You can verify your email configuration:

```typescript
const isConnected = await emailHelper.verifyConnection();
if (isConnected) {
  console.log("Email service is ready");
} else {
  console.error("Email service connection failed");
}
```

## Email Templates

All templates are responsive and include:

- **HTML Version**: Beautiful, modern design with proper styling
- **Plain Text Version**: For email clients that don't support HTML
- **Security Information**: Clear security warnings for sensitive actions
- **Branding**: Uses your app name and colors consistently

## Security Considerations

- **TLS Encryption**: All connections use TLS 1.2 or higher
- **Token Expiration**: Email verification and reset tokens have expiration times
- **No Sensitive Data**: Passwords and sensitive information are never included in emails
- **Rate Limiting**: Consider implementing rate limiting for email sending
- **Environment Variables**: Keep SMTP credentials secure and never commit them

## Troubleshooting

### Common Issues

1. **"Failed to send email"**

   - Check SMTP credentials
   - Verify network connectivity
   - Ensure app passwords are used for Gmail

2. **"FROM_EMAIL must be defined"**

   - Set `FROM_EMAIL` or `SMTP_USER` in environment variables

3. **"Connection refused"**

   - Check SMTP host and port
   - Verify firewall settings
   - Ensure TLS/SSL settings are correct

4. **"Authentication failed"**
   - Verify SMTP username and password
   - Use app-specific passwords for Gmail
   - Check if 2FA is required

### Debug Mode

Enable detailed logging by checking the console output. The email helper logs:

- Successful email sends with message IDs
- Configuration validation errors
- SMTP connection issues
- Template generation errors

## Contributing

When adding new email types:

1. Add the method to the `EmailHelper` class
2. Create both HTML and text templates
3. Include proper error handling
4. Update this documentation
5. Add type definitions if needed

## Dependencies

- `nodemailer`: Email sending library
- `@types/nodemailer`: TypeScript definitions
- `zod`: Schema validation

## Support

For issues with the email helper:

1. Check environment variable configuration
2. Verify SMTP provider settings
3. Test email connection with `verifyConnection()`
4. Check application logs for detailed error messages
