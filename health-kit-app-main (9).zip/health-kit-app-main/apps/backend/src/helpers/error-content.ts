import { z } from "zod";

const errorContent = {
	content: {
		"application/json": {
			schema: z.object({
				cause: z.string().optional().nullable(),
			}),
		},
	},
	description: "Error Response",
};

export default errorContent;
