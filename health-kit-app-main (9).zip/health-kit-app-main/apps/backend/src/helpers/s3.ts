import {
	S3Client,
	ListBucketsCommand,
	ListObjectsV2Command,
	GetObjectCommand,
	PutObjectCommand,
	DeleteObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

interface UploadFile {
	name: string;
	size: number;
	type: string;
	arrayBuffer(): Promise<ArrayBuffer>;
}

export async function uploadToS3(file: UploadFile, key: string) {
	if (
		!process.env.AWS_REGION ||
		!process.env.AWS_ACCESS_KEY_ID ||
		!process.env.AWS_SECRET_ACCESS_KEY ||
		!process.env.S3_BUCKET_NAME
	) {
		throw new Error(
			"S3 configuration is missing. Please check environment variables.",
		);
	}

	const client = new S3Client({
		region: process.env.AWS_REGION,
		credentials: {
			accessKeyId: process.env.AWS_ACCESS_KEY_ID,
			secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
		},
		// Add reasonable timeouts
		requestHandler: {
			abortSignal: AbortSignal.timeout(15000), // 15 second timeout
		},
	});

	try {
		// Convert File to Buffer properly
		const arrayBuffer = await file.arrayBuffer();
		const buffer = Buffer.from(arrayBuffer);

		const command = new PutObjectCommand({
			Bucket: process.env.S3_BUCKET_NAME,
			Key: key,
			Body: buffer,
			ContentType: file.type,
		});

		const result = await client.send(command);

		if (
			!result.$metadata.httpStatusCode ||
			result.$metadata.httpStatusCode !== 200
		) {
			throw new Error(
				`Upload failed with status ${result.$metadata.httpStatusCode}`,
			);
		}

		return result;
	} catch (error) {
		console.error("Error uploading to S3:", error);
		throw error;
	}
}

export async function deleteFromS3(key: string) {
	if (
		!process.env.AWS_REGION ||
		!process.env.AWS_ACCESS_KEY_ID ||
		!process.env.AWS_SECRET_ACCESS_KEY ||
		!process.env.S3_BUCKET_NAME
	) {
		throw new Error(
			"S3 configuration is missing. Please check environment variables.",
		);
	}

	const client = new S3Client({
		region: process.env.AWS_REGION,
		credentials: {
			accessKeyId: process.env.AWS_ACCESS_KEY_ID,
			secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
		},
	});

	try {
		const command = new DeleteObjectCommand({
			Bucket: process.env.S3_BUCKET_NAME,
			Key: key,
		});

		const result = await client.send(command);
		return result;
	} catch (error) {
		console.error("Error deleting from S3:", error);
		throw error;
	}
}

export async function getS3Object(key: string) {
	if (
		!process.env.AWS_REGION ||
		!process.env.AWS_ACCESS_KEY_ID ||
		!process.env.AWS_SECRET_ACCESS_KEY ||
		!process.env.S3_BUCKET_NAME
	) {
		throw new Error(
			"S3 configuration is missing. Please check environment variables.",
		);
	}

	const client = new S3Client({
		region: process.env.AWS_REGION,
		credentials: {
			accessKeyId: process.env.AWS_ACCESS_KEY_ID,
			secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
		},
	});

	try {
		const command = new GetObjectCommand({
			Bucket: process.env.S3_BUCKET_NAME,
			Key: key,
		});

		const result = await client.send(command);
		return result;
	} catch (error) {
		console.error("Error getting object from S3:", error);
		throw error;
	}
}

export function generateS3Key(userId: string, fileName: string): string {
	const timestamp = Date.now();
	const sanitizedFileName = fileName.replace(/[^a-zA-Z0-9.-]/g, "_");
	return `users/${userId}/${timestamp}_${sanitizedFileName}`;
}

export function getS3Url(key: string): string {
	return `https://${process.env.S3_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;
}

export async function generateSignedUrl(
	key: string,
	expiresIn = 3600,
): Promise<string> {
	if (
		!process.env.AWS_REGION ||
		!process.env.AWS_ACCESS_KEY_ID ||
		!process.env.AWS_SECRET_ACCESS_KEY ||
		!process.env.S3_BUCKET_NAME
	) {
		throw new Error(
			"S3 configuration is missing. Please check environment variables.",
		);
	}

	const client = new S3Client({
		region: process.env.AWS_REGION,
		credentials: {
			accessKeyId: process.env.AWS_ACCESS_KEY_ID,
			secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
		},
	});

	try {
		const command = new GetObjectCommand({
			Bucket: process.env.S3_BUCKET_NAME,
			Key: key,
		});

		const signedUrl = await getSignedUrl(client, command, { expiresIn });
		return signedUrl;
	} catch (error) {
		console.error("Error generating signed URL:", error);
		throw error;
	}
}
