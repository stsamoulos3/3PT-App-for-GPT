import { InfluxDB } from "@influxdata/influxdb-client";

const INFLUX_URL = process.env.INFLUX_URL || "http://localhost:8086";
const INFLUX_TOKEN = process.env.INFLUX_TOKEN;
const INFLUX_ORG = process.env.INFLUX_ORG || "my-org";
const INFLUX_BUCKET = process.env.INFLUX_BUCKET || "health-metrics";

export const influxDb = new InfluxDB({ url: INFLUX_URL, token: INFLUX_TOKEN });
export const writeApi = influxDb.getWriteApi(INFLUX_ORG, INFLUX_BUCKET);
export const queryApi = influxDb.getQueryApi(INFLUX_ORG);
