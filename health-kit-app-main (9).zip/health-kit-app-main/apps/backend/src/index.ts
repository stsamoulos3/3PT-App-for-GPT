import { highlightMiddleware } from "@highlight-run/hono";
import { serveStatic } from "hono/bun";
import admin from "./apis/admin";
import auth from "./apis/auth";
import foods from "./apis/foods";
import heartRate from "./apis/heart-rate";
import nutrition from "./apis/nutrition";
import user from "./apis/user";
import workout from "./apis/workout";
import createApp from "./lib/create-app";
import configureOpenAPI from "./lib/openapi";
import adminDashboard from "./static/admin-dashboard";
import adminDashboardJsx from "./static/admin-dashboard-jsx";
import privacyPolicy from "./static/privacy-policy";

const app = createApp();

if (Bun.env.HIGHLIGHT_PROJECT_ID) {
	app.use(
		highlightMiddleware({
			projectID: Bun.env.HIGHLIGHT_PROJECT_ID,
			serviceName: Bun.env.HIGHLIGHT_SERVICE_NAME,
			environment: Bun.env.HIGHLIGHT_ENVIRONMENT,
		}),
	);
}

app.use(async (c, next) => {
	console.log(`method: ${c.req.method} url: ${c.req.url} started`);
	try {
		await next();
		console.log(`method: ${c.req.method} url: ${c.req.url} finished`);
	} catch (error) {
		console.log(`method: ${c.req.method} url: ${c.req.url} error:`, error);
		throw error;
	}

	if (c.error) {
		console.log(`method: ${c.req.method} url: ${c.req.url} c.error:`, c.error);
		return c.json(
			{
				error: c.error.message,
			},
			500,
		);
	}
});

const routes = app
	.route("/auth", auth)
	.route("/admin", admin)
	.route("/workout", workout)
	.route("/heart-rate", heartRate)
	.route("/nutrition", nutrition)
	.route("/user", user)
	.route("/foods", foods)
	.get("/privacy-policy", (c) => {
		return c.html(privacyPolicy);
	})
	.get("/admin", (c) => {
		return c.html(adminDashboard());
	})
	.get("/admin-jsx", (c) => {
		return c.html(adminDashboardJsx());
	});

app.use(
	"/static/*",
	serveStatic({
		root: "./src/static",
		onNotFound(path, c) {
			console.log("Not found ------------------------ ", path);
		},
		onFound(path, c) {
			console.log("Found ------------------------ ", path);
		},
		rewriteRequestPath: (path) => path.replace(/^\/static/, ""),
	}),
);

configureOpenAPI(app);

console.log(`Hono is running on port http://localhost:${Bun.env.PORT}/docs`);

console.log(Bun.env.DATABASE_URL);

Bun.serve({
	fetch: app.fetch,
	port: Bun.env.PORT,
});

export type AppType = typeof routes;
