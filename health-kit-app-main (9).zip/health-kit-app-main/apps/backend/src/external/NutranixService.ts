import axios, { AxiosInstance } from "axios";
import { prisma } from "../db/client";

interface NutranixConfig {
  apiKey: string;
  apiId: string;
  baseUrl?: string;
}

interface NutranixProductListItem {
  region: number;
  nf_calories: number;
  serving_qty: number;
  brand_type: number;
  nix_brand_id: string;
  nix_item_id?: string;
  brand_name: string;
  photo: string[];
  brand_name_item_name: string;
  serving_unit: string;
  food_name: string;
  locale: string;
  tag_id?: string;
}

interface NutranixProduct {
  food_name: string;
  brand_name: string;
  serving_qty: number;
  serving_unit: string;
  serving_weight_grams: number;
  nf_metric_qty: number;
  nf_metric_uom?: string;
  nf_calories: number;
  nf_total_fat?: number;
  nf_saturated_fat?: number;
  nf_cholesterol?: number;
  nf_sodium?: number;
  nf_total_carbohydrate?: number;
  nf_dietary_fiber?: number;
  nf_sugars?: number;
  nf_protein?: number;
  nf_potassium?: number;
  nf_p?: number;
  full_nutrients?: {
    attr_id: number;
    value: number;
  }[];
  nix_brand_name?: string;
  nix_brand_id?: string;
  nix_item_name?: string;
  nix_item_id?: string;
  metadata?: Record<string, any>;
  source?: number;
  ndb_no?: number;
  tags?: {
    item: string;
    measure: string | null;
    quantity: string;
    food_group: number;
    tag_id: string;
  };
  alt_measures?: any;
  lat?: number;
  lng?: number;
  photo?: {
    thumb: string;
    highres: string;
    is_user_uploaded: boolean;
  };
  note?: any;
  class_code?: any;
  brick_code?: any;
  tag_id?: any;
  updated_at?: string;
  nf_ingredient_statement?: string;
}

const client = axios.create({
  baseURL: "https://trackapi.nutritionix.com/",
  headers: {
    "Content-Type": "application/json",
    "x-app-id": process.env.NUTRANIX_API_ID || "",
    "x-app-key": process.env.NUTRANIX_API_KEY || "",
    "x-remote-user-id": 0,
  },
});

export class NutranixService {
  static async searchProducts(
    query: string
  ): Promise<NutranixProductListItem[]> {
    if (!query) {
      return [];
    }

    try {
      // Make both API calls in parallel but handle them separately
      const [instantResponse, naturalResponse] = await Promise.allSettled([
        client.get<{
          [key: string]: NutranixProductListItem[];
        }>("/v2/search/instant/", {
          params: { query: query, common: true },
        }),
        client.post<{ foods: NutranixProduct[] }>("/v2/natural/nutrients", {
          query: query,
        }),
      ]);

      let instantFoods: NutranixProductListItem[] = [];
      let naturalFoods: NutranixProductListItem[] = [];

      // Handle instant search results
      if (instantResponse.status === "fulfilled") {
        const uniqueCommonFoods =
          instantResponse.value.data.common?.filter(
            (item, index, self) =>
              index === self.findIndex((t) => t.tag_id === item.tag_id)
          ) || [];

        instantFoods = [
          ...uniqueCommonFoods,
          ...(instantResponse.value.data.branded || []),
        ];
      } else {
        console.warn(
          "[NutranixService] Instant search failed:",
          instantResponse.reason
        );
      }

      // Handle natural language results
      if (naturalResponse.status === "fulfilled") {
        console.log(
          "[NutranixService] naturalResponse",
          naturalResponse.value.data
        );

        // Transform natural language results to match the expected structure
        naturalFoods =
          naturalResponse.value.data.foods?.map((food) => ({
            region: 1, // Default value
            nf_calories: food.nf_calories,
            serving_qty: food.serving_qty,
            brand_type: food.brand_name ? 1 : 0, // 1 for branded, 0 for common
            nix_brand_id: food.nix_brand_id || "",
            nix_item_id: food.nix_item_id,
            brand_name: food.brand_name || "",
            photo: food.photo ? [food.photo.thumb] : [],
            brand_name_item_name: food.brand_name
              ? `${food.brand_name} ${food.food_name}`
              : food.food_name,
            serving_unit: food.serving_unit,
            food_name: food.food_name,
            locale: "en_US", // Default locale
            tag_id: `${food.tag_id || food.nix_item_id || food.tags?.tag_id}-${food.serving_unit}`,
            tags: food.tags,
          })) || [];
      } else {
        console.warn(
          "[NutranixService] Natural language search failed:",
          naturalResponse.reason
        );
      }

      // Combine and deduplicate results
      const allFoods = [...naturalFoods, ...instantFoods];

      // Remove duplicates based on nix_item_id or tag_id
      const uniqueFoods = allFoods.filter((food, index, self) => {
        const identifier = food.nix_item_id || food.tag_id;
        if (!identifier) return true; // Keep foods without identifiers

        return (
          index ===
          self.findIndex((f) => (f.nix_item_id || f.tag_id) === identifier)
        );
      });

      console.log(
        "[NutranixService] searchProducts - Combined results:",
        uniqueFoods.length
      );
      return uniqueFoods;
    } catch (error) {
      console.error("Failed to search products:", error);
      throw new Error("Failed to search products in Nutranix API");
    }
  }

  static async getProductByBarcode({
    barcode,
    nixItemId,
  }: {
    barcode?: string;
    nixItemId?: string;
  }): Promise<NutranixProduct> {
    try {
      const response = await client
        .get(`/v2/search/item/`, {
          params: {
            upc: barcode,
            nix_item_id: nixItemId,
          },
        })
        .catch(async (error) => {
          try {
            const data = await prisma.food.findFirst({
              where: {
                nixId: nixItemId,
              },
            });

            if (!data) {
              throw new Error("Food not found");
            }

            const resp = await client.post(`/v2/natural/nutrients`, {
              query: `${data?.foodName} ${data?.servingSize}`,
            });

            console.log(
              "[NutranixService] getProductByBarcode - resp",
              resp.data
            );

            return resp;
          } catch (error) {
            console.error("Failed to fetch product by barcode:", error);
            throw new Error(
              "Failed to fetch product by barcode from Nutranix API"
            );
          }
        });

      return response.data.foods[0];
    } catch (error) {
      console.error("Failed to fetch product by barcode:", error);
      throw new Error("Failed to fetch product by barcode from Nutranix API");
    }
  }

  static async getNutrientInfo(nutrientId: string): Promise<any> {
    try {
      const response = await client.get(`/v1/nutrients/${nutrientId}`);
      return response.data;
    } catch (error) {
      console.error("Failed to fetch nutrient info:", error);
      throw new Error("Failed to fetch nutrient information from Nutranix API");
    }
  }
}
