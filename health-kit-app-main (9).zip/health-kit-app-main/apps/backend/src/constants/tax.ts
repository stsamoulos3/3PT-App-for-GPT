export const TAX_PERCENTAGE = 10;
