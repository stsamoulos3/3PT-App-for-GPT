#!/usr/bin/env bun
/**
 * Email Configuration Checker
 *
 * This script checks your current email configuration and shows what URLs
 * would be generated for password reset and email verification.
 *
 * Run with: bun run src/scripts/check-email-config.ts
 */

console.log("🔧 Email Configuration Check\n");

// Display current environment variables
console.log("📋 Current Configuration:");
console.log(
  `  SMTP_HOST: ${process.env.SMTP_HOST || "NOT SET (will use: smtp.gmail.com)"}`
);
console.log(
  `  SMTP_PORT: ${process.env.SMTP_PORT || "NOT SET (will use: 587)"}`
);
console.log(
  `  SMTP_SECURE: ${process.env.SMTP_SECURE || "NOT SET (will use: false)"}`
);
console.log(`  SMTP_USER: ${process.env.SMTP_USER ? "✅ SET" : "❌ NOT SET"}`);
console.log(`  SMTP_PASS: ${process.env.SMTP_PASS ? "✅ SET" : "❌ NOT SET"}`);
console.log(
  `  FROM_EMAIL: ${process.env.FROM_EMAIL || process.env.SMTP_USER || "❌ NOT SET"}`
);
console.log(
  `  APP_NAME: ${process.env.APP_NAME || "NOT SET (will use: Health App)"}`
);
console.log(
  `  FRONTEND_URL: ${process.env.FRONTEND_URL || "NOT SET (will use: http://localhost:3000)"}\n`
);

// Determine what URLs would be generated
const frontendUrl = process.env.FRONTEND_URL || "http://localhost:3000";
const sampleToken = "abc123def456ghi789";

console.log("🔗 Generated URLs:");

// Password reset URL
const resetUrl =
  frontendUrl.startsWith("exp://") || frontendUrl.startsWith("healthapp://")
    ? `${frontendUrl}/auth/reset-password?token=${sampleToken}`
    : `${frontendUrl}/auth/reset-password?token=${sampleToken}`;

console.log(`  Password Reset: ${resetUrl}`);

// Email verification URL
const verifyUrl =
  frontendUrl.startsWith("exp://") || frontendUrl.startsWith("healthapp://")
    ? `${frontendUrl}/auth/verify-email?token=${sampleToken}`
    : `${frontendUrl}/auth/verify-email?token=${sampleToken}`;

console.log(`  Email Verification: ${verifyUrl}\n`);

// Determine setup type
console.log("🎯 Detected Setup:");
if (frontendUrl.startsWith("exp://")) {
  console.log("  📱 Expo Development Server");
  console.log("  ⚠️  Make sure your mobile app handles these routes");
} else if (frontendUrl.startsWith("healthapp://")) {
  console.log("  📱 Custom Mobile Deep Links");
  console.log("  ⚠️  Make sure deep links are configured in your app");
} else if (frontendUrl.includes("localhost")) {
  console.log("  💻 Local Development (Web)");
  console.log("  ⚠️  Make sure your web app handles these routes");
} else if (frontendUrl.startsWith("https://")) {
  console.log("  🌐 Production Web App");
  console.log("  ✅ Using secure HTTPS URLs");
} else {
  console.log("  ❓ Unknown setup type");
}

// Recommendations
console.log("\n💡 Recommendations:");

if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
  console.log("  ❌ Set SMTP_USER and SMTP_PASS for email sending");
}

if (!process.env.FRONTEND_URL) {
  console.log("  ⚠️  Set FRONTEND_URL to point to your actual frontend");
  console.log("     Examples:");
  console.log('     - Web: FRONTEND_URL="https://your-app.com"');
  console.log('     - Mobile: FRONTEND_URL="healthapp://app"');
  console.log('     - Expo: FRONTEND_URL="exp://192.168.1.100:8081"');
}

if (frontendUrl.includes("localhost") && !frontendUrl.startsWith("exp://")) {
  console.log(
    "  📱 For mobile app: Consider using deep links instead of localhost"
  );
  console.log('     Example: FRONTEND_URL="healthapp://app"');
}

console.log("\n✅ Configuration check complete!");

// Check if routes exist in mobile app
import { existsSync } from "fs";
const mobileAuthDir = "../mobile-app/src/app/(public)/auth";

console.log("\n📱 Mobile App Route Check:");
if (existsSync(`${mobileAuthDir}/reset-password.tsx`)) {
  console.log("  ✅ Reset password route exists");
} else {
  console.log("  ❌ Reset password route missing");
  console.log(
    "     Create: apps/mobile-app/src/app/(public)/auth/reset-password.tsx"
  );
}

if (existsSync(`${mobileAuthDir}/verify-email.tsx`)) {
  console.log("  ✅ Email verification route exists");
} else {
  console.log("  ❌ Email verification route missing");
  console.log(
    "     Create: apps/mobile-app/src/app/(public)/auth/verify-email.tsx"
  );
}
