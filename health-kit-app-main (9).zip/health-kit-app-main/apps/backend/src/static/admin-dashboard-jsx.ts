export default function AdminDashboardJsx(): string {
	return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Admin Dashboard - File Upload</title>
      <script src="https://cdn.tailwindcss.com"></script>
      <script src="https://unpkg.com/htmx.org@1.9.10"></script>
      <style>
        .file-drop-zone {
          border: 2px dashed #d1d5db;
          transition: all 0.3s ease;
        }
        .file-drop-zone.dragover {
          border-color: #3b82f6;
          background-color: #eff6ff;
        }
        .file-item {
          transition: all 0.2s ease;
        }
        .file-item:hover {
          background-color: #f9fafb;
        }
        .loading {
          opacity: 0.6;
          pointer-events: none;
        }
        .logout-btn {
          position: fixed;
          top: 1rem;
          right: 1rem;
          z-index: 1000;
        }
        .modal {
          display: none;
          position: fixed;
          z-index: 1000;
          left: 0;
          top: 0;
          width: 100%;
          height: 100%;
          background-color: rgba(0, 0, 0, 0.5);
        }
        .modal.show {
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .modal-content {
          background-color: white;
          margin: auto;
          padding: 0;
          border-radius: 0.5rem;
          width: 90%;
          max-width: 600px;
          max-height: 90vh;
          overflow-y: auto;
        }
        .modal-header {
          padding: 1.5rem 1.5rem 0 1.5rem;
          border-bottom: 1px solid #e5e7eb;
          margin-bottom: 1.5rem;
        }
        .modal-body {
          padding: 0 1.5rem 1.5rem 1.5rem;
        }
        .close {
          color: #aaa;
          float: right;
          font-size: 28px;
          font-weight: bold;
          cursor: pointer;
          line-height: 1;
        }
        .close:hover,
        .close:focus {
          color: #000;
          text-decoration: none;
        }
      </style>
    </head>
    <body class="bg-gray-50 min-h-screen">
      <div class="flex min-h-screen">
        <!-- Main Content -->
        <div class="flex-1 flex flex-col">
          <!-- Top Header -->
          <header class="bg-white shadow flex items-center justify-between px-6 py-4">
            <div class="flex items-center gap-3">
              <img src="static/logo.png" alt="Three Point Healthcare Logo" class="h-8 w-auto">
              <div>
                <h1 class="text-2xl font-bold text-gray-900">Three Point Healthcare</h1>
                <p class="text-sm text-gray-600">Admin Dashboard</p>
              </div>
            </div>
            <div class="flex items-center gap-4">
              <span class="text-gray-600 text-sm font-medium" id="admin-user-info"></span>
              <button
                id="logout-btn"
                class="hidden inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
              >
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
                Logout
              </button>
            </div>
          </header>
          <!-- Main Area -->
          <main class="flex-1 p-6 bg-gray-50">
            <!-- Login Form -->
            <div id="login-section" class="max-w-md mx-auto bg-white rounded-lg shadow-md p-6 mb-8">
              <h2 class="text-xl font-semibold mb-4">Admin Login</h2>
              <form id="login-form" class="space-y-4">
                <div>
                  <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input type="email" id="email" name="email" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div>
                  <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                  <input type="password" id="password" name="password" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div class="flex items-center space-x-4">
                  <label class="flex items-center">
                    <input type="checkbox" id="remember-me" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                    <span class="ml-2 text-sm text-gray-700">Remember me (localStorage)</span>
                  </label>
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors">Sign In</button>
              </form>
              <div id="login-error" class="mt-3 text-red-600 text-sm hidden"></div>
            </div>
            <!-- Main Dashboard (hidden initially) -->
            <div id="dashboard-section" class="hidden">
              <!-- Dashboard Page -->
              <div id="dashboard-page">
                <!-- Page Header -->
                <div class="mb-6">
                  <h1 class="text-2xl font-bold text-gray-900">Dashboard</h1>
                  <p class="text-gray-600">Search and manage users</p>
                </div>

                <!-- Search Section -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                  <h2 class="text-xl font-semibold mb-4">Search Users</h2>
                  <div class="flex gap-4 mb-4">
                    <div class="flex-1">
                      <label for="user-search" class="block text-sm font-medium text-gray-700 mb-1">Search by name, email or id</label>
                      <input type="text" id="user-search" placeholder="Enter name or email to search..." class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                    <div class="flex items-end">
                      <button id="search-btn" class="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors">Search</button>
                    </div>
                  </div>
                </div>

                <!-- Users List -->
                <div class="bg-white rounded-lg shadow-md p-6">
                  <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">Users</h2>
                    <span id="users-count" class="text-sm text-gray-500">0 users found</span>
                  </div>
                  <div id="users-list" class="space-y-3"></div>
                </div>
              </div>

              <!-- User Details Page (hidden initially) -->
              <div id="user-details-page" class="hidden">
                <!-- Back Button and User Info -->
                <div class="flex items-center justify-between mb-6">
                  <div class="flex items-center space-x-4">
                    <button id="back-to-dashboard" class="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors">
                      <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M15 19l-7-7 7-7" />
                      </svg>
                      Back to Dashboard
                    </button>
                    <div class="h-6 w-px bg-gray-300"></div>
                    <div>
                      <h1 class="text-2xl font-bold text-gray-900" id="user-details-name"></h1>
                      <p class="text-gray-600" id="user-details-email"></p>
                    </div>
                  </div>
                  <div class="flex items-center space-x-2">
                    <span id="user-details-role" class="px-3 py-1 text-sm font-medium rounded-full"></span>
                  </div>
                </div>

                <!-- User Stats -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                      <div class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <svg class="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                          <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                      </div>
                      <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Total Files</p>
                        <p class="text-2xl font-bold text-gray-900" id="user-files-count">0</p>
                      </div>
                    </div>
                  </div>
                  <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                      <div class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                        <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                          <path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Last Active</p>
                        <p class="text-2xl font-bold text-gray-900" id="user-last-active">-</p>
                      </div>
                    </div>
                  </div>
                  <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                      <div class="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                        <svg class="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                          <path d="M8 7V3a4 4 0 118 0v4m-4 6v6m-4-6h8" />
                        </svg>
                      </div>
                      <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Total Size</p>
                        <p class="text-2xl font-bold text-gray-900" id="user-total-size">0 KB</p>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Files Section -->
                <div class="bg-white rounded-lg shadow-md p-6">
                  <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">Files</h2>
                    <button id="upload-files-btn" class="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors">
                      <svg class="w-4 h-4 mr-2 inline" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M12 4v16m8-8H4" />
                      </svg>
                      Upload Files
                    </button>
                  </div>
                  <div id="user-files-list" class="space-y-3"></div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>

      <!-- Upload Files Modal -->
      <div id="upload-modal" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <h3 class="text-lg font-semibold">Upload Files</h3>
            <span class="close" id="close-upload-modal">&times;</span>
          </div>
          <div class="modal-body">
            <div class="mb-4">
              <p class="text-sm text-gray-600 mb-2">Selected User: <span id="selected-user-info" class="font-medium"></span></p>
            </div>

            <form id="upload-form" class="space-y-4">
              <div>
                <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description (Optional)</label>
                <textarea
                  id="description"
                  name="description"
                  rows="3"
                  placeholder="Enter a description for the uploaded files..."
                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                ></textarea>
              </div>

              <div class="space-y-2">
                <label class="flex items-center">
                  <input type="checkbox" id="pnoe-data-toggle" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                  <span class="ml-2 text-sm text-gray-700">Mark as PNOE data file (will rename to pnoe.csv)</span>
                </label>
                <label class="flex items-center">
                  <input type="checkbox" id="vo2-master-toggle" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                  <span class="ml-2 text-sm text-gray-700">Mark as VO2 Master data file (will rename to vo2_master.csv)</span>
                </label>
              </div>

              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Files</label>
                <div
                  id="file-drop-zone"
                  class="file-drop-zone rounded-lg p-8 text-center cursor-pointer"
                >
                  <div class="space-y-2">
                    <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                      <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    <div class="text-gray-600">
                      <span class="font-medium">Click to upload</span> or drag and drop
                    </div>
                    <p class="text-xs text-gray-500">Multiple files supported</p>
                  </div>
                  <input
                    type="file"
                    id="file-input"
                    multiple
                    class="hidden"
                    accept=".csv"
                  >
                </div>
              </div>

              <div id="selected-files" class="space-y-2"></div>

              <div class="flex gap-3 pt-4">
                <button
                  type="button"
                  id="cancel-upload-btn"
                  class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="upload-btn"
                  class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled
                >
                  Upload Files
                </button>
              </div>
            </form>

            <div id="upload-error" class="mt-3 text-red-600 text-sm hidden"></div>
            <div id="upload-success" class="mt-3 text-green-600 text-sm hidden"></div>
          </div>
        </div>
      </div>

      <!-- Delete File Confirmation Modal -->
      <div id="delete-modal" class="modal">
        <div class="modal-content" style="max-width: 400px;">
          <div class="modal-header">
            <h3 class="text-lg font-semibold">Delete File</h3>
            <span class="close" id="close-delete-modal">&times;</span>
          </div>
          <div class="modal-body">
            <p class="text-gray-700 mb-4">Are you sure you want to delete this file? This action cannot be undone.</p>
            <div class="flex gap-3">
              <button
                type="button"
                id="cancel-delete-btn"
                class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                id="confirm-delete-btn"
                class="flex-1 bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Delete User Confirmation Modal -->
      <div id="delete-user-modal" class="modal">
        <div class="modal-content" style="max-width: 400px;">
          <div class="modal-header">
            <h3 class="text-lg font-semibold">Delete User</h3>
            <span class="close" id="close-delete-user-modal">&times;</span>
          </div>
          <div class="modal-body">
            <p class="text-gray-700 mb-2">Are you sure you want to delete user <strong id="delete-user-name"></strong>?</p>
            <p class="text-red-600 text-sm mb-4">⚠️ This will permanently delete the user and all their data including files. This action cannot be undone.</p>
            <div class="flex gap-3">
              <button
                type="button"
                id="cancel-delete-user-btn"
                class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                id="confirm-delete-user-btn"
                class="flex-1 bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors"
              >
                Delete User
              </button>
            </div>
          </div>
        </div>
      </div>

      <script>
        // Storage keys
        const STORAGE_KEYS = {
          ADMIN_TOKEN: 'admin_token',
          ADMIN_USER: 'admin_user',
          REMEMBER_ME: 'admin_remember_me'
        };

        // State management
        let adminToken = '';
        let adminUser = null;
        let selectedUserId = '';
        let selectedUser = null;
        let selectedFiles = [];
        let fileToDelete = null;
        let userToDelete = null;

        // Initialize the application
        function init() {
          console.log('Initializing admin dashboard...');

          // Check for existing authentication
          checkExistingAuth();

          // Set up event listeners
          setupEventListeners();
        }

        // Check for existing authentication
        function checkExistingAuth() {
          const rememberMe = localStorage.getItem(STORAGE_KEYS.REMEMBER_ME) === 'true';
          const storage = rememberMe ? localStorage : sessionStorage;

          const token = storage.getItem(STORAGE_KEYS.ADMIN_TOKEN);
          const user = storage.getItem(STORAGE_KEYS.ADMIN_USER);

          if (token && user) {
            try {
              adminToken = token;
              adminUser = JSON.parse(user);

              // Validate token by making a test API call
              validateToken().then(isValid => {
                if (isValid) {
                  showDashboard();
                } else {
                  clearAuth();
                  showLogin();
                }
              }).catch(() => {
                clearAuth();
                showLogin();
              });
            } catch (error) {
              console.error('Error parsing stored user data:', error);
              clearAuth();
              showLogin();
            }
          } else {
            showLogin();
          }
        }

        // Validate token by making a test API call
        async function validateToken() {
          try {
            const response = await fetch('/admin/users', {
              headers: {
                'x-api-key': adminToken,
              },
            });

            return response.ok;
          } catch (error) {
            console.error('Token validation error:', error);
            return false;
          }
        }

        // Store authentication data
        function storeAuth(token, user, rememberMe) {
          const storage = rememberMe ? localStorage : sessionStorage;

          storage.setItem(STORAGE_KEYS.ADMIN_TOKEN, token);
          storage.setItem(STORAGE_KEYS.ADMIN_USER, JSON.stringify(user));
          localStorage.setItem(STORAGE_KEYS.REMEMBER_ME, rememberMe.toString());

          adminToken = token;
          adminUser = user;
        }

        // Clear authentication data
        function clearAuth() {
          localStorage.removeItem(STORAGE_KEYS.ADMIN_TOKEN);
          localStorage.removeItem(STORAGE_KEYS.ADMIN_USER);
          localStorage.removeItem(STORAGE_KEYS.REMEMBER_ME);
          sessionStorage.removeItem(STORAGE_KEYS.ADMIN_TOKEN);
          sessionStorage.removeItem(STORAGE_KEYS.ADMIN_USER);

          adminToken = '';
          adminUser = null;
        }

        // Show login form
        function showLogin() {
          document.getElementById('login-section').classList.remove('hidden');
          document.getElementById('dashboard-section').classList.add('hidden');
          const adminUserInfo = document.getElementById('admin-user-info');
          if (adminUserInfo) {
            adminUserInfo.textContent = '';
          }
          // Hide logout button
          const logoutBtn = document.getElementById('logout-btn');
          if (logoutBtn) {
            logoutBtn.classList.add('hidden');
          }
        }

        // Show dashboard
        function showDashboard() {
          document.getElementById('login-section').classList.add('hidden');
          document.getElementById('dashboard-section').classList.remove('hidden');

          // Update admin user info in header
          const adminUserInfo = document.getElementById('admin-user-info');
          if (adminUserInfo && adminUser) {
            adminUserInfo.textContent = adminUser.first_name + ' ' + adminUser.last_name;
          }

          // Show logout button
          const logoutBtn = document.getElementById('logout-btn');
          if (logoutBtn) {
            logoutBtn.classList.remove('hidden');
          }

          showDashboardPage();
        }

        // Show dashboard page
        function showDashboardPage() {
          document.getElementById('dashboard-page').classList.remove('hidden');
          document.getElementById('user-details-page').classList.add('hidden');
          selectedUserId = '';
          selectedUser = null;
          loadUsers();
        }

        // Show user details page
        function showUserDetailsPage(user) {
          selectedUser = user;
          selectedUserId = user.id;

          // Update user details
          document.getElementById('user-details-name').textContent = user.first_name + ' ' + user.last_name;
          document.getElementById('user-details-email').textContent = user.email;

          const roleElement = document.getElementById('user-details-role');
          roleElement.textContent = user.role;
          roleElement.className = 'px-3 py-1 text-sm font-medium rounded-full ' +
            (user.role === 'ADMIN' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800');

          // Hide dashboard page and show user details page
          document.getElementById('dashboard-page').classList.add('hidden');
          document.getElementById('user-details-page').classList.remove('hidden');

          // Load user files and stats
          loadUserFiles();
        }

        // Modal functions
        function showModal(modalId) {
          document.getElementById(modalId).classList.add('show');
        }

        function hideModal(modalId) {
          document.getElementById(modalId).classList.remove('show');
        }

        // Set up all event listeners
        function setupEventListeners() {
          // Login form
          const loginForm = document.getElementById('login-form');
          if (loginForm) {
            loginForm.addEventListener('submit', handleLogin);
          }

          // Logout button
          const logoutBtn = document.getElementById('logout-btn');
          if (logoutBtn) {
            logoutBtn.addEventListener('click', handleLogout);
          }

          // User search
          const searchBtn = document.getElementById('search-btn');
          if (searchBtn) {
            searchBtn.addEventListener('click', loadUsers);
          }

          const userSearch = document.getElementById('user-search');
          if (userSearch) {
            userSearch.addEventListener('keypress', (e) => {
              if (e.key === 'Enter') {
                loadUsers();
              }
            });
          }

          // Upload files button
          const uploadFilesBtn = document.getElementById('upload-files-btn');
          if (uploadFilesBtn) {
            uploadFilesBtn.addEventListener('click', () => {
              if (selectedUserId) {
                showUploadModal();
              } else {
                showError('login-error', 'Please select a user first');
              }
            });
          }

          // Back to dashboard button
          const backToDashboardBtn = document.getElementById('back-to-dashboard');
          if (backToDashboardBtn) {
            backToDashboardBtn.addEventListener('click', showDashboardPage);
          }

          // Modal close buttons
          const closeUploadModal = document.getElementById('close-upload-modal');
          if (closeUploadModal) {
            closeUploadModal.addEventListener('click', () => hideModal('upload-modal'));
          }

          const closeDeleteModal = document.getElementById('close-delete-modal');
          if (closeDeleteModal) {
            closeDeleteModal.addEventListener('click', () => hideModal('delete-modal'));
          }

          // Cancel buttons
          const cancelUploadBtn = document.getElementById('cancel-upload-btn');
          if (cancelUploadBtn) {
            cancelUploadBtn.addEventListener('click', () => hideModal('upload-modal'));
          }

          const cancelDeleteBtn = document.getElementById('cancel-delete-btn');
          if (cancelDeleteBtn) {
            cancelDeleteBtn.addEventListener('click', () => hideModal('delete-modal'));
          }

          // Confirm delete button
          const confirmDeleteBtn = document.getElementById('confirm-delete-btn');
          if (confirmDeleteBtn) {
            confirmDeleteBtn.addEventListener('click', handleDeleteFile);
          }

          // Delete user modal buttons
          const closeDeleteUserModal = document.getElementById('close-delete-user-modal');
          if (closeDeleteUserModal) {
            closeDeleteUserModal.addEventListener('click', () => hideModal('delete-user-modal'));
          }

          const cancelDeleteUserBtn = document.getElementById('cancel-delete-user-btn');
          if (cancelDeleteUserBtn) {
            cancelDeleteUserBtn.addEventListener('click', () => hideModal('delete-user-modal'));
          }

          const confirmDeleteUserBtn = document.getElementById('confirm-delete-user-btn');
          if (confirmDeleteUserBtn) {
            confirmDeleteUserBtn.addEventListener('click', handleDeleteUser);
          }

          // File upload
          setupFileUploadListeners();

          // Upload form
          const uploadForm = document.getElementById('upload-form');
          if (uploadForm) {
            uploadForm.addEventListener('submit', handleFileUpload);
          }

          // Checkbox toggles (only one can be selected at a time)
          const pnoeToggle = document.getElementById('pnoe-data-toggle');
          const vo2MasterToggle = document.getElementById('vo2-master-toggle');
          
          if (pnoeToggle && vo2MasterToggle) {
            pnoeToggle.addEventListener('change', function() {
              if (this.checked) {
                vo2MasterToggle.checked = false;
              }
            });
            
            vo2MasterToggle.addEventListener('change', function() {
              if (this.checked) {
                pnoeToggle.checked = false;
              }
            });
          }

          // Close modals when clicking outside
          window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
              e.target.classList.remove('show');
            }
          });

          // Mobile sidebar toggle
          const sidebarToggle = document.getElementById('sidebar-toggle');
          const sidebar = document.querySelector('aside');
          if (sidebarToggle && sidebar) {
            sidebarToggle.addEventListener('click', () => {
              sidebar.classList.toggle('hidden');
            });
          }
        }

        // Show upload modal
        function showUploadModal() {
          // Reset form
          document.getElementById('upload-form').reset();
          selectedFiles = [];
          displaySelectedFiles();
          updateUploadButton();

          // Update user info
          const userInfo = document.getElementById('selected-user-info');
          if (userInfo) {
            const user = adminUser; // This should be the selected user, but for now using admin user
            userInfo.textContent = user.first_name + ' ' + user.last_name + ' (' + user.email + ')';
          }

          showModal('upload-modal');
        }

        // Handle login
        async function handleLogin(e) {
          e.preventDefault();
          const formData = new FormData(e.target);
          const email = formData.get('email');
          const password = formData.get('password');
          const rememberMe = document.getElementById('remember-me').checked;

          console.log('Attempting login for:', email);

          try {
            const response = await fetch('/admin/sign-in', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ email, password }),
            });

            const data = await response.json();
            console.log('Login response:', response.status, data);

            if (response.ok) {
              storeAuth(data.token, data.user, rememberMe);
              showDashboard();
            } else {
              showError('login-error', data.message || 'Login failed');
            }
          } catch (error) {
            console.error('Login error:', error);
            showError('login-error', 'Network error. Please try again.');
          }
        }

        // Handle logout
        function handleLogout() {
          clearAuth();
          showLogin();

          // Clear form
          document.getElementById('login-form').reset();

          // Clear any error messages
          hideError('login-error');
          hideError('upload-error');
          hideError('upload-success');
        }

        // Load users
        async function loadUsers() {
          const searchQuery = document.getElementById('user-search').value;
          const url = searchQuery
            ? '/admin/users/search?query=' + encodeURIComponent(searchQuery)
            : '/admin/users';

          try {
            const response = await fetch(url, {
              headers: {
                'x-api-key': adminToken,
              },
            });

            const data = await response.json();

            if (response.ok) {
              displayUsers(data.users || data.users);
            } else {
              if (response.status === 401) {
                // Token expired or invalid
                clearAuth();
                showLogin();
                showError('login-error', 'Session expired. Please login again.');
              } else {
                showError('login-error', data.message || 'Failed to load users');
              }
            }
          } catch (error) {
            showError('login-error', 'Network error. Please try again.');
          }
        }

        // Display users
        function displayUsers(users) {
          const usersList = document.getElementById('users-list');
          const usersCount = document.getElementById('users-count');
          usersList.innerHTML = '';

          // Update users count
          if (usersCount) {
            usersCount.textContent = users.length + ' user' + (users.length !== 1 ? 's' : '') + ' found';
          }

          if (users.length === 0) {
            usersList.innerHTML = '<div class="text-center py-12"><svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg><p class="mt-2 text-gray-500">No users found</p></div>';
            return;
          }

          users.forEach(user => {
            const userDiv = document.createElement('div');
            userDiv.className = 'p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-blue-50 hover:border-blue-300 transition-all duration-200 mb-3';
            userDiv.innerHTML =
              '<div class="flex items-center justify-between">' +
                '<div class="flex items-center space-x-3">' +
                  '<div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">' +
                    '<svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">' +
                      '<path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />' +
                    '</svg>' +
                  '</div>' +
                  '<div>' +
                    '<div class="font-semibold text-gray-900">' + user.first_name + ' ' + user.last_name + '</div>' +
                    '<div class="text-sm text-gray-600">' + user.email + '</div>' +
                  '</div>' +
                '</div>' +
                '<div class="flex items-center space-x-2">' +
                  '<span class="px-2 py-1 text-xs font-medium rounded-full ' +
                    (user.role === 'ADMIN' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800') +
                    '">' + user.role + '</span>' +
                  (user.role !== 'ADMIN' ? 
                    '<button ' +
                      'data-user-id="' + user.id + '"' +
                      'data-user-name="' + user.first_name + ' ' + user.last_name + '"' +
                      'class="inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors delete-user-btn"' +
                      'onclick="event.stopPropagation()"' +
                    '>' +
                      '<svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>' +
                      'Delete' +
                    '</button>' : '') +
                  '<svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">' +
                    '<path d="M9 5l7 7-7 7" />' +
                  '</svg>' +
                '</div>' +
              '</div>';

            userDiv.addEventListener('click', () => showUserDetailsPage(user));
            usersList.appendChild(userDiv);
          });

          // Add event listeners to delete user buttons
          document.querySelectorAll('.delete-user-btn').forEach(button => {
            button.addEventListener('click', function(e) {
              e.stopPropagation();
              const userId = this.getAttribute('data-user-id');
              const userName = this.getAttribute('data-user-name');
              showDeleteUserModal(userId, userName);
            });
          });
        }

        // Select user (kept for backward compatibility)
        function selectUser(user) {
          showUserDetailsPage(user);
        }

        // Set up file upload listeners
        function setupFileUploadListeners() {
          const fileDropZone = document.getElementById('file-drop-zone');
          const fileInput = document.getElementById('file-input');

          if (fileDropZone) {
            fileDropZone.addEventListener('click', () => fileInput.click());
            fileDropZone.addEventListener('dragover', (e) => {
              e.preventDefault();
              fileDropZone.classList.add('dragover');
            });
            fileDropZone.addEventListener('dragleave', () => {
              fileDropZone.classList.remove('dragover');
            });
            fileDropZone.addEventListener('drop', (e) => {
              e.preventDefault();
              fileDropZone.classList.remove('dragover');
              handleFiles(e.dataTransfer.files);
            });
          }

          if (fileInput) {
            fileInput.addEventListener('change', (e) => {
              handleFiles(e.target.files);
            });
          }
        }

        // Handle file selection
        function handleFiles(files) {
          selectedFiles = Array.from(files);
          displaySelectedFiles();
          updateUploadButton();
        }

        // Display selected files
        function displaySelectedFiles() {
          const container = document.getElementById('selected-files');
          container.innerHTML = '';

          selectedFiles.forEach((file, index) => {
            const fileDiv = document.createElement('div');
            fileDiv.className = 'file-item flex items-center justify-between p-3 bg-gray-50 rounded-md';
            fileDiv.innerHTML =
              '<div class="flex items-center space-x-3">' +
                '<svg class="h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">' +
                  '<path fill-rule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" clip-rule="evenodd" />' +
                '</svg>' +
                '<div>' +
                  '<div class="font-medium text-sm">' + file.name + '</div>' +
                  '<div class="text-xs text-gray-500">' + formatFileSize(file.size) + '</div>' +
                '</div>' +
              '</div>' +
              '<button ' +
                'type="button" ' +
                'data-file-index="' + index + '"' +
                'class="text-red-500 hover:text-red-700 text-sm remove-file-btn"' +
              '>' +
                'Remove' +
              '</button>';
            container.appendChild(fileDiv);
          });

          // Add event listeners to remove buttons
          document.querySelectorAll('.remove-file-btn').forEach(button => {
            button.addEventListener('click', function() {
              const index = parseInt(this.getAttribute('data-file-index'));
              removeFile(index);
            });
          });
        }

        // Remove file
        function removeFile(index) {
          selectedFiles.splice(index, 1);
          displaySelectedFiles();
          updateUploadButton();
        }

        // Update upload button state
        function updateUploadButton() {
          const uploadBtn = document.getElementById('upload-btn');
          if (uploadBtn) {
            uploadBtn.disabled = selectedFiles.length === 0;
          }
        }

        // Format file size
        function formatFileSize(bytes) {
          if (bytes === 0) return '0 Bytes';
          const k = 1024;
          const sizes = ['Bytes', 'KB', 'MB', 'GB'];
          const i = Math.floor(Math.log(bytes) / Math.log(k));
          return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        // Handle file upload
        async function handleFileUpload(e) {
          e.preventDefault();

          if (selectedFiles.length === 0) {
            showError('upload-error', 'Please select files to upload');
            return;
          }

          const formData = new FormData();
          formData.append('userId', selectedUserId);

          const description = document.getElementById('description').value;
          if (description) {
            formData.append('description', description);
          }

          const isPnoeData = document.getElementById('pnoe-data-toggle').checked;
          const isVo2MasterData = document.getElementById('vo2-master-toggle').checked;

          selectedFiles.forEach(file => {
            if (isPnoeData) {
              // Create a new file with the name 'pnoe.csv'
              const renamedFile = new File([file], 'pnoe.csv', { type: file.type });
              formData.append('files', renamedFile);
            } else if (isVo2MasterData) {
              // Create a new file with the name 'vo2_master.csv'
              const renamedFile = new File([file], 'vo2_master.csv', { type: file.type });
              formData.append('files', renamedFile);
            } else {
              formData.append('files', file);
            }
          });

          const uploadBtn = document.getElementById('upload-btn');
          uploadBtn.disabled = true;
          uploadBtn.textContent = 'Uploading...';

          try {
            const response = await fetch('/admin/upload-files', {
              method: 'POST',
              headers: {
                'x-api-key': adminToken,
              },
              body: formData,
            });

            const data = await response.json();

            if (response.ok) {
              showSuccess('upload-success', 'Successfully uploaded ' + data.files.length + ' file(s)');
              hideModal('upload-modal');
              loadUserFiles();
            } else {
              if (response.status === 401) {
                // Token expired or invalid
                clearAuth();
                showLogin();
                showError('login-error', 'Session expired. Please login again.');
              } else {
                showError('upload-error', data.message || 'Upload failed');
              }
            }
          } catch (error) {
            showError('upload-error', 'Network error. Please try again.');
          } finally {
            uploadBtn.disabled = false;
            uploadBtn.textContent = 'Upload Files';
          }
        }

        // Load user files
        async function loadUserFiles() {
          if (!selectedUserId) return;

          try {
            const response = await fetch('/admin/user/' + selectedUserId + '/files', {
              headers: {
                'x-api-key': adminToken,
              },
            });

            const data = await response.json();

            if (response.ok) {
              displayUserFiles(data.files);
              updateUserStats(data.files, selectedUser);
            } else {
              if (response.status === 401) {
                // Token expired or invalid
                clearAuth();
                showLogin();
                showError('login-error', 'Session expired. Please login again.');
              } else {
                console.error('Failed to load user files:', data.message);
              }
            }
          } catch (error) {
            console.error('Network error loading user files:', error);
          }
        }

        // Update user statistics
        function updateUserStats(files, userData) {
          const filesCount = document.getElementById('user-files-count');
          const totalSize = document.getElementById('user-total-size');
          const lastActive = document.getElementById('user-last-active');

          if (filesCount) {
            filesCount.textContent = files.length;
          }

          if (totalSize) {
            const totalBytes = files.reduce((sum, file) => sum + file.fileSize, 0);
            totalSize.textContent = formatFileSize(totalBytes);
          }

          if (lastActive && userData && userData.lastActiveAt) {
            const date = new Date(userData.lastActiveAt);
            lastActive.textContent = date.toLocaleDateString();
          } else if (lastActive) {
            lastActive.textContent = 'Never';
          }
        }

        // Display user files
        function displayUserFiles(files) {
          const container = document.getElementById('user-files-list');
          container.innerHTML = '';

          if (files.length === 0) {
            container.innerHTML = '<div class="text-center py-12"><svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg><p class="mt-2 text-gray-500">No files uploaded yet</p></div>';
            return;
          }

          files.forEach(file => {
            const fileDiv = document.createElement('div');
            fileDiv.className = 'file-item flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-all duration-200 mb-3';
            fileDiv.innerHTML =
              '<div class="flex items-center space-x-4">' +
                '<div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">' +
                  '<svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">' +
                    '<path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />' +
                  '</svg>' +
                '</div>' +
                '<div class="flex-1">' +
                  '<div class="font-semibold text-gray-900 text-sm">' + file.fileName + '</div>' +
                  '<div class="text-xs text-gray-500 mt-1">' + formatFileSize(file.fileSize) + ' • ' + new Date(file.createdAt).toLocaleDateString() + '</div>' +
                  (file.description ? '<div class="text-xs text-gray-600 mt-1">' + file.description + '</div>' : '') +
                '</div>' +
              '</div>' +
              '<div class="flex items-center space-x-2">' +
                '<button ' +
                  'data-file-id="' + file.id + '"' +
                  'class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors view-file-btn"' +
                '>' +
                  '<svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>' +
                  'View' +
                '</button>' +
                '<button ' +
                  'data-file-id="' + file.id + '"' +
                  'data-file-name="' + file.fileName + '"' +
                  'class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors delete-file-btn"' +
                '>' +
                  '<svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>' +
                  'Delete' +
                '</button>' +
              '</div>';
            container.appendChild(fileDiv);
          });

          // Add event listeners to view buttons
          document.querySelectorAll('.view-file-btn').forEach(button => {
            button.addEventListener('click', function() {
              const fileId = this.getAttribute('data-file-id');
              getSignedUrl(fileId);
            });
          });

          // Add event listeners to delete buttons
          document.querySelectorAll('.delete-file-btn').forEach(button => {
            button.addEventListener('click', function() {
              const fileId = this.getAttribute('data-file-id');
              const fileName = this.getAttribute('data-file-name');
              showDeleteModal(fileId, fileName);
            });
          });
        }

        // Show delete confirmation modal
        function showDeleteModal(fileId, fileName) {
          fileToDelete = { id: fileId, name: fileName };
          showModal('delete-modal');
        }

        // Handle file deletion
        async function handleDeleteFile() {
          if (!fileToDelete) return;

          const deleteBtn = document.getElementById('confirm-delete-btn');
          deleteBtn.disabled = true;
          deleteBtn.textContent = 'Deleting...';

          try {
            const response = await fetch('/admin/file/' + fileToDelete.id, {
              method: 'DELETE',
              headers: {
                'x-api-key': adminToken,
              },
            });

            if (response.ok) {
              hideModal('delete-modal');
              loadUserFiles();
              showSuccess('upload-success', 'File deleted successfully');
            } else {
              const data = await response.json();
              if (response.status === 401) {
                // Token expired or invalid
                clearAuth();
                showLogin();
                showError('login-error', 'Session expired. Please login again.');
              } else {
                showError('upload-error', data.message || 'Failed to delete file');
              }
            }
          } catch (error) {
            showError('upload-error', 'Network error. Please try again.');
          } finally {
            deleteBtn.disabled = false;
            deleteBtn.textContent = 'Delete';
            fileToDelete = null;
          }
        }

        // Get signed URL for file
        async function getSignedUrl(fileId) {
          try {
            const response = await fetch('/admin/file/' + fileId + '/signed-url?expiresIn=3600', {
              headers: {
                'x-api-key': adminToken,
              },
            });

            const data = await response.json();

            if (response.ok) {
              // Open the signed URL in a new tab
              window.open(data.signedUrl, '_blank');
            } else {
              if (response.status === 401) {
                // Token expired or invalid
                clearAuth();
                showLogin();
                showError('login-error', 'Session expired. Please login again.');
              } else {
                showError('upload-error', data.message || 'Failed to generate signed URL');
              }
            }
          } catch (error) {
            showError('upload-error', 'Network error. Please try again.');
          }
        }

        // Show error message
        function showError(elementId, message) {
          const element = document.getElementById(elementId);
          if (element) {
            element.textContent = message;
            element.classList.remove('hidden');
            setTimeout(() => element.classList.add('hidden'), 5000);
          }
        }

        // Hide error message
        function hideError(elementId) {
          const element = document.getElementById(elementId);
          if (element) {
            element.classList.add('hidden');
          }
        }

        // Show success message
        function showSuccess(elementId, message) {
          const element = document.getElementById(elementId);
          if (element) {
            element.textContent = message;
            element.classList.remove('hidden');
            setTimeout(() => element.classList.add('hidden'), 5000);
          }
        }

        // Show delete user confirmation modal
        function showDeleteUserModal(userId, userName) {
          userToDelete = { id: userId, name: userName };
          document.getElementById('delete-user-name').textContent = userName;
          showModal('delete-user-modal');
        }

        // Handle user deletion
        async function handleDeleteUser() {
          if (!userToDelete) return;

          const deleteBtn = document.getElementById('confirm-delete-user-btn');
          deleteBtn.disabled = true;
          deleteBtn.textContent = 'Deleting...';

          try {
            const response = await fetch('/admin/user/' + userToDelete.id, {
              method: 'DELETE',
              headers: {
                'x-api-key': adminToken,
              },
            });

            if (response.ok) {
              hideModal('delete-user-modal');
              loadUsers();
              showSuccess('login-error', 'User deleted successfully');
            } else {
              const data = await response.json();
              if (response.status === 401) {
                // Token expired or invalid
                clearAuth();
                showLogin();
                showError('login-error', 'Session expired. Please login again.');
              } else {
                showError('login-error', data.cause || 'Failed to delete user');
                hideModal('delete-user-modal');
              }
            }
          } catch (error) {
            showError('login-error', 'Network error. Please try again.');
            hideModal('delete-user-modal');
          } finally {
            deleteBtn.disabled = false;
            deleteBtn.textContent = 'Delete User';
            userToDelete = null;
          }
        }

        // Initialize when DOM is loaded
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', init);
        } else {
          init();
        }
      </script>
    </body>
    </html>
  `;
}
