export default function AdminDashboard(): string {
	return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Admin Dashboard</title>
      <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-gray-50 min-h-screen">
      <div class="container mx-auto px-4 py-8">
        <div class="text-center mb-8">
          <h1 class="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
          <p class="text-gray-600">Welcome to the admin dashboard</p>
        </div>
        
        <div class="max-w-md mx-auto bg-white rounded-lg shadow-md p-6">
          <h2 class="text-xl font-semibold mb-4">Quick Links</h2>
          <div class="space-y-3">
            <a 
              href="/admin-jsx" 
              class="block w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors text-center"
            >
              Go to File Upload Dashboard
            </a>
            <a 
              href="/docs" 
              class="block w-full bg-gray-600 text-white py-2 px-4 rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors text-center"
            >
              API Documentation
            </a>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
}
