export type FormType = "none" | "login" | "signup" | "forgot-password";
